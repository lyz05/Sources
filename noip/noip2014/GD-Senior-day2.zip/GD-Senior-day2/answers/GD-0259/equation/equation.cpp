#include <fstream>
#include <cstring>
#include <string.h>
#include <algorithm>
using namespace std;

ifstream fin("equation.in");
ofstream fout("equation.out");

long n, m;
long long a[101];
bool f[101];
void init()
{
	fin>>n>>m;
	for (long i=0; i<=n; i++) fin>>a[i];
}
void work(){
	
	long long ans=0;
	long num=0;
	for (long i=0; i<=n; i++) f[i]=false;
	for (long i=1; i<=m; i++)
	{
		long long  x=1;
	    for (long j=0; j<=n; j++)
		{
			ans+=a[j]*x;
			x=x*i;
		}
		if (ans==0) {
		  f[i]=true;
	      num++; 
	   }
			
	}
	fout<<num<<endl;
	for (long i=1; i<=m; i++) 
	   if (f[i]) fout<<i<<endl;
}
int main(){
	init();
	work();
	fin.close();
	fout.close();
	return 0;
}
