#include <fstream>
#include <cstring>
#include <algorithm>
using namespace std;

ifstream fin("wireless.in");
ofstream fout("wireless.out");

long d, n,x, y, k;
long a[150][150];
void init(){
	fin>>d>>n;
	memset(a, 0, sizeof(a));
	for (long i=1; i<=n; i++)
	{
		fin>>x>>y>>k;
		a[x][y]=k;
	}
    
}

void work(){
	long long ans, maxx=-1;
	long num=0;
	for (long i=0; i<=128; i++)
	   for (long j=0; j<=128; j++)
	   {
	   	   ans=0;
	   	   for (long k=i-d; k<=i+d; k++)
	   	      for (long p=j-d; p<=j+d; p++)
	   	         if (k>=0&&k<=128&&p>=0&&p<=128)
	   	         ans+=a[k][p];
	   	   if (ans==maxx) num++;  
	   	   if (ans>maxx){
	   	   	   num=1;
	   	   	   maxx=ans;
	   	   }  
		     
	   }
	fout<<num<<" "<<maxx<<endl;
}
int main(){
	init();
	work();
	fin.close();
	fout.close();
	return 0;
}
