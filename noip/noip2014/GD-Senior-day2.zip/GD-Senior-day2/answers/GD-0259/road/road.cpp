#include <fstream>
#include <cstring>
#include <algorithm>
using namespace std;

ifstream fin("road.in");
ofstream fout("road.out");


int main(){
	//init();
	fout<<-1<<endl;
	fin.close();
	fout.close();
	return 0;
}
