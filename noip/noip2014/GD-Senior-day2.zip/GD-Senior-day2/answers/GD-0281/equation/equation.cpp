#include<cstdio>
#include<cstring>
#include<cmath>
#include<vector>
#include<algorithm>
using namespace std;

const int mlen=10710;
const int maxn=110;

struct bigint
{
	char num[mlen];
	int len;
	int sig;
	bigint()
	{
		memset(num,0,sizeof(num));
		len=0;
		sig=1;
	}
};

void print(bigint a)
{
	if(a.len==0)
	{
		printf("0");
		return;		
	}
	if(a.sig==-1)
		printf("-");
	for(int i=a.len;i>=1;i--)
		printf("%d",a.num[i]);

}

bigint scan(char ch[])
{
	bigint a;
	int len=strlen(ch);
	a.len=len;
	if(ch[0]=='-')
	{
		a.sig=-1;
		a.len--;
	}
	for(int i=1;i<=a.len;i++)
	{
		a.num[i]=ch[len-i]-'0';
	}
	return a;
}

bool operator < (const bigint &a,const bigint &b)
{
	if(a.len<b.len)
		return true;
	else if(a.len>b.len)
		return false;
	else if(a.len==b.len)
	{
		for(int i=1;i<=a.len;i++)
		{
			if(a.num[i]<b.num[i])
				return true;
			else if(a.num[i]>b.num[i])
				return false;
		}
		return false;
	}
}
bool operator > (const bigint &a,const bigint &b)
{
	return b<a;
}

bigint operator * (const bigint &a,const int &b) //bigint * integer
{
	bigint c;
	int d=abs(b);
	if(b*a.sig>0)
		c.sig=1;
	else if(b*a.sig<0)
		c.sig=-1;
	else if(b==0)
	{
		c.sig=1;
		return c;
	}
	c.len=a.len;
	
	for(int i=1;i<=a.len;i++)
	{
		c.num[i]+=a.num[i]*d;
		c.num[i+1]=c.num[i]/10;
		c.num[i]=c.num[i]%10;
	}
	if(c.num[c.len+1]>0)
	{
		c.len++;
	}
	return c;
}

bigint operator * (const bigint &a,const bigint &b)
{
	bigint c;
	c.sig=a.sig*b.sig;
	c.len=a.len+b.len;
	for(int i=1;i<=a.len;i++)
	{
		for(int j=1;j<=b.len;j++)
		{
			c.num[i+j-1]+=a.num[i]*b.num[j];
			c.num[i+j]+=c.num[i+j-1]/10;
			c.num[i+j-1]%=10;
		}		
	}
	
	while(c.num[c.len]==0)
		c.len--;
	return c;
}

bigint operator - (const bigint &d,const bigint &e)
{
	bigint c;
	bigint a=d,b=e;
	c.len=max(a.len,b.len);
	if(a>b)
		c.sig=1;
	else if(a<b)
	{
		c.sig=-1;
		swap(a,b);		
	}
	else
	{
		c.len=0;
		c.sig=1;
		return c;
	}
	
	for(int i=1;i<=c.len;i++)
	{
		c.num[i]+=a.num[i]-b.num[i];
		if(c.num[i]<0)
		{
			c.num[i]+=10;
			c.num[i+1]--;
		}
	}
	while(c.num[c.len]==0)
	{
		c.len--;
	}
	c.num[c.len]=abs(c.num[c.len]);
	return c;
}

bigint operator + (const bigint &a,const bigint &b)
{
	bigint c;
	if(a.sig==-1&&b.sig==1)
	{
		return b-a;
	}
	else if(a.sig==1&&b.sig==-1)
	{
		return a-b;
	}
		
	c.len=max(a.len,b.len);
	for(int i=1;i<=c.len;i++)
	{
		c.num[i]+=a.num[i]+b.num[i];
		c.num[i+1]=c.num[i]/10;
		c.num[i]=c.num[i]%10;
	}
	if(c.num[c.len]>0)
		c.len++;
	return c;
}

bigint scan (int b)
{
	bigint c;
	int d=b;
	c.len=0;
	if(b<0)
		c.sig=-1;
	d=abs(d);
	
	while(d>0)
	{
		c.len++;
		c.num[c.len]=d%10;
		d/=10;
	}
	return c;
}

bigint a[maxn];

int main(void)
{
	int n,m;
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	
	int k1=0;
	int k2=0;
	scanf("%d%d",&n,&m);
	char ch[mlen];
	for(int i=0;i<=n;i++)
	{
		scanf("%s",ch);
		a[i]=scan(ch);
		if(ch[0]=='-')
			k2++;
		else if(strlen(ch)==0)
			k1++,k2++;
		else
			k1++;
	}
	if(k1==n+1||k2==n+1)
	{
		printf("0\n");
		return 0;
	}
	
	int sum=0;
	vector<int> g;
	for(int x=1;x<=m;x++)
	{
		bigint s=a[n];
		for(int i=n-1;i>=0;i--)
		{
			s=s*x+a[i];
		}
		
		if(s.len==0)
		{
			sum++;
			g.push_back(x);
		}
	}
	printf("%d\n",sum);
	for(int i=0;i<g.size();i++)
	{
		printf("%d\n",g[i]);
	}
	
	return 0;
}
