#include<cstdio>
#include<cstring>
#include<vector>
#include<queue>
#include<algorithm>
#define INF 100000000
const int maxn=10010;

using namespace std;

struct Edge
{
	int from,to,d;
};

struct HeapNode
{
	int u,d;
	bool operator < (const HeapNode &rhs) const
	{
		return d<rhs.d;
	}
};

int n,m;
vector<int> G[maxn];
vector<int> fG[maxn];
vector<Edge> edges;
int d[maxn];
bool lt[maxn];

void dijkstra(int s)
{
	bool done[maxn];
	priority_queue<HeapNode> Q;
	
	memset(done,0,sizeof(done));
	for(int i=1;i<=n;i++)
		d[i]=INF;
	d[s]=0;
	Q.push((HeapNode){s,0});
	
	while(!Q.empty())
	{
		HeapNode x=Q.top(); Q.pop();
		int u=x.u;
		if(done[u]==true)
			continue;
		done[u]=true;
		
		for(int i=0;i<G[u].size();i++)
		{
			Edge e=edges[G[u][i]];
			if(d[e.to]>d[u]+e.d&&lt[e.to]==true)
			{
				d[e.to]=d[u]+e.d;
				Q.push((HeapNode){e.to,d[e.to]});
			}
		}
	}
}

void bfs(int s)
{
	bool done[maxn];
	queue<int> Q;

	memset(lt,false,sizeof(lt));
	lt[s]=true;
	Q.push(s);
	
	while(!Q.empty())
	{
		int x=Q.front(); Q.pop();
		
		for(int i=0;i<fG[x].size();i++)
		{
			Edge e=edges[fG[x][i]];
			if(lt[e.from]==false)
			{
				lt[e.from]=true;
				Q.push(e.from);
			}
		}
	}
}

int main(void)
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int x,y;
	int k;
	int s,t;
	
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&x,&y);
		if(x==y)
			continue;
		else 
		{
			k=edges.size();
			G[x].push_back(k);
			fG[y].push_back(k);
			edges.push_back((Edge){x,y,1});	
		}
	}
	scanf("%d%d",&s,&t);
	bfs(t);
	for(int i=1;i<=n;i++)//spread
	{
		if(lt[i]==false)
		{
			for(int j=0;j<fG[i].size();j++)
			{
				Edge e=edges[fG[i][j]];
				if(lt[e.from]==true)
					lt[e.from]=false;
			}
		}
	}

	if(lt[s]==false)
	{
		printf("-1\n");
		return 0;
	}
	dijkstra(s);
	if(d[t]==INF)
		d[t]=-1;
	printf("%d\n",d[t]);
	
	return 0;
}
