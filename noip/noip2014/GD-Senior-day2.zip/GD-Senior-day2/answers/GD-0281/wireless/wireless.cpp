#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;

const int maxn=150;
int n,d;
int gra[maxn][maxn];
int main(void)
{
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	memset(gra,0,sizeof(gra));
	int x,y,k;
	scanf("%d",&d);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d%d",&x,&y,&k);
		int ux,uy,lx,ly;
		ux=x+d,uy=y+d,lx=x-d,ly=y-d;
		if(ux>128)
			ux=128;
		if(uy>128)
			uy=128;
		if(lx<0)
			lx=0;
		if(ly<0)
			ly=0;
		for(int a=lx;a<=ux;a++)
		{
			for(int b=ly;b<=uy;b++)
			{
				gra[a][b]+=k;
			}
		}
	}
	
	int sum=0,nmax=0;
	for(int i=0;i<=128;i++)
	{
		for(int j=0;j<=128;j++)
		{
			if(nmax<gra[i][j])
			{
				nmax=gra[i][j];
				sum=1;
			}
			else if(nmax==gra[i][j])
			{
				sum++;
			}
		}
	}
	
	printf("%d %d\n",sum,nmax);
	return 0;
}
