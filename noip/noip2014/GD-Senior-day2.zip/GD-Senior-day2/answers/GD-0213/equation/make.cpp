#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<vector>
#include<ctime>
#include<string>
#include<set>
#include<map>
#include<queue>
#define rep(i,x,y) for(i=x;i<=y;i++)
#define reps(i,x,y) for(i=x;i>=y;i--)
#define INF 0x5fffffff
#define MP make_pair
#define PB push_back
using namespace std;
typedef long long LL;
typedef double DB;
typedef unsigned long long ull;
typedef vector<int> VI;
int a[110];
int main(){
//	freopen(".in","r",stdin);
	freopen("equation.in","w",stdout);
	//init();
//	solve();
	srand(time(0));
	int n=5,m=100;
	printf("%d %d\n",n,m);
	int i;
	int ans=rand()%20+1;
	LL tmp=0,v1=ans;
	rep(i,1,n){
		int val=rand()%101-50;
		if(i==n&&!val)val++;
		a[i]=val;
		tmp+=a[i]*v1;
		v1*=ans;
	}
	cout<<-tmp;
	rep(i,1,n)printf(" %d",a[i]);
	puts("");
	return 0;
}
