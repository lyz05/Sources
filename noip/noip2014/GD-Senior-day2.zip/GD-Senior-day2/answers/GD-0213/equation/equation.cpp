#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<vector>
#include<ctime>
#include<string>
#include<set>
#include<map>
#include<queue>
#define rep(i,x,y) for(i=x;i<=y;i++)
#define reps(i,x,y) for(i=x;i>=y;i--)
#define INF 0x5fffffff
#define MP make_pair
#define PB push_back
using namespace std;
typedef long long LL;
typedef double DB;
typedef unsigned long long ull;
typedef vector<int> VI;
struct node{
	int s[130];
	int f;
	node(){
		memset(s,0,sizeof(s));
		s[0]=1;f=0;
	}
}a[110];
bool operator ==(const node &A,const node &B){
	if(A.s[0]!=B.s[0])return 0;
	int i;
	rep(i,1,A.s[0])
		if(A.s[i]!=B.s[i])return 0;
	return 1;
}
node operator *(const node &A,int val){
	int i;
	node ret;
	rep(i,1,A.s[0])ret.s[i]=A.s[i]*val;
	ret.s[0]=A.s[0];
	rep(i,1,ret.s[0]){
		ret.s[i+1]+=ret.s[i]/10;
		ret.s[i]%=10;
	}
	while(ret.s[ret.s[0]+1]){
		ret.s[0]++;
		ret.s[ret.s[0]+1]+=ret.s[ret.s[0]]/10;
		ret.s[ret.s[0]]%=10;
	}
	while(ret.s[0]>1&&!ret.s[ret.s[0]])ret.s[0]--;
	return ret;
}
node operator +(const node &A,const node &B){
	int i;
	node ret;
	ret.s[0]=max(A.s[0],B.s[0]);
	rep(i,1,ret.s[0])
		ret.s[i]=A.s[i]+B.s[i];
	rep(i,1,ret.s[0]){
		ret.s[i+1]+=ret.s[i]/10;
		ret.s[i]%=10;
	}
	while(ret.s[ret.s[0]+1]){
		ret.s[0]++;
		ret.s[ret.s[0]+1]+=ret.s[ret.s[0]]/10;
		ret.s[ret.s[0]]%=10;
	}
	while(ret.s[0]>1&&!ret.s[ret.s[0]])ret.s[0]--;
	return ret;
} 
char s[11000];
node get(){
	node ret;
	scanf("%s",s);
	int len=strlen(s);
	int st=0;
	if(s[st]=='-')ret.f=-1,st++;
	ret.s[0]=len-st;
	int k=0;
	for(int i=len-1;i>=st;i--)
		ret.s[++k]=s[i]-48;
	return ret;
}
int n,m;
void init(){
	int i,j,k;
//	scanf("%d%d",&n,&m);
	rep(i,0,n)
		a[i]=get();
}
bool check(int val){
	int i,j,k;
	node ans1,ans2;
	reps(i,n,0){
		if(a[i].f!=-1)ans1=ans1+a[i];
		else ans2=ans2+a[i];
		if(i){
			ans1=ans1*val;
			ans2=ans2*val;
		}
	}
	return ans1==ans2;
}
void solve(){
	int i,j,k;
	VI L;
	rep(i,1,m){
		if(check(i))L.PB(i);
	}
	printf("%d\n",L.size());
	for(i=0;i<L.size();i++)printf("%d\n",L[i]);
}
int main(){
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(m<=100){
		init();
		solve();
	}
	else puts("0");
	return 0;
}
