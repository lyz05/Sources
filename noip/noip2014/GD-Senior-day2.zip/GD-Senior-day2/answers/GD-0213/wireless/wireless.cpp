#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<vector>
#include<ctime>
#include<string>
#include<set>
#include<map>
#include<queue>
#define rep(i,x,y) for(i=x;i<=y;i++)
#define reps(i,x,y) for(i=x;i>=y;i--)
#define INF 0x5fffffff
#define MP make_pair
#define PB push_back
using namespace std;
typedef long long LL;
typedef double DB;
typedef unsigned long long ull;
typedef vector<int> VI;
int d,n;
int M[200][200];
void solve(){
	int i,j,k;
	scanf("%d%d",&d,&n);
	rep(i,1,n){
		scanf("%d%d",&j,&k);
		scanf("%d",&M[j][k]);
	}
	LL ans=0;int Count=0;
	rep(i,0,128){
		rep(j,0,128){
			LL size=0;
			int x,y;
			rep(x,i-d,i+d){
				if(0<=x&&x<=128)
				rep(y,j-d,j+d){
					if(0<=y&&y<=128)
						size+=M[x][y];
				}
			}
			if(ans<size){
				ans=size;
				Count=0;
			}
			if(ans==size)Count++;
		}
	}
	cout<<Count<<' '<<ans<<endl;
}
int main(){
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	//init();
	solve();
	return 0;
}
