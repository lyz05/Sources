#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<vector>
#include<ctime>
#include<string>
#include<set>
#include<map>
#include<queue>
#define rep(i,x,y) for(i=x;i<=y;i++)
#define reps(i,x,y) for(i=x;i>=y;i--)
#define INF 0x5fffffff
#define MP make_pair
#define PB push_back
#define N 11000
using namespace std;
typedef long long LL;
typedef double DB;
typedef unsigned long long ull;
typedef vector<int> VI;
VI L;
int dfn[N],low[N],belong[N];
bool mark[N],v[N];
VI G[N],rg[N];
int n,m,sp,tot,st,ed;
int d[N];
void tarjan(int x){
	int i,j,k;
	dfn[x]=low[x]=++tot;
	mark[x]=1;L.PB(x);
	for(k=0;k<G[x].size();k++){
		int y=G[x][k];
		if(!dfn[y]){
			tarjan(y);
			low[x]=min(low[x],low[y]);
		}
		else if(mark[y])
			low[x]=min(low[x],dfn[y]);
	}
	if(low[x]==dfn[x]){
		sp++;
		do{
			k=L.back();
			L.pop_back();
			mark[k]=0;
			belong[k]=sp;
//			sta[sp].PB(k);
		}while(k!=x); 
	}
}
void init(){
	int i,j,k;
	scanf("%d%d",&n,&m);
	while(m--){
		scanf("%d%d",&j,&k);
		if(j!=k)G[j].PB(k);
	}
	scanf("%d%d",&st,&ed);
	rep(i,1,n)
		if(!dfn[i])tarjan(i); 
	rep(i,1,n){
		for(k=0;k<G[i].size();k++){
			j=G[i][k];
			if(belong[i]==belong[j])continue;
			rg[belong[i]].PB(belong[j]);
		}
	}
}
int dfs(int x){
	int i,j,k;
	if(d[x]!=-1)return d[x];
	for(k=0;k<rg[x].size();k++){
		int y=rg[x][k];
		int val=dfs(y);
		if(val==1)return d[x]=1;
	}
	return d[x]=0;
}
priority_queue<pair<int,int> >Q;
void solve(){
	int i,j,k;
	rep(i,1,sp)d[i]=-1;
	d[belong[ed]]=1;
	rep(i,1,n){
		bool ok=1;
		for(k=0;k<G[i].size();k++){
			dfs(belong[G[i][k]]);
			if(!d[belong[G[i][k]]]){
				ok=0;break;
			}
		}
		if(!ok)v[i]=1;
	}
	if(v[st]){
		puts("-1");
		return ;
	}
	memset(d,63,sizeof(d));d[st]=0;
	Q.push(MP(0,st));
	while(!Q.empty()){
		pair<int,int> t=Q.top();Q.pop();
		if(v[t.second])continue;
		int x=t.second;
		v[x]=1;
		for(k=0;k<G[x].size();k++){
			int y=G[x][k];
			if(!v[y]&&d[y]>d[x]+1){
				d[y]=d[x]+1;
				Q.push(MP(-d[y],y));
			}
		}
	}
	if(d[ed]<=200000)printf("%d\n",d[ed]);
	else puts("-1");
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	init();
	solve();
	return 0;
}
