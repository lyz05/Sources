#include<cstdio>
#include<cstdlib>
#include<fstream>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<string>
#include<cmath>
#include<map>
#include<utility>
#include<queue>
#include<stack>
#include<set>
#include<bitset>
#include<vector>

using namespace std;

#define re(i,a,b) for(i=a;i<=b;i++)
#define red(i,a,b) for(i=a;i>=b;i--)
#define fi first
#define se second

typedef long long LL;
typedef double DB;
typedef pair<int,int> PII;

template<class T> T sqr(T x){return x*x;}
template<class T> void upmin(T &t,T tmp){if(t>tmp)t=tmp;}
template<class T> void upmax(T &t,T tmp){if(t<tmp)t=tmp;}
 
const DB EPS=1e-9;
inline int dblcmp(DB x){if(abs(x)<EPS)return 0;return (x>0)?1:-1;}

inline void SetOpen(string s)
  {
		freopen((s+".in").c_str(),"r",stdin);
		freopen((s+".out").c_str(),"w",stdout);
	}

const int maxN=10000;
const int maxM=200000;
const int INF=2147483647;

int N,M,S,T;
PII d[maxM+100];
int first[maxN+10],now;
struct Tedge{int v,next;}edge[maxM+100];
int flag[maxN+10];
int dis[maxN+10];

inline void addedge(int u,int v)
  {
		now++;
		edge[now].v=v;
		edge[now].next=first[u];
		first[u]=now;
	}

int head,tail,que[maxN+10];
int vis[maxN+10];
inline void BFS(int STR)
  {
		int i;
		re(i,1,N)vis[i]=0;
		vis[que[head=tail=0]=STR]=1;
		while(head<=tail)
		  {
				int u=que[head++],v;
				for(i=first[u],v=edge[i].v;i!=-1;i=edge[i].next,v=edge[i].v)if(!vis[v])vis[que[++tail]=v]=1;
			}
	}

inline void BFS2(int STR)
  {
		int i;
		re(i,1,N)dis[i]=INF;
		if(flag[STR]==0)return;
		dis[que[head=tail=0]=STR]=0;
		while(head<=tail)
		  {
				int u=que[head++],v;
				for(i=first[u],v=edge[i].v;i!=-1;i=edge[i].next,v=edge[i].v)
				  if(flag[v]==1 && dis[v]==INF)dis[que[++tail]=v]=dis[u]+1;
			}
	}

int main()
  {
		int i,j;
		SetOpen("road");
		scanf("%d%d\n",&N,&M);
		re(i,1,M)scanf("%d%d\n",&d[i].fi,&d[i].se);
		scanf("%d%d\n",&S,&T);
		re(i,1,N)first[i]=-1;now=-1;
		re(i,1,M)addedge(d[i].se,d[i].fi);
		BFS(T);
		re(i,1,N)first[i]=-1;now=-1;
		re(i,1,M)addedge(d[i].fi,d[i].se);
		re(j,1,N)
		  {
				flag[j]=1;
				int v;
				for(i=first[j],v=edge[i].v;i!=-1;i=edge[i].next,v=edge[i].v)if(!vis[v]){flag[j]=0;break;}
			}
		BFS2(S);
		if(dis[T]==INF) printf("-1\n"); else printf("%d\n",dis[T]);
		return 0;
	}
		
		
