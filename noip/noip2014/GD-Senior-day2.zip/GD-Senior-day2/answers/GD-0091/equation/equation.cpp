#include<cstdio>
#include<cstdlib>
#include<fstream>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<string>
#include<cmath>
#include<map>
#include<utility>
#include<queue>
#include<stack>
#include<set>
#include<bitset>
#include<vector>

using namespace std;

#define re(i,a,b) for(i=a;i<=b;i++)
#define red(i,a,b) for(i=a;i>=b;i--)
#define fi first
#define se second

typedef long long LL;
typedef double DB;
typedef pair<int,int> PII;

template<class T> T sqr(T x){return x*x;}
template<class T> void upmin(T &t,T tmp){if(t>tmp)t=tmp;}
template<class T> void upmax(T &t,T tmp){if(t<tmp)t=tmp;}
 
const DB EPS=1e-9;
inline int dblcmp(DB x){if(abs(x)<EPS)return 0;return (x>0)?1:-1;}

inline void SetOpen(string s)
  {
		freopen((s+".in").c_str(),"r",stdin);
		freopen((s+".out").c_str(),"w",stdout);
	}

const int maxN=100;
const int maxM=1000000;
const int maxlen=10000;
const LL Mod[5]={1000000007LL,909006707LL,103100007LL,703450603LL,715715877LL};

int N,M;
int tot,out[maxM+10];
LL AA[maxN+10][5];

char s[maxlen+100];int len;

inline int check(LL x)
  {
		int i,j;LL res,tmp;
		re(j,0,4)
		  {
				res=0;tmp=1;
				re(i,0,N)
				  {
						res=res+AA[i][j]*tmp;if(res>=Mod[j])res%=Mod[j];
						tmp=tmp*x;if(tmp>=Mod[j])tmp%=Mod[j];
					}
				if(res!=0)return 0;
			}
		return 1;
	}

int main()
  {
		int i,j,k;
		SetOpen("equation");
		scanf("%d%d\n",&N,&M);
		re(i,0,N)
		  {
				scanf("%s\n",s+1);len=strlen(s+1);
				re(j,0,4)
				  {
						AA[i][j]=0;
						int flag=1;
						re(k,1,len)
						  {
								if(s[k]=='-'){flag=-1;continue;}
								AA[i][j]=(AA[i][j]*10+s[k]-'0')%Mod[j];
							}
						if(flag==-1)AA[i][j]=-AA[i][j];
					}
			}
		tot=0;
		re(i,1,min(200000,M))if(check(LL(i))==1)out[++tot]=i;
		printf("%d\n",tot);re(i,1,tot)printf("%d\n",out[i]);
		return 0;
	}
