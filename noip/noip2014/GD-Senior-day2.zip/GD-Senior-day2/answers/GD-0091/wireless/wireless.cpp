#include<cstdio>
#include<cstdlib>
#include<fstream>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<string>
#include<cmath>
#include<map>
#include<utility>
#include<queue>
#include<stack>
#include<set>
#include<bitset>
#include<vector>

using namespace std;

#define re(i,a,b) for(i=a;i<=b;i++)
#define red(i,a,b) for(i=a;i>=b;i--)
#define fi first
#define se second

typedef long long LL;
typedef double DB;
typedef pair<int,int> PII;

template<class T> T sqr(T x){return x*x;}
template<class T> void upmin(T &t,T tmp){if(t>tmp)t=tmp;}
template<class T> void upmax(T &t,T tmp){if(t<tmp)t=tmp;}
 
const DB EPS=1e-9;
inline int dblcmp(DB x){if(abs(x)<EPS)return 0;return (x>0)?1:-1;}

inline void SetOpen(string s)
  {
		freopen((s+".in").c_str(),"r",stdin);
		freopen((s+".out").c_str(),"w",stdout);
	}

const int N=128;

int D,G;
LL v[N+10][N+10],H[N+10][N+10],S[N+10][N+10],F[N+10][N+10];
int ans1;
LL ans2;

int main()
  {
		int i,j;
		SetOpen("wireless");
		scanf("%d\n",&D);
		scanf("%d\n",&G);
		re(i,0,N)re(j,0,N)v[i][j]=0;
		re(i,1,G)
		  {
				int x,y,k;scanf("%d%d%d\n",&x,&y,&k);
				v[x][y]=LL(k);
			}
		re(i,0,N)
		  {
				H[i][0]=v[i][0];
				re(j,1,N)H[i][j]=H[i][j-1]+v[i][j];
			}
		re(j,0,N)S[0][j]=H[0][j];
		re(i,1,N)re(j,0,N)S[i][j]=S[i-1][j]+H[i][j];
		re(i,0,N)re(j,0,N)
		  {
				int a=max(0,i-D),b=max(0,j-D),c=min(N,i+D),d=min(N,j+D);
				F[i][j]=0;
				F[i][j]+=S[c][d];
				if(a-1>=0)F[i][j]-=S[a-1][d];
				if(b-1>=0)F[i][j]-=S[c][b-1];
				if(a-1>=0 && b-1>=0) F[i][j]+=S[a-1][b-1];
			}
		ans2=0;
		re(i,0,N)re(j,0,N)upmax(ans2,F[i][j]);
		ans1=0;
		re(i,0,N)re(j,0,N)if(F[i][j]==ans2)ans1++;
		cout<<ans1<<' '<<ans2<<endl;
		return 0;
	}
