#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <algorithm>
using namespace std;

int d,n,ans1,ans2;
int i,cur,cx,cy;
int x[111],y[111],k[111];

int main()
{
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	
	scanf("%d",&d);
	scanf("%d",&n);
	for (i=0;i<n;i++)
		scanf("%d%d%d",x+i,y+i,k+i);
	
	ans1=0;
	ans2=0;
	
	for (cx=0;cx<=128;cx++)
		for (cy=0;cy<=128;cy++)
		{
			cur=0;
			for (i=0;i<n;i++)
				if (x[i]-cx<=d&&cx-x[i]<=d)
					if	(y[i]-cy<=d&&cy-y[i]<=d)
						cur+=k[i];
			if (cur>ans2)
				ans1=0,ans2=cur;
			if (cur==ans2)
				ans1++;
		}
	
	printf("%d %d\n",ans1,ans2);
	
	return 0;
}

