#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <algorithm>
#define glen(x) (x[11110])
#define symb(x) (x[11109])
using namespace std;

typedef int Gao[11111];
Gao a[111],cur;
int ans[1111111];

char st[111111];
void getgao(Gao &a)
{
	char ch;
	for (ch=getchar();ch!='-'&&(ch>'9'||ch<'0');ch=getchar());
	if (ch=='-') ch='0',symb(a)=-1; else symb(a)=1;
	
	for (;ch=='0';ch=getchar());
	int n=3;
	for (;ch>='0'&&ch<='9';ch=getchar()) st[n++]=ch&15;
	
	int len;
	for (len=0;n>=4;n-=4,len++)
		a[len]=st[n-1]+st[n-2]*10+st[n-3]*100+st[n-4]*1000;
	
	glen(a)=len;
}

bool Divable(Gao &a,int g)
{
	long long c=0;
	int i;
	int &cd=glen(a);
	for (i=cd-1;i>=0;i--)
	{
		c=c*10000+a[i];
		a[i]=c/g;
		c=c%g;
	}
	if (c!=0)
		return 0;
	while (cd>0&&a[cd-1]==0)
		cd--;
	return 1;
}

void Add(Gao &a,const Gao &b)
{
	int &ca=glen(a);
	int cb=glen(b);
	int c=0,i;
	if (symb(a)==symb(b))
	{
		for (;ca<cb;ca++)
			a[ca]=0;
		for (i=0;i<ca;i++)
		{
			a[i]+=b[i]+c;
			if (a[i]>=10000)
				c=1,a[i]-=10000;
			else
				c=0;
		}
		if (c==1)
			a[ca++]=1;
		return ;
	}
	
	int flag;
	
	if (ca!=cb)
		if (ca<cb)
			flag=-1;
		else
			flag=1;
	else
	{
		for (;ca>0&&a[ca-1]==b[ca-1];a[ca]=0)
			ca--,cb--;
		if (ca==0)
			return ;
		if (a[ca-1]<b[ca-1])
			flag=-1;
		else
			flag=1;
	}
	
	if (flag==-1)
	{
		symb(a)=-symb(a);
		for (;ca<cb;ca++)
			a[ca]=0;
		
		for (i=0;i<ca;i++)
		{
			a[i]=b[i]-c-a[i];
			if (a[i]<0)
				c=1,a[i]+=10000;
			else
				c=0;
		}
		while (ca>0&&a[ca-1]==0) ca--;
	}
	else
	{
		for (i=0;i<ca;i++)
		{
			a[i]=a[i]-c-b[i];
			if (a[i]<0)
				c=1,a[i]+=10000;
			else
				c=0;
		}
		while (ca>0&&a[ca-1]==0) ca--;
	}
}

int main()
{
	int n,m,i,j;
	int anss;
	
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	
	scanf("%d%d",&n,&m);
	for (i=0;i<=n;i++)
		getgao(a[i]);
	
	anss=0;
	for (i=1;i<=m;i++)
	{
		memcpy(cur,a[0],sizeof(Gao));
		for (j=1;j<=n;j++)
		{
			if (!Divable(cur,i))
				break;
			Add(cur,a[j]);
		}
		if (j<=n) continue;
		if (glen(cur)==0)
			ans[anss++]=i;
		if (anss>=n)
			break;
	}
	
	printf("%d\n",anss);
	for (i=0;i<anss;i++)
		printf("%d\n",ans[i]);
	
	return 0;
}

