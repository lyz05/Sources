#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <algorithm>
#define oo 11111111
using namespace std;

int read()
{
	static char ch;
	int ret=0;
	for (ch=getchar();ch<'0'||ch>'9';ch=getchar());
	for (;ch>='0'&&ch<='9';ch=getchar()) ret=ret*10+(ch&15);
	return ret;
}

int q[11111];
int rable[11111];
int flag[11111];
int fir[11111];
int next[222222];
int tar[222222];
int S,T;
int n;

void work()
{
	int h,t,u,v,pt,i;
	q[0]=T; t=1;
	rable[T]=1;
	
	for (h=0;h<t;h++)
	{
		u=q[h];
		for (pt=fir[u];pt!=0;pt=next[pt])
		{
			v=tar[pt];
			if (rable[v]) continue;
			q[t++]=v;
			rable[v]=1;
		}
	}
	
	for (i=1;i<=n;i++)
		if (!rable[i])
		{
			flag[i]=oo;
			for (pt=fir[i];pt!=0;pt=next[pt])
				flag[tar[pt]]=oo;
		}
	
	q[0]=T; t=1;
	flag[T]=1;
	for (h=0;h<t;h++)
	{
		u=q[h];
		for (pt=fir[u];pt!=0;pt=next[pt])
		{
			v=tar[pt];
			if (flag[v]) continue;
			q[t++]=v;
			flag[v]=flag[u]+1;
		}
	}
	for (i=1;i<=n;i++)
		if (!flag[i])
			flag[i]=oo;
	
	if (flag[S]==oo)
		printf("-1\n");
	else
		printf("%d\n",flag[S]-1);
}

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	
	int m,u,v,i;
	
	n=read();
	m=read();
	for (i=1;i<=m;i++)
	{
		u=read();
		v=read();
		next[i]=fir[v];
		fir[v]=i;
		tar[i]=u;
	}
	
	S=read();
	T=read();
	
	work();
	
	return 0;
}

