#include<stdio.h>
#include<math.h>
#define MAXN 100+1

FILE *fin,*fout;

long a[MAXN];
int s,n,m;
int sm[1000000];

void Input()
{
	fscanf(fin,"%d%d",&n,&m);
	int i;
	for (i=0;i<=n;i++)
	  fscanf(fin,"%d",&a[i]);
}

void Solve()
{
	int i,j,k,h,ans;
	for (i=1;i<=m;i++)
	{
		ans=a[0];
		h=i;
		for (j=1;j<=n;j++)
		{
			for (k=2;k<=j;k++)
			  h=h*h;
			ans=ans+a[j]*h;
		}
		if (ans==0)
		{
			s++;
			sm[s]=i;
		} 
	}
	  
	    
	      
}

int main()
{
	fin=fopen("equation.in","r");
	fout=fopen("equation.out","w");
	Input();
	Solve();
	int i;
	if (s)
	{
		fprintf(fout,"%d\n",s);
		for (i=1;i<=s;i++)
		  fprintf(fout,"%d\n",sm[i]);
	}else fprintf(fout,"0\n");
	fclose(fin);
	fclose(fout);
}
