#include<stdio.h>
#include<string.h>
#include<math.h>

FILE *fin,*fout;

struct
{
	int x;
	int y;
}pub[129*129];

int d,n,t;
int city[129][129];
int ans,max;

void Input()
{
	memset(city,0,sizeof(city));
	memset(pub,0,sizeof(pub));
	ans=0;
	max=0;
	fscanf(fin,"%d",&d);
	fscanf(fin,"%d",&n);
	int i,k;
	for (i=1;i<=n;i++)
	{
		fscanf(fin,"%d%d%d",&pub[i].x,&pub[i].y,&k);
		city[pub[i].x][pub[i].y]=k;
	}
}

void Search(int x,int y)
{
	int i,j,m,h,q,g;
	int x0,y0,x1,y1;
	int s[400];
	memset(s,0,sizeof(s));
	q=0;
	g=1;
	for (i=1;i<=n;i++)
	  if (pub[i].x!=x && pub[i].y!=y)
	    if (abs(pub[i].x-x)<=(2*d) && abs(pub[i].y-y)<=(2*d))
	      s[++q]=i;
	x0=x-d;
	y0=y-d;
	x1=x+d;
	y1=y+d;
	if (x0<0) x0=0;
	if (y0<0) y0=0;
	if (x1>128) x1=128;
	if (y1>128) y1=128;
	for (i=x0;i<=x1;i++)
	  for (j=y0;j<=y1;j++)
	  {
	  	  h=city[x][y];
	  	  for (m=1;m<=q;m++)
	  	    if (abs(pub[s[m]].x-i)<=d && abs(pub[s[m]].y-j)<=d){
	  	      h+=city[pub[s[m]].x][pub[s[m]].y];
	  	      g++;
				}
	  	  if (h>max)
	  	  {
	  	  	  ans=1;
	  	  	  max=h;
	  	  	  g=0;
	  	  }
	  	  else if (h==max)
	  	  {
	  	  	  ans++;
	  	  	  t=g;
	  	  	  g=0;
	  	  }
	  	  
	  }
}

int main()
{
	fin=fopen("wireless.in","r");
	fout=fopen("wireless.out","w");
	Input();
	int i;
	for (i=1;i<=n;i++)
	  Search(pub[i].x,pub[i].y);
	fprintf(fout,"%d %d\n",ans/t,max);
	fclose(fin);
	fclose(fout);
	return 0;
}
