#include<stdio.h>
#include<string.h>

FILE *fin,*fout;

struct
{
	int e;
	int u,d;
	int up[2000];
	int down[2000];
}line[100];

int n,m;
int s,t;
int min;

void Solve(int a,int c)
{
	int i;
	if (a==t)
	{
		if (c<min) min=c;
		return;
	}
	if (line[a].d==0)
	{
		if (line[a].e==0) 
		{
			for (i=1;i<=line[a].u;i++)
	          line[line[a].up[i]].e=1;
		      line[a].e=1;
		}
		return;
	}
	for (i=1;i<=line[a].d;i++)
		if (line[a].down[line[a].d]==t) 
		{
			c+=1;
			if (c<min) min=c;
			return;
		}
		
	for (i=1;i<=line[a].d;i++)
	{
		if (line[line[a].down[i]].e==0)
		{
			c++;
			line[line[a].down[i]].e=1;
			Solve(line[a].down[i],c);
			c--;
			line[line[a].down[i]].e=0;
		}
	}
}

void Broken()
{
	int i,j;
	for (i=1;i<=n;i++)
	  if (line[i].d==0 && i!=t)
	  {
		  for (j=1;j<=line[i].u;j++)
	      line[line[i].up[j]].e=1;
		  line[i].e=1;
	  }
}

int main()
{
	fin=fopen("road.in","r");
	fout=fopen("road.out","w");
	memset(line,0,sizeof(line));
	min=2001;
	fscanf(fin,"%d%d",&n,&m);
	int i,x,y;
	for (i=1;i<=m;i++)
	{
		fscanf(fin,"%d%d",&x,&y);
		line[x].d++;
		line[x].down[line[x].d]=t;
		line[y].u++;
		line[y].up[line[y].u]=t;
	}
	fscanf(fin,"%d%d",&s,&t);
	Broken();
	Solve(s,0);
	if (min!=2001) fprintf(fout,"%d\n",min);
	else fprintf(fout,"-1\n");
	fclose(fin);
	fclose(fout);
}
