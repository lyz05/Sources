#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cstdlib>
#include <cmath>
using namespace std;

#define Mod1 1000000007LL
#define Mod2 500000003LL
#define maxN 105
#define maxM 1000005
#define maxL 10050
typedef long long LL;

int N, M;
LL a[maxN], b[maxN];
bool ans[maxM];
char st[maxL];

int main()
{
	freopen("equation.in", "r", stdin);
	freopen("equation.out", "w", stdout);
	
	scanf("%d%d", &N, &M);
	for (int i=0; i<=N; ++i)
	{
		scanf("%s", st);
		char *be = st;
		bool flag = false;
		if ((*be) == '-')
		{
			flag = true;
			++be;
		}
		a[i] = b[i] = 0;
		while ( (*be) != 0 ) 
		{
			a[i] = ((a[i] * 10LL) + (*be) - '0') % Mod1;
			b[i] = ((b[i] * 10LL) + (*be) - '0') % Mod2;
			++be;
		}
		if (flag)
		{
			a[i] = Mod1 - a[i];
			b[i] = Mod2 - b[i];
		}
	}
	
	int s = 0;
	for (int i=1; i<=M; ++i)
	{
		LL v1 = -a[N], v2 = -b[N];
		for (int j=N-1; j>=0; --j)
		{
			v1 = (v1 * i - a[j]) % Mod1;
			v2 = (v2 * i - b[j]) % Mod2;
		}
		v1 = (v1 + Mod1) % Mod1;
		v2 = (v2 + Mod2) % Mod2;
		ans[i] = (v1 == 0 && v2 == 0);
		if (ans[i]) ++s;
	}
	
	printf("%d\n", s);
	for (int i=1; i<=M; ++i) if (ans[i]) printf("%d\n", i);
	
	return 0;
}
