#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cstdlib>
using namespace std;

#define maxN 10005
#define maxM 200005

int N, M, S, T;
int H[2][maxN], now;
struct Tedge
{
	int id, nxt;
} edge[2][maxM];

bool vis[maxN], ok[maxN];
int head, tail, q[maxN];
int dis[maxN];

void addedge(int a, int b)
{
	++now;
	edge[0][now].id = b;
	edge[0][now].nxt = H[0][a];
	H[0][a] = now;
	edge[1][now].id = a;
	edge[1][now].nxt = H[1][b];
	H[1][b] = now;
}

void Bfs(int s)
{
	for (int i=1; i<=N; ++i) vis[i] = false;
	vis[s] = true;
	head = tail = 0;
	q[0] = s;
	while (head <= tail)
	{
		int now = q[head++];
		for (int tmp = H[1][now]; tmp; tmp = edge[1][tmp].nxt)
		{
			int id = edge[1][tmp].id;
			if (vis[id]) continue;
			vis[id] = true;
			q[++tail] = id;
		}
	}
}

int Find_Path(int s, int t)
{
	if (!ok[s]) return -1;
	for (int i=1; i<=N; ++i) dis[i] = -1;
	dis[s] = 0;
	head = tail = 0;
	q[0] = s;
	while (head <= tail)
	{
		int now = q[head++];
		for (int tmp = H[0][now]; tmp; tmp = edge[0][tmp].nxt)
		{
			int id = edge[0][tmp].id;
			if (!ok[id]) continue;
			if (dis[id] > -1) continue;
			dis[id] = dis[now] + 1;
			if (id == t) return dis[id];
			q[++tail] = id;
		}
	}
	return -1;
}

int main()
{
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	
	scanf("%d%d", &N, &M);
	now = 0;
	for (int i=1; i<=N; ++i) H[0][i] = H[1][i] = 0;
	while (M--)
	{
		int x, y;
		scanf("%d%d", &x, &y);
		addedge(x, y);
	}
	
	scanf("%d%d", &S, &T);
	
	Bfs(T);
	
	for (int i=1; i<=N; ++i)
	{
		ok[i] = vis[i];
		for (int tmp = H[0][i]; tmp; tmp = edge[0][tmp].nxt)
		{
			int id = edge[0][tmp].id;
			ok[i] = (ok[i] && vis[id]);
		}
	}
	
	printf("%d\n", Find_Path(S, T));
	
	return 0;
}
