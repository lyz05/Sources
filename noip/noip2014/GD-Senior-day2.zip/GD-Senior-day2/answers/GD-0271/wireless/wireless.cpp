#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
int d,n,a[140][140],f[140][140],ans,maxx;
inline void init(){
	scanf("%d%d",&d,&n);
	memset(a,0,sizeof(a));
	for(int i=1;i<=n;++i){
		int x,y,k;
		scanf("%d%d%d",&x,&y,&k);
		a[x][y]=k;
	}
	memset(f,0,sizeof(f));
	for(int i=0;i<129;++i)
	 for(int j=1;j<=129;++j)f[i][j]=f[i][j-1]+a[i][j-1];
}
inline void ppp(){
	ans=0;maxx=0;
	for(int i=0;i<129;++i)
	 for(int j=0;j<129;++j)
	  {
		int l=0;
		for(int k=max(0,i-d);k<=min(i+d,128);++k)
		l+=(f[k][min(128,j+d)+1]-f[k][max(0,j-d)]);
		if(l>ans){ans=l;maxx=1;}
		else if(l==ans)++maxx;
	}
	
}
inline void qqq(){
	printf("%d %d\n",maxx,ans);
}

int main(){
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	init();
	ppp();
	qqq();
return 0;
}
