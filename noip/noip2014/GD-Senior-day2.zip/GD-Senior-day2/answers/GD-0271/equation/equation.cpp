#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<vector>
#include<string>
#include<iostream>
using namespace std;
const int bb=1000000;
struct bignum{
   int N;
   vector<int>data;
}a[111];
int n,m,nn,kk;
char c;
string s;
bool ok;
vector<int>ans;
bignum operator + (const bignum &lhs,const bignum &rhs){
    bignum x=lhs;
    for(int i=0;i<rhs.N;++i){
    	if(i+1>x.N){++x.N;x.data.push_back(0);}
		if(i>0){x.data[i]+=x.data[i-1]%bb;x.data[i-1]/=bb;}
		x.data[i]+=rhs.data[i];
	}
    if(x.data[x.N]>=bb){x.N++;x.data.push_back(x.data[x.N-1]/bb);x.data[x.N-1]%=bb;}	
    while(!(x.data[x.N-1])&&x.N)--x.N;
	return x;
}
bignum operator * (const bignum &lhs,const int &rhs){
	bignum x=lhs;
    for(int i=0;i<x.N;++i){
		if(i>0){x.data[i]+=x.data[i-1]%bb;x.data[i-1]/=bb;}
		else x.data[i]*=rhs;
	}
    if(x.data[x.N]>=bb){x.N++;x.data.push_back(x.data[x.N-1]/bb);x.data[x.N-1]%=bb;}	
    return x;
}
bool operator < (const bignum &lhs,const bignum &rhs){
	if(lhs.N!=rhs.N)return lhs.N<rhs.N;
	for(int i=lhs.N-1;i>=0;--i)if(lhs.data[i]!=rhs.data[i])return lhs.data[i]<rhs.data[i];
	return false;
}
inline void readnum(int x){
	ok=false;
	cin>>s;if(s[0]=='-')ok=true;kk=0;nn=s.length();
	for(int i=nn-1;i>=0+(ok);--i){

		kk=kk*10+int(s[i])-'0';
		if(!((nn-i)%6))
		{
		if(!ok)a[x].data.push_back(kk);else a[x].data.push_back(-kk);
		kk=0;}
	}
	if(kk){a[x].N++;if(!ok)a[x].data.push_back(kk);else a[x].data.push_back(-kk);}
}
inline void init(){
	scanf("%d%d",&n,&m);
	for(int i=0;i<=n;++i)readnum(i);
	
}
void printnum(bignum x){
	for(int i=x.N-1;i>=0;--i)printf("%d",x.data[i]);
	printf("\n");
}
inline void ppp(){
	for(int i=1;i<=m;++i){
		bignum num;num.N=0;
		for(int j=n;j>=0;--j){
			bignum num1=a[j];
			for(int k=1;k<=j;++k)num1=num1*i;
			num=num+num1;
		}
		
		if (!num.N)ans.push_back(i);
	}
}	
inline void qqq(){
printf("%d\n",ans.size());
for(int i=0;i<ans.size();++i)printf("%d\n",ans[i]);
}

int main(){
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	init();
	ppp();
	qqq();
return 0;
}
