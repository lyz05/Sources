#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<vector>
#include<queue>
using namespace std;
queue<int> Q;
vector<int>G[10010],g[10010];
int n,m,s,t,d[10010];
bool vis[10010],b[1001],ok;
inline void addedge(int x,int y){
	G[x].push_back(y);
	g[y].push_back(x);
}
inline void init(){
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;++i){
		int x,y;
		scanf("%d%d",&x,&y);
		if(x!=y)
		addedge(x,y);
	}
	scanf("%d%d",&s,&t);
}
inline void ppp(){
	for(int i=1;i<=Q.size();++i)Q.pop();memset(vis,0,sizeof(vis));
	Q.push(t);vis[t]=true;
	while(!Q.empty()){
	  int x=Q.front();Q.pop();
	  for(int i=0;i<g[x].size();++i)if(!vis[g[x][i]]){
	  	Q.push(g[x][i]);
	  	vis[g[x][i]]=true;
	  }
   }
   ok=vis[s];
}
inline void extra(){
	for(int i=1;i<=Q.size();++i)Q.pop();memset(b,0,sizeof(b));
	Q.push(s);b[s]=true;d[s]=0;
	while(!Q.empty()){
	  int x=Q.front();Q.pop();bool yes=true;
	  for(int i=0;i<G[x].size();++i)if(!vis[G[x][i]]){yes=false;break;}
	  if(!yes)continue;
	  for(int i=0;i<G[x].size();++i)if(!b[G[x][i]]){
	  	Q.push(G[x][i]);
		b[G[x][i]]=true;
		d[G[x][i]]=d[x]+1;
	  }
   }
   ok=b[t];
}
inline void qqq(){
	if(!ok)printf("-1\n");
	else printf("%d\n",d[t]);
}

int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	init();
	ppp();
	if(ok)extra();
	qqq();
return 0;
}
