// NOIP 2014 D2P3 equation
// @pwecar
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <algorithm>
#include <iostream>
#include <functional>
#include <utility>
#include <numeric>
#include <vector>
#include <set>
#include <map>

#define fo(i,a,b) for (int i = a; i <= b; i ++)
#define fd(i,a,b) for (int i = a; i >= b; i --)
#define fi first
#define se second
#define mkp make_pair
#define Fill(x,y) memset(x,y,sizeof(x))

using namespace std;

typedef long long LL;

int Read()
{
	char c; while (c = getchar(), (c != '-') && (c < '0' || c > '9'));
	bool neg = (c == '-'); int ret = neg ? 0 : c - 48;
	while (c = getchar(), c >= '0' && c <= '9') ret = ret * 10 + c - 48;
	return neg ? -ret : ret;
}

const int P = 500, MAXN = 2000005, BIG = 1e9;

//int pr[MAXN], v[MAXN];
int N, M, ans[105], tt[1200], p[P+5], a[105][P+5];
bool sign[105];
char s[10005];

//#include <cmath>

void GetPrime()
{
	/*double tmp = 0; int ws = 0;
	fo (i, 2, 2000000)
	{
		if (!v[i])
		{
			pr[++ pr[0]] = i;
			tmp += log(i);
			if (tmp > 10000 * log(10) && !ws) ws = pr[0];
		}
		fo (j, 1, pr[0])
		{
			int k = i * pr[j];
			if (k >= MAXN) break;
			v[k] = pr[j];
			if (i % pr[j] == 0) break;
		}
	}*/
	/*fo (i, 1, P) p[i] = pr[pr[0] - i + 1];*/
	fo (i, 159000737, 159100737)
	{
		bool prime = 1;
		for (int j = 2; j * j <= i; j ++)
			if (i % j == 0) { prime = 0; break; }
		if (prime)
		{
			p[++ p[0]] = i;
			if (p[0] == P) break;
		}
	}
}

void init()
{
	// getprime
	GetPrime();
	scanf("%d%d", &N, &M);
	fo (i, 0, N)
	{
		scanf("%s", s); int len = strlen(s);
		sign[i] = (s[0] == '-');
		int ta = 1, tb = 1, tc = 0; Fill(tt, 0);
		fo (j, sign[i], len - 1)
		{
			tt[ta] *= 10, tt[ta] += s[j] - 48;
			if (++ tc == 9) ++ ta, tb = 1, tc = 0;
				else tb *= 10;
		}
		fo (j, 1, P)
		{
			fo (k, 1, ta - 1)
				a[i][j] = ((LL) a[i][j] * BIG + tt[k]) % p[j];
			a[i][j] = ((LL) a[i][j] * tb + tt[ta]) % p[j];
		}
	}
}

bool Solve(int x)
{
	fo (j, 1, P)
	{
		int ret = 0, pw = 1, cur;
		fo (i, 0, N)
		{
			cur = (LL) pw * a[i][j] % p[j];
			ret += (sign[i] ? p[j] - cur : cur), ret -= (ret >= p[j] ? p[j] : 0);
			pw = (LL) pw * x % p[j];
		}
		if (ret) return 0;
	}
	return 1;
}

void work()
{
	fo (i, 1, M)
		if (Solve(i))
		{
			ans[++ ans[0]] = i;
			if (ans[0] == N) break;
		}
	printf("%d\n", ans[0]);
	fo (i, 1, ans[0]) printf("%d\n", ans[i]);
}

int main()
{
	freopen("equation.in", "r", stdin), freopen("equation.out", "w", stdout);
	init();
	work();
	return 0;
}

