#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <algorithm>
#include <iostream>
#include <functional>
#include <utility>
#include <numeric>
#include <vector>
#include <set>
#include <map>

#define fo(i,a,b) for (int i = a; i <= b; i ++)
#define fd(i,a,b) for (int i = a; i >= b; i --)
#define fi first
#define se second
#define mkp make_pair

using namespace std;

int Read()
{
	char c; while (c = getchar(), (c != '-') && (c < '0' || c > '9'));
	bool neg = (c == '-'); int ret = neg ? 0 : c - 48;
	while (c = getchar(), c >= '0' && c <= '9') ret = ret * 10 + c - 48;
	return neg ? -ret : ret;
}

const int MAXN = 150;

int N, D, ans1 = -1, ans2 = 0, x[MAXN], y[MAXN], z[MAXN];

void init()
{
	scanf("%d%d", &D, &N);
	fo (i, 1, N) x[i] = Read(), y[i] = Read(), z[i] = Read();
}

bool in(int x, int y) { return x >= y - D && x <= y + D; }

void work()
{
	fo (i, 0, 128)
		fo (j, 0, 128)
		{
			int cur = 0;
			fo (k, 1, N)
				if (in(x[k], i) && in(y[k], j))
					cur += z[k];
			if (cur > ans1) ans1 = cur, ans2 = 1;
				else if (cur == ans1) ++ ans2;
		}
	printf("%d %d\n", ans2, ans1);
}

int main()
{
	freopen("wireless.in", "r", stdin), freopen("wireless.out", "w", stdout);
	init();
	work();
	return 0;
}

