// NOIP 2014 D2P2 road
// @pwecar
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <algorithm>
#include <iostream>
#include <functional>
#include <utility>
#include <numeric>
#include <vector>
#include <set>
#include <map>

#define fo(i,a,b) for (int i = a; i <= b; i ++)
#define fd(i,a,b) for (int i = a; i >= b; i --)
#define fe(i,x,y) for (int i = x, y = lnk[i]; i; i = nxt[i], y = lnk[i])
#define fi first
#define se second
#define mkp make_pair
#define Fill(x,y) memset(x,y,sizeof(x))

using namespace std;

int Read()
{
	char c; while (c = getchar(), (c != '-') && (c < '0' || c > '9'));
	bool neg = (c == '-'); int ret = neg ? 0 : c - 48;
	while (c = getchar(), c >= '0' && c <= '9') ret = ret * 10 + c - 48;
	return neg ? -ret : ret;
}

const int MAXN = 10005, MAXM = 200005;

int N, M, cnt, S, T, st[MAXN], sr[MAXN], q[MAXN], nxt[MAXM << 1], lnk[MAXM << 1], dis[MAXN];
bool vis[MAXN], can[MAXN];

void init()
{
	scanf("%d%d", &N, &M);
	fo (i, 1, M)
	{
		int u = Read(), v = Read();
		lnk[++ cnt] = v, nxt[cnt] = st[u], st[u] = cnt;
		lnk[++ cnt] = u, nxt[cnt] = sr[v], sr[v] = cnt;
	}
	scanf("%d%d", &S, &T);
}

void Reverse_BFS()
{
	int tail = 1; q[1] = T, vis[T] = 1;
	fo (head, 1, tail)
	{
		int x = q[head];
		fe (i, sr[x], y) if (!vis[y])
			q[++ tail] = y, vis[y] = 1;
	}
}

void work()
{
	// reverse
	Reverse_BFS();

	fo (i, 1, N)
	{
		can[i] = vis[i];
		fe (j, st[i], k)
			can[i] &= vis[k];
	}

	if (!can[S]) { puts("-1"); return; }

	int tail = 1; q[1] = S; Fill(dis, -1), dis[S] = 0;
	fo (head, 1, tail)
	{
		int x = q[head];
		fe (i, st[x], y) if (can[y] && dis[y] < 0)
			q[++ tail] = y, dis[y] = dis[x] + 1;
	}
	printf("%d\n", dis[T]);
}

int main()
{
	freopen("road.in", "r", stdin), freopen("road.out", "w", stdout);
	init();
	work();
	return 0;
}
