#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstring>

using namespace std;


long long  f[102][102];
long long x[103];

long long pas(long long n)
{
	long long tmp=0;
	for (long long i=0;i<=n;++i)
		tmp+=x[i]*f[n+1][i+1];
	return tmp;
}

int main()
{
	long long i,j,k;
	ifstream fin;
	ofstream fout;
	fin.open("equation.in");
	fout.open("equation.out");
	for (long long i=0;i<102;x[i++]=1);
	f[0][1]=1;	
	for (long long i=1;i<=101;++i)
		for (long long j=1;j<=i;++j)
			f[i][j]=f[i-1][j-1]+f[i-1][j];
	long long n,m;
	fin>>n>>m;

	long long a[102];
	for (i=0;i<=n;++i)
		fin>>a[i]; 
	long long sol[102];
	long long ans=0;

	long long cur=0;
	for (i=0;i<=n;++i)
	{	
		cur+=a[i];	
	}	
	if (cur==0)
	{
		ans++;
		sol[ans]=1;
	}

	for (i=2;i<=m;++i)
	{
		cur=0;
		for (j=n;j>=0;--j)
		{
			if (x[i]==0)continue;
			x[j]=pas(j);
			cur+=x[j]*a[j];
		}
			if (cur==0)
		{
			ans++;
			sol[ans]=i;
			if (ans==n)break;
		}
	}
	
	fout<<ans<<endl;
	for (i=1;i<=ans;fout<<sol[i++]<<endl);
	fin.close();
	fout.close();
	
	return 0;
}
	
