#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstring>
using namespace std;

int main()
{
	ifstream fin;
	ofstream fout;
	fin.open("wireless.in");
	fout.open("wireless.out");
	int r,n;
	fin>>r>>n;
	int i,j,k;
	long long f[129][129];
	memset(f,0,sizeof(f));
	int ans=0,sum=0;
	
	for (i=0;i<n;++i)
	{
		int x,y,z;
		fin>>x>>y>>z;
		int a,b,c,d;
		a=x-r;
		b=x+r;
		c=y-r;
		d=y+r;
		a=a>0?a:0;
		b=b<128?b:128;
		c=c>0?c:0;
		d=d<128?d:128;
		for (j=a;j<=b;++j)
			for (k=c;k<=d;++k)
			{
				f[j][k]+=z;
				if (f[j][k]>sum)
				{
					ans=1;
					sum=f[j][k];
				}
				else if(f[j][k]==sum)
					ans++;
			}
	}
	fout<<ans<<" "<<sum;
	fin.close();
	fout.close();
	return 0;
}
				
				
		
