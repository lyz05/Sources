#include <iostream>
#include <fstream>
#include <cstdio>
using namespace std;

int  main()
{
	ofstream fout;
	fout.open("road.txt");
	fout<<-1;
	return 0;
}
	
