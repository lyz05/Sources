#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <map>
#include <queue>
#include <vector>
using namespace std;

// public***********

int n, m;
char st[10050];

// public***********


// 50***************

int temp[1050], a[1050], b[1050], one[1050], result[1050];
int number[1050][1050];
bool reduce[1050];


// 50***************


// 100***************

int mod[100] = {1000000007, 1000000009, 1000000021, 1000000033, 1000000087, 
               1000000093, 1000000097, 1000000103, 1000000123, 1000000181, 
               1000000207, 1000000223, 1000000241, 1000000271, 1000000289, 
               1000000297, 1000000321, 1000000349, 1000000363, 1000000403, 
               1000000409, 1000000411, 1000000427, 1000000433, 1000000439, 
               
               1000000447, 1000000453, 1000000459, 1000000483, 1000000513, 
               1000000531, 1000000579, 1000000607, 1000000613, 1000000637, 
               1000000663, 1000000711, 1000000753, 1000000787, 1000000801, 
               1000000829, 1000000861, 1000000871, 1000000891, 1000000901, 
               1000000919, 1000000931, 1000000933, 1000000993, 1000001011, 
               
               1000001021, 1000001053, 1000001087, 1000001099, 1000001137, 
               1000001161, 1000001203, 1000001213, 1000001237, 1000001263, 
               1000001269, 1000001273, 1000001279, 1000001311, 1000001329, 
               1000001333, 1000001351, 1000001371, 1000001393, 1000001413, 
               1000001447, 1000001449, 1000001491, 1000001501, 1000001531, 
               
               1000001537, 1000001539, 1000001581, 1000001617, 1000001621, 
               1000001633, 1000001647, 1000001663, 1000001677, 1000001699, 
               1000001759, 1000001773, 1000001789, 1000001791, 1000001801, 
               1000001803, 1000001819, 1000001857, 1000001887, 1000001917, 
               1000001927, 1000001957, 1000001963, 1000001969, 1000002043};
int jieguo[1000050], chuli[1000050], shu[105], data[105][105];
bool jian[105];

// 100***************


int  Rand()
{
     return (rand() << 15) | rand();
}

int  Read()
{
int  result = 0;
char flag = getchar();
     
     for (; flag < '0' || '9' < flag; flag = getchar());
     for (; '0' <= flag && flag <= '9'; flag = getchar())
     {
         result = 10 * result + flag - 48;
     }
     
     return result;
}

void Solve50()
{
int  i, j, k, len, total, doing;
bool solved;
     
     memset(reduce, false, sizeof(reduce));
     for (i = 0; i <= n; i++)
     {
         memset(st, 0, sizeof(st));
         scanf("%s", st + 1);
         len = strlen(st + 1);
         if  (st[1] == '-')
         {
             reduce[i] = true;
             len--;
             for (j = 1; j <= len; j++)
             {
                 st[j] = st[j + 1];
             }
             st[len + 1] = 0;
         }
         for (j = 1; j <= len; j++)
         {
             number[i][j] = st[len - j + 1] - 48;
         }
         number[i][0] = len;
     }
     
     total = 0;
     
     for (doing = 1; doing <= m; doing++)
     {
         memset(a, 0, sizeof(a));
         memset(b, 0, sizeof(b));
         for (i = 0; i <= n; i++)
         if  (reduce[i])
         {
             memcpy(one, number[i], sizeof(one));
             for (j = 1; j <= i; j++)
             {
                 for (k = 1; k <= one[0]; k++)
                 {
                     temp[k] = one[k] * doing;
                 }
                 temp[0] = one[0];
                 for (k = 1; k <= one[0]; k++)
                 {
                     temp[k + 1] += temp[k] / 10;
                     temp[k] %= 10;
                 }
                 for (; temp[temp[0] + 1] > 0;)
                 {
                     temp[0]++;
                     temp[temp[0] + 1] += temp[temp[0]] / 10;
                     temp[temp[0]] %= 10;
                 }
                 memcpy(one, temp, sizeof(one));
             }
             len = max(a[0], one[0]);
             for (j = 1; j <= len; j++)
             {
                 a[j] += one[j];
             }
             for (j = 1; j <= len; j++)
             {
                 a[j + 1] += a[j] / 10;
                 a[j] %= 10;
             }
             if  (a[len + 1] > 0)
             {
                 len++;
             }
             a[0] = len;
         }   else
         {
             memcpy(one, number[i], sizeof(one));
             for (j = 1; j <= i; j++)
             {
                 for (k = 1; k <= one[0]; k++)
                 {
                     temp[k] = one[k] * doing;
                 }
                 temp[0] = one[0];
                 for (k = 1; k <= one[0]; k++)
                 {
                     temp[k + 1] += temp[k] / 10;
                     temp[k] %= 10;
                 }
                 for (; temp[temp[0] + 1] > 0;)
                 {
                     temp[0]++;
                     temp[temp[0] + 1] += temp[temp[0]] / 10;
                     temp[temp[0]] %= 10;
                 }
                 memcpy(one, temp, sizeof(one));
             }
             len = max(b[0], one[0]);
             for (j = 1; j <= len; j++)
             {
                 b[j] += one[j];
             }
             for (j = 1; j <= len; j++)
             {
                 b[j + 1] += b[j] / 10;
                 b[j] %= 10;
             }
             if  (b[len + 1] > 0)
             {
                 len++;
             }
             b[0] = len;
         }
         if  (a[0] == b[0])
         {
             solved = true;
             for (i = 1; i <= a[0]; i++)
             if  (a[i] != b[i])
             {
                 solved = false;
                 break;
             }
             if  (solved)
             {
                 result[++total] = doing;
             }
         }
     }
     
     printf("%d\n", total);
     for (i = 1; i <= total; i++)
     {
         printf("%d\n", result[i]);
     }
     
     return;
}



void Solve70()
{
int  i, j, k, len, times, vs, cheng, ta, tb;
bool solved;
     
     times = 30;
     
     memset(jian, false, sizeof(jian));
     memset(data, 0, sizeof(data));
     for (i = 0; i <= n; i++)
     {
         memset(st, 0, sizeof(st));
         scanf("%s", st + 1);
         len = strlen(st + 1);
         if  (st[1] == '-')
         {
             jian[i] = true;
             len--;
             for (j = 1; j <= len; j++)
             {
                 st[j] = st[j + 1];
             }
             st[len + 1] = 0;
         }
         for (j = 0; j < times; j++)
         {
             for (k = 1; k <= len; k++)
             {
                 data[j][i] = (10ll * data[j][i] + st[k] - 48) % mod[j];
             }
         }
     }
     
     vs = 0;
     
     for (i = 1; i <= m; i++)
     {
         solved = true;
         for (j = 0; j < times; j++)
         {
             cheng = 1;
             ta = 0;
             tb = 0;
             for (k = 0; k <= n; k++)
             {
                 if  (jian[k])
                 {
                     tb = (tb + (1ll * cheng * data[j][k])) % mod[j];
                 }   else
                 {
                     ta = (ta + (1ll * cheng * data[j][k])) % mod[j];
                 }
                 cheng = 1ll * i * cheng % mod[j];
             }
             if  (ta != tb)
             {
                 solved = false;
                 break;
             }
         }
         if  (solved)
         {
             jieguo[++vs] = i;
         }
     }
     
     printf("%d\n", vs);
     for (i = 1; i <= vs; i++)
     {
         printf("%d\n", jieguo[i]);
     }
//     printf("\n\n%d", clock());
     return;
}



void Solve100()
{
int  i, j, k, len, times, vs, cheng, ta, tb, zhege, xianzhi;
bool solved;
     
     zhege = mod[Rand() % 100];
          
     memset(jian, false, sizeof(jian));
     memset(data, 0, sizeof(data));
     for (i = 0; i <= n; i++)
     {
         memset(st, 0, sizeof(st));
         scanf("%s", st + 1);
         len = strlen(st + 1);
         if  (st[1] == '-')
         {
             jian[i] = true;
             len--;
             for (j = 1; j <= len; j++)
             {
                 st[j] = st[j + 1];
             }
             st[len + 1] = 0;
         }
         for (j = 1; j <= len; j++)
         {
             shu[i] = (10ll * shu[i] + st[j] - 48) % zhege;
         }
     }
     
     vs = 0;
     
     for (i = 1; i <= m; i++)
     {
         chuli[i] = i;
     }
     for (i = 1; i <= 100000; i++)
     {
         swap(chuli[Rand() % m + 1], chuli[Rand() % m + 1]);
     }
     
     xianzhi = min(m, 200000);
     
     for (i = 1; i <= xianzhi; i++)
     {
             cheng = 1;
             ta = 0;
             tb = 0;
             for (j = 0; j <= n; j++)
             {
                 if  (jian[j])
                 {
                     tb = (tb + (1ll * cheng * shu[j])) % zhege;
                 }   else
                 {
                     ta = (ta + (1ll * cheng * shu[j])) % zhege;
                 }
                 cheng = 1ll * chuli[i] * cheng % zhege;
             }
             if  (ta == tb)
             {
                 jieguo[++vs] = chuli[i];
             }
     }
     
     sort(jieguo + 1, jieguo + vs + 1);
     
     printf("%d\n", vs);
     for (i = 1; i <= vs; i++)
     {
         printf("%d\n", jieguo[i]);
     }
//     printf("\n\n%d", clock());
     return;
}

int  main()
{
     
     
     freopen("equation.in", "r", stdin);
     freopen("equation.out", "w", stdout);
     
     srand((unsigned) time (0));
     
     scanf("%d%d", &n, &m);
     
     
     
     if  (n <= 100 && m <= 100)
     {
         Solve50();
     }   else
     if  (m <= 10000)
     {
         Solve70();
     }   else
     {
         Solve100();
     }
     
     
     
     return 0;
}
