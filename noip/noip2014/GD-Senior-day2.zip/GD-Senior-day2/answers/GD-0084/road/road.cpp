#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <map>
#include <queue>
#include <vector>
using namespace std;

struct Tedge
{
       int to, flag, next;
}      edge[1000050];

int n, m, s, t, now, first[10050], dist[10050], Q[1000050];
bool can[10050], visited[10050], boo[10050];

int  Rand()
{
     return (rand() << 15) | rand();
}

int  Read()
{
int  result = 0;
char flag = getchar();
     
     for (; flag < '0' || '9' < flag; flag = getchar());
     for (; '0' <= flag && flag <= '9'; flag = getchar())
     {
         result = 10 * result + flag - 48;
     }
     
     return result;
}

void Addedge(int x, int y, int z)
{
     edge[++now].to = y;
     edge[now].flag = z;
     edge[now].next = first[x];
     first[x] = now;
     
     return;
}

void BFS(int source)
{
int  low, high, pointer, next;
     
     memset(can, false, sizeof(can));
     can[source] = true;
     Q[low = high = 0] = source;
     while (low <= high)
     {
           for (pointer = first[Q[low]]; pointer; pointer = edge[pointer].next)
           {
               next = edge[pointer].to;
               if  (edge[pointer].flag == 1 ||
                   can[next])
               {
                   continue;
               }
               can[next] = true;
               Q[++high] = next;
           }
           low++;
     }
     
     return;
}

void Solve(int source)
{
int  low, high, pointer, next;
     
     memset(dist, -1, sizeof(dist));
     memset(boo, false, sizeof(boo));
     boo[source] = true;
     dist[source] = 0;
     Q[low = high = 0] = source;
     while (low <= high)
     {
           for (pointer = first[Q[low]]; pointer; pointer = edge[pointer].next)
           {
               next = edge[pointer].to;
               if  (edge[pointer].flag == 2 || boo[next] || !visited[next])
               {
                   continue;
               }
               boo[next] = true;
               dist[next] = dist[Q[low]] + 1;
               Q[++high] = next;
           }
           low++;
     }
     
     return;
}

int  main()
{
int  i, x, y, pointer, next;
bool stop;
     
     freopen("road.in", "r", stdin);
     freopen("road.out", "w", stdout);
     
     srand((unsigned) time (0));
     
     scanf("%d%d", &n, &m);
     for (i = 1; i <= m; i++)
     {
         scanf("%d%d", &x, &y);
         Addedge(x, y, 1);
         Addedge(y, x, 2);
     }
     scanf("%d%d", &s, &t);
     
     BFS(t);
     
     memset(visited, false, sizeof(visited));
     visited[t] = true;
     for (i = 1; i <= n; i++)
     if  (can[i] && i != t)
     {
         stop = false;
         for (pointer = first[i]; pointer; pointer = edge[pointer].next)
         {
             next = edge[pointer].to;
             if  (edge[pointer].flag == 2)
             {
                 continue;
             }
             if  (!can[next])
             {
                 stop = true;
                 break;
             }
         }
         if  (!stop)
         {
             visited[i] = true;
         }
     }
     
     if  (!visited[s])
     {
         printf("-1\n");
         return 0;
     }
     
     Solve(s);
     
     printf("%d\n", dist[t]);
     
     return 0;
}
