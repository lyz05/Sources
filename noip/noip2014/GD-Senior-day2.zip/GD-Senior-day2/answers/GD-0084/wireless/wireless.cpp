#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <map>
#include <queue>
#include <vector>
using namespace std;

int x[25], y[25], z[25];

int  Rand()
{
     return (rand() << 15) | rand();
}

int  Read()
{
int  result = 0;
char flag = getchar();
     
     for (; flag < '0' || '9' < flag; flag = getchar());
     for (; '0' <= flag && flag <= '9'; flag = getchar())
     {
         result = 10 * result + flag - 48;
     }
     
     return result;
}

int  main()
{
int  d, n, i, j, k, best, sum, total;
     
     freopen("wireless.in", "r", stdin);
     freopen("wireless.out", "w", stdout);
     
     srand((unsigned) time (0));
     
     scanf("%d%d", &d, &n);
     for (i = 1; i <= n; i++)
     {
         scanf("%d%d%d", &x[i], &y[i], &z[i]);
     }
     
     best = 0;
     sum = 0;
     
     for (i = 0; i <= 128; i++)
     {
         for (j = 0; j <= 128; j++)
         {
             total = 0;
             for (k = 1; k <= n; k++)
             if  (i - d <= x[k] && x[k] <= i + d &&
                 j - d <= y[k] && y[k] <= j + d)
             {
                 total += z[k];
             }
             if  (total > best)
             {
                 best = total;
                 sum = 1;
             }   else
             if  (total == best)
             {
                 sum++;
             }
         }
     }
     
     printf("%d %d\n", sum, best);
     
     return 0;
}
