#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <queue>
#include <map>
#include <vector>
#include <fstream>

using namespace std;

FILE *fin;

int d,n;
int maps[200][200];
long long s[200][200],maxn,ans;

int maxa(int a,int b)
{
if(a>b) return a;
else return b;
}

int main()
{
fin=fopen("wireless.in","r");
ofstream fout("wireless.out");

maxn=-1;

fscanf(fin,"%d%d",&d,&n);
for(int i=0;i<n;i++) 
 {
 int x,y,k;
 fscanf(fin,"%d%d%d",&x,&y,&k);
 maps[x][y]=k;
 }
 
for(int i=0;i<=128;i++)
 for(int j=0;j<=128;j++) 
 {
 if(i==0&&j==0) s[i][j]=maps[i][j];
 else if(i==0) s[i][j]=s[i][j-1]+maps[i][j];
 else if(j==0) s[i][j]=s[i-1][j]+maps[i][j];
 else s[i][j]=s[i-1][j]+s[i][j-1]-s[i-1][j-1]+maps[i][j];
 }

for(int i=-d;i<=128;i++)
 for(int j=-d;j<=128;j++)
  {
  long long f;
  int ma=min(128,i+2*d),my=min(128,j+2*d);
  if(i<=0&&j<=0) f=s[ma][my];
  else if(i<=0) f=s[ma][my]-s[ma][j-1];
  else if(j<=0) f=s[ma][my]-s[i-1][my];
  else f=s[ma][my]-s[ma][j-1]-s[i-1][my]+s[i-1][j-1];
  //if(i<=10&&j<=10) cout <<i<<' '<<j<<' '<<f<<' '<<maxn<<' '<<ans<<endl;
  
  if(maxn==f) {
  ans++; }
  if(maxn<f)
   {
   maxn=f;
   ans=1;
   }
  }
 
fout <<ans<<' '<<maxn<<endl;
 
 //system("pause");
fclose(fin);
return 0;
}
