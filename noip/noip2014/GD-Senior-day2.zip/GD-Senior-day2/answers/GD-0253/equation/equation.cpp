#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <queue>
#include <map>
#include <vector>
#include <fstream>

using namespace std;

FILE *fout;
string nums[10010];
long long num[10010];
int sum[10010],k,ans,n,m;
bool yes,no;

int main()
{
ifstream fins("equation.in");
fout=fopen("equation.out","w");

fins >>n>>m;
for(int i=0;i<=n;i++) fins >>nums[i];
for(int i=0;i<=n;i++) 
 {
 if(nums[i][0]=='-') no=true;
 else yes=true;
 }
 
if( (yes==true&&no==false) || (yes==false&&no==true) ) 
 {
 fprintf(fout,"0\n");
 fclose(fout);
 return 0;
 }

for(int i=0;i<=n;i++)
{
bool flag=false;
 for(int j=0;j<nums[i].size();j++)
  {
  if(nums[i][j]=='-') flag=true;
  else { num[i]=num[i]*10+(nums[i][j]-'0'); }
  }
if(flag) num[i]*=-1;  
}

for(int i=1;i<=m;i++)
{
long long f=num[0],x=i;
for(int j=1;j<=n;j++) 
 {
 f+=num[j]*x;
 x*=i;	
 }
if(f==0) { ans++; sum[k++]=i; }
}
fprintf(fout,"%d\n",ans);
for(int i=0;i<k;i++) fprintf(fout,"%d\n",sum[i]);
fclose(fout);	
return 0;
}
