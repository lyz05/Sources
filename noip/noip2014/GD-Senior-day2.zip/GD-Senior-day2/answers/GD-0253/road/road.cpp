#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <queue>
#include <map>
#include <vector>
#include <fstream>

using namespace std;

FILE *fin,*fout;

int n,m,s,t;
int u[200100],v[200100];
int anf[10100],ann[200100];
queue<int> q;
queue< pair<int,int> >q1;
bool done[10100],rights[10100];

int main()
{
fin=fopen("road.in","r");
fout=fopen("road.out","w");

memset(anf,-1,sizeof(anf));
memset(ann,-1,sizeof(ann));

fscanf(fin,"%d%d",&n,&m);
for(int i=0;i<m;i++)
 {
 fscanf(fin,"%d%d",&u[i],&v[i]);
 ann[i]=anf[v[i]];
 anf[v[i]]=i;
 }
fscanf(fin,"%d%d",&s,&t);

q.push(t);
rights[t]=true; done[t]=true; 
while(!q.empty())
{
 int x=q.front(); q.pop(); 
 for(int i=anf[x];i!=-1;i=ann[i]) 
 {

  if(!done[ u[i] ]) 
  { 
  q.push(u[i]); 
  rights[u[i]]=true; done[u[i]]=true; 
  } 
  }
}


for(int i=1;i<=n;i++) 
 {
 if(done[i]==false)
 {
  for(int j=anf[i];j!=-1;j=ann[j]) rights[u[j]]=false;
   }
 }

if(rights[s]!=true) {
fprintf(fout,"-1\n");
fclose(fin);
fclose(fout);
return 0;
}


memset(done,false,sizeof(done));
pair<int,int> now;
now.first=t; now.second=0;
q1.push(now); done[t]=true;
bool have=false;
while(!q1.empty())
{
now=q1.front(); q1.pop();
if(now.first==s) { fprintf(fout,"%d\n",now.second); have=true; break; }
for(int i=anf[now.first];i!=-1;i=ann[i]) 
 if(rights[u[i]]&&done[u[i]]==false)
 {
 pair<int,int> te;
 te.first=u[i]; te.second=now.second+1;
 q1.push(te);
 done[u[i]]=true;
 }
}

if(have==false) fprintf(fout,"-1\n");

fclose(fin);
fclose(fout);	
return 0;
}
