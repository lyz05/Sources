#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
using namespace std;
int main(){
	freopen("road.in","w",stdout);
	srand(time(0));
	long n=rand()%800+1,m=rand()*rand()%200000,i,j,k;
	printf("%ld %ld\n",n,m);
	for (i=0;i<m;i++){
		j=rand()*rand()%n+1;
		k=rand()*rand()%n+1;
		printf("%ld %ld\n",j,k);
	}
	do{
		j=rand()*rand()%n+1;
		k=rand()*rand()%n+1;
	}while(j==k);
	printf("%ld %ld\n",j,k);
	fclose(stdout);
	return 0;
}

