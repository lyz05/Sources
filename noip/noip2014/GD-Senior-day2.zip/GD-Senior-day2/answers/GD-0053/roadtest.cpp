#include <cstdio>
#include <cstdlib>
#include <cstring>
using namespace std;
const long maxn=5000,maxm=200000;
long n,m,an=0,S,T;
//struct pat{long lh,to;} a[maxm+5],b[maxm+5];
long a[maxn+5][maxn+5],b[maxn+5][maxn+5];
bool ava[maxn+5];

void init(){
	long i,j,k;
	scanf("%ld%ld",&n,&m);
	for (i=1;i<=n;i++)
		for (j=1;j<=n;j++)
			a[i][j]=b[i][j]=-1;
	for (i=0;i<m;i++){
		scanf("%ld%ld",&j,&k);
		a[j][k]=b[j][k]=1;
	}
	scanf("%ld%ld",&S,&T);
	a[T][T]=0;
	memset(ava,1,sizeof(ava));
}
void floyd(){
	long i,j,k;
	for (k=1;k<=n;k++)
		for (i=1;i<=n;i++)
			if (k!=i&&a[i][k]>=0)
				for (j=1;j<=n;j++)
					if (k!=j&&i!=j&&a[k][j]>=0&&ava[k]&&ava[i]&&ava[j])
						if (a[i][j]<0||a[i][k]+a[k][j]<a[i][j])
							a[i][j]=a[i][k]+a[k][j];
}
void tr(){
	long i,j;
	floyd();
	for (i=1;i<=n;i++)
		for (j=1;j<=n;j++)
			if (b[i][j]>=0&&a[j][T]<0){
				ava[i]=0;
				break;
			}
	if (!ava[S]){
		printf("-1");
		return;
	}
	for (i=1;i<=n;i++)
		for (j=1;j<=n;j++)
			a[i][j]=b[i][j];
	floyd();
	if (a[S][T]<0)
		printf("-1");
	else printf("%ld",a[S][T]);
}
int main(){
	freopen("road.in","r",stdin);
	freopen("roadtest.out","w",stdout);
	init();
	tr();
	fclose(stdin);
	fclose(stdout);
	return 0;
}

