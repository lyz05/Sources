#include <cstdio>
#include <cstdlib>
#include <cstring>
using namespace std;
const long maxl=203;
long n,m;
bool f[1000005];
struct hi{
	long a[2*maxl+5];
	bool z;
	void ge(){
		char c;
		long i=0,j,t;
		memset(a,0,sizeof(a));
		scanf("%c",&c);
		if (c=='-'){
			z=0;
			scanf("%c",&c);
		}else z=1;
		for (;c>='0'&&c<='9';scanf("%c",&c)){
			a[i]=c-'0';
			i++;
		}
		if (c!='\n') scanf("\n");
		for (j=0;j+j<i;j++){
			t=a[j]; a[j]=a[i-j-1]; a[i-j-1]=t;
		}
	}
	void g0(){
		z=1;
		memset(a,0,sizeof(a));
	}
	void g1(){
		z=1;
		memset(a,0,sizeof(a));
		a[0]=1;
	}
	void operator *=(long k){
		long j=0;
		for (long i=0;i<maxl;i++){
			a[i]=a[i]*k+j;
			j=a[i]/10;
			a[i]%=10;
		}
	}
	hi operator *(hi b){
		hi c;
		memset(c.a,0,sizeof(c.a));
		long i,j;
		for (i=0;i<maxl;i++)
			for (j=0;j<maxl;j++){
				c.a[i+j]+=a[i]*b.a[j];
				c.a[i+j+1]+=c.a[i+j]/10;
				c.a[i+j]%=10;
			}
		return c;
	}
	void operator +=(hi b){
		long i;
		for (i=0;i<maxl;i++){
			a[i]+=b.a[i];
			a[i+1]+=a[i]/10;
			a[i]%=10;
		}
	}
	hi operator +(hi b){
		hi c;
		memset(c.a,0,sizeof(c.a));
		long i;
		for (i=0;i<maxl;i++){
			c.a[i]+=a[i]+b.a[i];
			c.a[i+1]=c.a[i]/10;
			c.a[i]%=10;
		}
		return c;
	}
	bool operator ==(hi b){
		for (long i=0;i<maxl;i++)
			if (a[i]!=b.a[i])
				return 0;
		return 1;
	}
}x[105];
void init(){
	long i;
	scanf("%ld%ld\n",&n,&m);
	for (i=0;i<=n;i++)
		x[i].ge();
}
bool check(long k){
	long i;
	hi s1,s2,t;
	s1.g0(); s2.g0(); t.g1();
	for (i=0;i<=n;i++){
		if (x[i].z)
			s1=s1+x[i]*t;
		else s2+=x[i]*t;
		t*=k;
	}
	return s1==s2;
}
void tr(){
	long i,ans=0;
	memset(f,0,sizeof(f));
	for (i=1;i<=m;i++)
		if (check(i)){
			f[i]=1;
			ans++;
			if (ans==n) break;
		}
	printf("%ld\n",ans);
	for (i=1;i<=m;i++)
		if (f[i])
			printf("%ld\n",i);
}
int main(){
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	init();
	tr();
	fclose(stdin);
	fclose(stdout);
	return 0;
}

