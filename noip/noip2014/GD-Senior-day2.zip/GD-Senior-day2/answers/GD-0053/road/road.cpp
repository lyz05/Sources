#include <cstdio>
#include <cstdlib>
#include <cstring>
using namespace std;
const long maxn=10000,maxm=200000;
long n,m,an=0,S,T,ah[maxn+5],bh[maxn+5];
struct pat{long lh,to;} a[maxm+5],b[maxm+5];
long d[maxn+5];
bool ava[maxn+5];

void add(long x,long y){
	an++;
	a[an].to=y; a[an].lh=ah[x]; ah[x]=an;
	b[an].to=x; b[an].lh=bh[y]; bh[y]=an;
}
void init(){
	long i,j,k;
	scanf("%ld%ld",&n,&m);
	for (i=1;i<=n;i++)
		ah[i]=bh[i]=0;
	for (i=0;i<m;i++){
		scanf("%ld%ld",&j,&k);
		add(j,k);
	}
	scanf("%ld%ld",&S,&T);
	memset(ava,1,sizeof(ava));
}
void SPFa(pat *c,long *ch,long ss){
	long P,p=0,q=1,i,t,Q[maxn+5];
	bool f[maxn+5];
	memset(f,0,sizeof(f));
	for (i=1;i<=n;i++) d[i]=-1;
	Q[0]=ss; f[ss]=1; d[ss]=0;
	while (p!=q){
		P=Q[p];
		for (i=ch[P];i>0;i=c[i].lh){
			t=c[i].to;
			if (!ava[t]) continue;
			if (d[P]+1<d[t]||d[t]<0){
				d[t]=d[P]+1;
				if (!f[t]){
					f[t]=1;
					Q[q]=t;
					q=(q+1)%n;
				}
			}
		}
		f[P]=0;
		p=(p+1)%n;
	}
}
void tr(){
	long i,j;
	SPFa(b,bh,T);
	for (i=1;i<=n;i++)
		for (j=ah[i];j>0;j=a[j].lh)
			if (d[a[j].to]<0){
				ava[i]=0;
				break;
			}
	if (!ava[S]){
		printf("-1");
		return;
	}
	SPFa(a,ah,S);	
	if (d[T]<0)
		printf("-1");
	else printf("%ld",d[T]);
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	init();
	tr();
	fclose(stdin);
	fclose(stdout);
	return 0;
}

