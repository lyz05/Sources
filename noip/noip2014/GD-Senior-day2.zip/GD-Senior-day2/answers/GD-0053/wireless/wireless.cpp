#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
using namespace std;
long n,R;
struct xxx{long x,y,s;}a[25];
void init(){
	long i;
	scanf("%ld%ld",&R,&n);
	for (i=0;i<n;i++)
		scanf("%ld%ld%ld",&(a[i].x),&(a[i].y),&(a[i].s));
}
void tr(){
	long i,j,k,s,ans=0,ansh=1;
	for (i=0;i<=128;i++)
		for (j=0;j<=128;j++){
			s=0;
			for (k=0;k<n;k++)
				if (abs(a[k].x-i)<=R&&abs(a[k].y-j)<=R)
					s+=a[k].s;
			if (s>ans){
				ans=s;
				ansh=1;
			}else if (s==ans)
				ansh++;
		}
	printf("%ld %ld",ansh,ans);
}
int main(){
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	init();
	tr();
	fclose(stdin);
	fclose(stdout);
	return 0;
}

