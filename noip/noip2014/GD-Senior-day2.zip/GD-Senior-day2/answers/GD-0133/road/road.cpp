#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;

#define N 10000+10
#define M 200000+10
struct Nodetype
{
	int node;
	Nodetype *next;
}*a[N],*b[N],*q,*p;

bool bz[N],B[N];
int d[2*M][3];
int n,m,s,t;

void link1(int x,int y)
{
	p=new Nodetype;
	p->node=y;
	p->next=a[x];
	a[x]=p;
}

void link2(int x,int y)
{
	q=new Nodetype;
	q->node=y;
	q->next=b[x];
	b[x]=q;
}

void Pre()
{
	int i=0,j=1;
	d[1][1]=t;
	bz[t]=1;
	while(i<j)
	{
		i++;
		int now=d[i][1];
		q=b[now];
		while(q)
		{
			if(!bz[q->node])
			{
				bz[q->node]=1;
				d[++j][1]=q->node;
			}
			q=q->next;
		}
	}
	for(int i=1;i<=n;i++)
	{
		if(!bz[i]) continue;
		p=a[i];
		B[i]=1;
		while(p)
		{
			if(!bz[p->node])
			{
				B[i]=0;
				break;
			}
			p=p->next;
		}
	}
}

int BFS()
{
	int i=0,j=1;
	d[1][1]=s;
	d[1][2]=0;
	bz[s]=1;
	if(s==t&&B[s]) return 0;
	while(i<j)
	{
		i++;
		int now=d[i][1];
		p=a[now];
		while(p)
		{
			if(!bz[p->node]&&B[p->node])
			{
				bz[p->node]=1;
				d[++j][1]=p->node;
				d[j][2]=d[i][2]+1;
				if(p->node==t) return d[j][2];
			}
			p=p->next;
		}
	}
	return -1;
}

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		if(x==y) continue;
		link1(x,y);
		link2(y,x);
	}
	scanf("%d%d",&s,&t);
	Pre();
	memset(bz,0,sizeof(bz));
	printf("%d\n",BFS());
	return 0;
}
