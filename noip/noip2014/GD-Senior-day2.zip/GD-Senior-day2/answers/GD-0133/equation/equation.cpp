#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;

#define N 100+10
#define M 10000+10
const int MO=1000000000;
typedef long long LL;
struct Htype
{
	int l,num[1200];
	void clear() { memset(num,0,sizeof(num)); l=0; }
}a[N],T[N];

char s[M];
int ans[N];
int n,m,tot=0;

int Max(int a,int b) {return a > b ? a : b ;}

void Swap(Htype *a,Htype *b) {Htype t=*a; *a=*b; *b=t;}

bool operator < (Htype a,Htype b)
{
	if(a.l<b.l) return 1;
	if(a.l>b.l) return 0;
	for(int i=a.l;i>=1;i--)
	{
		if(a.num[i]<b.num[i]) return 1;
		if(a.num[i]>b.num[i]) return 0;
	}
	return 0;
}

Htype operator * (Htype a,Htype b)
{
	Htype c;
	c.clear();
	if(!a.num[0]||!b.num[0]) c.num[0]=0;
	else c.num[0]=1;
	for(int i=1;i<=a.l;i++)
	{
		for(int j=1;j<=b.l;j++)
		{
			c.num[i+j]+=((LL)c.num[i+j-1]+(LL)a.num[i]*b.num[j])/MO;
			c.num[i+j-1]=((LL)c.num[i+j-1]+(LL)a.num[i]*b.num[j])%MO;
		}
	}
	c.l=a.l+b.l;
	while(c.l>0&&c.num[c.l]<=0) c.l--;
	return c;
}

Htype operator - (Htype a,Htype b)
{
	Htype c;
	c.clear();
	if(a<b) c.num[0]=0,Swap(&a,&b);
	else c.num[0]=1;
	for(int i=1;i<=a.l;i++)
	{
		if(i>b.l) b.num[i]=0;
		c.num[i]+=a.num[i]-b.num[i];
		if(c.num[i]<0)
		{
			c.num[i]+=MO;
			c.num[i+1]--;
		}
	}
	c.l=a.l;
	while(c.l>0&&c.num[c.l]<=0) c.l--;
	return c;
}

Htype operator + (Htype a,Htype b)
{
	int L=Max(a.l,b.l);
	Htype c;
	c.clear();
	if(!a.num[0]&&b.num[0]) return b-a;
	if(!b.num[0]&&a.num[0]) return a-b;
	if(!a.num[0]&&!b.num[0]) c.num[0]=0;
	else c.num[0]=1;
	for(int i=1;i<=L;i++)
	{
		c.num[i+1]+=((LL)a.num[i]+b.num[i])/MO;
		c.num[i]+=((LL)a.num[i]+b.num[i])%MO;
	}
	if(c.num[L+1]>0) L++;
	c.l=L;
	return c;
}

void turn(int k)
{
	int st=0,l=strlen(s);
	if(s[0]=='-') st=1,a[k].num[0]=0;
	else a[k].num[0]=1;
	a[k].l=0;
	for(int i=l-1;i>=st;i-=9)
	{
		int x=s[max(st,i-8)]-'0';
		for(int j=max(st,i-8)+1;j<=i;j++) x=x*10+(s[j]-'0');
		a[k].num[++a[k].l]=x;
	}
}

void make(int x)
{
	Htype t;
	t.num[0]=1;
	t.num[1]=x;
	t.l=1;
	T[1]=t;
	for(int i=2;i<=n;i++) T[i]=T[i-1]*t;
}

int main()
{
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=0;i<=n;i++)
	{
		scanf("%s",s);
		turn(i);
	}
	Htype t;
	for(int i=1;i<=m;i++)
	{
		make(i);
		t=a[0];
		for(int j=1;j<=n;j++) t=t+(a[j]*T[j]);
		if(t.l==0) ans[++tot]=i;
	}
	printf("%d\n",tot);
	for(int i=1;i<=tot;i++) printf("%d\n",ans[i]);
	return 0;
}
