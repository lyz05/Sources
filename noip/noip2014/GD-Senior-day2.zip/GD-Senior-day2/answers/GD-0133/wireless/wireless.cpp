#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;

#define N 200+10

int row[N][N],map[N][N];
int d,n,ans=0,Maxans=0,Maxx=0,Maxy=0;

int main()
{
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	scanf("%d%d",&d,&n);
	memset(row,0,sizeof(row));
	for(int i=1;i<=n;i++)
	{
		int x,y,z;
		scanf("%d%d%d",&x,&y,&z);
		x++; y++;
		map[x][y]=z;
		if(x>Maxx) Maxx=x;
		if(y>Maxy) Maxy=y;
	}
	for(int i=1;i<=Maxx+d;i++)
	{
		for(int j=1;j<=Maxy+d;j++)
		{
			row[i][j]=row[i][j-1]+map[i][j];
		}
	}
	for(int i=1+d;i<=Maxx-d;i++)
	{
		for(int j=1+d;j<=Maxy-d;j++)
		{
			int left=j-d,right=j+d,tot=0;
			for(int k=i-d;k<=i+d;k++) tot+=row[k][right]-row[k][left-1];
			if(tot>Maxans) Maxans=tot,ans=1;
			else if(tot==Maxans) ans++;
		}
	}
	printf("%d %d\n",ans,Maxans);
	return 0;
}
