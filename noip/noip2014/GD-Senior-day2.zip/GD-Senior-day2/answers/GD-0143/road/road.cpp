#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <string>
#include <iostream>
#include <set>
#include <map>
#include <queue>
#include <stack>
#include <vector>
#include <bitset>
using namespace std;

typedef pair<int,int> pii;
#define ll long long
#define dou double
#define st first
#define nd second
#define For(_i,a,b) for (int _i=(a),_n=(b); _i<=_n; _i++)
#define Rof(_i,a,b) for (int _i=(a),_n=(b); _i>=_n; _i--)
#define mp make_pair
#define mpii make_pair<int,int>
#define Mem(a,b) memset(a,b,sizeof(a))
#define Cpy(a,b) memcpy(a,b,sizeof(b))

const int maxn=10000+100,maxm=200000+100;
struct Edge
{
	int node,next;
	Edge() { node=next=0; }
	Edge(int a,int b) { node=a,next=b; }
}E[maxm*2];
int N,M,fre,head[maxn],Rh[maxn],o[maxn],dep[maxn];
int S,T;
bool boo[maxn];

void add_Edge(int x,int y,int *h)
{
	E[fre]=Edge(y,h[x]),h[x]=fre++;
}
void Prepare()
{
	Mem(dep,255);
	int h=1,t=1; o[1]=T; dep[T]=0;
	for (; h<=t; h++)
	{
		int x=o[h];
		for (int i=Rh[x]; i!=-1; i=E[i].next)
		{
			int y=E[i].node;
			if (dep[y]!=-1) continue;
			dep[y]=dep[x]+1; o[++t]=y;
		}
	}
	For(x,1,N)
	{
		boo[x]=true;
		for (int i=head[x]; i!=-1; i=E[i].next)
		{
			int y=E[i].node;
			if (dep[y]==-1) { boo[x]=false; break; }
		}
	}
}
int Done()
{
	if (!boo[S]) return -1;
	Mem(dep,255);
	int h=1,t=1; o[1]=S; dep[S]=0;
	for (; h<=t; h++)
	{
		int x=o[h];
		for (int i=head[x]; i!=-1; i=E[i].next)
		{
			int y=E[i].node;
			if (!boo[y] || dep[y]!=-1) continue;
			dep[y]=dep[x]+1; o[++t]=y;
		}
	}
	return dep[T];
}
void work()
{
	fre=0; Mem(head,255); Mem(Rh,255);
	For(i,1,M)
	{
		int x,y; scanf("%d%d",&x,&y);
		add_Edge(x,y,head);
		add_Edge(y,x,Rh);
	}
	scanf("%d%d",&S,&T);
	Prepare();
	printf("%d\n",Done());
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	
	scanf("%d%d",&N,&M); 
	work();
	
	return 0;
}

