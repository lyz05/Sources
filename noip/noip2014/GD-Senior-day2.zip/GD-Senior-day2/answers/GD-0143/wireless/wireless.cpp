#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <cmath>
#include <algorithm>
#include <string>
#include <iostream>
#include <set>
#include <map>
#include <queue>
#include <stack>
#include <vector>
#include <bitset>
using namespace std;

typedef pair<int,int> pii;
#define ll long long
#define dou double
#define st first
#define nd second
#define For(_i,a,b) for (int _i=(a),_n=(b); _i<=_n; _i++)
#define Rof(_i,a,b) for (int _i=(a),_n=(b); _i>=_n; _i--)
#define mp make_pair
#define mpii make_pair<int,int>
#define Mem(a,b) memset(a,b,sizeof(a))
#define Cpy(a,b) memcpy(a,b,sizeof(b))

const int maxn=200+10;
int N,M,Q,A[maxn][maxn],Ans,Num,D;

void Done(int sx,int sy)
{
	int ret=0;
	int fir=max(1,sy-D),sec=min(M,sy+D);
	For(i,max(1,sx-D),min(N,sx+D))
	{
		ret+=A[i][sec]-A[i][fir-1];
	}
	if (ret>Num) Ans=1,Num=ret;
	 else if (ret==Num) Ans++;
}
void work()
{
	N=129,M=129;
	scanf("%d",&Q);
	Mem(A,0);
	For(i,1,Q)
	{
		int x,y,k;
		scanf("%d%d%d",&x,&y,&k);
		x++,y++;
		A[x][y]+=k;
	}
	For(i,1,N) For(j,1,M) A[i][j]+=A[i][j-1];
	Ans=0,Num=0;
	For(i,1,N) For(j,1,M) Done(i,j);
	printf("%d %d\n",Ans,Num);
}
int main()
{
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	
	scanf("%d",&D);
	work();
	
	return 0;
}

