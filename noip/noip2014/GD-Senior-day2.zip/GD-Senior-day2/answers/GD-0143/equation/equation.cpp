#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <string>
#include <iostream>
#include <set>
#include <map>
#include <queue>
#include <stack>
#include <vector>
#include <bitset>
using namespace std;

typedef pair<int,int> pii;
#define ll long long
#define dou double
#define st first
#define nd second
#define For(_i,a,b) for (int _i=(a),_n=(b); _i<=_n; _i++)
#define Rof(_i,a,b) for (int _i=(a),_n=(b); _i>=_n; _i--)
#define mp make_pair
#define mpii make_pair<int,int>
#define Mem(a,b) memset(a,b,sizeof(a))
#define Cpy(a,b) memcpy(a,b,sizeof(b))

struct Hashh
{
	int n,*p,*a;
	Hashh() { n=0; p=NULL; a=NULL; }
	Hashh(int x) { n=x; p=new int[x+2]; For(i,0,n-1) p[i]=0; }
	void init(int x) 
	{ 
		n=x; 
		p=new int[x+2]; 
		a=new int[105];
		For(i,0,n-1) p[i]=0;
	}
}H[20+2];
int N,M,T;
char cs[10000+100];
bool boo[1000*1000+10];

void Prepare()
{
	T=15;
	H[0].init(2);
	H[1].init(3);
	H[2].init(97);
	H[3].init(283);
	H[4].init(409);
	H[5].init(577);
	H[6].init(619);
	H[7].init(761);
	H[8].init(881);
	H[9].init(983);
	H[10].init(1093);
	H[11].init(2503);
	H[12].init(4099);
	H[13].init(7603);
	H[14].init(9067);
}
void Init()
{
	For(k,0,N)
	{
		scanf("%s",cs+1);
		int len=strlen(cs+1);
		if (cs[1]=='-')
		{
			For(i,0,T-1)
			{
				int ret=0,s=1;
				int modd=H[i].n;
				Rof(j,len,2)
				{
					ret=(ret+s*(cs[j]-48)) % modd;
					s=(s*10) %modd;
				}
				H[i].a[k]=modd-ret;
			}
		}
		else
		{
			For(i,0,T-1)
			{
				int ret=0,s=1;
				int modd=H[i].n;
				Rof(j,len,1)
				{
					ret=(ret+s*(cs[j]-48)) %modd;
					s=(s*10) %modd;
				}
				H[i].a[k]=ret;
			}
		}
	}
}
bool Done(int pp)
{
	For(i,0,T-1)
	{
		int modd=H[i].n;
		int x=pp % modd;
		if (H[i].p[x]==-1) return false;
		if (H[i].p[x]==1) continue;
		int ret=0,s=1;
		For(k,0,N)
		{
			ret=(ret+s*H[i].a[k]) %modd;
			s=(s*x) %modd;
		}
		ret=(ret %modd+modd) %modd;
		if (ret!=0) { H[i].p[x]=-1; return false; }
		 else H[i].p[x]=1;
	}
	return true;
}
void work()
{
	Prepare();
	Init();
	For(i,1,M) boo[i]=true;
	For(i,1,M) boo[i]=Done(i);
	int ans=0;
	For(i,1,M) if (boo[i]) ans++;
	printf("%d\n",ans);
	For(i,1,M) if (boo[i]) printf("%d\n",i);
}

int main()
{
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	
	scanf("%d%d",&N,&M); 
	work();
	
	return 0;
}

