#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<ctime>
#include<algorithm>
#define rep(i,j,k) for (i=j;i<=k;i++)
#define reps(i,j,k) for (i=j;i>=k;i--)
#define mem(a,b) memset(a,b,sizeof(a))
#define maxn 111
using namespace std;
int n,m,a[maxn],ans,sta[maxn],top;
int calc(int x)
{
	int ret=0,now=1,i,j,k;
	rep(i,0,n)
	{
		ret+=a[i]*now;
		now*=x;
	}
	return ret;
}
int main()
{
	freopen("equation.in","r",stdin);freopen("equation.out","w",stdout);
	int i,j,k;
	scanf("%d%d",&n,&m);
	rep(i,0,n)
	{
		scanf("%d",&a[i]);
	}
	top=0;
	rep(i,1,m)
	{
		if (calc(i)==0)sta[++top]=i;
	}
	printf("%d\n",top);
	rep(i,1,top)
	{
		printf("%d\n",sta[i]);
	}
	return 0;
}

