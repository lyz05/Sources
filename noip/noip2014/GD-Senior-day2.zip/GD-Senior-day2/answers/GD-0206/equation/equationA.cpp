#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<ctime>
#include<algorithm>
#define rep(i,j,k) for (i=j;i<=k;i++)
#define reps(i,j,k) for (i=j;i>=k;i--)
#define mem(a,b) memset(a,b,sizeof(a))
using namespace std;
typedef long long LL;
const LL oo=1000000000;
struct node
{
	LL num[1500];int len,bo; 
	void init()
	{
		mem(num,0);len=bo=1;
	}
}a[110],zero,C,xpow,ans,temp,temp1,temp2,temp3,temp4;
char ch[11000];
int n,m,data[11000],len,top;
int cmp(const node &A,const node &B)
{
	int i,j,k;
	if (A.bo&&!B.bo)return 1;
	if (!A.bo&&B.bo) return -1;
	if (A.bo&&A.len>B.len||!A.bo&&A.len<B.len)return 1;
	if (A.bo&&A.len<B.len||!A.bo&&A.len>B.len)return -1;
	if (A.bo)
	{
		reps(i,A.len,1)if (A.num[i]>B.num[i]) return 1;
		else if (A.num[i]<B.num[i]) return -1;
	}
	else
	{
		reps(i,A.len,1)if (A.num[i]>B.num[i]) return -1;
		else if (A.num[i]<B.num[i]) return 1;	
	}
	return 0;
}
int cmp1(const node &A,const node &B)
{
	int i,j,k;
	if (A.len>B.len)return 1;
	if (A.len<B.len)return -1;
	reps(i,A.len,1)if (A.num[i]>B.num[i])return 1;
	else if (A.num[i]<B.num[i])return -1;
	return 0;
}
void change(int x)
{
	int i,j,k;
	C.init();C.len=0;
	top=0;
	while(x>0)
	{
		data[++top]=x%10;
		x/=10;
	}
	int now=0;
	LL ten=1,nn=0;
	rep(i,1,top)
	{
		now++;
		nn+=ten*data[i];
		ten*=10;
		if (now==9)
		{
			C.num[++C.len]=nn;
			nn=0;ten=1;now=0;
		}
	}
	if (now!=0)C.num[++C.len]=nn;
}
node cheng(const node &A,const node &B)
{
	int i,j,k;
	temp1.init();temp1.len=A.len+B.len-1;temp1.bo=A.bo&B.bo;
	rep(i,1,A.len)
		rep(j,1,B.len)
		temp1.num[i+j-1]+=A.num[i]*B.num[j];
	rep(i,1,temp1.len)
	{
		temp1.num[i+1]+=temp1.num[i]/oo;
		temp1.num[i]%=oo;
	}
	while(temp1.num[temp1.len+1]>0)
	{
		temp1.len++;
		temp1.num[temp1.len+1]+=temp1.num[temp1.len]/oo;
		temp1.num[temp1.len]%=oo;
	}
	return temp1;
}
node jia(const node &A,const node &B)
{
	int i,j,k;
	temp2.init();
	temp2.len=max(A.len,B.len);
	temp2.bo=A.bo;
	rep(i,1,temp2.len)
	{
		temp2.num[i]+=A.num[i]+B.num[i];
		temp2.num[i+1]+=temp2.num[i]/oo;
		temp2.num[i]%=oo;
	}
	while(temp2.num[temp2.len+1]>0)
	{
		temp2.len++;
		temp2.num[temp2.len+1]+=temp1.num[temp2.len]/oo;
		temp2.num[temp2.len]%=oo;
	}
	return temp2;
}
node jian(const node &A,const node &B)
{
	int i,j,k;
	temp2.init();
	temp2.len=A.len;
	rep(i,1,temp2.len)
	{
		temp2.num[i]+=A.num[i]-B.num[i];
		if (temp2.num[i]<0)
		{
			temp2.num[i]+=oo;
			temp2.num[i+1]--;
		}
	}
	while(temp2.num[temp2.len]==0&&temp2.len>=2)temp2.len--;
	return temp2;
}
node Jia(node &A,const node &B)
{
	if (A.bo&&B.bo) return jia(A,B);
	if (!A.bo&&!B.bo) return jia(A,B);
	if (A.bo&&!B.bo)
	{
		if (cmp1(A,B)>=0){temp3=jian(A,B);temp3.bo=1;}
		else {temp3=jian(B,A);temp3.bo=0;}
		return temp3;
	}
	else 
	{
		if (cmp1(A,B)>0){temp3=jian(A,B);temp3.bo=0;}
		else {temp3=jian(B,A);temp3.bo=1;}
		return temp3;
	}
}
node calc(int x)
{
	int i,j,k;
	change(x);
	xpow.len=xpow.bo=1;xpow.num[1]=1;
	ans.init();
	rep(i,0,n)
	{
		temp=cheng(xpow,a[i]);
		xpow=cheng(xpow,C);
		temp4=Jia(ans,temp);
		ans=temp4;
	}
	return ans;
}
int div2(int l,int r,int h)
{
	if (l>r)return -1;
	if (h==1&&cmp(calc(l),zero)>0)return -1;
	if (h==0&&cmp(calc(l),zero)<0)return -1;
	int ans=-1;
	while(l<=r)
	{
		int mid=(l+r)/2;int res=cmp(calc(mid),zero);
		if (res==0){ans=mid;break;}
		if (res==1&&h==1||res==-1&&h==0)r=mid-1;
		else l=mid+1;
	}
	return ans;
}
int div3(int l,int r)
{
	if (l>r) return -1;
	while(l+1<r)
	{
		int mid1,mid2;
		mid1=l+(r-l+1)/3;mid2=r-(r-l+1)/3;
		int res=cmp(calc(mid1),calc(mid2));
		if (res==0)
		{
			l=mid1;r=mid2;
		}
		else if (a[n].bo==1)
		{
			if (res==1)l=mid1;
			else r=mid2;
		}
		else
		{
			if (res==1)r=mid2;
			else l=mid1;
		}
	}
	return l;
}
void solve()
{
	int i,j,k;
	if (n%2==1)
	{
		int x=div2(1,m,a[n].bo);
		if (x==-1)
		printf("0\n");
		else
		{
			printf("1\n%d\n",x);
		}
	}
	else
	{
		int s=div3(1,m);
		int x=div2(1,s-1,!a[n].bo);
		int y=div2(s+1,m,a[n].bo);
		int res=cmp(calc(s),zero);
		top=0;
		if (x!=-1)data[++top]=x;
		if (res==0)data[++top]=s;
		if (y!=-1)data[++top]=y;
		printf("%d\n",top);
		rep(i,1,top)
		{
			printf("%d\n",data[i]);
		}
	}
}
int main()
{
	freopen("equation.in","r",stdin);freopen("equation.out","w",stdout);
	int i,j,k;
	scanf("%d%d",&n,&m);
	rep(i,0,n)
	{
		scanf("%s",ch);
		int st=0,fu=1;
		if (ch[0]=='-'){fu=0;st=1;}
		len=0;
		for (j=st;ch[j];j++)
		{
			data[++len]=ch[j]-'0';
		}
		int now=0;LL nn=0,ten=1;
		a[i].len=0;
		reps(j,len,1)
		{
			now++;
			nn=nn+data[j]*ten;
			ten*=10;
			if (now==9)
			{
				a[i].num[++a[i].len]=nn;
				now=0;
				nn=0;ten=1;
			}
		}
		if (now!=0)
		a[i].num[++a[i].len]=nn;
		if (a[i].len==0)a[i].len=1;
		a[i].bo=fu;
	}
	zero.len=1;mem(zero.num,0);zero.bo=1;
	solve();
	return 0;
}

