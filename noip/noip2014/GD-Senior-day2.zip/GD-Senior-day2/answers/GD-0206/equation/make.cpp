#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<ctime>
#include<algorithm>
#define rep(i,j,k) for (i=j;i<=k;i++)
#define reps(i,j,k) for (i=j;i>=k;i--)
#define mem(a,b) memset(a,b,sizeof(a))
using namespace std;
typedef long long LL;
int main()
{
	freopen("equation.in","w",stdout);
	int i,j,k;
	srand(time(0));
	int n=rand()%3+1,m=rand()%100+1;
	printf("%d %d\n",n,m);
	rep(i,0,n)
	{
		int x=rand()%20-10;
		if (i==n&&x==0)
		{
			int y=rand()%2;
			if (y==0)x++;
			else x--;
		}
		printf("%d\n",x);
	}
	return 0;
}

