#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<ctime>
#include<algorithm>
#define rep(i,j,k) for (i=j;i<=k;i++)
#define reps(i,j,k) for (i=j;i>=k;i--)
#define mem(a,b) memset(a,b,sizeof(a))
#define maxn 11000
#define maxm 210000
using namespace std;
struct node
{
	int y,next;
}edge[maxm],edge1[maxn];
int n,m,first[maxn],len,sta[maxn],first1[maxn],st,ed,head,tail,dis[maxn];
bool bo[maxn],bo1[maxn];
void ins(int x,int y)
{
	edge[++len].y=y;edge[len].next=first[x];first[x]=len;
}
void ins1(int x,int y)
{
	edge1[len].y=y;edge1[len].next=first1[x];first1[x]=len;
}
void bfs()
{
	int i,j,k;
	mem(bo,false);
	sta[head=tail=1]=ed;
	bo[ed]=true;
	while(head<=tail)
	{
		int x=sta[head];
		for (k=first1[x];k!=-1;k=edge1[k].next)
		{
			int y=edge1[k].y;
			if (!bo[y])
			{
				bo[y]=true;
				sta[++tail]=y;
			}
		}
		head++;
	}
	mem(bo1,true);
	rep(i,1,n)
	{
		if (!bo[i])bo1[i]=false;
		int x=i;
		for (k=first[x];k!=-1;k=edge[k].next)
		{
			int y=edge[k].y;
			if (!bo[y]){bo1[x]=false;break;}
		}
	}
}
void dfs(int x,int len)
{
	int i,j,k;
	if (dis[x]!=-1&&dis[x]<len)return;
	if (dis[x]==-1||dis[x]>len)dis[x]=len;
	if (x==ed)return;
	for (k=first[x];k!=-1;k=edge[k].next)
	{
		int y=edge[k].y;
		if (bo1[y])dfs(y,len+1);
	}
}
int main()
{
	int i,j,k;
	freopen("road.in","r",stdin);freopen("road.ans","w",stdout);
	scanf("%d%d",&n,&m);
	mem(first,-1);len=0;mem(first1,-1);
	rep(i,1,m)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		ins(x,y);ins1(y,x);
	}
	scanf("%d%d",&st,&ed);
	bfs();
	if (!bo1[st]){printf("-1\n");return 0;}
	mem(dis,-1);
	dfs(st,0);
	printf("%d\n",dis[ed]);
	return 0;
}

