#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<ctime>
#include<algorithm>
#define rep(i,j,k) for (i=j;i<=k;i++)
#define reps(i,j,k) for (i=j;i>=k;i--)
#define mem(a,b) memset(a,b,sizeof(a))
#define maxn 11000
#define maxm 210000
using namespace std;
int main()
{
	freopen("road.in","w",stdout);
	srand(time(0));
	int n=rand()%20+1,m=rand()%50+1,i,j,k;
	printf("%d %d\n",n,m);
	rep(i,1,m)
	{
		int x,y;
		x=rand()%n+1;y=rand()%n+1;
		printf("%d %d\n",x,y);
	}
	int st,ed;
	st=rand()%n+1;ed=rand()%n+1;
	printf("%d %d\n",st,ed);
	return 0;
}
