#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<ctime>
#include<algorithm>
#define rep(i,j,k) for (i=j;i<=k;i++)
#define reps(i,j,k) for (i=j;i>=k;i--)
#define mem(a,b) memset(a,b,sizeof(a))
#define maxn 101
using namespace std;
int main()
{
	freopen("wireless.in","w",stdout);
	srand(time(0));
	int d,n,i,j,k;
	d=rand()%20+1;n=rand()%20+1;
	printf("%d\n%d\n",d,n);
	rep(i,1,n)
	{
		int x,y,h;
		x=rand()%129;y=rand()%129;h=rand()%1000+1;
		printf("%d %d %d\n",x,y,h);
	}
	return 0;
}
