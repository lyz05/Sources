#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<ctime>
#include<algorithm>
#define rep(i,j,k) for (i=j;i<=k;i++)
#define reps(i,j,k) for (i=j;i>=k;i--)
#define mem(a,b) memset(a,b,sizeof(a))
#define maxn 101
using namespace std;
int num[150][150],ans,ans2,d,n;
int main()
{
	freopen("wireless.in","r",stdin);freopen("wireless.out","w",stdout);
	int i,j,k;
	scanf("%d%d",&d,&n);
	mem(num,0);
	rep(i,1,n)
	{
		int x,y,lx,ly,rx,ry,h;
		scanf("%d%d%d",&x,&y,&h);
		lx=x-d;rx=x+d;ly=y-d;ry=y+d;
		if (lx<0)lx=0;if (ly<0)ly=0;
		if (rx>128)rx=128;if (ry>128)ry=128;
		rep(j,lx,rx)
			rep(k,ly,ry)num[j][k]+=h;
	}
	ans=-1;ans2=0;
	rep(i,0,128)
		rep(j,0,128)
		{
			if (num[i][j]>ans)
			{
				ans=num[i][j];ans2=1;
			}
			else if (num[i][j]==ans)ans2++;
		}
	printf("%d %d\n",ans2,ans);
	return 0;
}

