#include<cstdio>
#include<cstring>
using namespace std;

const int N = 10005 , M = 200005;

#define fo(i , st , en) for (int i = st; i <= en; i++)
#define Me(x , y) memset(x , y , sizeof(x))

struct _two{
	int a , b;
}edge[M] , aedge[N];

int n , m , s , t;
int st[N] , ast[N] , qu[N] , dis[N];
bool f1[N] , f2[N];

void bfs1(){
	int be = 0 , en = 1; qu[1] = t; f1[t] = 1;
	while (be < en){
		int x = qu[++be];
		for (int i = ast[x]; i; i = aedge[i].b)
			if (!f1[aedge[i].a]){
				f1[aedge[i].a] = 1; qu[++en] = aedge[i].a;
			}
	}
}

void Init(){
	scanf("%d%d" , &n , &m); int x , y;
	fo (i , 1 , m){
		scanf("%d%d" , &x , &y);
		edge[i] = (_two){y , st[x]}; st[x] = i;
		aedge[i] = (_two){x , ast[y]}; ast[y] = i;
	}
	scanf("%d%d" , &s , &t); bfs1();
	fo (i , 1 , n){
		f2[i] = 1;
		for (int j = st[i]; j; j = edge[j].b)
			if (!f1[edge[j].a]){
				f2[i] = 0; break;
			}
	}
		
}

void Work(){
	int be = 0 , en = 0; Me(dis , 0);
	if (f2[s]){
		qu[++en] = s; dis[s] = 1;
	}
	while (be < en){
		int x = qu[++be];
		for (int i = st[x]; i; i = edge[i].b)
			if (!dis[edge[i].a] && f2[edge[i].a]){
				dis[edge[i].a] = dis[x] + 1; qu[++en] = edge[i].a;
			}
	}
	printf("%d\n" , dis[t] - 1);
}

int main(){
	freopen("road.in" , "r" , stdin);
	freopen("road.out" , "w" , stdout);
	Init();
	Work();
	return 0;
}

