#include<cstdio>
#include<cstring>
using namespace std;

const int N = 25;

#define fo(i , st , en) for (int i = st; i <= en; i++)
#define Me(x , y) memset(x , y , sizeof(x))

struct _three{
	int a , b , c;
}a[N];

int n , d;

void Init(){
	scanf("%d%d" , &d , &n);
	fo (i , 1 , n) scanf("%d%d%d" , &a[i].a , &a[i].b , &a[i].c);
}

int Calc(int i , int j){
	int sum = 0;
	fo (k , 1 , n)
		if (i - d <= a[k].a && a[k].a <= i + d)
			if (j - d <= a[k].b && a[k].b <= j + d)
				sum += a[k].c;
	return sum;
}

void Work(){
	int ans = 0 , num = 0;
	fo (i , 0 , 128)
		fo (j , 0 , 128){
			int sum = Calc(i , j);
			if (sum > ans){
				ans = sum; num = 0;
			}
			if (ans == sum) num++;
		}
	printf("%d %d\n" , num , ans);
}

int main(){
	freopen("wireless.in" , "r" , stdin);
	freopen("wireless.out" , "w" , stdout);
	Init();
	Work();
	return 0;
}

