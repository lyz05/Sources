#include<cstdio>
#include<cstring>
using namespace std;

const int N = 105 , M = 10005 , Ans = 1000005;

#define fo(i , st , en) for (int i = st; i <= en; i++)
#define fd(i , st , en) for (int i = st; i >= en; i--)
#define Me(x , y) memset(x , y , sizeof(x))

int n , m , sum;
char ch[M];
int a[N] , b[N] , c[N];
int ans[Ans];

void Init(){
	scanf("%d%d" , &n , &m);
	fo (i , 0 , n){
		scanf("%s" , ch + 1); int len = strlen(ch + 1);
		if (ch[1] != '-')
			fo (j , 1 , len) a[i] = a[i] * 10 + ch[j] - '0';
		else{
			fo (j , 2 , len) a[i] = a[i] * 10 + ch[j] - '0';
			a[i] = -a[i];
		}
	}
}

int Calc(int x){
	int sum = 0;
	fd (i , n , 0) sum = sum * x + a[i];
	return sum;
}

void Work(){
	fo (i , 0 , n) b[i] = Calc(i);
	fo (i , 0 , n){
		c[i] = b[0];
		fo (j , 0 , n - i - 1) b[j] = b[j + 1] - b[j];
	}
	fo (i , 1 , m){
		fo (j , 0 , n - 1) c[j] += c[j + 1];
		if (!c[0]) ans[++sum] = i;
	}
	printf("%d\n" , sum);
	fo (i , 1 , sum) printf("%d\n" , ans[i]);
}

int main(){
	freopen("equation.in" , "r" , stdin);
	freopen("equation.out" , "w" , stdout);
	Init();
	Work();
	return 0;
}
