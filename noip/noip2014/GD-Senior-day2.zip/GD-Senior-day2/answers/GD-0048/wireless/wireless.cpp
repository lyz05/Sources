#include<fstream>
using namespace std;
int lukou[129][129]={0};
int main()
{
	ifstream fin;
	ofstream fout;
	fin.open("wireless.in");
	fout.open("wireless.out");
	int d,n,x,y,k;    fin>>d>>n;
	for (int a=1;a<=n;a++)
	{
		fin>>x>>y>>k;
		lukou[x][y]=k;
	}
	int ansnum=0,ans=0,sum;
	for (int a=0;a<=128;a++)
	    for (int b=0;b<=128;b++)
	    {
	    	sum=0;
	    	for (int c=a-d;c<=a+d;c++)
	    	    for (int e=b-d;e<=b+d;e++)
	    	        if (c>=0&&e>=0&&c<=128&&e<=128)    {sum+=lukou[c][e];	}
	    	if (sum==ans)    {ansnum++;}
	    	if (sum>ans)    {ansnum=1;    ans=sum;}
	    }
	fout<<ansnum<<" "<<ans;
	fin.close();
	fout.close();
	return 0;
}
