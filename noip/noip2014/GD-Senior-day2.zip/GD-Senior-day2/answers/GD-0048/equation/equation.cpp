#include<fstream>
using namespace std;
int main()
{
	ifstream fin;
	ofstream fout;
	fin.open("equation.in");
	fout.open("equation.out");
	int n,m,sum,coutt=0;
	fin>>n>>m;
	if (n>2)    
	{
	    fout<<0<<endl;
		return 0;	
	}
	int a[3]={0};
	for (int b=0;b<=n;b++)    fin>>a[b];
	for (int x=1;x<=m;x++)
	{
		sum=a[0]+a[1]*x+a[2]*x*x;
		if (sum==0)    coutt++;
	}
	fout<<coutt<<endl;
	for (int x=1;x<=m;x++)
	{
		sum=a[0]+a[1]*x+a[2]*x*x;
		if (sum==0)    fout<<x<<endl;
	}
	fin.close();
	fout.close();
	return 0;
}
