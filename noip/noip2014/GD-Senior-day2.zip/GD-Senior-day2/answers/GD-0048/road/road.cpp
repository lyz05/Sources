#include<fstream>
using namespace std;
	int n,m,start,end;
	bool bians[101][101]={false};
	bool ifokk[101]={false};
	bool ifok[101]={false};
int main()
{
	ifstream fin;
	ofstream fout;
	fin.open("road.in");
	fout.open("road.out");
	fin>>n>>m;
	int discc[101][101],key,where;
	for (int a=1;a<=100;a++)
	for (int b=1;b<=100;b++)
	discc[a][b]=10000;
	for (int a=1;a<=m;a++)
	{
		fin>>start>>end;
		bians[end][start]=true;
		discc[end][start]=1;
	}
	fin>>start>>end;
	
	for (int c=1;c<=n;c++)
    {
	    for (int a=1;a<=n;a++)    
	        if (ifok[a]==false&&bians[end][a]==true) 
	        {
	        	for (int b=1;b<=n;b++)
	        	if (bians[a][b]==true)    bians[end][b]=true;
	        	ifok[a]=true;
	        }
	}
	for (int a=1;a<=n;a++)    bians[end][end]=true;
	for (int a=1;a<=n;a++)
	    if (bians[end][a]==false)
	        for (int b=1;b<=n;b++)
	            if (bians[a][b]==true)    bians[end][b]=false; 
    discc[end][end]=0;
    for (int b=1;b<=n;b++)
    {
	for (int a=1;a<=n;a++)
    fout<<discc[b][a]<<" ";
    fout<<endl;
    }
    for (int a=1;a<=n;a++)
    fout<<ifok[a]<<" ";
    fout<<endl;
	for (int c=1;c<=n;c++)
	{
		key=10000;
		for (int a=1;a<=n;a++)    
		    if (discc[end][a]<key&&ifokk[a]==false&&ifok[a]==true)    
			{
				key=discc[end][a];    where=a;
		    }
		    fout<<where<<" ";
		if (where==start)    break;
		ifokk[where]=true;
		for (int a=1;a<=n;a++)
		    if (discc[end][a]>discc[end][where]+discc[where][a]&&discc[where][a]!=0&&discc[end][where]!=0&&ifok[a]==true)    discc[end][a]=discc[end][where]+discc[where][a];
	}
	if (discc[end][start]==10000)    fout<<-1<<endl;
	else    fout<<discc[end][start]<<endl;
	fin.close();
	fout.close();
	return 0;
}
