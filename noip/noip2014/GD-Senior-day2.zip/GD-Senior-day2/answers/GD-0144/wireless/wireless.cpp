#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#define LL long long 
using namespace std;
const int n=129;
LL ans2,sum[200][200];
int d,N,ans1;

LL Sum(int ,int );
int main()
{
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	scanf("%d",&d);
	scanf("%d",&N);
	for (int i=0;i<N;i++)
	{
		int x,y,k;
		scanf("%d%d%d",&x,&y,&k);
		x++,y++;
		sum[x][y]+=k;
	}
	for (int i=1;i<=n;i++)
		for (int j=1;j<=n;j++)
		sum[i][j]+=sum[i-1][j]+sum[i][j-1]-sum[i-1][j-1];
	for (int i=1;i<=n;i++)
		for (int j=1;j<=n;j++)
		{
			LL tmp=Sum(i+d,j+d)-Sum(i-d-1,j+d)-Sum(i+d,j-d-1)+Sum(i-d-1,j-d-1);
			if (tmp==ans2) ans1++;
			if (tmp>ans2)
			{
				ans2=tmp;
				ans1=1;
			}
		}
	cout<<ans1<<' '<<ans2<<endl;
	return 0;
}
LL Sum(int x,int y)
{
	if (x<0) x=0;
	if (y<0) y=0;
	if (x>n) x=n;
	if (y>n) y=n;
	return sum[x][y];
}
