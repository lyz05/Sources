#include<algorithm>
#include<cstring>
#include<cstdlib>
#include<cstdio>
using namespace std;
const int maxm=1000000+10;
const int maxn=500+10;
char st[maxn];
struct Tnum
{
	int n,a[maxn];
	Tnum(){n=0,memset(a,0,sizeof(a));};
	friend Tnum operator + (const Tnum &A,const Tnum &B)
	{
		Tnum C=Tnum();
		if (A.n>B.n) C.n=A.n; else C.n=B.n;
		for (int i=1;i<=C.n;i++)
		{
			C.a[i+1]+=(C.a[i]+A.a[i]+B.a[i])/10;
			C.a[i]=(C.a[i]+A.a[i]+B.a[i])%10;
		}
		if (C.a[C.n+1]) C.n++;
		for (;(!C.a[C.n])&&C.n;C.n--);
		return C;
	}
	friend Tnum operator * (const Tnum &A,const Tnum &B)
	{
		Tnum C=Tnum();
		C.n=A.n+B.n-1;
		for (int i=1;i<=A.n;i++)
			for (int j=1;j<=B.n;j++)
			{
				C.a[i+j]+=(C.a[i+j-1]+A.a[i]*B.a[j])/10;
				C.a[i+j-1]=(C.a[i+j-1]+A.a[i]*B.a[j])%10;
			}
		if (C.a[C.n+1]) C.n++;
		for (;(!C.a[C.n])&&C.n;C.n--);
		return C;
	}
	bool Zero()
	{
		for (int i=1;i<=n;i++)
		if (a[i]) return false;
		return true;
	}
	void num(int N)
	{
		for (;N;N/=10)
		a[++n]=N%10;
		return ;
	}
	void in()
	{
		scanf("\n");
		scanf("%s",&st);
		if (st[0]=='-')
		{
			n=strlen(st)-1;
			for (int i=n;i>0;i--)
			a[i]=0-st[n-i+1]+'0';
		} else
		{
			n=strlen(st);
			for (int i=n;i>0;i--)
			a[i]=st[n-i]-'0';
		}
		return ;
	}
	void out()
	{
		for (int i=n;i>0;i--)
		printf("%d",a[i]);
		printf("\n");
		return ;
	}
} A[110];
struct TNum
{
	int n,a[maxn*20];
	TNum(){n=0,memset(a,0,sizeof(a));};
	friend TNum operator + (const TNum &A,const TNum &B)
	{
		TNum C=TNum();
		if (A.n>B.n) C.n=A.n; else C.n=B.n;
		for (int i=1;i<=C.n;i++)
		{
			C.a[i+1]+=(C.a[i]+A.a[i]+B.a[i])/10;
			C.a[i]=(C.a[i]+A.a[i]+B.a[i])%10;
		}
		if (C.a[C.n+1]) C.n++;
		for (;(!C.a[C.n])&&C.n;C.n--);
		return C;
	}
	friend TNum operator * (const TNum &A,const TNum &B)
	{
		TNum C=TNum();
		C.n=A.n+B.n-1;
		for (int i=1;i<=A.n;i++)
			for (int j=1;j<=B.n;j++)
			{
				C.a[i+j]+=(C.a[i+j-1]+A.a[i]*B.a[j])/10;
				C.a[i+j-1]=(C.a[i+j-1]+A.a[i]*B.a[j])%10;
			}
		if (C.a[C.n+1]) C.n++;
		for (;(!C.a[C.n])&&C.n;C.n--);
		return C;
	}
	bool Zero()
	{
		for (int i=1;i<=n;i++)
		if (a[i]) return false;
		return true;
	}
	void num(int N)
	{
		for (;N;N/=10)
		a[++n]=N%10;
		return ;
	}
	void in()
	{
		scanf("\n");
		scanf("%s",&st);
		if (st[0]=='-')
		{
			n=strlen(st)-1;
			for (int i=n;i>0;i--)
			a[i]=0-st[n-i+1]+'0';
		} else
		{
			n=strlen(st);
			for (int i=n;i>0;i--)
			a[i]=st[n-i]-'0';
		}
		return ;
	}
	void out()
	{
		for (int i=n;i>0;i--)
		printf("%d",a[i]);
		printf("\n");
		return ;
	}
} B;

int N,M,ans,p[maxm];
void work1();
void work2();
void work3();
bool ok(int );
int main()
{
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	scanf("%d%d",&N,&M);
	if (N<=2) work1();
		 else if (M<=100) work2();
		 else work3();
	printf("%d\n",ans);
	for (int i=0;i<ans;i++)
	printf("%d\n",p[i]);
	return 0;
}
void work1()
{
	int a[10];
	for (int i=0;i<=N;i++)
	scanf("%d",&a[i]);
	for (int i=1;i<=M;i++)
	{
		int tmp=0;
		int x=1;
		for (int j=0;j<=N;j++)
		{
			tmp=tmp+a[j]*x;
			x=x*i;
		}
		if (tmp==0) p[ans++]=i;
	}
	return ;
}
void work2()
{
	for (int i=0;i<=N;i++) A[i].in();
	for (int i=1;i<=M;i++)
	if (ok(i)) p[ans++]=i;
	return ;
}
void work3()
{
	TNum Sum=TNum();
	for (int i=0;i<=N;i++)
	{
		B.in();
		Sum=Sum+B;
	}
	if (Sum.Zero()) p[ans++]=1;
	return ;
}
bool ok(int x)
{
	Tnum tmp=A[0],P,X;
	P.num(x);
	X.num(x);
	for (int i=1;i<=N;i++)
	{
		tmp=tmp+A[i]*X;
		X=X*P;
	}
	return tmp.Zero();
}
