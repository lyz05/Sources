#include<algorithm>
#include<cstring>
#include<cstdlib>
#include<cstdio>
using namespace std;
const int maxm=200000+10;
const int maxn=10000+10;
int N,M,st,en,dist[maxn],f[maxn],g[maxm][2];
int fre,head[maxn],node[maxm],next[maxm];
bool flag[maxn];
void Clean();
void BFS(int );
void doit(int );
void add(int ,int );

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d%d",&N,&M);
	for (int i=0;i<M;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		g[i][0]=x,g[i][1]=y;
	}
	scanf("%d%d",&st,&en);
	Clean();
	for (int i=0;i<M;i++)
	add(g[i][1],g[i][0]);
	BFS(en);
	for (int i=1;i<=N;i++)
	if (!dist[i]) doit(i);
	Clean();
	for (int i=0;i<M;i++)
	add(g[i][0],g[i][1]);
	BFS(st);
	printf("%d\n",dist[en]-1);
	return 0;
}
void BFS(int st)
{
	memset(dist,0,sizeof(dist));
	if (flag[st]) return ;
	int H=0,T=0;
	dist[st]=1;
	f[T++]=st;
	for (;H<T;H++)
	{
		int u=f[H];
		for (int i=head[u];i!=-1;i=next[i])
		{
			int v=node[i];
			if (dist[v]||flag[v]) continue;
			dist[v]=dist[u]+1;
			f[T++]=v;
		}
	}
	return ;
}
void doit(int u)
{
	for (int i=head[u];i!=-1;i=next[i])
	{
		int v=node[i];
		flag[v]=true;
	}
	return ;
}
void add(int u,int v)
{
	node[fre]=v;
	next[fre]=head[u];
	head[u]=fre;
	fre++;
	return ;
}
void Clean()
{
	memset(head,-1,sizeof(head));
	fre=0;
	return ;
}
