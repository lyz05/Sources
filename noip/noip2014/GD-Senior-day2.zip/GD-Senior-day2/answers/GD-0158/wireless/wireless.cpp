#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
using namespace std;
#define FOR(i,j,k) for(i=j;i<=k;i++)
#define rep(i,j,k) for(i=j;i<k;i++)
#define inf 0x7ffffff
#define max(i,j) ((i)>(j)?(i):(j))
#define min(i,j) ((i)<(j)?(i):(j))
typedef long long ll;

#define FILENAME "wireless"

// =A= lalalalayayayayahahahahapapapapa

#define MAXN 205
#define MAP 128

typedef ll Array[MAXN][MAXN];

int d;
Array turning, count;

void readin() {
	memset(turning, 0, sizeof(turning));
	ll i, x, y, k, n;
	cin>>d>>n;
	FOR(i,1,n) {
		cin>>x>>y>>k;
		turning[x][y]=k;
	}
}

ll getArray(Array a, int x, int y) {
	if(x<0||y<0||x>MAP||y>MAP) return 0;
	return a[x][y];
}

void getRight(int &a) {
	if(a<0)a=0;
	if(a>MAP)a=MAP;
}

ll getRange(Array a, int x1, int y1, int x2, int y2) {
	getRight(x1);getRight(x2);getRight(y1);getRight(y2);
	
	return getArray(a, x2, y2) -
		getArray(a, x1-1,y2) - getArray(a,x2,y1-1) +
		getArray(a,x1-1,y1-1);
}

void init() {
	int i, j;
	memset(count,0,sizeof(count));
	FOR(i,0,MAP) {
		FOR(j,0,MAP) {
			count[i][j]=getArray(count, i - 1, j) +
				getArray(count, i, j - 1) -
				getArray(count, i - 1, j - 1) +
				turning[i][j];
		}
	}
}

ll maxans = 0, anscount = 0;

void work() {
	init();
	
	int i, j;
	FOR(i,0,MAP) {
		FOR(j,0,MAP) {
			ll k = getRange(count,i-d,j-d,i+d,j+d);
			if(maxans < k) {
				maxans = k;
				anscount = 0;
			}
			if(maxans == k) {
				anscount++;
			}
		}
	}
}

void print() {
	cout<<anscount<<' '<<maxans;
}

int main() {
	freopen(FILENAME".in","r",stdin);
	freopen(FILENAME".out","w",stdout);
	
	readin();
	work();
	print();
	
	return 0;
}

