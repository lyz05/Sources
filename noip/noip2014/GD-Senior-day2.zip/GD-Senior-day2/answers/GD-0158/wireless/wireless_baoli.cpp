#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
using namespace std;
#define FOR(i,j,k) for(i=j;i<=k;i++)
#define rep(i,j,k) for(i=j;i<k;i++)
#define inf 0x7ffffff
#define max(i,j) ((i)>(j)?(i):(j))
#define min(i,j) ((i)<(j)?(i):(j))
typedef long long ll;

// =A= lalalalayayayayahahahahapapapapa

#define MAXN 205
#define MAP 128

typedef ll Array[MAXN][MAXN];

int d;
Array turning, count;

void readin() {
	memset(turning, 0, sizeof(turning));
	int i, x, y, k, n;
	scanf("%d%d", &d, &n);
	FOR(i,1,n) {
		scanf("%d%d%d", &x, &y, &k);
		turning[x][y]=k;
	}
}

ll maxans = 0, anscount = 0;

void work() {
	ll i, j, k, p, q;
	FOR(i,0,MAP) {
		FOR(j,0,MAP) {
			k = 0;
			FOR(p,max(i-d,0),min(i+d,MAP)) {
				FOR(q,max(j-d,0),min(j+d,MAP)) {
					k += turning[p][q];
				}
			}
			if(maxans < k) {
				maxans = k;
				anscount = 0;
			}
			if(maxans == k) {
				anscount++;
			}
		}
	}
}

void print() {
	cout<<anscount<<' '<<maxans;
}

int main() {
	freopen("wireless.in","r",stdin);
	freopen("wireless_baoli.out","w",stdout);
	
	readin();
	work();
	print();
	
	return 0;
}

