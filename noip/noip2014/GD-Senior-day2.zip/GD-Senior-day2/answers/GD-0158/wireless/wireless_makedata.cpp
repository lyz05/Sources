#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <iostream>
using namespace std;
#define FOR(i,j,k) for(i=j;i<=k;i++)
#define rep(i,j,k) for(i=j;i<k;i++)
#define inf 0x7ffffff
#define max(i,j) ((i)>(j)?(i):(j))
#define min(i,j) ((i)<(j)?(i):(j))
typedef long long ll;

// =A= lalalalayayayayahahahahapapapapa

int main() {
	freopen("wireless.in","w",stdout);
	
	srand(time(NULL));
	int d = rand() % 21;
	int n = rand() % 21;
	cout<<d<<endl<<n<<endl;
	while(n--) {
		cout<<rand()%129<<' '<<rand()%129<<' '<<(ll)(1000000.0*rand()/RAND_MAX)<<endl;
	}
	
	return 0;
}

