#include <fstream>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <algorithm>
using namespace std;
#define FOR(i,j,k) for(i=j;i<=k;i++)
#define rep(i,j,k) for(i=j;i<k;i++)
#define inf 0x7ffffff
#define max(i,j) ((i)>(j)?(i):(j))
#define min(i,j) ((i)<(j)?(i):(j))
typedef long long ll;

// =A= lalalalayayayayahahahahapapapapa
// =X= EA FUCK UP EVERYTHING!!!
// QAQ QAQ QAQ QAQ !!!

#define MAXN 105
#define MAXM 1100000
	
static char temp[10005];

struct bint {
	static const int MAXLEN = 10005;
	int num[MAXLEN]; int len;
	
	// 0 - zheng; 1 - fu
	int dir;
	
	bint() {
		len = 0;
	}
	
	bint(int i) {
		len = 0;
		if(i < 0) {
			dir = 1;
			i = -i;
		} else {
			dir = 0;
		}
		while(i!=0) {
			num[len++] = i % 10;
			i /= 10;
		}
	}
	
	bint(char *c) {
		init(c);
	}
	
	void init(char *c) {
		len = strlen(c);
		int start;
		if(c[0] == '-') {
			start = 1;
			dir = 1;
		} else {
			start = 0;
			dir = 0;
		}
		reverse(c + start, c + len);
		for(int i = start; i < len; i++) {
			num[i - start] = c[i] - '0';
		}
	}
	
	void clear() {
		memset(num,0,sizeof(num));
	}
	
	friend bint operator +(const bint &a, const bint &b) {
		bint c;
		int j = max(a.len, b.len);
		
		int &i = c.len, carry = 0;
		for(i=0;i<j||carry;i++) {
			c.num[i] = a.num[i] + b.num[i] + carry;
			carry = c.num[i] / 10;
			c.num[i] %= 10;
		}
		return c;
	}
	
	friend bint operator *(const bint &a, const bint &b) {
		bint c;
		c.clear();
		
		int i, j;
		for(i=0;i<a.len;i++) {
			for(j=0;j<b.len;j++) {
				c.num[i+j] += a.num[i] * b.num[j];
				c.num[i+j+1] += c.num[i+j]/10;
				c.num[i+j] %= 10;
			}
		}
		c.dir = a.dir^b.dir;
		for(c.len=0;c.num[c.len]!=0;c.len++);
		
		return c;
	}
	
	friend bool operator ==(const bint &a, const bint &b) {
		if(a.len != b.len) return false;
		for(int i = 0; i < a.len; i++)
			if(a.num[i] != b.num[i]) return false;
		return true;
	}
	
	bool isZero() {
		return (len == 0) || (len == 1 && num[0] == 0);
	}
	
	friend istream &operator >> (istream &a, bint &b) {
		a>>temp;
		b.init(temp);
	}
	
	friend ostream &operator << (ostream &a, bint &b) {
		for(int i=b.len-1;i>=0;i--)
			a<<b.num[i];
	}
};

int n, m;
bint a[MAXN];

void readin() {
	ifstream fin("equation.in");
	fin>>n>>m;
	for(int i=0;i<=n;i++) fin>>a[i];
}

//ll fuck(int x) {
bool fuck(int x) {
	bint ra = 0, rb = 0, xn = 1;
	for(int i=0;i<=n;i++) {
		if(a[i].dir) rb = rb + xn * a[i];
		else ra = ra + xn * (a[i]);
		xn = xn * x;
	}
	return ra == rb;
}

ll ans[MAXM], anscnt = 0;

void work() {
	int ret = 0;
	for(int i=1;i<=m;i++) {
		//if(fuck(i) == 0) {
		if(fuck(i)) {
			ans[anscnt++] = i;
		}
	}
}

void print() {
	ofstream fout("equation.out");
	fout<<anscnt<<endl;
	for(int i=0;i<anscnt;i++) fout<<ans[i]<<endl;
	
	bint ra = 0, rb = 0, xn = 1;
	for(int i=0;i<=n;i++) {
		if(a[i].dir) rb = rb + xn * a[i];
		else ra = ra + xn * (a[i]);
		xn = xn * 10;
	}
	fout<<ra<<endl;
	fout<<rb<<endl;
}

int main() {
	readin();
	work();
	print();
	
	return 0;
}

