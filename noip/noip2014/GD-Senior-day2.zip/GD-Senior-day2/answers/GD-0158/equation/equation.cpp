#include <fstream>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <algorithm>
using namespace std;
#define FOR(i,j,k) for(i=j;i<=k;i++)
#define rep(i,j,k) for(i=j;i<k;i++)
#define inf 0x7ffffff
#define max(i,j) ((i)>(j)?(i):(j))
#define min(i,j) ((i)<(j)?(i):(j))
typedef long long ll;

// =A= lalalalayayayayahahahahapapapapa
// =X= EA FUCK UP EVERYTHING!!!
// QAQ QAQ QAQ QAQ !!!

#define MAXN 105
#define MAXM 1100000


int n, m;
ll a[MAXN];

void readin() {
	ifstream fin("equation.in");
	fin>>n>>m;
	for(int i=0;i<=n;i++) fin>>a[i];
}

ll fuck(int x) {
	ll ret, xn = 1;
	for(int i=0;i<=n;i++) {
		ret += xn * a[i];
		xn = xn * x;
	}
	return ret;
}

ll ans[MAXM], anscnt = 0;

void work() {
	int ret = 0;
	for(int i=1;i<=m;i++) {
		if(fuck(i) == 0) {
			ans[anscnt++] = i;
		}
	}
}

void print() {
	ofstream fout("equation.out");
	fout<<anscnt<<endl;
	for(int i=0;i<anscnt;i++) fout<<ans[i]<<endl;
	
	fout<<fuck(10)<<endl;
}

int main() {
	readin();
	work();
	print();
	
	return 0;
}

