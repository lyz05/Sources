#include <cstdio>
#include <cstdlib>
#include <ctime>
using namespace std;
#define FOR(i,j,k) for(i=j;i<=k;i++)
#define rep(i,j,k) for(i=j;i<k;i++)
#define inf 0x7ffffff
#define max(i,j) ((i)>(j)?(i):(j))
#define min(i,j) ((i)<(j)?(i):(j))
typedef long long ll;

#define FILENAME "equation"

// =A= lalalalayayayayahahahahapapapapa

int main() {
	freopen(FILENAME".in","w",stdout);
	
	srand(time(NULL));
	int n = rand() % 101;
	int m = rand() % 101;
	printf("%d %d\n", n, m);
	
	while(n--) {
		int a = rand() % 201;
		a -= 100;
		printf("%d\n", a);
	}
	
	return 0;
}

