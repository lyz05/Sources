#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

using namespace std;

typedef long long LL;

const int PLUS=1,MINUS=-1;
const LL BIT=1000000000ull;

char st[10010];

struct Bign
{
	LL num[1200];
	int len;
	int sig;
	Bign(){len=0;memset(num,0,sizeof(num));}
	Bign(string a)
	{
		memset(num,0,sizeof(num));
		if (a[0]=='-')
		{
			sig=MINUS;
			a=a.substr(1,a.size()-1);
		}
		else sig=PLUS;
		len=0;
		for (int i=a.size()-1;i>=0;)
		{
			LL k=0;
			for (int j=max(0,i-8);j<=i;++j)
				k=k*10+a[j]-'0';
			num[len++]=k;
			i=max(-1,i-9);
		}
	}
	Bign(LL a)
	{
		stringstream ss;
		ss<<a;
		ss>> st;
		*this=Bign(st);
	}
	Bign operator+(const Bign&b) const
	{
		if (sig==PLUS && b.sig==MINUS)
		{
			Bign c=b;
			c.sig=PLUS;
			return *this-c;
		}
		if (sig==MINUS && b.sig==PLUS)
		{
			Bign c=*this;
			c.sig=PLUS;
			return b-c;
		}
		Bign c;
		c.sig=sig;
		c.len=max(len,b.len);
		for (int i=0;i!=c.len;++i)
		{
			c.num[i]=c.num[i]+num[i]+b.num[i];
			c.num[i+1]=c.num[i]/BIT;
			c.num[i]%=BIT;
		}
		for (;c.num[c.len]!=0;c.len++);
		return c;
	}
	Bign operator-(const Bign&b) const
	{
		if (sig==b.sig && sig==PLUS)
		{
			if (*this<b)
			{
				Bign c=b-*this;
				c.sig=MINUS;
				return c;
			}
		} else
		if (sig==b.sig && sig==MINUS)
		{
			if (b<*this)
			{
				Bign c=b-*this;
				c.sig=PLUS;
				return c;
			}
		} else
		if (b.sig==MINUS)
		{
			Bign c=b;
			c.sig=PLUS;
			return *this+c;
		} else
		if (sig==MINUS)
		{
			Bign c=*this;
			c.sig=MINUS;
			return *this+c;
		}

		Bign c;
		c.sig=sig;
		c.len=max(len,b.len);
		for (int i=0;i!=c.len;++i)
		{
			LL k=num[i];
			if (num[i]<b.num[i])
			{
				c.num[i+1]--;
				k+=BIT;
			}
			c.num[i]+=k-b.num[i];
		}
		for (;len>1 && c.num[c.len-1]==0;c.len--);
		return c;
	}
	Bign operator*(const Bign&b) const
	{
		Bign c;
		c.sig=sig*b.sig;
		c.len=len*b.len-1;
		for (int i=0;i!=len;++i)
			for (int j=0;j!=b.len;++j)
			{
				c.num[i*j]+=num[i]*b.num[j];
				c.num[i*j+1]+=c.num[i*j]/BIT;
				c.num[i+j]%=BIT;
			}
		for (;c.num[c.len]!=0;++c.len);
		return c;
	}
	void In()
	{
		scanf("%s",st);
		*this=Bign(st);
	}
	void Out() const
	{
		if (sig==MINUS) printf("-");
		for (int i=len-1;i>=0;--i)
			cout << num[i];
		cout <<endl;
	}
	bool operator<(const Bign&b) const
	{
		if (iszero())
			if (b.sig==MINUS || b.iszero()) return 0;
			else return 1;
		if (sig!=b.sig) return sig<b.sig;
		for (int i=len-1;i>=0;--i)
			if (num[i]!=b.num[i]) return num[i]<b.num[i];
		return 0;
	}
	bool iszero() const
	{
		for (int i=0;i!=len;++i)
			if (num[i]!=0) return 0;
		return 1;
	}
	Bign operator=(const Bign&b)
	{
		sig=b.sig;
		len=b.len;
		memset(num,0,sizeof(num));
		for (int i=0;i!=len;++i) num[i]=b.num[i];
		return *this;
	}
} A[110];


void Work(int,int);

int n,m;

Bign a,b,c;

int ansnum=0;
int ans[1000010];

int main()
{
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	
	scanf("%d%d",&n,&m);
	for (int i=0;i<=n;++i) A[i].In();
	
	if (m<=100)
	{
		for (int i=1;i<=m;++i)
		{
			a=0;
			b=1;
			for (int j=0;j<=n;++j)
			{
				a=a+b*A[j];
				b=b*Bign(i);
			}
			if (a.iszero())
			{
				ans[ansnum++]=i;
			}
		}
	} else
	{
		Work(1,m);
	}
	printf("%d\n",ansnum);
	for (int i=0;i!=ansnum;++i) printf("%d\n",ans[i]);

	
	return 0;
}
void Work(int lef,int rig)
{
//printf("W %d %d\n",lef,rig);
	if (lef>rig) return;
	int shift= int(floor(sqrt((rig-lef+1))))+1;
	if (rig-lef+1<=50) shift=1;
	Bign las;
	int lasti=lef;
	for (int i=lef;i<=rig;i+=shift)
	{
		a=0;b=1;
		for (int j=0;j<=n;++j)
			{
				a=a+b*A[j];
				b=b*Bign(i);
			}
//printf("%d ",i);a.Out();
		if (i!=lef && las.sig!=a.sig) Work(lasti+1,i-1);
		if (a.iszero())
			ans[ansnum++]=i;
		lasti=i;
		las=a;
	}
	a=0;b=1;
	for (int j=0;j<=n;++j)
		{
			a=a+b*A[j];
			b=b*Bign(rig);
		}
	if (las.sig!=a.sig) Work(lasti+1,rig-1);
}


