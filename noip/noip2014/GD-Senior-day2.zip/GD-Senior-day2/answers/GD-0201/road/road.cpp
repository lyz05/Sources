#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <iostream>
#include <fstream>
#include <queue>

using namespace std;

const int MAXN=10010,INF=(1<<30)-1;

vector<int> E_L[MAXN];
int n_L,m_L,s_L,t_L;
vector<int> E_rev[MAXN];

bool vis_L[MAXN];
bool vis_rev[MAXN];
bool canpass[MAXN];

int dis_L[MAXN];

void BFS_L();
void Dijkstra_L();

struct Node
{
	int x;
	int pos;
	Node(){}
	Node(int x1,int p1):x(x1),pos(p1){}
	bool operator<(const Node&a) const
	{
		return x<a.x;
	}
};

queue<int> que;
priority_queue<Node> pque;

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	
	scanf("%d%d",&n_L,&m_L);
	for (int i=0;i!=m_L;++i)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		if (x==y) continue;
		E_L[x].push_back(y);
		E_rev[y].push_back(x);
	}
	scanf("%d%d",&s_L,&t_L);
	BFS_L();

	for (int i=1;i<=n_L;++i)
	{
		canpass[i]=1;
		if (!vis_rev[i])
			canpass[i]=0;
		else
		for (int j=0;j!=E_L[i].size();++j)
			if (!vis_rev[E_L[i][j]])
			{
				canpass[i]=0;
				break;
			}
	}
	
	Dijkstra_L();
	if (dis_L[t_L]>n_L) printf("-1\n");
	else
	printf("%d\n",dis_L[t_L]);
	
	return 0;
}

void BFS_L()
{
	vis_rev[t_L]=1;
	que.push(t_L);
	for (;!que.empty();que.pop())
	{
		int x=que.front();
		for (int i=0;i!=E_rev[x].size();++i)
		{
			int y=E_rev[x][i];
			if (vis_rev[y]) continue;
			vis_rev[y]=1;
			que.push(y);
		}
	}
}
void Dijkstra_L()
{
	for (int i=1;i<=n_L;++i) dis_L[i]=INF;
	dis_L[s_L]=0;
	pque.push(Node(0,s_L));
	for (;!pque.empty();)
	{
		int x=pque.top().pos;
		pque.pop();

		if (vis_L[x]) continue;
		vis_L[x]=1;
		for (int i=0;i!=E_L[x].size();++i)
		{
			int y=E_L[x][i];
			if (vis_L[y] || !canpass[y]) continue;
			if (dis_L[y]>dis_L[x]+1)
			{
				dis_L[y]=dis_L[x]+1;
				pque.push(Node(dis_L[y],y));
			}
		}
	}
}

