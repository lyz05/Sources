#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <iostream>
#include <fstream>
#include <algorithm>

using namespace std;

const int MAXN=50;

int posx_L[MAXN],posy_L[MAXN];
int num_L[MAXN];
int D,N;

int main()
{
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	
	scanf("%d",&D);
	scanf("%d",&N);
	for (int i=0;i!=N;++i)
		scanf("%d%d%d",&posx_L[i],&posy_L[i],&num_L[i]);
		
	int ans=0;
	int ansnum_L=0;
	for (int x=0;x<=128;++x)
		for (int y=0;y<=128;++y)
		{
			int p=0;
			for (int i=0;i!=N;++i)
				if (abs(x-posx_L[i])<=D && abs(y-posy_L[i])<=D) p+=num_L[i];
			if (p==ans)
				ansnum_L++;
			else
			if (p>ans)
			{
				ans=p;
				ansnum_L=1;
			}
		}
	printf("%d %d\n",ansnum_L,ans);
	
	return 0;
}
