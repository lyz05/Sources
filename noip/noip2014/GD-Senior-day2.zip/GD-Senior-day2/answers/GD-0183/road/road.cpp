#include<iostream>
#include<stdio.h>
using namespace std;
int next[10001][10001]={0};
int last[10001][10001]={0};
int numn[10001]={0};
int numl[10001]={0};
int all[10001]={0};
int qu[10001]={0};
int lig[10001]={0};
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n,m;
	cin>>n>>m;
	int x,y;
	for(int i=1;i<=m;i++)
	{
		cin>>x>>y;
		next[x][numn[x]++]=y;
		last[y][numl[y]++]=x;
	}
	int s,t;
	cin>>s>>t;
	int be=1,en=1;
	all[t]=1;
	lig[t]=1;
	qu[en++]=t;
	int now=0;
	while(be<en)
	{
		now=qu[be++];
		for(int k=0;k<numl[now];k++)
		{
			int mom=last[now][k];
			if(all[mom]==0) {
				all[mom]=1;
				lig[mom]=1;
				qu[en++]=mom;
			}
		}
	}
	for(int i=1;i<=n;i++)
	if(all[i]==0){
		for(int k=0;k<numl[i];k++) lig[last[i][k]]=0;
	}
	if(lig[s]!=1) {
	    cout<<-1; 
	    return 0;
	}
	for(int i=be;i>=0;i--) qu[i]=0;
	for(int i=0;i<=n;i++) all[i]=0;
	be=1;en=1;
	qu[en++]=s;
	all[s]=1;
	int step=0;
	while(be<en)
	{
	    
		int ken=en;
		for(;be<ken;be++)
		{
		    if(qu[be]==t) {cout<<step;return 0;}
			now=qu[be];
			for(int k=0;k<numn[now];k++)
		    {
			    int mom=next[now][k];
			    if(lig[mom]==1&&all[mom]==0) {
			    	qu[en++]=mom;
			    }
		    }
		}
		step++;
	}
	step++;
	cout<<step;
	return 0;
}
