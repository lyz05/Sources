#include<iostream>
#include<stdio.h>
using namespace std;
int a[200];
int sol[100000]={0};
int qul(int n,int x);
int main()
{
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	int n,m;
	cin>>n>>m;
	for(int i=0;i<=n;i++) cin>>a[i];
	int num=0;
    //qul(3,3);
	for(int i=1;i<=m;i++) if(qul(n,i)==1) sol[num++]=i;
	cout<<num<<endl;
	for(int i=0;i<num;i++) cout<<sol[i]<<endl;
	return 0;
}
int qul(int n,int x)
{
	int all=0;
	for(int i=n;i>0;i--)
	{
		all=(all+a[i])*x;
		//cout<<all<<' ';
	}
	//cout<<all+a[0];
	if(all+a[0]==0) return 1;
	else return 0;
}
