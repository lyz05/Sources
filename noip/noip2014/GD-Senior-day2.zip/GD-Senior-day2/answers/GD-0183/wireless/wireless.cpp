#include<iostream>
#include<stdio.h>
using namespace std;
int city[170][170]={0};
int main()
{
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	for(int i=0;i<170;i++)
	  for(int j=0;j<170;j++) city[i][j]=0;
	int d,n;
	cin>>d>>n;
	int x,y;
	for(int i=0;i<n;i++) {
		cin>>x>>y;
		cin>>city[x+19][y+19];
	}
	int max=-1,num=0;
	int a,b;
	int p=0;
	int tol=0;
	
    for(int i=19;i<148;i++)
      for(int j=19;j<148;j++)
      {
      	  tol=0;
          for(a=i-d;a<=i+d;a++)
              for(b=j-d;b<=j+d;b++)
              {
              	tol+=city[a][b];
              }
          if(tol>max) {max=tol;num=1;}
          else if(tol==max) num++;
      }
      cout<<num<<' '<<max;
	return 0;
}
