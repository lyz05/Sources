#include <iostream>
#include <cstdio>
using namespace std;

const long N=130, M=30;
long d, n, m, S, NS;
long a[N][N], s[N][N];
long x[M], y[M], z[M];

int main()
{
	long i, j, ax, ay, bx, by, v;
	freopen("wireless.in", "r", stdin);
	freopen("wireless.out", "w", stdout);
	m=129;
	scanf("%ld%ld", &d, &n);
	for (i=1; i<=n; i++)
	{
		scanf("%ld%ld%ld", &x[i], &y[i], &z[i]);
		x[i]++; y[i]++;
		a[x[i]][y[i]]=z[i];
	}
	for (i=1; i<=m; i++)
		for (j=1; j<=m; j++)
			s[i][j]=s[i-1][j]+s[i][j-1]-s[i-1][j-1]+a[i][j];
	for (i=1; i<=m; i++)
		for (j=1; j<=m; j++)
		{
			ax=max(i-d, 1l); ay=max(j-d, 1l);
			bx=min(i+d, m); by=min(j+d, m);
			v=s[bx][by]-s[ax-1][by]-s[bx][ay-1]+s[ax-1][ay-1];
			if (v > S)
			{
				S=v; NS=1;
				continue;
			}
			if (v == S)
				NS++;
		}
	printf("%ld %ld\n", NS, S);
	fclose(stdin); fclose(stdout);
	return 0;
}
