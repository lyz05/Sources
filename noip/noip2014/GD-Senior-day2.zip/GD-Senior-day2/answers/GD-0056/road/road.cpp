#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

struct edge
{ long x; edge *next; };
const long N=10010, M=200010, L=9999999;
long n, m, s, t;
long e[N], d[N];
bool vis[N], can[N];
edge es[M];

void bfs()
{
	long p, q, v;
	edge *i;
	p=0; q=1;
	e[++q]=t;
	vis[t]=1;
	while (p < q)
	{
		v=e[++p];
		for (i=es[v].next; i!=NULL; i=i->next)
			if (!vis[i->x])
			{
				e[++q]=i->x;
				vis[i->x]=1;
			}
	}
	for (v=1; v<=n; v++)
		can[v]=1;
	for (v=1; v<=n; v++)
		if (!vis[v])
			for (i=es[v].next; i!=NULL; i=i->next)
				can[i->x]=0;
}

void work()
{
	long p, q, v;
	edge *i;
	for (v=1; v<=n; v++)
		d[v]=L;
	memset(e, 0, sizeof(e));
	p=0; q=1;
	e[++q]=t;
	d[t]=0;
	while (p < q)
	{
		v=e[++p];
		for (i=es[v].next; i!=NULL; i=i->next)
			if (d[i->x] == L && can[i->x])
			{
				e[++q]=i->x;
				d[i->x]=d[v]+1;
			}
	}
}

int main()
{
	long i, dx, dy;
	edge *p;
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	scanf("%ld%ld", &n, &m);
	for (i=1; i<=m; i++)
	{
		scanf("%ld%ld", &dx, &dy);
		p=new edge;
		p->x=dx; p->next=es[dy].next;
		es[dy].next=p;
	}
	scanf("%ld%ld", &s, &t);
	bfs();
/*	for (i=1; i<=n; i++)
		cout << can[i] << ' ';
	cout << '\n';
	for (i=1; i<=n; i++)
		cout << vis[i] << ' ';
	cout << '\n';*/
	work();
	if (d[s] == L) d[s]=-1;
	printf("%ld\n", d[s]);
	fclose(stdin); fclose(stdout);
	return 0;
}
