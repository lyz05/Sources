#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
#define Long long long
using namespace std;

const Long N=110, M=1010, L=9999999, W=9;
Long n, m, p, pd;
Long cs[N][M+1], x[M+1], b[M+1], c[M+1];
long ans[100010];
string s;

void Print(Long x[])
{
	Long i;
	if (x[0] == 1) cout << '-';
	for (i=1; x[i] == 0 && i < M; i++) ;
	for ( ; i<=M; i++) cout << x[i];
	cout << '\n';
}

void Read(Long x[])
{
	Long i, j, l, p;
	getline(cin, s, '\n');
	l=s.length();
	if (s[0] != '-')
		s=' '+s;
	else l--;
	if (s[0] == '-') x[0]=1;
	j=M; p=1;
	for (i=l; i>=1; i--)
	{
		x[j]=x[j]+(s[i]-48)*p;
		p=p*10;
		if ((l-i+1)%W == 0)
			j--, p=1;
	}
}

void mult(Long c[], Long a[], Long b[]) //memset()
{
	long w, v, i, j;
	for (i=1; i<=M; i++)
		c[i]=0;
	c[0]=(a[0]+b[0])%2;
	for (i=M; i>=1; i--)
	{
		w=0;
		for (j=M; j>=1; j--)
		{
			v=i+j-M;
			if (v <= 0) break;
			c[v]=c[v]+a[i]*b[j]+w;
			w=c[v]/p;
			c[v]=c[v]%p;
		}
	}
}

void multx(Long a[], Long x)
{
	Long w, i;
	w=0;
	for (i=M; i>=1; i--)
	{
		a[i]=a[i]*x+w;
		w=a[i]/p;
		a[i]%=p;
	}
}

void add(Long b[], Long a[])
{
	Long w, i;
	w=0;
	for (i=M; i>=1; i--)
	{
		a[i]=a[i]+b[i]+w;
		w=a[i]/p;
		a[i]%=p;
	}
}

bool comp(Long a[], Long b[]) // a <= b
{
	long i;
	for (i=1; i<=M; i++)
		if (a[i] < b[i])
			return true;
		else
			if (a[i] > b[i])
				return false;
	return true;
}

void dec(Long b[], Long a[]) //a=a-b;
{
	Long w, i, t;
	if (comp(a, b))
		for (i=0; i<=M; i++)
			t=a[i], a[i]=b[i], b[i]=t;
	w=0;
	for (i=M; i>=1; i--)
	{
		a[i]=a[i]-b[i]-w;
		if (a[i] < 0) a[i]+=p, w=1;
		else w=0;
	}
}

int main()
{
	Long i, j;
	freopen("equation.in", "r", stdin);
	freopen("equation.out", "w", stdout);
	scanf("%lld%lld\n", &n, &m);
	for (i=p=1; i<=W; i++)
		p*=10;
	for (i=0; i<=n; i++)
		Read(cs[i]);
	for (i=1; i<=m; i++)
	{
		memset(c, 0, sizeof(c));
		x[M]=1;
		for (j=0; j<=n; j++)
		{
			mult(b, x, cs[j]);
			if (b[0] == c[0])
				add(b, c);
			else
				dec(b, c);
			multx(x, i);
		}
		for (j=1; j <= M && c[j] == 0; j++) ;
		if (c[j] == 0)
			ans[++pd]=i;
	}
	printf("%lld\n", pd);
	for (i=1; i<=pd; i++)
		printf("%lld\n", ans[i]);
	fclose(stdin); fclose(stdout);
	return 0;
}
