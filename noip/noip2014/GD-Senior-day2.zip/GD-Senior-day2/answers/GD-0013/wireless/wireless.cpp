#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cstdlib>
#include <cmath>

using namespace std ;

#define rep( i , x ) for ( int i = 0 ; i ++ < x ; )
#define REP( i , l , r ) for ( int i = l ; i <= r ; ++ i )

const int maxn = 210 ;

int n , d , p[ maxn ][ 3 ] , ans0 = 0 , ans1 = 0 ; 

int Count( int x , int y ) {
	int rec = 0 ; 
	rep( i , n ) if ( abs( p[ i ][ 0 ] - x ) <= d && abs( p[ i ][ 1 ] - y ) <= d ) rec += p[ i ][ 2 ] ;
	return rec ; 
}

int main(  ) {
	freopen( "wireless.in" , "r" , stdin ) ; freopen( "wireless.out" , "w" , stdout ) ;
	scanf( "%d%d" , &d , &n ) ; 
	rep( i , n ) scanf( "%d%d%d" , p[ i ] , p[ i ] + 1 , p[ i ] + 2 ) ;
	int ret ; 
	REP( i , 0 , 128 ) REP( j , 0 , 128 ) if ( ( ret = Count( i , j ) ) > ans0 ) {
		ans0 = ret , ans1 = 1 ; 
	} else if ( ret == ans0 ) ++ ans1 ; 
	printf( "%d %d\n" , ans1 , ans0 ) ; 
	fclose( stdin ) , fclose( stdout ) ;
	return 0 ; 
}
