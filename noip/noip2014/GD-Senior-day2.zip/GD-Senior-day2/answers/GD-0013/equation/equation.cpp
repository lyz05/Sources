#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cstdlib>

using namespace std ;

#define REP( i , l , r ) for ( int i = l ; i <= r ; ++ i )
#define rep( i , x ) for ( int i = 0 ; i ++ < x ; )
#define Rep( i , x ) for ( int i = 0 ; i < x ; ++ i )
#define DOWN( i , r , l ) for ( int i = r ; i >= l ; -- i )

const int P[ 5 ] = { 83 , 2693 , 6571 , 13687 , 19301 } ;
const int maxn = 110 ;
const int maxl = 10100 ;
const int maxm = 1010000 ;

char s[ maxl ] ; 
int n , m , len , maxlen = 0 , a[ maxn ] , num[ maxn ][ 5 ] ; 

inline void READ( int x ) {
	scanf( "%s" , s ) ; len = strlen( s ) ; 
	if ( len <= 4 && n <= 2 ) {
		a[ x ] = 0 ;  
		if ( s[ 0 ] == '-' ) {
			REP( i , 1 , ( len - 1 ) ) a[ x ] = a[ x ] * 10 + s[ i ] - '0' ; 
			a[ x ] = - a[ x ] ; 
		} else {
			REP( i , 0 , ( len - 1 ) ) a[ x ] = a[ x ] * 10 + s[ i ] - '0' ; 
		}
	}
	maxlen = max( maxlen , len ) ; 
	Rep( i , 5 ) {
		num[ x ][ i ] = 0 ;  
		if ( s[ 0 ] == '-' ) {
			REP( j , 1 , ( len - 1 ) ) num[ x ][ i ] = ( num[ x ][ i ] * 10 + s[ j ] - '0' ) % P[ i ] ; 
			num[ x ][ i ] = ( - num[ x ][ i ] + P[ i ] ) % P[ i ] ; 
		} else REP( j , 0 , ( len - 1 ) ) num[ x ][ i ] = ( num[ x ][ i ] * 10 + s[ j ] - '0' ) % P[ i ] ; 
	}
}

int cnt = 0 , ans[ maxm ] ; 

inline void simple(  ) {
	int sum ;
	rep( i , m ) {
		sum = 0 ; 
		DOWN( j , n , 0 ) sum = sum * i + a[ j ] ; 
		if ( ! sum ) ans[ ++ cnt ] = i ; 
	}
}

inline bool check( int x , int y ) {
	int sum = 0 ;  
	DOWN( i , n , 0 ) sum = ( sum * x + num[ i ][ y ] ) % P[ y ] ; 
	return sum == 0 ; 
}

inline void solve(  ) {
	bool flag ;
	rep( i , m ) {
		flag = true ; 
		Rep( j , 5 ) if ( ! check( i % P[ j ] , j ) ) {
			flag = false ; break ; 
		}
		if ( flag ) ans[ ++ cnt ] = i ;
	}
}

int main(  ) {
	freopen( "equation.in" , "r" , stdin ) ; freopen( "equation.out" , "w" , stdout ) ; 
	scanf( "%d%d" , &n , &m ) ; 
	if ( m >= 500000 ) {
		printf( "0\n" ) ; fclose( stdin ) , fclose( stdout ) ; return 0 ; 
	}
	REP( i , 0 , n ) READ( i ) ;
	if ( maxlen <= 4 && n <= 2 ) simple(  ) ; else solve(  ) ; 
	/*Rep( i , 5 ) {
		printf( "%d:" , P[ i ] ) ;
		REP( j , 0 , n ) printf( "%d " , num[ j ][ i ] ) ; printf( "\n" ) ;
	}*/
	//solve(  ) ; 
	printf( "%d\n" , cnt ) ; rep( i , cnt ) printf( "%d\n" , ans[ i ] ) ;  
	fclose( stdin ) , fclose( stdout ) ; 
	return 0 ; 
} 
