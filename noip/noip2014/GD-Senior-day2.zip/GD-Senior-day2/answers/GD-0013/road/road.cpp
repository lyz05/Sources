#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cstdlib>
#include <queue>

using namespace std ;

#define rep( i , x ) for ( int i = 0 ; i ++ < x ; )
#define REP( i , l , r ) for ( int i = l ; i <= r ; ++ i )

const int maxm = 201000 ;
const int maxn = 10100 ;

struct Edge {
	int s , t ; 
	inline void READ(  ) {
		scanf( "%d%d" , &s , &t ) ; 
	}
	bool operator < ( const Edge &x ) const {
		return s < x.s || ( s == x.s && t < x.t ) ;
	}
} EDGE[ maxm ] , E0[ maxm ] ; 

struct edge {
	int t ;
	edge *next ;
} E[ maxm ] ; 

edge *head[ maxn ] , *pt ;

inline void Init_Graph(  ) {
	pt = E , memset( head , 0 , sizeof( head ) ) ; 
}

inline void addedge( int s , int t ) {
	pt -> t = t , pt -> next = head[ s ] ; head[ s ] = pt ++ ; 
}

int n , m , S , T , M = 0 ; 

bool used[ maxn ] , flag[ maxn ] ; 

#define travel( v ) for ( edge *p = head[ v ] ; p ; p = p -> next )

void dfs( int now ) {
	used[ now ] = true ; travel( now ) if ( ! used[ p -> t ] ) dfs( p -> t ) ;
}

inline bool check( int now ) {
	travel( now ) if ( ! used[ p -> t ] ) return false ;
	return true ; 
}

const int inf = 0x7fffffff ;

queue < int > Q ;
int dist[ maxn ] ; 

inline int bfs(  ) {
	if ( ! flag[ S ] ) return -1 ; 
	while ( ! Q.empty(  ) ) Q.pop(  ) ; 
	rep( i , n ) dist[ i ] = inf ; 
	dist[ S ] = 0 , Q.push( S ) ; 
	int now , cost ; 
	while ( ! Q.empty(  ) ) {
		now = Q.front(  ) ; Q.pop(  ) ; 
		travel( now ) if ( dist[ p -> t ] == inf && flag[ p -> t ] ) {
			dist[ p -> t ] = dist[ now ] + 1 , Q.push( p -> t ) ; 
		}
	}
	return dist[ T ] < inf ? dist[ T ] : -1 ;
}

int main(  ) {
	freopen( "road.in" , "r" , stdin ) ; freopen( "road.out" , "w" , stdout ) ;
	scanf( "%d%d" , &n , &m ) ; rep( i , m ) EDGE[ i ].READ(  ) ; scanf( "%d%d" , &S , &T ) ;
	sort( EDGE + 1 , EDGE + m + 1 ) ; 
	rep( i , m ) if ( i == 1 || EDGE[ i ].s != EDGE[ i - 1 ].s || EDGE[ i ].t != EDGE[ i - 1 ].t ) {
		if ( EDGE[ i ].s != EDGE[ i ].t ) E0[ ++ M ] = EDGE[ i ] ; 
	}
	Init_Graph(  ) ; 
	rep( i , M ) addedge( E0[ i ].t , E0[ i ].s ) ; 
	memset( used , false , sizeof( used ) ) ; dfs( T ) ; 
	Init_Graph(  ) ;
	rep( i , M ) addedge( E0[ i ].s , E0[ i ].t ) ; 
	rep( i , n ) flag[ i ] = check( i ) ;
	printf( "%d\n" , bfs(  ) ) ; 
	//rep( i , n ) printf( "%d:%d " , i , flag[ i ] ) ;
	fclose( stdin ) , fclose( stdout ) ;
	return 0 ; 
}
