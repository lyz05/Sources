#include <fstream>
#include <math.h>
using namespace std;

ifstream fin("equation.in");
ofstream fout("equation.out");

#define maxn 105

int n, m, a[maxn];

void swap(int &x, int &y) {
	int t = x;
	x = y;
	y = t;
}

int main() {
	fin >> n >> m;
	for (int i=0; i<=n; i++)
		fin >> a[i];
	
	if (n==1) {
		int xt = (-a[0])/a[1];
		if (a[0]+a[1]*xt == 0 && xt >=1 && xt <=m)
			fout << '1' << endl << xt << endl;
		else 
			fout << '0' << endl;
	}
	if (n==2) {
		int num=0, xt, x1, x2;
		int derta = a[1]*a[1]-4*a[2]*a[0];
		if (derta < 0) num=0;
		if (derta >= 0) {
			xt = (int )sqrt(derta)+0.5;
			x1 = (xt-a[1]) / (2*a[2]);
			x2 = (-xt-a[1]) / (2*a[2]);
			if (a[2]*x1*x1+a[1]*x1+a[0] ==0 && x1>=1 && x2<=m) num++;
			if (a[2]*x2*x2+a[1]*x2+a[0] ==0 && x2>=1 && x2<=m) num++;
			if (x1 == x2) num--;
			if (x1 > x2) swap(x1, x2);
		}
		
		if (num ==0)
			fout << '0' << endl;
		if (num ==1)
			fout << '1' << endl << x1 << endl;
		if (num ==2)
			fout << '2' << endl << x1 << endl << x2 << endl;
	}
	if (n >= 2)
		fout << '0' << endl;
	return 0;
}
