#include <fstream>
using namespace std;

ifstream fin("wireless.in");
ofstream fout("wireless.out");

#define maxl 129

int d, n, maxx, num;
int A[maxl][maxl], Pre[maxl][maxl];

void work() {
	maxx = -100000005;
	for (int i=d; i!=maxl-d; ++i)
		for (int j=d; j!=maxl-d; ++j) {
			int sum=0;
			for (int l=i-d; l<=i+d; l++)
				sum += (Pre[l][j+d]- Pre[l][j-d] + A[l][j-d]);
			if (sum >maxx) {
				maxx = sum;
				num = 1;
			}
			else
				if (sum == maxx) num++;
		}
}

int main() {
	fin >> d;
	fin >> n;
	for (int i=0; i!=n; ++i) {
		int x, y, k;
		fin >> x >> y >> k;
		A[y][x] = k;
	}
	for (int i=0; i!=maxl; ++i)
		for (int j=0; j!=maxl; ++j)
			if (j == 0) Pre[i][j] = A[i][j];
				else Pre[i][j] = Pre[i][j-1] + A[i][j];
	
	work();
	
	fout << num << ' ' << maxx << endl;
	return 0;
}
