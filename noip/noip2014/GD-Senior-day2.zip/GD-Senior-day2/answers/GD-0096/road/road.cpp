#include <fstream>
#include <vector>
#include <queue>
using namespace std;

ifstream fin("road.in");
ofstream fout("road.out");

#define maxn 10005

int n, m, s, t, ans;
int cnt[maxn], F[maxn];
vector <int > son[maxn], father[maxn];
queue <int > Q;
bool vis[maxn], cant[maxn], canp[maxn];

void init() {
	fin >> n >> m;
	for (int i=0; i!=m; ++i) {
		int x, y;
		fin >> x >> y;
		son[x].push_back(y);
		father[y].push_back(x);
	}
	fin >> s >> t;
}

void is_t() {
	for (; Q.empty() == 0; ) Q.pop();
	Q.push(t);
	cant[t] = true;
	for (; Q.empty() == 0; ) {
		int now = Q.front();
		Q.pop();
		for (int j=0; j!=father[now].size(); ++j)
			if (cant[ father[now][j] ] == false){
				cant[ father[now][j] ] = true;
				Q.push( father[now][j] );
			}
	}
}

void is_point() {
	for (int i=1; i<=n; i++)
		if (cant[i] == true)
			for (int j=0; j!=father[i].size(); ++j)
				cnt[ father[i][j] ] ++;
	for (int i=1; i<=n; i++)
		if (cnt[i] == son[i].size()  && cant[i] == true)
			canp[i] = true; 
	
	/*for (int i=1; i<=n; i++)
		fout << cant[i] << ' ';
	fout << endl;	
	
	for (int i=1; i<=n; i++)
		fout << cnt[i] << ' ';
	fout << endl;
	for (int i=1; i<=n; i++)
		fout << son[i].size() << ' ';
	fout << endl;	
	for (int i=1; i<=n; i++)
		fout << canp[i] << ' ';
	fout << endl;*/
}

void find_way() {
	for (int i=1; i<=n; i++) F[i] = 100000005;
	for (int i=1; i<=n; i++) vis[i] = false;
	//vis = memset(vis, false, sizeof(vis));
	for (; Q.empty() == 0; ) Q.pop();
	
	Q.push(s);
	F[s] = 0;
	vis[s] = true;
	for (; Q.empty() == 0; ) {
		int i = Q.front();
		Q.pop();
		//fout << i << ' '; 
		for (int j=0; j!=son[i].size(); ++j)
			if (canp[ son[i][j] ] == true &&
				vis[ son[i][j] ] == false) {
				F[ son[i][j] ] = F[i] +1;
				vis[ son[i][j] ] = true;
				Q.push( son[i][j] );
			}
	}
	
	if (F[t] == 100000005) ans=-1;
		else ans = F[t];
}

int main() {
	init();
	
	is_t();
	is_point();
	find_way();
	
	fout << ans << endl;
	return 0;
}
