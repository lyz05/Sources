#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#include<queue>
using namespace std;
#define rep(i,u,v) for (int i=(u);i<=(v);i++)
#define reph(k,x) for (int k=fir[x];k;k=e1[k].next)
#define reph2(k,x) for (int k=fir2[x];k;k=e2[k].next)
#define N 10010
#define M 200010
#define INF 100000000
struct node{
	  int  y,next;
}e1[M],e2[M];
struct nn{
   int x,d;
}n0,n3;
bool operator < (const nn &n1,const nn &n2){
	return n1.d>n2.d;	 
}
int n,m,len,len2,st,ed;
int fir[N],fir2[N],d[N],bo[N],bb[N];
priority_queue<nn> Q;
void ins1(int x,int y){
	 e1[++len].y=y;e1[len].next=fir[x];fir[x]=len;
}
void ins2(int x,int y){
	 e2[++len2].y=y;e2[len2].next=fir2[x];fir2[x]=len2;
}
void re_go(int x){
	 bo[x]=1;
	 reph2(k,x){
		int y=e2[k].y;
		if (bo[y])continue;
		re_go(y);
     }
}
void solve(){
	 if (bb[st]!=1){
	 	printf("-1\n");
	 	return;
	 }
	 while (!Q.empty())Q.pop();
	 n0.x=st;n0.d=0;d[st]=0;
	 Q.push(n0);
	 int x,y;
	 while (!Q.empty()){
	 	   n0=Q.top();Q.pop();
	 	   x=n0.x;
	 	   if (n0.d!=d[x])continue;
	 	   reph(k,x){
  			  int y=e1[k].y;
  			  if (bb[y]!=1)continue;
  			  if (d[x]+1<d[y]){
  			  	 d[y]=d[x]+1;
  			  	 n3.x=y;n3.d=d[y];
  			  	 Q.push(n3);
		      }
		   }
	 }
	 if (d[ed]==INF)d[ed]=-1;
	 printf("%d\n",d[ed]);
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int x,y,bk;
	scanf("%d%d",&n,&m);
	len=len2=0;
	rep(i,1,m){
		scanf("%d%d",&x,&y);
 	    if (x==y)continue;
 	    ins1(x,y);
 	    ins2(y,x);
	}
	scanf("%d%d",&st,&ed);
	re_go(ed);
	rep(i,1,n){
	   if (bo[i]==1){
       	  bk=1;
          reph(k,i){
		      y=e1[k].y;
		      if (!bo[y]){
		      	 bk=0;break;
			  }
          }
       	  if (bk==1){
			 bb[i]=1;
 		  	 d[i]=INF;
		   }
       }
	}
	solve();
	return 0; 
}
