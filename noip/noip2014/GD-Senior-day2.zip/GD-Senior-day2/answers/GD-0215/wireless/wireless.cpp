#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
using namespace std;
#define rep(i,u,v) for (int i=(u);i<=(v);i++)
int d,n,ans,sum;
int a[135][135],s[135][135];
int mymin(int x,int y){
	return x>y?y:x;
}
int mymax(int x,int y){
	return x>y?x:y;
}
int main(){
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	int x,y,k,lc,lr,rc,rr,cnt;
	ans=sum=0;
	scanf("%d",&d);
	scanf("%d",&n);
	rep(i,1,n){
		scanf("%d%d%d",&x,&y,&k);
		x++;y++;
		a[x][y]=k; 
	}
	rep(i,1,129)
	    rep(j,1,129)
 			 s[i][j]=s[i-1][j]+s[i][j-1]-s[i-1][j-1]+a[i][j];
	rep(i,1,129)
	    rep(j,1,129){
		   lc=mymax(1,j-d);
		   lr=mymax(1,i-d);
		   rc=mymin(129,j+d);
		   rr=mymin(129,i+d);
		   cnt=s[rr][rc]-s[rr][lc-1]-s[lr-1][rc]+s[lr-1][lc-1];
		   if (cnt>ans){
		   	  ans=cnt;sum=1;
		   }
		   else if (cnt==ans)sum++;
		}
	printf("%d %d\n",sum,ans);
	return 0;
}
