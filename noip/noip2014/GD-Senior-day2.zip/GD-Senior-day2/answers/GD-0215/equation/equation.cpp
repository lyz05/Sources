#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
using namespace std;
#define rep(i,u,v) for (int i=(u);i<=(v);i++)
#define dto(i,u,v) for (int i=(u);i>=(v);i--)
#define md 10000
struct node{
	   int b[2550];
	   int len,ty;
}a1[105],nn,k1,k2,pow,n0;
int ans[10010],a[110];
int cc[6];
int n,m;
void solve1(){
	 ans[0]=0;
	 rep(i,0,n)scanf("%d",&a[i]);
	 if (n==1){
	 	rep(i,1,m){
			if (a[0]+a[1]*i==0)
			   ans[++ans[0]]=i;
	 	}
     }	
 	 else {
	    rep(i,1,m){
			if (a[0]+a[1]*i+a[2]*i*i==0)
			   ans[++ans[0]]=i;
	 	}
     }
     printf("%d\n",ans[0]);
     rep(i,1,ans[0])printf("%d\n",ans[i]);
     return;
}
int mymax(int x,int y){return x>y?x:y;}
char s1[10010];
void pre(){
	 ans[0]=0;
	 rep(i,0,n){
		scanf("%s",s1+1);
		int ll=strlen(s1+1);
		if (s1[1]=='-'){
		   a1[i].ty=2;a1[i].len=0;
		   reverse(s1+1,s1+1+ll);
		   cc[0]=0;
			 rep(j,1,ll-1){
			     cc[++cc[0]]=s1[j]-'0';
			     if (cc[0]==4){
			     	a1[i].len++;
			     	a1[i].b[a1[i].len]=cc[4]*1000+cc[3]*100+cc[2]*10+cc[1];
			     	cc[0]=0;
				 }
			 }
			 if (cc[0]>0){
			 	a1[i].len++;a1[i].b[a1[i].len]=0;
			 	dto(j,cc[0],1)
			  	    a1[i].b[a1[i].len]=a1[i].b[a1[i].len]*10+cc[j];
			 }
		}
		else {
			a1[i].ty=1;a1[i].len=0;
			 reverse(s1+1,s1+1+ll);	 
			 cc[0]=0;
			 rep(j,1,ll){
			     cc[++cc[0]]=s1[j]-'0';
			     if (cc[0]==4){
			     	a1[i].len++;
			     	a1[i].b[a1[i].len]=cc[4]*1000+cc[3]*100+cc[2]*10+cc[1];
			     	cc[0]=0;
				 }
			 }
			 if (cc[0]>0){
			 	a1[i].len++;a1[i].b[a1[i].len]=0;
			 	dto(j,cc[0],1)
			  	    a1[i].b[a1[i].len]=a1[i].b[a1[i].len]*10+cc[j];
			 }
		}
	 }
     return;
}
node multi (node &n1,node &n2){
	 n0.len=0;
	 if (n1.ty!=n2.ty)n0.ty=2;
	 else n0.ty=1;
	 memset(n0.b,0,sizeof(n0.b));
	 int len1=n1.len,len2=n2.len,len3=n1.len+n2.len-1;
	 rep(i,1,len1)
        rep(j,1,len2){
  			n0.b[i+j-1]+=n1.b[i]*n2.b[j];	
       }
     rep(i,1,len3){
         n0.b[i+1]+=n0.b[i]/md;
         n0.b[i]%=md;
	 }
	 while (n0.b[len3+1]>0){
	 	   len3++;
	 	   n0.b[len3+1]+=n0.b[len3]/md;
	 	   n0.b[len3]%=md;
	 }
	 while (n0.b[len3]==0&&len3>1)len3--;
     n0.len=len3;
     return n0;
}
node jia (node &n1,node &n2){
 	 n0.len=0;n0.ty=n1.ty;
	 memset(n0.b,0,sizeof(n0));
	 int len1=n1.len,len2=n2.len,len3=mymax(n1.len,n2.len);
	 rep(i,1,len3){
         n0.b[i]+=n1.b[i]+n2.b[i];
         n0.b[i+1]+=n0.b[i]/md;
         n0.b[i]%=md;
	 }
	 while (n0.b[len3+1]>0){
	 	   len3++;
	 	   n0.b[len3+1]+=n0.b[len3]/md;
	 	   n0.b[len3]%=md;
	 }
	 while (n0.b[len3]==0&&len3>1)len3--;
	 n0.len=len3;
	return n0;
}
int cmp(node &n1,node &n2){
	if (n1.len>n2.len)return 1;
	if (n1.len<n2.len)return 0;
	if (n1.len==n2.len){
	   rep(i,1,n1.len)
		   if (n1.b[i]>n2.b[i])return 1;
		   else if (n1.b[i]<n2.b[i])return 0;
	}
	return 1;
}
node jian (node &n1,node &n2){
 	 n0.len=0;n0.ty=n1.ty;
	 memset(n0.b,0,sizeof(n0));
	 int len1=n1.len,len2=n2.len,len3=n1.len;
	 rep(i,1,len3)n0.b[i]=n1.b[i]-n2.b[i];
 	 rep(i,1,len3){
 	 	if (n0.b[i]<0){
		   n0.b[i]+md;
		   n0.b[i+1]--;
		}
     }
	 while (n0.b[len3]==0&&len3>1)len3--;
	 n0.len=len3;
	 return n0;
}
int pd(){
	k1=a1[0];
	memset(pow.b,0,sizeof(pow.b));
	pow.b[1]=1;pow.len=1;
	rep(i,1,n){
         pow=multi(pow,nn);
         pow.ty=1;
         k2=a1[i];
         k2=multi(k2,pow);
         if (k2.ty==k1.ty)k1=jia(k1,k2);
		 else {
		 	  if (cmp(k1,k2))
			   	 k1=jian(k1,k2);
              else k1=jian(k2,k1);
		 }
	}
	if (k1.len==1&&k1.b[1]==0)return 1;
	else return 0;
}
void solve2(){
	nn.len=0;
	rep(i,1,m){
       	int x=i;
        rep(j,0,nn.len+1)nn.b[i]=0;
        nn.len=0;
        if (x<10000){
           nn.b[1]=i;
           nn.len=1;
		}
		else {
			 nn.b[1]=x%md;
			 nn.b[2]=x/md;
			 nn.len=2;
		}
		nn.ty=1;
		if (pd()) ans[++ans[0]]=i;
	}
    printf("%d\n",ans[0]);
    rep(i,1,ans[0])printf("%d\n",ans[i]);
}
int main(){
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	scanf("%d%d",&n,&m);
	if (n<=2)solve1();
	else {
		 pre();
		 solve2();
    }
	return 0;
}
