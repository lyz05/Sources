#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<cctype>
#include<string>
#include<vector>
#include<queue>
#include<cmath>
#include<ctime>
#include<map>
#include<set>
#define Read(a) a=readint()
#define For(i,a,b) for ( int i = a ; i < b ; i++ )
using namespace std ;

struct node {
	int u , v ;
	node ( int u = 0 , int v = 0 ):u(u),v(v) {}
};

typedef long long ll ;
typedef double db ;

const int maxn = 10000 + 10 ;
const int maxm = 1000 + 10 ;
const int INF = 2147483647 ;
vector < int > G[ maxn ] , T[ maxn ] ;
vector < node > E ;

int readint ( )
{
	char c = getchar ( ) ;
	while ( !isdigit ( c ) ) c = getchar ( ) ;
	int x = c - '0' ;
	while ( isdigit ( c = getchar ( ) ) ) x = x * 10 + c - '0' ;
	return x ;
}

int n , m ;
int st , ed ;
bool vis[ maxn ] , cant_go[ maxn ] , inq[ maxn ] ;
int dis[ maxn ] ;

void input ( )
{
	Read ( n ) ;
	Read ( m ) ;
	For ( i , 0 , m )
	{
		int x , y ;
		Read ( x ) ;
		Read ( y ) ;
		G[ x ].push_back ( y ) ;
		T[ y ].push_back ( x ) ;
		E.push_back ( node ( x , y ) ) ;
	}
	Read ( st ) ;
	Read ( ed ) ;
}

void bfs ( int s )
{
	queue < int > Q ;
	Q.push ( s ) ;
	vis[ s ] = true ;
	while ( !Q.empty ( ) )
	{
		int u = Q.front ( ) ; Q.pop ( ) ;
		For ( i , 0 , T[ u ].size ( ) )
		{
			int v = T[ u ][ i ] ;
			if ( vis[ v ] ) continue ;
			vis[ v ] = true ;
			Q.push ( v ) ;
		}
	}
}

int spfa ( int st , int ed )
{
	queue < int > Q ; while ( !Q.empty ( ) ) Q.pop ( ) ;
	Q.push ( st ) ;
	memset ( dis , 0x7f , sizeof ( dis ) ) ;
	int inf = dis[ 0 ] ;
	inq[ st ] = true ;
	dis[ st ] = 0 ;
	while ( !Q.empty ( ) )
	{
		int u = Q.front ( ) ; Q.pop ( ) ;
		inq[ u ] = false ;
		For ( i , 0 , G[ u ].size ( ) )
		{
			int v = G[ u ][ i ] ;
			if ( cant_go[ v ] ) continue ;//the dot which cannot reach the end, delete
			if ( dis[ v ] > dis[ u ] + 1 )
			{
				dis[ v ] = dis[ u ] + 1 ;//relax edges
				if ( !inq[ v ] )
				{
					Q.push ( v ) ;
					inq[ v ] = true ;
				}
			}
		}
	}
	return dis[ ed ] == inf ? -1 : dis[ ed ] ;
}

void solve ( )
{
	//check all dots which can be reached by ending-dot
	bfs ( ed ) ;
	if ( !vis[ st ] )
	{
		puts ( "-1" ) ;
		return ;
	}
	//The dot which is not on the path
	For ( i , 0 , E.size ( ) )
	{
		int u = E[ i ].u , v = E[ i ].v ;
		if ( !vis[ v ] )
		{
			cant_go[ u ] = cant_go[ v ] = true ;
		}
	}
	//calculate shotest path
	int ans = spfa ( st , ed ) ;
	cout << ans << endl ;
}

int main ( )
{
	freopen ( "road.in" , "r" , stdin ) ;
	freopen ( "road.out" , "w" , stdout ) ;
	input ( ) ;
	solve ( ) ;
	fclose ( stdin ) ;
	fclose ( stdout ) ;
	return 0 ;
}
