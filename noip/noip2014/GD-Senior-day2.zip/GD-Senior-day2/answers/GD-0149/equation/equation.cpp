#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<cctype>
#include<string>
#include<vector>
#include<queue>
#include<cmath>
#include<ctime>
#include<map>
#include<set>
#define For(i,a,b) for ( int i = a ; i < b ; i++ )
using namespace std ;

typedef long long ll ;
typedef double db ;

const int maxn = 100 + 5 ;
const int maxm = 1000 + 10 ;
const int cut = 10000 ;
const int INF = 2147483647 ;
const double eps = 1e-7 ;

char chtmp[ maxn*maxn ] ;

struct int10000 {
	int neg , len ;
	int num[ maxm ] ;
	
	void init ( int10000 a )
	{
		neg = a.neg ;
		len = a.len ;
		memcpy ( num , a.num , sizeof ( a.num ) ) ; 
	}
	
	void read ( )
	{
		char c = getchar ( ) ;
		while ( c != '-' && !isdigit ( c ) ) c = getchar ( ) ;
		if ( c == '-' ) this->neg = -1 , c = getchar ( ) ;
		else this->neg = 1 ;
		memset ( chtmp , 0 , sizeof ( chtmp ) ) ;
		int tmp = 0 ;
		while ( isdigit ( c ) ) chtmp[ tmp++ ] = c , c = getchar ( ) ;
		int x = 0 ;
		int cnt = 0 ;
		this->len = 0 ;
		int pow = 1 ;
		for ( int i = tmp - 1 ; i >= 0 ; i-- )
		{
			//x = x * 10 + chtmp[ i ] - '0' ;
			x = x + pow * ( chtmp[ i ] - '0' ) ;
			pow *= 10 ;
			cnt++;
			if ( cnt == 4 ) 
			{
				num[ len++ ] = x ;
				x = 0 ; 
				cnt = 0 ;
				pow = 1;
			}
		}
		if ( x != 0 ) num[ len++ ] = x ;
	}
	
	bool ok ( )
	{
		if ( len == 1 && num[ 0 ] == 0 ) return true ;
		else return false ;
	}
	
	/*void print ( )
	{
		if ( neg == -1 ) putchar('-');
		char tmp[10];
		for ( int i = len - 1 ; i >= 0 ; i-- )
		{
			sprintf(tmp,"%d",num[i]);
			int j = 0;
			while (isdigit(tmp[j])) j++;
			if (j<4) while((4-(j++))) putchar('0');
			printf("%s",tmp);
		}
		puts("\0");
	}*/
	
	bool operator< ( int10000&a )
	{
		if ( a.len != len ) return len < a.len ;
		For ( i , 0 , len ) if ( num[ i ] < a.num[ i ] ) return true ;
		else if ( num[ i ] > a.num[ i ] ) return false ;
		return false ;
	}
	
	void operator-=( int10000&a )
	{
		int x = 0 ;
		For ( i , 0 , len )
		{
			num[ i ] -= a.num[ i ] + x ;
			if ( num[ i ] < 0 )
			{
				x = 1 ;
				num[ i ] += cut ;
			}
			else x = 0 ;
		}
		while ( num[ len - 1 ] == 0 && len > 1 ) len-- ;
	}
	
	void operator+=( int10000&a )
	{
		int x = 0 ;
		int maxx = max ( len , a.len ) ;
		if ( a.neg * neg != 1 )
		{
			int neg_tmp = neg ;
			if ( neg == -1 )
			{
				if ( (*this) < a )
				{
					int10000 tmp ; tmp.init ( a ) ;
					tmp -= (*this) ;
					this->init ( tmp ) ;
					neg = - neg_tmp ;
				}
				else
				{
					int10000 tmp ; tmp.init ( *this ) ;
					tmp -= a ;
					this->init ( tmp ) ;
					neg = neg_tmp ;
				}
			}
			else
			{
				if ( a.operator< ( *this ) )
				{
					this->operator-= ( a ) ;
					neg = neg_tmp ;
				}
				else
				{
					int10000 tmp ; tmp.init ( a ) ;
					tmp -= (*this) ;
					this->init ( tmp ) ;
					neg = -1 ;
				}
			}
			return ;
		} 
		For ( i , 0 , maxx )
		{
			num[ i ] += a.num[ i ] + x ;
			if ( num[ i ] >= cut )
			{
				x = num[ i ] / cut ;
				num[ i ] %= cut ;
			}
			else x = 0 ;
		}
		if ( x != 0 ) num[ len = maxx ] = x , len++ ;
	}
	
	void operator*=( const int&a )
	{
		int x = 0 ;
		if ( a < 0 ) neg = -neg ;
		For ( i , 0 , len )
		{
			num[ i ] *= a ;
			num[ i ] += x ;
			if ( num[ i ] >= cut )
			{
				x = num[ i ] / cut ;
				num[ i ] %= cut ;
			}
			else x = 0 ;
		}
		if ( x != 0 )
		{
			len++;
			num[ len - 1 ] = x % cut ;
			if ( x / cut > 0 )
			{
				len++;
				num[ len - 1 ] = x / cut ;
			}
		}
	}
}a[ maxn ] , ans , bigtmp ;

int n , m ;

void input ( )
{
	scanf ( "%d %d" , &n , &m ) ;
	For ( i , 0 , n + 1 )
		a[ i ].read ( ) ;
}

int x ;
int x_list[ maxn ] , x_cnt ;

void calc ( int times )
{
	ans *= x ;
	ans += a[ times ] ;
	if ( times == 0 ) return ;
	else calc ( times - 1 ) ;
}

void solve ( )
{
	for ( x = 1 ; x <= m ; x++ )
	{
		ans.init ( a[ n ] ) ;
		calc ( n - 1 ) ; 
		if ( ans.ok ( ) ) x_list[ x_cnt++ ] = x ;
	}
	printf ( "%d\n" , x_cnt ) ;
	For ( i , 0 , x_cnt )
		printf ( "%d\n" , x_list[ i ] ) ;
}

int main ( )
{
	freopen ( "equation.in" , "r" , stdin ) ;
	freopen ( "equation.out" , "w" , stdout ) ;
	input ( ) ;
	solve ( ) ;
	fclose ( stdin ) ;
	fclose ( stdout ) ;
	return 0 ;
}
