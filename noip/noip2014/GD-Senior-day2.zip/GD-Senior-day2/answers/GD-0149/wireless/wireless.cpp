#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<cctype>
#include<string>
#include<vector>
#include<queue>
#include<cmath>
#include<ctime>
#include<map>
#include<set>
#define Read(a) a=readint()
#define For(i,a,b) for ( int i = a ; i < b ; i++ )
using namespace std ;

typedef int ll ;
typedef double db ;

const int maxn = 128 + 10 ;
const int maxm = 1000 + 10 ;
const int INF = 2147483647 ;
const double eps = 1e-7 ;

int readint ( )
{
	char c = getchar ( ) ;
	while ( !isdigit ( c ) ) c = getchar ( ) ;
	int x = c - '0' ;
	while ( isdigit ( c = getchar ( ) ) ) x = x * 10 + c - '0' ;
	return x ;
}

int n , m ;
int d ;
int G[ maxn ][ maxn ] , sum[ maxn ][ maxn ] ;
int minx , miny , maxx , maxy ;

void input ( )
{
	Read ( d ) ;
	Read ( n ) ;
	memset ( G , 0 , sizeof ( G ) ) ;
	minx = miny = INF ;
	For ( i , 0 , n )
	{
		int x , y , v ;
		Read ( x ) ;
		minx = min ( minx , x ) ;
		maxx = max ( maxx , x ) ;
		Read ( y ) ;
		miny = min ( miny , y ) ;
		maxy = max ( maxy , y ) ;
		Read ( v ) ;
		G[ x ][ y ] = v ;
	}
	/*sum[ minx ][ miny ] = G[ minx ][ miny ] ;
	For ( i , 1 , maxy + 1 )
		sum[ minx ][ i ] = sum[ minx ][ i - 1 ] + G[ minx ][ i ] ;
	For ( i , 1 , maxx + 1 )
		sum[ i ][ miny ] = sum[ i - 1 ][ miny ] + G[ i ][ miny ] ;
	For ( i , 2 , maxx + 1 )
		For ( j , 2 , maxy + 1 )
			sum[ i ][ j ] = sum[ i - 1 ][ j ] + sum[ i ][ j - 1 ] - sum[ i - 1 ][ j - 1 ] ;*/
}

ll calc ( int x , int y )
{
	ll ret = 0 ;
	int UP = max ( minx , x - d ) ;
	int DOWN = min ( maxx , x + d ) ;
	int LEFT = max ( miny , y - d ) ;
	int RIGHT = min ( maxy , y + d ) ;
	/*ret = sum[ DOWN ][ RIGHT ] - sum[ DOWN ][ max ( LEFT - 1 , miny ) ] 
		- sum[ max ( UP - 1 , minx ) ][ RIGHT ] + sum[ max ( UP - 1 , minx ) ][ max ( LEFT - 1 , miny ) ] ;*/
	For ( i , UP , DOWN + 1 )
		For ( j , LEFT , RIGHT + 1 )
			ret += G[ i ][ j ] ;
	return ret ;
}

void solve ( )
{
	ll ans = 0 ;
	int cnt = 0 ;
	For ( i , minx , maxx + 1 )
		For ( j , miny , maxy + 1 )
		{
			ll tmp = calc ( i , j ) ;
			if ( tmp > ans )
			{
				ans = tmp ;
				cnt = 1 ;
			}
			else if ( tmp == ans )
				cnt++ ;
		}	
	cout << cnt << " " << ans << endl ;
}

int main ( )
{
	freopen ( "wireless.in" , "r" , stdin ) ;
	freopen ( "wireless.out" , "w" , stdout ) ;
	input ( ) ;
	solve ( ) ;
	fclose ( stdin ) ;
	fclose ( stdout ) ;
	return 0 ;
}
