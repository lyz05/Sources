#include<cstdio>
#include<algorithm>
#include<vector>
#include<cstring>
#define MOD 9
#define MOD2 10000000
using namespace std;

int n,m,q,len[105],sum[105],last[105];
char a[105][10005];

vector<int> ans;

int find() {
	int b[5],sum0;
	for (int i=0;i<=n;i++) scanf("%d",&b[i]);
	for (int i=1;i<=m;i++) {
		sum0=0;
		for (int j=n;j>0;j--) {
			sum0=(sum0+b[j])*i;
		}
		if (sum0+b[0]==0) {
			ans.push_back(i);
		}
	}
	printf("%d\n",ans.size());
	for (int i=0;i<ans.size();i++) {
		printf("%d\n",ans[i]);
	}
}

int search(int k) {
	int sum0=0;
	for (int i=0;i<n;i++) {
		sum0=(sum0+last[i]) % MOD2;
		sum0=(sum0*k) % MOD2;
	}

	if ((sum0+last[n]) % MOD2 != 0) return 0;
	sum0=0;
	for (int i=0;i<n;i++) {
		sum0=(sum0+sum[i]) % MOD;
		sum0=(sum0*k) % MOD;
	}
	if ((sum0+sum[n]) % MOD != 0) return 0;
	return 1;
}

int shui() {
	for (int div=1;div<=m;div++) {
		if (search(div)) ans.push_back(div);
	}
}

int main() {
	freopen("equation.in","r",stdin);freopen("equation.out","w",stdout);
	scanf("%d%d",&n,&m);
	if (n<=2) find();
	else {
		for (int i=n;i>=0;i--) {
			getchar();
			scanf("%s",a[i]);
			len[i]=strlen(a[i]);
			if (a[i][0]=='-') q=1;
			else q=0;
			for (int j=q;j<len[i];j++) {
				sum[i]+=a[i][j]-'0';
			}
			sum[i]%=MOD;
			for (int j=len[i]-1,k=1;j>=max(q,len[i]-7);j--,k*=10) {
				last[i]+=(a[i][j]-'0')*k;
			}
			if (q) {
				sum[i]*=-1;
				last[i]*=-1;
			}
		}
		while (sum[n]==0 && last[n]==0) n--;
		shui();
		printf("%d\n",ans.size());
		for (int i=0;i<ans.size();i++) {
			printf("%d\n",ans[i]);
		}
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
