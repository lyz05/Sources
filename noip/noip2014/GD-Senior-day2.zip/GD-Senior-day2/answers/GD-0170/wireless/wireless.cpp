#include<cstdio>
#include<cstring>

int n,d,x,y,k,max=-1,ans=0;

int sum[129][129];

int main() {
	freopen("wireless.in","r",stdin);freopen("wireless.out","w",stdout);
	scanf("%d%d",&d,&n);
	memset(sum,0,sizeof(sum));
	for (int i=0;i<n;i++) {
		scanf("%d%d%d",&x,&y,&k);
		for (int x0=x-d;x0<=x+d;x0++) if (x0>=0 && x0<=128)
			for (int y0=y-d;y0<=y+d;y0++) if (y0>=0 && y0<=128)
				sum[x0][y0]+=k;
	}
	for (int i=0;i<=128;i++) for (int j=0;j<=128;j++) {
		if (sum[i][j]==max) {
			ans++;
		}
		if (sum[i][j]>max) {
			max=sum[i][j];
			ans=1;
		}
	}
	printf("%d %d\n",ans,max);
	fclose(stdin);fclose(stdout);
	return 0;
}
