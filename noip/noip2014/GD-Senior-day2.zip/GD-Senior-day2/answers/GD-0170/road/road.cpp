#include<cstdio>
#include<vector>
#include<cstring>
#define MAXN 10005
using namespace std;

vector<int> edges[10005];

int n,m,p,now,r,h,u,v,s,t,ans=-1;

int f[MAXN],flag[MAXN],from[MAXN],q[MAXN],que[MAXN],dist[MAXN];

int main() {
	freopen("road.in","r",stdin);freopen("road.out","w",stdout);
	scanf("%d%d",&n,&m);
	memset(from,0,sizeof(from));
	memset(f,0,sizeof(f));
	for (int i=0;i<m;i++) {
		scanf("%d%d",&u,&v);
		edges[v].push_back(u);
		from[u]++;
	}
	scanf("%d%d",&s,&t);
	r=h=0;
	q[0]=t;
	while (r<=h) {
		p=q[r++];
		for (int i=0;i<edges[p].size();i++) {
			now=edges[p][i];
			if (!f[now]) q[++h]=now;
			f[now]++;
		}
	}
	r=0;h=1;
	que[0]=t;
	memset(dist,0x7f,sizeof(dist));
	dist[t]=0;
	while (r!=h) {
		p=que[r];
		r=(r+1)%n;
		for (int i=0;i<edges[p].size();i++) {
			now=edges[p][i];
			if (from[now]!=f[now]) continue;
			if (dist[now]>dist[p]+1) {
				dist[now]=dist[p]+1;
				if (now==s) ans=dist[now];
				if (!flag[now]) {
					flag[now]=1;
					que[h]=now;
					h=(h+1)%n;
				}
			}
		}
		flag[p]=0;
	}
	printf("%d\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
