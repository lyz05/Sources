#include<cstdio>
#include<cstring>

int book[105],map[105][105],s,t,step,flag,n,min;
int dfs(int d){
	int i;	
	if (d==t) {
		flag=1;
		if (min>step) min=step;
		return step;
	}
	for (i=1; i<=n; i++)
	    if (book[i]==0 && map[d][i]==1){

			step++;
	    	book[i]=1;
	    	dfs(i);	     	
	    	step--;
	    	book[i]=0;	
	    }
}

int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	
	int i,m,x,y;
	memset(map,0,sizeof(map));
	scanf("%d%d",&n,&m);
	for (i=1; i<=m; i++){
		scanf("%d%d",&x,&y);
		map[x][y]=1;
	}
	scanf("%d%d",&s,&t);
	
	min=1000; flag=0; dfs(s);
	if (flag==1) printf("%d",min);
	else printf("-1");
	return 0;
}
