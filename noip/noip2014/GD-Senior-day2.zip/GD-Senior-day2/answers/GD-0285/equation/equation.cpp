#include<cstdio>
#include<cstring>

int main(){
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	
	int n,m,i,j,k,num,sum,a[105],s[105];
	scanf("%d%d",&n,&m);
	sum=0;
	memset(s,0,sizeof(s));
	for (i=0; i<=n; i++) scanf("%d",&a[i]);
	for (i=1; i<=m; i++){
	    for (j=0; j<=n; j++){
		    num=1;
	    	for (k=1; k<=j; k++)
		        num*=i;
		    s[i]+=a[j]*num;
		    
	    }
	    if (s[i]==0) sum++;
    }
	
	printf("%d\n",sum);	    
	for (i=1; i<=m; i++)
		if (s[i]==0) printf("%d\n",i);

	return 0;
}
