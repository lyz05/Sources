#include<cstdio>
#include<cstring>

int main(){
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	
	int d,n,i,j,m,k,x,y,max,num,l,r,a[130][130];
	memset(a,0,sizeof(a));
	max=0; l=128; r=0;
	scanf("%d",&d);
	scanf("%d",&n);
	for (i=1; i<=n; i++){
		scanf("%d%d%d",&x,&y,&k);
		if (x<l) l=x; if (y>r) r=y;
		for (j=x-d; j<=x+d; j++)
		    for (m=y-d; m<=y+d; m++) a[j][m]+=k;		
	} 
	
	num=0; l-=d; r+=d;
	for (i=l; i<=r; i++)
	    for (j=l; j<=r; j++){
	         if (a[i][j]>max) {
	         	max=a[i][j];
	         	num=1;
	         }
	         else if (a[i][j]==max) num++;
	    }
	printf("%d %d",num,max);
	return 0;
}
