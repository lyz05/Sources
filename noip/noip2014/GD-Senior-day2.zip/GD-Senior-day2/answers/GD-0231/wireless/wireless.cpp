#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;
int f[310][310];
int main()
{
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	int d,n,i,j,t,x,y,k,x1,x2,y1,y2,s=0,p=0;
	memset(f,0,sizeof(f));
	scanf("%d%d",&d,&n);
	for(t=1;t<=n;t++)
	{
	  scanf("%d%d%d",&x,&y,&k);
	  x1=x-d;if(x1<0)x1=0;
	  x2=x+d;if(x2>128)x2=128;
	  y1=y-d;if(y1<0)y1=0;
	  y2=y+d;if(y2>128)y2=128;
	  for(i=x1;i<=x2;i++)
	    for(j=y1;j<=y2;j++)
	      f[i][j]+=k;
	}
	for(i=0;i<=128;i++)
	  for(j=0;j<=128;j++)
	  	if(f[i][j]>s)s=f[i][j],p=1;
	  	else if(f[i][j]==s)p++;
	printf("%d %d\n",p,s);
	return 0;
}
