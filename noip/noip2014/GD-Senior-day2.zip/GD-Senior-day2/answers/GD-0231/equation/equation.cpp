#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;
int p[10010],len=0,n;
struct node
{
	int a[15010],l;
	node()
	{
	  memset(a,0,sizeof(a));
	  l=0;
	}
}w[110],o[110];
char c[10010];
node cheng(node x,int k)
{
	if(k==0)
	{
	  node s;
	  return s;
	}
	int ok=0;
	if(k<0)
	{
	  k=-k;
	  if(ok)ok=0;
	  else ok=1;
    }
    if(x.a[x.l]<0)
    {
      x.a[x.l]=-x.a[x.l];
      if(ok)ok=0;
	  else ok=1;	
    }
	int i;
	for(i=1;i<=x.l;i++)
	  x.a[i]*=k;
	for(i=1;i<=x.l;i++)
	{
	  x.a[i+1]+=x.a[i]/10;
	  x.a[i]%=10;
	}
	while(x.a[x.l+1]!=0)
	{
	  x.l++;
	  x.a[x.l+1]+=x.a[x.l]/10;
	  x.a[x.l]%=10;
	}
	if(ok)x.a[x.l]=-x.a[x.l];
	return x;
}
int q(node x,node y)
{
	int i,l=x.l>y.l?x.l:y.l;
	if(x.l>y.l)return 1;
	if(x.l<y.l)return 0;
	for(i=l;i>=1;i--)
	{
	  if(x.a[i]>y.a[i])return 1;
	  if(x.a[i]<y.a[i])return 0;
	}
	return 1;
}
node tjian(node x,node y)
{
    int i,ok=0;
	node t;
	if(!q(x,y)){t=x;x=y;y=t;ok=1;}
	for(i=1;i<=x.l;i++)
	{
	  x.a[i]-=y.a[i];
	  if(x.a[i]<0)
	  {
	    x.a[i]+=10;
	    x.a[i+1]--;
      }
	}
	while(x.a[x.l]==0&&x.l!=0)
	  x.l--;
	if(ok)x.a[x.l]=-x.a[x.l];
	return x;
}
node jia(node x,node y)
{
	int i;
	x.l=x.l>y.l?x.l:y.l;
	for(i=1;i<=x.l;i++)
	{
	  x.a[i]+=y.a[i];
	  x.a[i+1]+=x.a[i]/10;
	  x.a[i]%=10;
	}
	while(x.a[x.l]!=0)
	{
	  x.l++;
	  x.a[x.l+1]+=x.a[x.l]/10;
	  x.a[x.l]%=10;
	}
	return x;
}
node jian(node x,node y)
{
	if(x.l==0)
	{
	  y.a[y.l]=-y.a[y.l];
	  return y;
	}
	if(y.l==0)return x;
	if(x.a[x.l]>0&&y.a[y.l]>0)return tjian(x,y);
	if(x.a[x.l]<0&&y.a[y.l]<0)
	{
	  x.a[x.l]=-x.a[x.l];
	  y.a[y.l]=-y.a[y.l];
	  x=tjian(x,y);
	  x.a[x.l]=-x.a[x.l];
	  return x;
    }
    if(x.a[x.l]>0&&y.a[y.l]<0)
    {
      y.a[y.l]=-y.a[y.l];
      return jia(x,y);
    }
    if(x.a[x.l]<0&&y.a[y.l]>0)
    {
      x.a[x.l]=-x.a[x.l];
      x=jia(x,y);
      x.a[x.l]=-x.a[x.l];
      return x;
    }
	
}
int g(int x)
{
	int i;
	o[n]=w[n];
	for(i=n-1;i>=0;i--)
	  o[i]=jian(w[i],cheng(o[i+1],x));
	if(o[0].l==0&&o[0].a[1]==0)
	{
	  n--;
	  for(i=0;i<=n;i++)
	    w[i]=o[i+1];
	  return 1;
	}
	return 0;
}
int main()
{
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	int m,i,j,x,y,z;
	scanf("%d%d",&n,&m);
	if(n<=2)
	{
	  if(n==1)
	  {
	    scanf("%d%d",&x,&y);
	    for(i=1;i<=m;i++)
	      if(x+y*i==0)p[++len]=i;
	  }
	  else
	  {
	  	scanf("%d%d%d",&x,&y,&z);
	  	  for(i=1;i<=m;i++)
	  	    if(x+y*i+z*i*i==0)p[++len]=i;
	  }
	  printf("%d\n",len);
	  for(i=1;i<=len;i++)
	    printf("%d\n",p[i]);
	}
	else
	{
	  for(i=0;i<=n;i++)
	  {
	  	scanf("%s",c);
	  	if(c[0]=='-')
	  	{
	  	  w[i].l=strlen(c)-1;
	  	  for(j=1;j<=w[i].l;j++)
	  	    w[i].a[j]=c[w[i].l-j+1]-'0';
	  	  w[i].a[w[i].l]=-w[i].a[w[i].l];
	  	}
	  	else
		{
		  w[i].l=strlen(c);
	  	  for(j=1;j<=w[i].l;j++)
	  	    w[i].a[j]=c[w[i].l-j]-'0';
	  	}
	  }
	  for(i=1;i<=m;i++)
	    if(g(-i))p[++len]=i;
	  printf("%d\n",len);
	  for(i=1;i<=len;i++)
	    printf("%d\n",p[i]);
	}
	return 0;
}
