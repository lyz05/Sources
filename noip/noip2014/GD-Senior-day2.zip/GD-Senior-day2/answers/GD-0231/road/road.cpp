#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<queue>
using namespace std;
struct node
{
    int x,y,next;
}a[200010],b[200010];
int first[10010],len=0,first1[10010],sp,tp,f[10010];
bool v[10010],p[10010];
queue<int> z;
void ins(int x,int y)
{
	a[++len].x=x;a[len].y=y;
	a[len].next=first[x];first[x]=len;
	b[len].x=y;b[len].y=x;
	b[len].next=first1[y];first1[y]=len;
}
void g(int x)
{
	v[x]=1;
	int k,y;
	for(k=first1[x];k;k=b[k].next)
	{
	  y=b[k].y;
	  if(!v[y])g(y);
	}
}
void spfa()
{
	int x,y,k;
	while(!z.empty())z.pop();
	memset(f,63,sizeof(f));
	memset(v,0,sizeof(v));
	f[sp]=0;z.push(sp);v[sp]=1;
	while(!z.empty())
	{
	  x=z.front();
	  for(k=first[x];k;k=a[k].next)
	  {
	    y=a[k].y;
	    if(!p[y])continue;
	    if(f[y]>f[x]+1)
	    {
	      f[y]=f[x]+1;
	      if(!v[y]){z.push(y);v[y]=1;}
	    }
	  }
	  z.pop();
	  v[x]=0;
	}
	if(f[tp]<10000010)printf("%d\n",f[tp]);
	else printf("-1\n");
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n,m,i,k,x,y;
	scanf("%d%d",&n,&m);
	for(i=1;i<=m;i++)
	{
	  scanf("%d%d",&x,&y);
	  ins(x,y);
	}
	scanf("%d%d",&sp,&tp);
	memset(v,0,sizeof(v));
	g(tp);
	memset(p,1,sizeof(p));
	for(i=1;i<=n;i++)
	  for(k=first[i];k;k=a[k].next)
	    if(!v[a[k].y]){p[i]=0;break;}
	if(!p[sp])printf("-1\n");
	else spfa();
	return 0;
}
