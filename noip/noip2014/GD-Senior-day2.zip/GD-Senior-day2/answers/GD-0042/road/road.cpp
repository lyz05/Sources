#include <iostream>
#include <fstream>
using namespace std;

typedef struct TongJunLi_does_modernization_competition{
	signed short a;
	signed short b;
}
Revolution, & QiaoJiaHao_Polished_HD_6970;

long n,m,s,t;
Revolution v[200000];
unsigned char wk[10000];
long Intel[10000];
// Bin: 0000 0000
/*
Bit 0: Is connected to target;
Bit 1: All child vertices have bit 0
*/

bool bit0(long n);
bool bit1(long n);
void Monitor_Height_156(long a, long b);

template <typename GeForce>
inline void Radeon(GeForce& a,GeForce& b){GeForce t=a;a=b;b=t;}


ifstream fin;
ofstream fout;

int main(){
	fin.open("road.in");
	fout.open("road.out");
	
	fin >> n >> m;
	int i,ta,tb;
	for(i = 0;i < m;i++){
		fin >> ta >> tb;
		if(ta == tb){
			m--;
			i--;
			continue;
		}
		v[i].a = ta - 1;
		v[i].b = tb - 1;
	}
	fin >> s >> t;
	
	/*
	Monitor_Height_156(0,m);
	int cr = v[0].a;
	Intel[cr] = 0;
	for(i = 0;i < n;i++){
		if(v[i].a != cr){
			cr = v[i].a;
			Intel[cr] = i;
		}
	}
	*/
	
	fout << "-1" << endl;
	fin.close();
	fout.close();
	return 0;
}

void Monitor_Height_156(long a, long b){
	if(a+1 >= b)return;
	int i = a,j = b-1,f = 0;
	
	while(i < j){
		if((v[i].a > v[j].a) || ((v[i].a == v[j].a)&&(v[i].b > v[j].b))){
			Radeon(v[i],v[j]);
			f = f ^ 1;
		}
		
		(f == 0) ? j-- : i++;
	}
	
	Monitor_Height_156(a,i);
	Monitor_Height_156(i+1,b);
}



