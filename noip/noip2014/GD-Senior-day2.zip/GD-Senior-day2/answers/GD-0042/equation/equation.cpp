#include <iostream>
#include <fstream>
using namespace std;

long n, m, ansc, ans[10000];
long a[100];

long ipow(long x,long i){
	if(i == 0)return 1;
	int a;
	for(a = 1;a < i;a++){
		x *= x;
	}
	return x;
}

long func(long x){
	int i,m = 0;
	for(i = 0;i <= n;i ++){
		m += a[i] * ipow(x,i);
	}
	return m;
}

ifstream fin;
ofstream fout;

int main(){
	fin.open("equation.in");
	fout.open("equation.out");
	
	fin >> n >> m;
	int i;
	for(i = 0;i <= n;i++)
		fin >> a[i];
	
	/*XZSYWXZSYWXZSYWXZSYWXZSYWXZSYWXZSYWXZSYW*/
	if(n>2){
		fout << 0 << endl;
		fout.close();
		return 0;
	}
	/*XZSYWXZSYWXZSYWXZSYWXZSYWXZSYWXZSYWXZSYW*/
	
	ansc = 0;
	for(i = 1;i <= m;i++){
		if(func(i) == 0){
			ans[ansc] = i;
			ansc ++;
		}
	}
	
	fout << ansc << endl;
	for(i = 0;i < ansc;i++)
		fout << ans[i] << endl;
	
	fin.close();
	fout.close();
	return 0;
}

/*
TongJunLi is a Modernization Competition Dog
*/


