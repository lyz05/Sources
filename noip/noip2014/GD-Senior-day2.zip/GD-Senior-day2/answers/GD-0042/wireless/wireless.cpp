#include <iostream>
#include <fstream>
using namespace std;

typedef struct _YaoTianXi_ZhongKao_Only_652{
	long x;
	long y;
	long k;
}
Zoe_score_779;

long d,n,range,ap;

Zoe_score_779 zoe[20];

long map[130][130],ansn,answ;

ifstream fin;
ofstream fout;

bool loveZY(long,long);

int main(){
	fin.open("wireless.in");
	fout.open("wireless.out");
	
	fin >> d >> n;
	ap = 2*d + 1;
	range = ap*ap;
	int i,k;
	for(i = 0;i < n;i++)
		fin >> zoe[i].x >> zoe[i].y >> zoe[i].k;
	
	int x,y,c;
	for(i = 0;i < n;i++){
		c = zoe[i].k;
		for(k = 0;k < range;k++){
			x = zoe[i].x - d + k%ap;
			y = zoe[i].y - d + k/ap;
			if(loveZY(x,y))
				map[x][y] += c;
		}
	}
	
	ansn = answ = 0;
	for(i = 0;i < 129*129;i++){
		if(map[i%129][i/129] > ansn){
			ansn = map[i%129][i/129];
			answ = 1;
		}
		else if(map[i%129][i/129] == ansn){
			answ ++;
		}
	}
	
	fout << answ << " " << ansn << endl;
	fin.close();
	fout.close();
	return 0;
}

inline bool loveZY(long x,long y){
	if(x<0 || y<0 || x>128 || y>128){
		return false;
	}else{
		return true;
	}
}

