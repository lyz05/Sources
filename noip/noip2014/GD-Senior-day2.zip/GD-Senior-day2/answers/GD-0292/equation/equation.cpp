#include <stdio.h>
#include <iostream>
using namespace std;

int n,m;
int a[1001];
int ans[1001],num=0;

int main(){
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	cin>>n>>m;
	int i,j,k;
	int flag=0;
	for(i=0;i<=n;++i){
		scanf("%d",&a[i]);
		if(a[i]<=0) flag=1; 
	}
	if(flag==0) cout<<"0"<<endl;
	else{
	for(i=1;i<=m;++i){
		int sum=0;
		int x=1;
		for(j=0;j<=n;++j){
			sum=sum+a[j]*x;
			x=x*i;
		}
		if(sum==0) ans[++num]=i;
	}
	cout<<num<<endl;
	for(i=1;i<=num;++i) cout<<ans[i]<<endl;
	return 0;
    }
}
