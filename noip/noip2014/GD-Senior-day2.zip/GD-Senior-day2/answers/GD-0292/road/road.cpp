#include <stdio.h>
#include <iostream>
using namespace std;

int n,m,s,t;
int e[10001][10001]={0},dist[10001],sp[100001]={0},vis[10001]={0},ava[10001]={0};

struct node{
	int u;
	int v;
}road[200001];

int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d%d",&n,&m);
	int i,j,k;
	for(i=1;i<=m;++i){
		scanf("%d%d",&road[i].u,&road[i].v);
		e[road[i].u][road[i].v]=1;
	}
	scanf("%d%d",&s,&t);
	//�����T��ʼ��
	for(i=1;i<=n;++i) dist[i]=1000000; 
	int p=1;
	sp[p]=t;
	vis[t]=1;
	dist[t]=0;
	int end=p;
	while(sp[p]!=0){
		for(i=1;i<=n;++i){
			if(vis[i]==0){ 
				if(dist[i]>dist[sp[p]]+e[i][sp[p]] && e[i][sp[p]]==1){
					dist[i]=dist[sp[p]]+e[i][sp[p]];
					end++;
					sp[end]=i;
					vis[i]=1;
				}
			}
		}
		vis[sp[p]]=0;
		p++;
	}
	//ɾ��ɾ�ߣ�
	for(i=1;i<=n;++i){
		if(dist[i]==1000000){
			for(j=1;j<=n;++j){
				if(e[j][i]==1){
					ava[j]=1;
				}
			}
			ava[i]=1;
		}
	} 
	//�س�ʼ���� 
	for(i=1;i<=n;++i){
	    for(j=1;j<=n;++j){
	    	e[i][j]=0;
	    }
	    dist[i]=1000000;
	    vis[i]=0;
	}
	for(i=1;i<=end+2;++i) sp[i]=0;
	for(i=1;i<=m;++i){
		int i1,i2;
		i1=road[i].u;
		i2=road[i].v;
		if(ava[i1]==0 && ava[i2]==0){
			e[i1][i2]=1;
		}
	}
	//�����s��ʼ��
	p=1;
	sp[p]=s;
	vis[s]=1;
	dist[s]=0;
	end=p;
	while(sp[p]!=0){
		for(i=1;i<=n;++i){
			if(ava[i]==0 &&vis[i]==0){ 
				if(dist[i]>dist[sp[p]]+e[sp[p]][i] && e[sp[p]][i]==1){
					dist[i]=dist[sp[p]]+e[sp[p]][i];
					end++;
					sp[end]=i;
					vis[i]=1;
				}
			}
		}
		vis[sp[p]]=0;
		p++;
	} 
	//����� 
	if(dist[t]==1000000) cout<<"-1";
	else printf("%d",dist[t]);
	return 0;
}








