#include <stdio.h>
#include <iostream>
#include <cstdlib>
using namespace std;

int n,d;
int p[200][200]={0};

struct node{
	int x;
	int y;
	int val;
}pub[101];

int main(){
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	scanf("%d%d",&d,&n);
	int i,j,k;
	for(i=1;i<=n;++i){
		cin>>pub[i].x>>pub[i].y>>pub[i].val;
	}
	int da=0,sum=0;
	for(i=0;i<=128;++i){
		for(j=0;j<=128;++j){
			for(k=1;k<=n;++k){
				if(abs(i-pub[k].x)<=d && abs(j-pub[k].y)<=d){
					p[i][j]+=pub[k].val;
				}
			}
			if(da<p[i][j]){
				da=p[i][j];
				sum=1;
			}
			else if(da==p[i][j]) 
			    sum++;//��������һ�� 
		}
	}
	printf("%d %d",sum,da);
	return 0;
}
