#include<iostream>
#include<stdio.h>
#include<string.h>
using namespace std;
int e[100][10000],ed[100],f[100][10000],ted[100][20000];
int main()
{
  freopen("equation.in","r",stdin);
  freopen("equation.out","w",stdout);
  int n,m;
  scanf("%d%d",&n,&m);
  if(n<=2)
    {
     int a[100],ans[200];
     int tmp,x;
     for(int i=0;i<=n;i++)
       {
        scanf("%d",&a[i]);
       }
     ans[0]=0;
     for(int i=1;i<=m;i++)
       {
       	tmp=0;
       	x=1;
        for(int j=0;j<=n;j++)
          {
           tmp+=a[j]*x;
           x*=i;
          }
        if(tmp==0)
          ans[++ans[0]]=i;
       }
     printf("%d\n",ans[0]);
     for(int i=1;i<=ans[0];i++)
      printf("%d\n",ans[i]);
    }
  else
    {
     int l;
     char c[11000];
     int ans[10000];
     ans[0]=0;
     for(int i=0;i<=n;i++)
       {
        scanf("%s",c);
        l=strlen(c);
        e[i][0]=l;
        int x=0;
        if(c[0]=='-')
          {
           ed[i]=0;
           x=1;
          }
        else ed[i]=1;
        for(int j=x;j<l;j++)
          e[i][j+1]=int(c[j])-'0';
       }
     memset(f,0,sizeof(f));
	 memset(ted,0,sizeof(ted));
     f[0][1]=1;
     f[0][0]=1;
     int len,x;
     for(int i=1;i<=m;i++)
     {
      for(int j=0;j<=n;j++)
        {
         for(int h=1;h<=e[j][0];h++)
          for(int r=1;r<=f[j][0];r++)
            {
             ted[j][h+r-1]+=e[j][h]*f[j][r];
            }
         len=e[j][0]+f[j][0];
         x=1;
         while(x<=len)
           {
           	if(ted[j][x]!=0)ted[j][0]=x;
           	ted[j][x+1]+=ted[j][x]/10;
           	ted[j][x]%=10;
           }
         for(int h=1;h<=f[j][0];h++)
           f[j+1][h]=f[j][h]*i;
         len=f[j][0];
         if(i>=10)len+=2;
         else len+=1;
         x=1;
           while(x<=len)
             {
              if(f[j+1][x]>0)f[j+1][0]=x;
              f[j+1][x+1]+=f[j+1][x]/10;
              f[j+1][x]%=10;
             }
        }
	  if(ed[n]==0)
	    for(int j=1;j<=ted[n][0];j++)
	    ted[n][j]=-ted[n][j];
	  len=ted[n][0];
      for(int j=0;j<n;j++)
	    {
	     if(ted[j][0]>len)
	       len=ted[j][0];
	     if(ed[j]==0)x=-1;
	     else x=1;
	     for(int h=1;h<=ted[j][0];h++)
	     ted[n][h]+=ted[j][h]*x;
	    }
	  x=1;
	  len+=10;
	  while(x<=len)
	    {
	     ted[n][x+1]+=ted[n][x]/10;
	     ted[n][x]%=10;
	    }
	  int pan=1;
	    for(int j=1;j<=len;j++)
	      if(ted[j]!=0){pan=0;break;}
	  if(pan)
	    ans[++ans[0]]=i;
     }
     printf("%d\n",ans[0]);
     for(int i=1;i<=ans[0];i++)
     printf("%d\n",ans[i]);
    }
  return 0;
}

