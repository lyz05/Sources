#include<iostream>
#include<stdio.h>
#include<string.h>
using namespace std;
int map[200][200]={0},f[200][200]={0};
int n=129,m=129,ant,ans;
int main()
{
  freopen("wireless.in","r",stdin);
  freopen("wirelsee.out","w",stdout);
  int d,rt,x,y,tmp;
  scanf("%d%d",&d,&rt);
  d=d*2;
  for(int i=1;i<=rt;i++)
    {
     scanf("%d%d",&x,&y);
     scanf("%d",&map[x+1][y+1]);
    }
  for(int i=1;i<=n;i++)
    for(int j=1;j<=m;j++)
      {
       map[i][j]+=map[i-1][j]+map[i][j-1]-map[i-1][j-1];
      }
  ans=0;
  x=d+1;y=d+1;
  if(n<x)x=n;
  if(m<y)y=m;  
   for(int i=x;i<=n;i++)
     for(int j=y;j<=m;j++)
       {
        tmp=map[i][j]+map[i-x][j-y]-map[i-x][j]-map[i][j-y];
        if(tmp>ans)
          {
           ans=tmp;
           ant=1;
           
          }
        else if(tmp==ans)
          ant++;
       }
  printf("%d %d\n",ant,ans);
  return 0;
}








