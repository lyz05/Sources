#include<iostream>
#include<stdio.h>
#include<string.h>
using namespace std;
struct str
{
   int v;
   int next;
}eu[220000],ev[220001];
int te=0;
int pu[10001]={0},pv[10001]={0};
int fu[10001],fv[10001]={0};
int e[10001]={0};
int q[100000],vis[10001];
int main()
{
  freopen("road.in","r",stdin);
  freopen("road.out","w",stdout);
  int n,m,s,t;
  int x,y;
  scanf("%d%d",&n,&m);
  for(int i=1;i<=m;i++)
    {
     scanf("%d%d",&x,&y);
     if(x==y)continue;
     te++;
     eu[te].v=y;
	 eu[te].next=pu[x];
	 pu[x]=te;
	 ev[te].v=x;
	 ev[te].next=pv[y];
	 pv[y]=te;
    }
  scanf("%d%d",&s,&t);
  int h,r,next;
  h=r=1;
  q[h]=t;
  //memset(vis,0,sizeof(vis));
  while(h<=r)
    {
      x=q[h];
      next=pv[x];
      while(next!=0)
        {
         if(fv[ev[next].v]==0)
           {
            fv[ev[next].v]=1;
            r=(r+1)%50000;
            q[r]=ev[next].v;
           }
         next=ev[next].next;
        }
      h=(h+1)%50000;
    }
  fv[t]=1;
  //for(int i=1;i<=n;i++)cout<<i<<" "<<fv[i]<<endl;
  int pan;
  for(int i=1;i<=n;i++)
    {
     pan=1;
     next=pu[i];
     while(next!=0)
       {
        if(fv[eu[next].v]!=1)
         {
          pan=0;
          break;
         }
        next=eu[next].next;
       }
     if(pan&&fv[i])
       e[i]=1;
    }
  //for(int i=1;i<=n;i++)cout<<i<<" "<<e[i]<<endl;
  int ans=-1;
  if(e[s]==1)
    {
      h=r=1;
      q[h]=s;
      memset(fu,-1,sizeof(fu));
      memset(vis,0,sizeof(vis));
      fu[s]=0;
      while(h<=r)
      {
       x=q[h];
       next=pu[x];
       vis[x]=0;
       while(next!=0)
         {
         if(e[eu[next].v])
          if((fu[x]+1<fu[eu[next].v])||(fu[eu[next].v]==-1))
           {
            fu[eu[next].v]=fu[x]+1;
            if(vis[eu[next].v]==0)
              {
               vis[eu[next].v]=1;
               r=(r+1)%50000;
               q[r]=eu[next].v;
              }
           }
          next=eu[next].next;
         }
       h=(h+1)%50000;
      }
     if(fu[t]>ans)
     ans=fu[t];
    }
  //for(int i=1;i<=n;i++)cout<<i<<" "<<fu[i]<<endl;
  printf("%d\n",ans);
  return 0;
}










