#include<cstdio>
#include<algorithm>
#include<cmath>
using namespace std;
int sum=0,ss[1000100];
int n,m;
int   a[110];
int main(){
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(n == 1){
		int x,y;
		scanf("%d%d",&x,&y);
		int qq=-y%x;
		  int w=-y/x;
		if((qq==0) && (w>0) && (w<=m)) {			
		  printf("1\n");
		  printf("%d\n",w);
		}
		else printf("0\n");
		return 0;
	}
	else if(n==2){
		int x,y,z;
		scanf("%d%d%d",&z,&y,&x);
		int ww=0,ee[3];
        for(int i=1;i<=m;i++)  
          if( (x*i*i+y*i+z)==0) {
          	ww++;
          	ee[ww]=i;
          }
        if(ww){
        	printf("%d\n",ww);
        	for(int j=1;j<=ww;j++)
        	  printf("%d\n",ee[j]);
        }
		else printf("0\n");
		return 0;
		
	}
	else {		
	for(int i=0;i<=n;i++) {	scanf("%d",&a[i]);}
	for(int  i=1;i<=m;i++){
		int good=n;
		int ans=a[n];
		good=n-1;
		while(good!=-1){
			ans=ans*i+a[good];
			good--;
		}
		if (ans==0) {
			sum++;
			ss[sum]=i;
		}
	}
	printf("%d\n",sum);
	for(int i=1;i<=sum;i++)
	  printf("%d\n",ss[i]);
	return 0;
	}
}
