#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
struct lk{
	int x,y,k;
}point[50];
const int l[9]={0,0,1,0,-1,1,1,-1,-1};
const int r[9]={0,1,0,-1,0,1,-1,1,-1};
int d,n,f[150][150],ans,sum;
int main(){
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	scanf("%d%d",&d,&n);
	memset(f,0,sizeof(f));
	for(int i=1;i<=n;i++){
		scanf("%d%d%d",&point[i].x,&point[i].y,&point[i].k);
		int x=point[i].x,y=point[i].y,k=point[i].k;
		f[x][y]+=k;
		for(int j=1;j<=d;j++){
			for(int q=1;q<=8;q++)
			if( (x+j*l[q]>=0) && (x+j*l[q]<=129) && (y+j*r[q]>=0) && (y+j*r[q]<=129))
			  f[x+j*l[q]][y+j*r[q]]+=k;
		}
	}
	ans=0;
	sum=0;
	for(int i=0;i<=129;i++)
	  for(int j=0;j<=129;j++){
	  	if(ans==f[i][j]) sum++;
	  	if(ans<f[i][j]){
	  		ans=f[i][j];
	  		sum=1;
	  	}
	  }
	printf("%d %d\n",sum,ans);
	return 0;
}
