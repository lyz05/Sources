#include<cstdio>
#include<vector>
#include<queue>
#include<cstring>
using namespace std;
#define INF 0x7fffffff;
struct edge{
	int to,dist;
};
vector<edge> ee[200100];
int n,m,s,t,fa[10100],ans,bo[10100],dist[10100],boo[10100];
queue<int> q;
int spfa(int x,int y){
	for(int i=1;i<=n;i++) dist[i]=INF;
	dist[x]=0;
	memset(bo,0,sizeof(bo));
	q.push(x);
	bo[x]=1;
	while(!q.empty()){
		int u=q.front();q.pop();
		bo[u]=0;
		for(int i=0;i<ee[u].size();i++)
		  if(boo[ee[u][i].to] && (ee[u][i].dist+dist[u]<dist[ee[u][i].to])){
		  	dist[ee[u][i].to]=ee[u][i].dist+dist[u];
		  	if(!bo[ee[u][i].to]){
		  		q.push(ee[u][i].to);
		  		bo[ee[u][i].to]=1;
		  	}
		  }
	}
	return dist[y];
}
int addedge(int x,int y,int z){
	ee[x].push_back((edge){y,z});
	return 0;
}
int findfa(int x){
	if(fa[x]!=x) return findfa(fa[x]);
	  else return fa[x];
	return 0;
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) fa[i]=i;
	for(int i=1;i<=m;i++){
		int x,y;
		scanf("%d%d",&x,&y);
		addedge(x,y,1);
		fa[x]=findfa(y);
	}
	scanf("%d%d",&s,&t);
	ee[t].clear();
	for(int i=0;i<=n;i++) boo[i]=1;
	for(int i=1;i<=n;i++){
		int pd=1;
		if((!ee[i].size()) && (i!=t)) pd=0;
		  else  for(int j=0;j<ee[i].size();j++)
		            if(findfa(ee[i][j].to)!=findfa(t)) pd=0;	  
		if(!pd) boo[i]=0;
	}
	ans=spfa(s,t);
	if( (ans == 0x7fffffff) || (findfa(s)!= findfa(t))) printf("-1\n");
	    else printf("%d\n",ans);
	return 0;
}
