#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <ctime>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <set>
#include <map>
#include <vector>
#include <queue>

#define MAXN (1000 + 10)

int d , n , x[MAXN] , y[MAXN] , w[MAXN];

void Init()
{
	int i;
	scanf("%d%d",&d,&n);
	for (i = 0 ; i < n ; i ++)
		scanf("%d%d%d",&x[i],&y[i],&w[i]);
}

void Solve()
{
	int i , j , k;
	int Max = 0 , num = 0;
	for (i = 0 ; i <= 128 ; i ++)
		for (j = 0 ; j <= 128 ; j ++)
		{
			int ths = 0;
			for (k = 0 ; k < n ; k ++)
				if ((x[k] - i) * (x[k] - i) <= d * d)
					if ((y[k] - j) * (y[k] - j) <= d * d)
						ths += w[k];
			if (ths > Max)
			{
				Max = ths;
				num = 1;
			}
			else
			if (ths == Max)
				num ++;
		}
	printf("%d %d\n" , num , Max);
}

int main()
{
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	Init();
	Solve();
	return (0);
}

