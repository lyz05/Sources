#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <ctime>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <set>
#include <map>
#include <vector>
#include <queue>

#define MAXN (20000 + 100)
#define MAXM (400000 + 100)

int n , m;

int now[2] , H[2][MAXN];

struct edge
{
	int v , nxt;
}e[2][MAXM];

void Ins(int type , int u , int v)
{
	++ now[type];
	e[type][now[type]] . v = v;
	e[type][now[type]] . nxt = H[type][u];
	H[type][u] = now[type];
}

void Init()
{
	int i , j;
	scanf("%d%d",&n,&m);
	now[0] = now[1] = -1;
	for (i = 0 ; i < n ; i ++) H[0][i] = H[1][i] = -1;
	for (i = 0 ; i < m ; i ++)
	{
		int u , v;
		scanf("%d%d",&u,&v);
		u -- ; v --;
		Ins(0 , u , v);
		Ins(1 , v , u);
	}
}

bool vis[MAXN] , no[MAXN];

int dis[MAXN];

int h , t , q[MAXN];

void bfs(int type , int src)
{
	int i;
	for (i = 0 ; i < n ; i ++)
	{
		vis[i] = 0;
		dis[i] = -1;
	}
	h = t = 1;
	q[1] = src;
	vis[src] = 1;
	dis[src] = 0;
	if (no[src]) return;
	for (;h <= t; h ++)
	{
		int u = q[h];
		for (i = H[type][u] ; i != -1 ; i = e[type][i] . nxt)
		{
			int v = e[type][i] . v;
			if (vis[v]) continue;
			if (no[v]) continue;
			vis[v] = 1;
			dis[v] = dis[u] + 1;
			q[++ t] = v;
		}
	}
}

void Solve()
{
	int st , ed;
	scanf("%d%d",&st,&ed);
	st -- ; ed --;
	int i , j , k;
	for (i = 0 ; i < n ; i ++) no[i] = 0;
	bfs(1 , ed);
	for (i = 0 ; i < n ; i ++)
		for (j = H[0][i] ; j != -1 ; j = e[0][j] . nxt)
		{
			int v = e[0][j] . v;
			if (! vis[v]) no[i] = 1;
		}
	bfs(0 , st);
	printf("%d\n" , dis[ed]);
}

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	Init();
	Solve();
	return (0);
}

