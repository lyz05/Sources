#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <ctime>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <set>
#include <map>
#include <vector>
#include <queue>

#define MAXN (100 + 10)
#define MAXK (10000 + 10)
#define MAXM (1000000 + 10)

int n , m;

char s[MAXK];

int a[MAXN][MAXK];

inline int abs(int xx)
{
	if (xx >= 0) return xx;
	return - xx;
}

void Init()
{
	int i , j;
	scanf("%d%d",&n,&m);
	for (i = 0 ; i <= n ; i ++)
	{
		scanf("%s" , s);
		a[i][0] = strlen(s);
		if (s[0] == '-')
		{
			a[i][0] --;
			for (j = 1 ; j <= a[i][0] ; j ++)
				a[i][a[i][0] - j + 1] = s[j] - '0';
			a[i][0] = - a[i][0];
		}
		else
		{
			for (j = 0 ; j < a[i][0] ; j ++)
				a[i][a[i][0] - j] = s[j] - '0';
		}
	}
}

void Solve1()
{
	int i , j , a0 = 0 , a1 = 0 , a2 = 0;
	for (i = abs(a[0][0]) ; i >= 1 ; i -- ) a0 = a0 * 10 + a[0][i];
	if (a[0][0] < 0) a0 = - a0;
	for (i = abs(a[1][0]) ; i >= 1 ; i -- ) a1 = a1 * 10 + a[1][i];
	if (a[1][0] < 0) a1 = - a1;
	if (n == 2)
	{
		for (i = abs(a[2][0]) ; i >= 1 ; i -- ) a2 = a2 * 10 + a[2][i];
		if (a[2][0] < 0) a2 = - a2;
	}else a2 = 0;
	int num = 0;
	for (i = 1 ; i <= m ; i ++)
		if (a0 + a1 * i + a2 * i * i == 0)
			num ++;
	printf("%d\n" , num);
	for (i = 1 ; i <= m ; i ++)
		if (a0 + a1 * i + a2 * i * i == 0)
			printf("%d\n" , i);
}

int c[MAXK] , d[MAXK] , e[MAXK] , f[MAXK];

void multi(int A[MAXK] , int B[MAXK] , int C[MAXK])
{
	int i , j , k;
	A[0] = abs(B[0]) + abs(C[0]) - 1;
	for (i = 1 ; i <= A[0] ; i ++) A[i] = 0;
	for (i = 1 ; i <= abs(B[0]) ; i ++)
		for (j = 1 ; j <= abs(C[0]) ; j ++)
			A[0] += B[i] * C[j];
	for (i = 1 ; i < A[0] ; i ++)
	{
		A[i + 1] += A[i] / 10;
		A[i] %= 10;
	}
	for (;A[A[0]] > 10; A[0] ++)
	{
		A[A[0] + 1] = A[A[0]] / 10;
		A[A[0]] %= 10;
	}
	for (;A[0] > 1 && A[0] == 0; A[0] --);
	if (B[0] * C[0] < 0) A[0] = - A[0];
}

void add(int A[MAXK] , int B[MAXK] , int C[MAXK])
{
	int i , j , k;
	A[0] = abs(B[0]);
	if (abs(C[0]) > A[0]) A[0] = abs(C[0]);
	for (i = 1 ; i <= A[0] ; i ++) A[i] = 0;
	for (i = 1 ; i <= abs(B[0]) ; i ++)
		if (B[0] > 0) A[i] += B[i];
		else A[i] -= B[i];
	for (i = 1 ; i <= abs(C[0]) ; i ++)
		if (C[0] > 0) A[i] += C[i];
		else A[i] -= C[i];
	for (i = 1 ; i < A[0] ; i ++)
	{
		if (A[i] < 0)
		{
			A[i + 1] += A[i] / 10 - 1;
			A[i] = (A[i] % 10 + 10) % 10;
		}
		else
		{
			A[i + 1] += A[i] / 10;
			A[i] %= 10;
		}
	}
	if (A[A[0]] < 0)
	{
		for (i = 1 ; i < A[0] ; i ++)
		{
			A[i + 1] += A[i] / 10 + 1;
			A[i] = (A[i] % 10 - 10) % 10;
		}
	}
	for (;abs(A[A[0]]) > 10;A[0] ++)
	{
		A[A[0] + 1] = A[A[0]] / 10;
		A[A[0]] %= 10;
	}
	for (;A[0] > 1 && A[A[0]] == 0;A[0] --);
	if (A[A[0]] < 0)
	{
		for (i = 1 ; i <= A[0] ; i ++) A[i] = - A[i];
		A[0] = - A[0];
	}
}

int num , ans[MAXM];

void Solve2()
{
	int i , j , k;
	num = 0;
	for (i = 1 ; i <= m ; i ++)
	{
		c[0] = c[1] = 1;
		f[0] = 1; f[1] = 0;
		int tmp = i;
		for (j = 1;tmp ;j ++)
		{
			d[j] = tmp % 10;
			tmp /= 10;
		}
		d[0] = j - 1;
		for (j = 0 ; j <= n ; j ++)
		{
			multi(e , c , a[j]);
			add(f , f , e);
			multi(c , c , d);
		}
		if (f[0] == 1 && f[1] == 0)
		{
			ans[++ num] = i;
		}
	}
	printf("%d\n" , num);
	for (i = 1 ; i <= num ; i ++)
		printf("%d\n" , ans[i]);
}

void Solve()
{
	
	if (n == 1 && abs(a[0][0]) <= 9 && abs(a[1][0]) <= 9)
	{
		Solve1();
		return;
	}
	if (n == 2 && abs(a[0][0]) <= 9 && abs(a[1][0]) <= 9 && abs(a[2][0]) <= 9)
	{
		Solve1();
		return;
	}
	Solve2();
}

int main()
{
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	Init();
	Solve();
	return (0);
}

