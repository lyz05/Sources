#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int ans1,ans2,x,y,z,k,n,m;
int f[200][200];
int main(){
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	scanf("%d",&k);
	k=k*2+1;
	scanf("%d",&m);
	for (int i=1;i<=m;i++){
		scanf("%d %d %d",&x,&y,&z);
		x++;
		y++;
		f[x][y]=z;
	}
	n=129;
	for (int i=1;i<=n;i++)
		for (int j=1;j<=n;j++)
			f[i][j]+=f[i-1][j]-f[i-1][j-1]+f[i][j-1];
	for (int i=k;i<=n;i++)
		for (int j=k;j<=n;j++){
			x=f[i][j]-f[i-k][j]+f[i-k][j-k]-f[i][j-k];
			if (ans1<x){
				ans1=x;
				ans2=1;
			}else 
				if (ans1==x)ans2++;
		}
	printf("%d %d",ans2,ans1);
	return 0;
}

