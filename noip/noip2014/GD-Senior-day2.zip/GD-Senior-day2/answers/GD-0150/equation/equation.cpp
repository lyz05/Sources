#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int n,m,p,mod,x,l,y,z,zz;
char s[100000];
long long a[120][3000],help[120][3000];
int ans[1000001];
int max(int x,int y){
	if (x>y)return(x);return(y);
}
bool jian(int x){
	for (int i=0;i<=a[0][0];i++)
		help[0][i]=a[0][i];
	help[1][1]=0;
	for (int i=1;i<=n;i++){
		if (i==100){
			ans[0]=0;
		}
		help[i+1][1]=0;
		help[i][0]=max(help[i-1][0],a[i][0]);
		for (int j=1;j<=help[i][0];j++){
			help[i][j]+=help[i-1][j]*x+a[i][j];
			help[i][j+1]=0;
			while (help[i][j]<0){
				help[i][j]+=mod;
				help[i][j+1]--;
			}
			if (help[i][j]>=mod){
				help[i][j+1]+=help[i][j]/mod;
				help[i][j]=help[i][j]%mod;	
			}
		}
		while (help[i][help[i][0]+1]!=0){
			help[i][0]++;
			help[i][help[i][0]+1]=0;
			if (help[i][help[i][0]]>mod){
				help[i][help[i][0]+1]=help[i][help[i][0]]/mod;
				help[i][help[i][0]]=help[i][help[i][0]]%mod;
				help[i][0]++;
			}
		}
		while ((help[i][help[i][0]]==0)&&(help[i][0]>1))help[i][0]--;
	}
	if ((help[n][0]==1)&&(help[n][1]==0))return(true);return(false);
}
int main(){
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	scanf("%d %d",&n,&m);
	mod=10000000;
	for (int i=n;i>=0;i--){
		scanf("%s",s);
		x=0;
		if (s[0]=='-'){
			x++;
			p=-1;
		}else
			p=1;
		l=strlen(s)-1;
		y=1;
		z=1;
		for (int j=l;j>=x;j--){
			a[i][z]+=y*p*(s[j]-'0');
			y*=10;
			if (y==mod){
				y=1;
				z++;
			}
		}
		a[i][0]=z;
		zz+=z;
	}
	ans[0]=0;
	for (int i=1;i<=m;i++){
		if (jian(i)){
			ans[0]++;
			ans[ans[0]]=i;
			if (ans[0]==n)break;
		}	
		if (i*zz>1000000)
			break;
	}
	for (int i=0;i<=ans[0];i++)
		printf("%d\n",ans[i]);
	return 0;
}
