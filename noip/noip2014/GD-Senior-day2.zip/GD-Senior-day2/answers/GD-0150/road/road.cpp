#include<algorithm>
#include<cstdio>
#include<iostream>
using namespace std;
int x,y,n,m,l,r,start,end;
bool p;
int g[20000],a[300000][2],g1[20000],a1[300000][2],d[20000],f[20000];
bool bz[20000],bz1[20000];
void bfs(){
	d[1]=end;
	l=0;
	r=1;
	bz[end]=true;
	while (l!=r){
		l++;
		for (int i=g1[d[l]];i!=0;i=a1[i][1])
			if (bz[a1[i][0]]==false){
				bz[a1[i][0]]=true;
				r++;
				d[r]=a1[i][0];
			}
	}
}
void spfa(){
	l=0;
	r=1;
	d[1]=start;
	f[start]=0;
	bz[start]=true;
	while (l!=r){
		l=l%n+1;
		for (int i=g[d[l]];i!=0;i=a[i][1])
			if (bz1[a[i][0]])
				if ((f[a[i][0]]==-1)||(f[a[i][0]]>f[d[l]]+1)){
					f[a[i][0]]=f[d[l]]+1;
					if (bz[a[i][0]]==false){
						r=r%n+1;
						d[r]=a[i][0];
						bz[a[i][0]]=true;
					}
				}
		bz[d[l]]=false;
	}
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d %d",&n,&m);
	for (int i=1;i<=m;i++){
		scanf("%d %d",&x,&y);
		a[i][0]=y;
		a[i][1]=g[x];
		g[x]=i;
		a1[i][0]=x;
		a1[i][1]=g1[y];
		g1[y]=i;
	}
	scanf("%d %d",&start,&end);
	bfs();
	for (int i=1;i<=n;i++)
		if (bz[i]){
			p=true;
			for (int j=g[i];j!=0;j=a[j][1])
				if (bz[a[j][0]]==false){
					p=false;
					break;
				}
			if (p)bz1[i]=true;
		}
	for (int i=1;i<=n;i++){
		f[i]=-1;
		bz[i]=false;
	}
	if (bz1[start])spfa();
	printf("%d",f[end]);
	return 0;
}
