#include<cstdio>
#include<cmath>
#include<iostream>
#include<vector>
using namespace std;
#define LL  long long
#define LD long double

int main()
{
 freopen("equation.in","r",stdin);
 freopen("equation.out","w",stdout);
 ios::sync_with_stdio(false);
 int n,m;
 LL a[101];
 cin>>n>>m;
 for(int i=0;i<=n;i++)cin>>a[i];
 LD f,w;
 vector<int> ans;
 for(int x=1;x<=m;x++)
 {
 	f=0.0;
 	w=1;
 	for(int i=0;i<=n;i++)
 	{
	 f+=(LD)a[i]*w;
 	 w*=x;
 	}
 	 
 	if(f==0.0)ans.push_back(x);
 }
 cout<<ans.size()<<endl;
 for(int i=0;i<ans.size();i++)
 cout<<ans[i]<<endl;
 return 0;
}

