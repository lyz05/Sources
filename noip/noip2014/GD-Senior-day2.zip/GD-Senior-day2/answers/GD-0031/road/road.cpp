#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
#include<vector>
using namespace std;
bool b[10001],vaild[10001];
long n,m,s,t,i;
vector<long> v[10001],u[10001];
typedef vector<long>::iterator it;
void BFS()
{
	queue<long> q;
	q.push(t);
	memset(b,false,sizeof(b));
	b[t]=true;
	while(!q.empty())
	{
		long r=q.front();
		q.pop();
		for(it itr=u[r].begin();itr!=u[r].end();itr++)
		{
			long rr=*itr;
			if(!b[rr])
			{
				b[rr]=true;
				q.push(rr);
				}
	    }
	}
}
void SPFA()
{
	long dist[10001];
	queue<long> q;
	q.push(s);
	memset(dist,255,sizeof(dist));
	memset(b,true,sizeof(b));
    b[s]=false;
	dist[s]=0;
	while(!q.empty())
	{
		long p=q.front();
		b[p]=true;
		q.pop();
		for(it itr=v[p].begin();itr!=v[p].end();itr++)
		{
			long tt=*itr;
			if(!vaild[tt])continue;
			if(dist[tt]==-1)
			{
				dist[tt]=dist[p]+1;
				q.push(tt);
				b[tt]=false;
			}
			else
			if(dist[tt]>dist[p]+1)
			{
				dist[tt]=dist[p]+1;
				if(b[tt])
				{
					q.push(tt);
				    b[tt]=false;
				}
			}
		}
	}
	printf("%ld",dist[t]);
}
int main()
{
 freopen("road.in","r",stdin);
 freopen("road.out","w",stdout);
 scanf("%ld %ld",&n,&m);
 for(i=1;i<=m;i++)
 {
 	long x,y;
 	scanf("%ld %ld",&x,&y);
 	v[x].push_back(y);
 	u[y].push_back(x);
 }
 scanf("%ld %ld",&s,&t);
 BFS();
 for(int i=1;i<=n;i++)
 {
 	vaild[i]=b[i];
 	for(it itr=v[i].begin();itr!=v[i].end();itr++)
 	vaild[i]=vaild[i] && b[*itr];
 }
 if(!vaild[s])
 {
 	printf("-1");
 	return 0;
 }
 SPFA();
 return 0;
}

