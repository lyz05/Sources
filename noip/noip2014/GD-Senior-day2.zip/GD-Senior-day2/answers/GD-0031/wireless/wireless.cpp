#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
long c[256][256];
void update(int x,int y,long delta)
{
	for(int i=x;i<256;i+=i & (-i))
	for(int j=y;j<256;j+=j & (-j))
	c[i][j]+=delta;
}
long getsum(int x,int y)
{
	long sum=0;
	for(int i=x;i;i-=i & (-i))
	for(int j=y;j;j-=j & (-j))
	sum+=c[i][j];
	return sum;
}
int main()
{
 freopen("wireless.in","r",stdin);
 freopen("wireless.out","w",stdout);
 int d,n;
 scanf("%d",&d);
 scanf("%d",&n);
 memset(c,0,sizeof(c));
 for(;n--;)
 {
 	int x,y;
 	long k;
 	scanf("%d %d %ld",&x,&y,&k);
 	x++,y++;
 	if(x<=d)
 	{
 		if(y<=d)update(1,1,k);
 		else update(1,y-d,k);
 	}
 	else
 	if(y<=d)update(x-d,1,k);
 	else update(x-d,y-d,k);
 	if(y<=d)update(x+d+1,1,-k);
 	else update(x+d+1,y-d,-k);
 	if(x<=d)update(1,y+d+1,-k);
 	else update(x-d,y+d+1,-k);
 	update(x+1+d,y+d+1,k);
 }
 long ans=0,opt;
 for(int i=1;i<=129;i++)
 for(int j=1;j<=129;j++)
 {
 	long x=getsum(i,j);
 	if(x>ans)ans=x,opt=1;
 	else
 	if(x==ans)opt++;
 }
 printf("%ld %ld",opt,ans);
 return 0;
}

