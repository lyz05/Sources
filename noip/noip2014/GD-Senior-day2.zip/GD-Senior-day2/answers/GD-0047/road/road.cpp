#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#define SIZE (int )200001
#define SIZE2 (int )10001
using namespace std;
const int INF=100000000;
struct node
{
    int x,y,d,next;
}a1[SIZE],a[SIZE];
int first[SIZE],len,head,tail;
int st,ed;
int d[SIZE2],v[SIZE2],list[SIZE2],d1[SIZE2];
int xx[SIZE],yy[SIZE];
int n,m;
void ins1(int x,int y)
{
    len++;
    a1[len].x=x;a1[len].y=y;a1[len].d=1;
    a1[len].next=first[x];first[x]=len;
}
void ins2(int x,int y)
{
     len++;
     a[len].x=x;a[len].y=y;a[len].d=1;
    a[len].next=first[x];first[x]=len;
}
int pd(int now)
{
	int y;
	int x=first[now];
	if(d1[a[x].y]>=INF)return 0;
	int k=a[x].next;
    while(k)
    {
	     y=a[k].y;
	     if(d1[a[k].y]>=INF)return 0;
	     k=a[k].next;
	}
	return 1;
}

void work1()
{
	int i;
	memset(first,0,sizeof(first));len=0;
	for(i=1;i<=m;i++)
	ins1(yy[i],xx[i]);
	int x,k,y;
    memset(d1,63,sizeof(d));
	memset(v,0,sizeof(v));
	head=1;tail=2;
	d1[ed]=0;v[ed]=1;list[1]=ed;
	while(head!=tail)
	{
	     x=list[head];
	     k=first[x];
	     while(k!=0)
	     {
		      y=a1[k].y;		 
		      if(d1[y]>d1[x]+a1[k].d)
		      {
			      d1[y]=d1[x]+a1[k].d;
			      if(!v[y])
			      {
				       v[y]=1;
				       list[tail]=y;
				       tail++;if(tail==n+1)tail=1;
				  }
			  }
			  k=a1[k].next;
		 }
		 v[x]=0;head++;if(head==n+1)head=1;
	     
	}
}

void work2()
{
	int i;
	memset(d,63,sizeof(d));
	memset(first,0,sizeof(first));len=0;	
	for(i=1;i<=m;i++)
	ins2(xx[i],yy[i]);
	int x,k,y;
	 memset(v,0,sizeof(v));
	 head=1;tail=2;
	 d[ed]=INF;
	 d[st]=0;v[st]=1;list[1]=st;
	 while(head!=tail)
	 {
	     x=list[head];
	     k=first[x];
	     while(k!=0)
	     {
		      y=a[k].y;		 
		    //  printf("%d %d\n",y,pd(y));
		      if(d[y]>d[x]+a[k].d&&(pd(y)||y==ed))
		      {
			      d[y]=d[x]+a[k].d;
			      if(!v[y])
			      {
				       v[y]=1;
				       list[tail]=y;
				       tail++;if(tail==n+1)tail=1;
				  }
			  }
			  k=a[k].next;
		 }
		 v[x]=0;head++;if(head==n+1)head=1;
	}
}

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int i;	
	scanf("%d %d",&n,&m);
	for(i=1;i<=m;i++)
	    scanf("%d %d",&xx[i],&yy[i]);
	scanf("%d %d",&st,&ed);
	work1();
//	for(i=1;i<=n;i++)printf("%d\n",d1[i]);
	work2();
	if(d[ed]<INF)printf("%d\n",d[ed]);
	else printf("-1\n");
    return 0;
}
