#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#define SIZE (int )130
using namespace std;

int map[SIZE][SIZE],f[SIZE][SIZE];
int n,d;
int find(int i,int j)
{
    if(i+d>128&&j+d>128) return f[128][128]-f[i][j-d-1]-f[i-d-1][j]+f[i-d-1][j-d-1];
    if(i+d>128) return f[i][j+d]-f[i][j-d-1]-f[i-d-1][j+d]+f[i-d-1][j-d-1];
    if(j+d>128) return f[i+d][j]-f[i+d][j-d-1]-f[i-d-1][j]+f[i-d-1][j-d-1];
    if(j-d<0&&i-d<0)return f[i+d][j+d];
    if(i-d<0) return f[i+d][j+d]-f[i+d][j-d-1];
    if(j-d<0) return f[i+d][j+d]-f[i-d-1][j+d];
    return f[i+d][j+d]-f[i+d][j-d-1]-f[i-d-1][j+d]+f[i-d-1][j-d-1];
}

int main()
{
    freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	int i,j,x,y,dd,tt,maxn=-1,ans;
	memset(map,0,sizeof(map));
    scanf("%d %d",&d,&n);
    for(i=1;i<=n;i++)
    {
	    scanf("%d %d %d",&x,&y,&dd);
	    map[x][y]=dd;
	}
	f[0][0]=map[0][0];
	for(i=1;i<=128;i++)f[i][0]=f[i-1][0]+map[i][0];
	for(i=1;i<=128;i++)f[0][i]=f[0][i-1]+map[0][i];
	for(i=1;i<=128;i++)
	for(j=1;j<=128;j++)
	    f[i][j]=f[i-1][j]+f[i][j-1]-f[i-1][j-1]+map[i][j];
	for(i=0;i<=128;i++)
	for(j=0;j<=128;j++)
	{
	     tt=find(i,j);
 	     if(tt>maxn){maxn=tt;ans=1;}
	     else if(tt==maxn)
		 {
		     ans++;
		 }
	}
	printf("%d %d\n",ans,maxn);
  //system("pause");
}
