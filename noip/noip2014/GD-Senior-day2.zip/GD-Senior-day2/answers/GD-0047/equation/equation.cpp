#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
using namespace std;

int n,m,a[1100];
int b[1100];

int main()
{
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	int i,k,x,tt,res;
    scanf("%d %d",&n,&m);
    for(i=0;i<=n;i++)
	    scanf("%d",&a[i]);
	int ans=0;
	if(n<=2&&m<=100)
	{
	    for(k=1;k<=m;k++)
	    {
	        x=k;tt=1;res=0;
	        for(i=0;i<=n;i++)
	        {
		      res+=a[i]*tt;
		      tt*=x;
		    }
	 	   if(res==0){ans++;b[ans]=k;}
	    }
	    printf("%d\n",ans);
	    for(i=1;i<=ans;i++)
  	    printf("%d\n",b[i]);
   }
   else
   printf("0\n");
	return 0;
    //system("pause");
}
