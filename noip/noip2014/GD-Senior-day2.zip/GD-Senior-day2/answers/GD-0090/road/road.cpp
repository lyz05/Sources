#include <cstdio>
#include <algorithm>
#include <cmath>
#include <queue>
#include <deque>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <map>
using namespace std;
const int maxn=int(1e4)+100;
const int maxm=int(2e5)+100;


struct line
{ int id,next; };

int n,m,now,nowr,sc,st;
int h[maxn],hr[maxn],q[maxn],f[maxn];
line t[maxm],tr[maxm];
bool vis[maxn],cgo[maxn];

void join(int u,int v)
{
    t[now].id=v; t[now].next=h[u]; h[u]=now++;
}
void joinr(int u,int v)
{
    tr[nowr].id=v; tr[nowr].next=hr[u]; hr[u]=nowr++;
}
void init()
{
    scanf("%d%d",&n,&m);
    for (int i=1;i<=n;++i) h[i]=hr[i]=-1;
    for (int i=1;i<=m;++i)
    {
        int u,v;
        scanf("%d%d",&u,&v);
        join(u,v);
        joinr(v,u);
    }
    scanf("%d%d",&sc,&st);
}
void bfs()
{
    int head=1,tail=1;
    q[1]=st;
    for (int i=1;i<=n;++i) vis[i]=false;
    vis[st]=true;
    while (head<=tail)
    {
        int cur=q[head++];
        for (int i=hr[cur];i>-1;i=tr[i].next)
        if (!vis[tr[i].id])
        {
            vis[tr[i].id]=true;
            q[++tail]=tr[i].id;
        }
    }
    for (int i=1;i<=n;++i)
    {
        bool flag=true;
        for (int j=h[i];j>-1;j=t[j].next)
        if (!vis[t[j].id]) { flag=false; break; }
        if (flag) cgo[i]=true;
    }
}
void solve()
{
    if (!cgo[sc]) { printf("-1\n"); return; }
    int head=1,tail=1;
    q[1]=sc;
    for (int i=1;i<=n;++i) vis[i]=false;
    vis[sc]=true;
    f[sc]=1;
    while (head<=tail)
    {
        int cur=q[head++];
        for (int i=h[cur];i>-1;i=t[i].next)
        if (cgo[t[i].id])
        {
            q[++tail]=t[i].id;
            f[t[i].id]=f[cur]+1;
        }
    }
    if (f[st]==0) printf("-1\n"); else printf("%d\n",f[st]-1);
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	init();
	bfs();
	solve();
	return 0;
}

