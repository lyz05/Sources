#include <cstdio>
#include <algorithm>
#include <cmath>
#include <queue>
#include <deque>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <map>
using namespace std;
const int cut=130;


int n,dis;
int Map[cut+100][cut+100];
int sum,ans;

void init()
{
    scanf("%d",&dis);
    scanf("%d",&n);
    for (int i=1;i<=n;++i)
    {
        int x,y,s;
        scanf("%d%d%d",&y,&x,&s);
        ++x; ++y;
        Map[x][y]=s;
    }
}
void solve()
{
    sum=0; ans=0;
    for (int i=1;i<cut;++i)
        for (int j=1;j<cut;++j)
        {
            int s=0;
            int high=max(1,i-dis);
            int low=min(cut-1,i+dis);
            int L=max(1,j-dis);
            int R=min(cut-1,j+dis);
            for (int k=high;k<=low;++k)
                for (int p=L;p<=R;++p)
                s+=Map[k][p];
            if (s>ans) { ans=s; sum=1; }
            else if (s==ans) ++sum;
        }
}
int main()
{
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	init();
	solve();
	printf("%d %d\n",sum,ans);
	return 0;
}
