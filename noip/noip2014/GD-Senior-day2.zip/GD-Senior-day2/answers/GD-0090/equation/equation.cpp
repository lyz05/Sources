#include <cstdio>
#include <algorithm>
#include <cmath>
#include <queue>
#include <deque>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <map>
using namespace std;

struct gjd
{
    int sum;
    int a[2000];
    bool minus;
    gjd()
    { sum=0; minus=false; }
};

int n,m,sumans;
int ans[200];
gjd cur,tmp,num[200],x,tmp2;

void init(int nid)
{
    char h;
    while ((h=getchar())!='-' && (h<'0' || h>'9'));
    if (h=='-') num[nid].minus=true; else { num[nid].a[++num[nid].sum]=h-'0'; }
    while ('0'<=(h=getchar()) && h<='9') num[nid].a[++num[nid].sum]=h-'0';
    for (int i=1;i<=(num[nid].sum+1)/2;++i) swap(num[nid].a[i],num[nid].a[num[nid].sum-i+1]);
}
void mulx()
{
    tmp.sum=x.sum+tmp2.sum-1;
    for (int i=1;i<=tmp.sum+1;++i) tmp.a[i]=0;
    for (int i=1;i<=x.sum;++i)
    {
        for (int j=1;j<=tmp2.sum;++j) tmp.a[i+j-1]+=x.a[i]*tmp2.a[j];
    }
    for (int i=1;i<=tmp.sum;++i)
    {
        tmp.a[i+1]+=tmp.a[i]/10;
        tmp.a[i]%=10;
        if (tmp.a[tmp.sum+1]>0)
        {
            ++tmp.sum;
            tmp.a[tmp.sum+1]=0;
        }
    }
    x.sum=tmp.sum;
    for (int i=1;i<=tmp.sum;++i) x.a[i]=tmp.a[i];
}
void mul(int nid)
{
    tmp.sum=x.sum+num[nid].sum-1;
    for (int i=1;i<=tmp.sum+1;++i) tmp.a[i]=0;
    for (int i=1;i<=x.sum;++i)
    {
        for (int j=1;j<=num[nid].sum;++j) tmp.a[i+j-1]+=x.a[i]*num[nid].a[j];
    }
    for (int i=1;i<=tmp.sum;++i)
    {
        tmp.a[i+1]+=tmp.a[i]/10;
        tmp.a[i]%=10;
        if (tmp.a[tmp.sum+1]>0)
        {
            ++tmp.sum;
            tmp.a[tmp.sum+1]=0;
        }
    }
    tmp.minus=num[nid].minus;
}
void add()
{
    int len=max(cur.sum,tmp.sum);
    cur.a[len+1]=0;
    for (int i=1;i<=len;++i)
    {
        if (cur.sum<i) cur.a[i]=0;
        if (tmp.sum>=i) cur.a[i]+=tmp.a[i];
    }
    cur.sum=len;
    for (int i=1;i<=cur.sum;++i)
    {
        cur.a[i+1]+=cur.a[i]/10;
        cur.a[i]%=10;
        if (cur.a[cur.sum+1]>0)
        {
            ++cur.sum;
            cur.a[cur.sum+1]=0;
        }
    }
}
bool big()
{
    if (tmp.sum!=cur.sum) return (tmp.sum>cur.sum);
    for (int i=tmp.sum;i>0;--i)
    if (tmp.a[i]>cur.a[i]) return true;
    else if (tmp.a[i]<cur.a[i]) return false;
    return false;
}
void jian()
{
    if (big()) swap(cur,tmp);
    int len=max(cur.sum,tmp.sum);
    cur.a[len+1]=0;
    for (int i=1;i<=len;++i)
    {
        if (cur.sum<i) cur.a[i]=0;
        if (tmp.sum>=i) cur.a[i]-=tmp.a[i];
    }
    cur.sum=len;
    for (int i=1;i<=len;++i)
    {
        if (cur.a[i]<0) { --cur.a[i+1]; cur.a[i]+=10; }
    }
    while (cur.sum>0 && cur.a[cur.sum]==0) --cur.sum;
    if (cur.sum==0) { cur.sum=1; cur.minus=false; }
}
void solve()
{
    sumans=0;
    for (int i=1;i<=m;++i)
    {
        int b=i;
        x.sum=0;
        while (b)
        {
            x.a[++x.sum]=b%10;
            b/=10;
        }
        tmp2=x;
        cur=num[0];
        mul(1);
        if ((cur.minus^tmp.minus)==0) add(); else jian();
        for (int j=2;j<=n;++j)
        {
            mulx();
            mul(j);
            if ((cur.minus^tmp.minus)==0) add(); else jian();
        }
        if (cur.sum==1 && cur.a[1]==0) ans[++sumans]=i;
    }
}
void work()
{
    for (int i=0;i<=n;++i) init(i);
    solve();
    printf("%d\n",sumans);
    for (int i=1;i<=sumans;++i) printf("%d\n",ans[i]);
}
int main()
{
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	scanf("%d%d",&n,&m);
	if (m<=1000) work();
	else printf("0\n");
	return 0;
}

