#include <fstream>
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <algorithm>
#include <string.h>
#include <string>
#include <math.h>
#include <time.h>
#include <vector>
#include <map>
using namespace std;

const int maxn = 150;
const int n = 129;
const int m = 129;

int d;
long long sum[maxn][maxn];

void Init() {
	int t, x, y, k;
	scanf("%d", &d);
	scanf("%d", &t);
	for (int i = 0; i < t; i++) {
		scanf("%d%d%d", &x, &y, &k);
		sum[x + 1][y + 1] = k;
	}
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++)
			sum[i][j] += sum[i - 1][j] + sum[i][j - 1] - sum[i - 1][j - 1];
}

int get(int a, int b, int t, int g) {
	if (a < 1) a = 1;
	if (b < 1) b = 1;
	if (t > n) t = n;
	if (g > m) g = m;
	return sum[t][g] - sum[t][b - 1] - sum[a - 1][g] + sum[a - 1][b - 1];
}

void Solve() {
	int tot = 0, best = 0;
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++) {
			int tmp = get(i - d, j - d, i + d, j + d);
			if (tmp > best) {
				best = tmp;
				tot = 1;
			}
			else if (tmp == best) {
				tot++;
			}
		}
	cout << tot << ' ' << best << endl;
}

int main() {
	freopen("wireless.in", "r", stdin);
	freopen("wireless.out", "w", stdout);
	
	Init();
	Solve();
	
	return 0;
}

