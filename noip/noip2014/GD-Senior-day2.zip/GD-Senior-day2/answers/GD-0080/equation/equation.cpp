#include <fstream>
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <algorithm>
#include <string.h>
#include <string>
#include <math.h>
#include <time.h>
#include <vector>
#include <map>
using namespace std;

const int mod = 10000000;
const int maxbit = 10000 + 2;
const int maxc = 1450;
const int maxn = 100 + 2;
const int maxm = 1000000 + 2;

struct Tnode {
	int len;
	bool isMinus;
	int d[maxc];
	
	void output() {
		if (len == 0) {
			printf("0\n");
			return ;
		}
		if (isMinus) printf("-");
		printf("%d", d[len - 1]);
		for (int i = len - 2; i > -1; i--)
			printf("%07d", d[i]);
		printf("\n");
	}
};

Tnode tmp;

bool canDiv(Tnode &u, int d) {
	long long cur = 0;
	for (int i = u.len - 1; i > -1; i--) {
		cur = cur * mod + u.d[i];
		cur = cur % d;
	}
	if (cur == 0) return true;
	return false;
}

int sig(Tnode &u, Tnode &v) {
	if (u.isMinus && !v.isMinus) return -1;
	if (!u.isMinus && v.isMinus) return 1;
	
	int flag;
	if (u.isMinus) flag = -1;
	else flag = 1;
	
	if (u.len > v.len) return flag;
	if (u.len < v.len) return -flag;
	
	for (int i = u.len - 1; i > -1; i--)
		if (u.d[i] > v.d[i]) return flag;
		else if (u.d[i] < v.d[i]) return -flag;
		
	return 0;
}

void Add(Tnode &u, Tnode &v);
void Minus(Tnode &u, Tnode &v);

void Add(Tnode &u, Tnode &v) {
	if (u.isMinus && !v.isMinus) {
		u.isMinus = false;
		Minus(v, u);
		u.isMinus = true;
		return ;
	}
	if (!u.isMinus && v.isMinus) {
		v.isMinus = false;
		Minus(u, v);
		v.isMinus = true;
		return ;
	}
	
	for (int i = 0; i < maxc; i++) tmp.d[i] = 0;
	tmp.len = max(u.len, v.len);
	for (int i = 0; i < tmp.len; i++) {
		tmp.d[i] += u.d[i] + v.d[i];
		if (tmp.d[i] >= mod) {
			tmp.d[i + 1]++;
			tmp.d[i] -= mod;
		}
	}
	if (tmp.d[ tmp.len ]) tmp.len++;
	tmp.isMinus = u.isMinus;
}

void Minus(Tnode &u, Tnode &v) {
	if (v.isMinus) {
		v.isMinus = false;
		Add(u, v);
		v.isMinus = true;
		return ;
	}
	if (sig(u, v) == -1) {
		Minus(v, u);
		tmp.isMinus ^= 1;
		return ;
	}
	
	for (int i = 0; i < maxc; i++) tmp.d[i] = 0;
	tmp.len = max(u.len, v.len);
	for (int i = 0; i < tmp.len; i++) {
		if (u.d[i] < v.d[i]) {
			u.d[i + 1]--;
			u.d[i] += mod;
		}
		tmp.d[i] = u.d[i] - v.d[i];
	}
	while (tmp.len > 0 && tmp.d[ tmp.len - 1 ] == 0) tmp.len--;
	tmp.isMinus = false;
}

void Div(Tnode &u, int v) {
	for (int i = 0; i < maxc; i++) tmp.d[i] = 0;
	tmp.len = u.len;
	long long cur = 0;
	for (int i = tmp.len - 1; i > -1; i--) {
		cur = cur * mod + u.d[i];
		tmp.d[i] = cur / v;
		cur = cur % v;
	}
	while (tmp.len > 0 && tmp.d[ tmp.len - 1 ] == 0) tmp.len--;
	tmp.isMinus = u.isMinus;
}

int n, m;
char st[maxbit];
bool ans[maxm];
Tnode a[maxn];

void Init() {
	scanf("%d%d", &n, &m);
	for (int i = 0; i <= n; i++) {
		scanf("%s", st);
		int size = strlen(st);
		
		int p = 0, cur = 0, star = 0;
		if (st[0] == '-') {
			a[i].isMinus = true;
			star = 1;
		}
		else a[i].isMinus = false;
		
		int aoe = 1;
		for (int j = size - 1; j >= star; j--) {
			cur = (st[j] - '0') * aoe + cur;
			aoe *= 10;
			if ((size - j - 1) % 7 == 6 || (j == star)) {
				a[i].d[p] = cur;
				cur = 0;
				aoe = 1;
				p++;
			}
		}
		a[i].len = p;
		
		while (a[i].len > 0 && a[i].d[ a[i].len - 1 ] == 0) a[i].len--;
	}
}

int pcnt;
bool isPrime[maxm];
int pri[maxm], cont[maxm], inx[maxm];

void build() {
	for (int i = 2; i < m; i++) {
		if (!isPrime[i]) {
			inx[i] = pcnt;
			pri[pcnt++] = i;
		}
		for (int j = 0; i < m / pri[j]; j++) {
			isPrime[ i * pri[j] ] = true;
			if (i % pri[j] == 0) break;
		}
	}
	for (int i = 0; i < pcnt; i++) {
		if (pri[i] > 280000) break;
		if (pri[i] >= m / pri[i]) {
			if (canDiv(a[0], pri[i])) cont[i] = 1;
			else cont[i] = 0;
			//break;
			continue;
		}
		
		int cur = pri[i], cal = 1;
		while (1) {
			if (!canDiv(a[0], cur)) {
				cont[i] = cal - 1;
				break;
			}
			cal++;
			if (cur >= m / pri[i]) {
				cont[i] = cal - 1;
				break;
			}
			cur *= pri[i];
		}
	}
}

bool able(int u) {
	for (int i = 0; pri[i] * pri[i] <= u; i++) {
		if (!isPrime[u]) break;
		int cnt = 0;
		while (u % pri[i] == 0) {
			cnt++;
			u /= pri[i];
		}
		if (cnt > cont[i]) return false;
	}
	if (u != 1) {
		if (u <= 280000) {
			if (cont[inx[u]] >= 1) return true;
			return false;
		}
		if (canDiv(a[0], u)) return true;
		return false;
	}
	return true;
}

void Solve() {
	m++;
	build();
	int cnt = 0;
	Tnode cur;
	for (int i = 1; i < m; i++) {
		if (!able(i)) continue;
		for (int j = 0; j < maxc; j++) cur.d[j] = 0;
		cur.isMinus = false;
		cur.len = 0;
		
		bool flag = true;
		for (int j = 0; j <= n; j++) {
			Minus(cur, a[j]);
			if (!canDiv(tmp, i)) {
				flag = false;
				break;
			}
			cur = tmp;
			Div(cur, i);
			cur = tmp;
		}
		if (flag && cur.len == 0) {
			ans[i] = true;
			cnt++;
		}
	}
	printf("%d\n", cnt);
	for (int i = 1; i <= m; i++)
		if (ans[i]) printf("%d\n", i);
}

int main() {
	freopen("equation.in", "r", stdin);
	freopen("equation.out", "w", stdout);
	Init();
	Solve();
	return 0;
}

