#include <fstream>
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <algorithm>
#include <string.h>
#include <string>
#include <math.h>
#include <time.h>
#include <vector>
#include <map>
using namespace std;

const int maxn = 10000 + 10;
const int maxm = 400000 + 10;

struct Tedge {
	int v, next;
} e[maxm];

int N;
int head[maxn];

void insert(int x, int y) {
	e[N].v = y;
	e[N].next = head[x];
	head[x] = N;
	N++;
}

int n, m, St, En;
int o[maxn], ans[maxn];
bool vis[maxn], reach[maxn], block[maxn];

void Init() {
	int x, y;
	scanf("%d%d", &n, &m);
	for (int i = 0; i < n; i++) head[i] = -1;
	for (int i = 0; i < m; i++) {
		scanf("%d%d", &x, &y);
		x--;
		y--;
		insert(x, y);
		insert(y, x);
	}
	scanf("%d%d", &St, &En);
	St--;
	En--;
}

void getRid() {
	for (int i = 0; i < n; i++) reach[i] = false;
	int h = 0, t = 0;
	o[h] = En;
	reach[En] = true;
	while (h <= t) {
		int cur = o[h];
		for (int i = head[cur]; i != -1; i = e[i].next)
			if ((i % 2) == 1) {
				int v = e[i].v;
				if (reach[v]) continue;
				reach[v] = true;
				t++;
				o[t] = v;
			}
		h++;
	}
	for (int i = 0; i < n; i++) {
		block[i] = false;
		for (int j = head[i]; j != -1; j = e[j].next)
			if (((j % 2) == 0) && !reach[ e[j].v ]) {
				block[i] = true;
				break;
			}
	}
}

void bfs() {
	for (int i = 0; i < n; i++) vis[i] = false;
	int h = 0, t = 0;
	o[h] = St;
	vis[St] = true;
	ans[St] = 0;
	while (h <= t) {
		int cur = o[h];
		for (int i = head[cur]; i != -1; i = e[i].next)
			if ((i % 2) == 0) {
				int v = e[i].v;
				if (block[v] || vis[v]) continue;
				ans[v] = ans[cur] + 1;
				vis[v] = true;
				t++;
				o[t] = v;
			}
		h++;
	}
	if (!vis[En]) {
		cout << -1 << endl;
	}
	else {
		cout << ans[En] << endl;
	}
}

void Solve() {
	getRid();
	bfs();
}

int main() {
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	Init();
	Solve();
	return 0;
}

