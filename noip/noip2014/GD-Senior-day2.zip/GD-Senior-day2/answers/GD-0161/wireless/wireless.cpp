#include<iostream>
#include<cstdio>
#include<string.h>

using namespace std;
int i,j,k,f[129][129]={0},d,n,x,y,x1,y1,i1,j1,maxx,maxf,ll;
void intt()
{
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	cin>>d;
	cin>>n;
	for (i=1;i<=n;i++)
	{
		cin>>x>>y>>k;
		f[x][y]=k;
	}
	maxx=maxf=0;
}

int main()
{
	intt();
	for (i=0;i<=128;i++)
	for (j=0;j<=128;j++)
	{
		x=i-d;y=j-d;x1=i+d;y1=j+d;ll=0;
		x=max(0,x);y=max(0,y);x1=min(128,x1);y1=min(128,y1);
		for (i1=x;i1<=x1;i1++)
		for (j1=y;j1<=y1;j1++)
		ll+=f[i1][j1];
		if (ll==maxx)
		maxf++;
		else
		if (ll>maxx)
		{
			maxx=ll;
			maxf=1;
		}
		
	}
	cout<<maxf<<" "<<maxx;
	
	fclose(stdin);fclose(stdout);
	return 0;
}

