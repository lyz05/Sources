#include<iostream>
#include<cstdio>
#include<string.h>

using namespace std;

int i,j,k,n,m,a[101],x,lj=0,jx[101],t=0,pd=0;
void intt()
{
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
    cin>>n>>m;
    for (i=0;i<=n;i++)
    {
      cin>>a[i];
      if (a[i]<=0) pd=1;
   }
}
int qq(int x)
{
	
	int k=0,xx=1;
	for (int j=0;j<=n;j++)
	{
		k+=a[j]*xx;
		xx*=x;
	}
	return k;
	
}
int main()
{
	intt();
	if (pd==0)
	cout<<"0";
	else
	{
	
	for (i=1;i<=m;i++)
	{
		k=qq(i);
		if (k==0)
		{
			lj++;
			jx[lj]=i;
	    }
	}
	cout<<lj<<endl;
	for (i=1;i<=lj;i++)
	cout<<i<<endl;
   }
	fclose(stdin);fclose(stdout);
	return 0;
}

