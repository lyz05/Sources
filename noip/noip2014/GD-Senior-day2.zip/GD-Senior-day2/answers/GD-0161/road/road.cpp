#include<iostream>
#include<cstdio>
#include<string.h>

using namespace std;

const int maxn=10001,maxm=200001;
  struct link{
	int a;
	link *next;
	
};
struct data{
	int v;
	link *s;
	link *t;
	
};   
int i,j,k,n,m,x,y,b[maxn]={0},b1[maxn]={0},b2[maxn]={0},d[maxn],l,r,ll,rr,s,t,aa;
data f[maxn];
link *p,*q;


void addedge(int x,int y)
{
	q=new link;p=q;
	q->a=y;
	q->next=f[x].s->next;
	f[x].s->next=q;
	q=new link ;
	q->a=x;
	q->next=f[y].t->next;
	f[y].t->next=q;
	
	
}
void intt()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>m;
	for (i=1;i<=n;i++)
	{
		f[i].s=new link ;f[i].t=new link;
		f[i].s->next=f[i].s;
		
		f[i].t->next=f[i].t;
	}
	for (i=1;i<=m;i++)
	
	{
		cin>>x>>y;
		addedge(x,y);
		
	}
	cin>>s>>t;
    
}

int main()
{
	intt();
	//part 1
	l=r=1;d[l]=t;b[t]=1;
	while (l<=r)
	{
		ll=l%maxn;
		aa=d[ll];
		q=f[aa].t->next;
		while (q!=f[aa].t)
		{
			i=q->a;
			if (b[i]==0)
			{
				b[i]=1;
				r++;
				rr=r%maxn;
				d[rr]=i;
			}
			q=q->next;
		}
		l++;
	}
	
	//part 2
	for (i=1;i<=n;i++)
	if (b[i]==0)
	{
	
	  b1[i]=1;
	  q=f[i].t->next;
	  while (q!=f[i].t)
	  {
	  	j=q->a;
	    b1[j]=1;
	    q=q->next;
	  }
    }
    
    
    //part 3
    for (i=1;i<=n;i++)
    b[i]=maxn+1;
    	l=r=1;d[l]=s;b[s]=0;
	while (l<=r)
	{
		ll=l%maxn;
		aa=d[ll];
		b2[aa]=0;
		q=f[aa].s->next;
		if (b1[aa]==0)
		while (q!=f[aa].s)
		{
			i=q->a;
			if (b1[i]==0)
			if (1+b[aa]<b[i])
			{
			   b[i]=1+b[aa];
			  if (b2[i]==0)
			  {
			 	b2[i]=1;
				r++;
				rr=r%maxn;
				d[rr]=i;
			  }
		   }
		   q=q->next;
		}
		l++;
	}
    if (b[t]==maxn+1)
    cout<<"-1";
    else
	cout<<b[t];  
	
	fclose(stdin);fclose(stdout);
	return 0;
}

