#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <map>
#include <queue>
using namespace std;

const int MAXN = 10000 + 5;
const int MAXM = 200000 + 5;
const int INF = 1000000000;//0x3f3f3f3f;

struct Edge
{
	int to;
	Edge *next;
}pool[MAXM], *pool_cur=pool, *info[MAXN];

void Insert(int u, int v)
{
	pool_cur->to = v;
	pool_cur->next = info[u];
	info[u] = pool_cur++;
}

int n, m, s, t;

bool arrive_t[MAXN];

void Arrive()
{
	queue<int> Que;
	arrive_t[t] = true;
	Que.push(t);
	while (! Que.empty())
	{
		int u = Que.front();
		Que.pop();
		for (Edge *p=info[u]; p; p=p->next)
		{
			int v = p->to;
			if (arrive_t[v]) continue;
			Que.push(v);
			arrive_t[v] = true;
		}
	}
}

bool can_pass[MAXN];
int dis[MAXN];
bool inQue[MAXN];

void Solve()
{
	queue<int> Que;
	for (int i=1; i<=n; i++)
	{
		dis[i] = INF;
	}
	dis[t] = 0;
	Que.push(t);
	inQue[t] = true;
	while (! Que.empty())
	{
		int u = Que.front();
		inQue[u] = false;
		Que.pop();
		for (Edge *p=info[u]; p; p=p->next)
		{
			int v = p->to;
			if (! can_pass[v]) continue;
			if (dis[u] + 1 < dis[v])
			{
				dis[v] = dis[u]+1;
				if (! inQue[v])
				{
					inQue[v] = true;
					Que.push(v);
				}
			}
		}
	}
	if (dis[s] == INF) printf("-1\n");
	else printf("%d\n", dis[s]);
}

int main()
{
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);

	scanf("%d%d", &n, &m);
	for (int i=0; i<m; i++)
	{
		int u, v;
		scanf("%d%d", &u, &v);
		Insert(v, u);
	}
	scanf("%d%d", &s, &t);

	Arrive();
	for (int i=1; i<=n; i++)
	{
		can_pass[i] = true;
	}
	for (int u=1; u<=n; u++)
	{
		if (! arrive_t[u])
		{
			for (Edge *p=info[u]; p; p=p->next)
			{
				int v = p->to;
				can_pass[v] = false;
			}
		}
	}
	Solve();

	return 0;
}

