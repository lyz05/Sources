#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <map>
using namespace std;

int d;
int n;
int X[233], Y[233], C[233];

int Solve(int x, int y)
{
	int ret = 0;
	int L = x-d;
	int R = x+d;
	int U = y+d;
	int D = y-d;
	for (int i=0; i<n; i++)
	{
		if (X[i] >= L && X[i] <= R &&
				Y[i] >= D && Y[i] <= U)
		{
			ret += C[i];
		}
	}
	return ret;
}

int main()
{
	freopen("wireless.in", "r", stdin);
	freopen("wireless.out", "w", stdout);

	scanf("%d%d", &d, &n);
	for (int i=0; i<n; i++)
	{
		scanf("%d%d%d", X+i, Y+i, C+i);
	}

	int cnt=0, maxcover=0;
	for (int i=0; i<=128; i++)
	{
		for (int j=0; j<=128; j++)
		{
			int tmp = Solve(i,j);
			if (tmp > maxcover)
			{
				maxcover = tmp;
				cnt = 1;
			}
			else if (tmp == maxcover)
			{
				cnt ++;
			}
		}
	}
	printf("%d %d\n", cnt, maxcover);

	return 0;
}

