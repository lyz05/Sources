#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <map>
using namespace std;

const int MOD = 1000000007;

int n, m;
bool Minus[233];
long long a[233];

string str;

void Scan(int j)
{
	cin >> str;
	int len = str.size();
	long long &ret = a[j];
	if (str[0] == '-')
	{
		Minus[j] = true;
	}
	for (int i=Minus[j]; i<len; i++)
	{
		ret = ret*10 + (str[i]-'0');
		ret %= MOD;
	}
}

int nAns, ans[1000005];

bool check(int x)
{
	long long mi = 1;
	long long ans = 0;
	for (int i=0; i<=n; i++)
	{
		if (Minus[i])
		{
			ans = (ans - mi * a[i]) % MOD;
		}
		else
		{
			ans = (ans + mi * a[i]) % MOD;
		}
		mi = mi * x % MOD;
	}
	return ans == 0LL;
}

int main()
{
	freopen("equation.in", "r", stdin);
	freopen("equation.out", "w", stdout);

	cin >> n >> m;
	for (int i=0; i<=n; i++)
	{
		Scan(i);
	}
	
	int tm = m;
	m = min(m, 23333333/n);
	
	for (int x=1; x<m; x++)
	{
		if (check(x)) 
		{
			ans[nAns ++] = x;
		}
	}
	if (check(tm))
	{
		ans[nAns ++] = tm;
	}
	printf("%d\n", nAns);
	for (int i=0; i<nAns; i++)
	{
		printf("%d\n", ans[i]);
	}

	return 0;
}

