#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cstring>
using namespace std;

int d, n;
int map[130][130];

int main()
{
	freopen("wireless.in", "r", stdin);
	freopen("wireless.out", "w", stdout);
	
	cin >> d >> n;
	for (int i=1; i<=n; i++)
	{
		int x, y, k;
		cin >> x >> y >> k;
		map[x][y] = k;
	}
	
	for (int i=0; i<=128; i++)
	{
		for (int j=1; j<=128; j++)
		{
			map[i][j] += map[i][j-1];
		}
	}
	for (int i=1; i<=128; i++)
	{
		for (int j=0; j<=128; j++)
		{
			map[i][j] += map[i-1][j];
		}
	}
	
//	for (int i=0; i<=128; i++)
//	{
//		for (int j=0; j<=128; j++)
//		{
//			cout << map[i][j] << ' ';
//		}
//		cout << endl;
//	}
	
	int ans = 0, num = 0;
	for (int i=d; i<=(128-d); i++)
	{
		for (int j=d; j<=(128-d); j++)
		{
			int temp;
			
			if (i == d)
			{
				if (j == d)
				{
					temp = map[i+d][j+d];
				}
				else
				{
					temp = map[i+d][j+d] - map[i+d][j-d-1];
				}
			}
			else
			{
				if (j == d)
				{
					temp = map[i+d][j+d] - map[i-d-1][j+d];
				}
				else
				{
					temp = map[i+d][j+d] - map[i-d-1][j+d] - map[i+d][j-d-1] + map[i-d-1][j-d-1];
				}
			}
			
			if(ans < temp)
			{
				ans = temp;
				num = 1;
			}
			else if (ans == temp)
			{
				num++;
			}
		}
	}
	
	cout << num << ' ' << ans << endl;
	
	return 0;
}
