#include <iostream>
#include <cmath>
#include <cstdlib>
#include <cstdio>
using namespace std;

int n, m;
int a0, a1, a2, a3;

int main()
{
	freopen("equation.in", "r", stdin);
	freopen("equation.out", "w", stdout);
	
	cin >> n >> m;
	if (n == 1)
	{
		cin >> a0 >> a1;    // a0+a1x=0 => x=-a0/a1
		if ((a0/a1)*a1 != a0)
		{
			cout << 0 << endl;
		}
		else
		{
			if (-a0/a1>=1 && -a0/a1<=m)
			{
				cout << 1 << endl;
				cout << -a0/a1 << endl;
			}
		}
	}
	else if (n == 2)
	{
		cin >> a0 >> a1 >> a2;  // a0+a1x+a2x^2=0 => a2x^2+a1x+a0=0
		if (a1*a1-4*a2*a0 < 0)
		{
			cout << 0 << endl;
		}
		else
		{
			int square_root = int(sqrt(a1*a1-4*a2*a0));
			if (square_root*square_root != a1*a1-4*a2*a0)
			{
				cout << 0 << endl;
			}
			else
			{
				int ans = 2, can1 = true, can2 = true;
				int root1 = -a1+square_root, root2 = -a1-square_root;
				if (root1 > root2)
				{
					int temp = root1;
					root1 = root2;
					root2 = temp;
				}
				if ((root1/(2*a2))*(2*a2) != root1)
				{
					ans--;
					can1 = false;
				}
				else
				{
					if (root1/(2*a2)<1 || root1/(2*a2)>m)
					{
						ans--;
						can1 = false;
					}
				}
				if ((root2/(2*a2))*(2*a2) != root2)
				{
					ans--;
					can2 = false;
				}
				else
				{
					if (root2/(2*a2)<1 || root2/(2*a2)>m)
					{
						ans--;
						can2 = false;
					}
				}
				if (root1 == root2)
				{
					ans--;
					can2 = false;
				}
				cout << ans << endl;
				if (can1)
				{
					cout << root1/(2*a2) << endl;
				}
				if (can2)
				{
					cout << root2/(2*a2) << endl;
				}
			}
		}
	}
	else
	{
		cout << 0 << endl;
	}
	
	return 0;
}
