#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <queue>
using namespace std;

int n, m, s, t;
const int MAXN = 10005, INT_MAX = 2147483640;
struct nodetype
{
	nodetype *next;
	int to;
	nodetype()
	{
		to = 0;
	}
};
nodetype node[MAXN];
bool reach[MAXN];

void add_road(int x, int y);
bool dfs(int now);
int spfa();

int main()
{
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	
	cin >> n >> m;
	for (int i=1; i<=m; i++)
	{
		int x, y;
		cin >> x >> y;
		if (x != y)
		{
			add_road(x, y);
		}
	}
	cin >> s >> t;
	
//	for (int i=1; i<=n; i++)
//	{
//		nodetype *p = &node[i];
//		cout << i << ": ";
//		while (p->to != 0)
//		{
//			cout << p->to << " ";
//			p = p->next;
//		}
//		cout << endl;
//	}
	
	dfs(s);
	reach[t] = true;

	if (!reach[s])
	{
		cout << -1 << endl;
	}
	else
	{
		for (int i=1; i<=n; i++)
		{
			if (!reach[i])
			{
				continue;
			}
			nodetype *p = &node[i];
			while (p->to != 0)
			{
				if (!reach[p->to])
				{
					reach[i] = false;
					break;
				}
				p = p->next;
			}
		}

//		for (int i=1; i<=n; i++)
//		{
//			cout << i << ' ';
//			if (reach[i])
//			{
//				cout << "true";
//			}
//			else
//			{
//				cout << "false";
//			}
//			cout << endl;
//		}

		int ans = spfa();
		if (ans == INT_MAX)
		{
			cout << -1 << endl;
		}
		else
		{
			cout << ans << endl;
		}
	}

	return 0;
}

void add_road(int x, int y)
{
	nodetype *p = new nodetype;
	p->next = node[x].next;
	p->to = node[x].to;
	node[x].next = p;
	node[x].to = y;
	
	return;
}

bool visit[MAXN];

bool dfs(int now)
{
	if (reach[now] || now == t)
	{
		reach[now] = true;
		return true;
	}
	if (visit[now])
	{
		return false;
	}

	visit[now] = true;
	nodetype *p = &node[now];
	while (p->to != 0)
	{
		if (dfs(p->to))
		{
			reach[now] = true;
		}
		p = p->next;
	}
	visit[now] = false;
	
	if (reach[now])
	{
		return true;
	}
	return false;
}

int dis[MAXN];
queue<int> q;
bool inq[MAXN];
int num[MAXN];

int spfa()
{
	for (int i=1; i<=n; i++)
	{
		dis[i] = INT_MAX;
	}
	memset(inq, false, sizeof(inq));
	memset(num, 0, sizeof(num));
	while (!q.empty())
	{
		q.pop();
	}

	q.push(s);
	num[s]++;
	inq[s] = true;
	dis[s] = 0;
	
	while (!q.empty())
	{
		if (num[q.front()] > n-1)
		{
			break;
		}
		nodetype *p = &node[q.front()];
		while (p->to != 0)
		{
			if (reach[p->to] && dis[p->to] > dis[q.front()]+1)
			{
				dis[p->to] = dis[q.front()] + 1;
				num[p->to]++;
				if (!inq[p->to])
				{
					q.push(p->to);
					inq[p->to] = true;
				}
			}
			p = p->next;
		}
		inq[q.front()] = false;
		q.pop();
	}
	
	return dis[t];
}
