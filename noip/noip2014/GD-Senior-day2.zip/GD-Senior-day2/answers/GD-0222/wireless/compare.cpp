#include <cstdio>

FILE *fpr,*fpw;

long int a[260][260]; 

int main()
{
	fpr=fopen("wireless.in","r");
	long int n=129,m,d;
	long int i,j,x,y,k;
	long int max=0,num=0;
	fscanf(fpr,"%ld%ld",&d,&m);
	for (i=1;i<=m;i++)
	{
		fscanf(fpr,"%ld%ld%ld",&x,&y,&k);
		a[x+1][y+1]+=k;
	}
	for (i=1;i<=n;i++)
		for (j=1;j<=n;j++)
		{
			k=0;
			for (x=(i-d)>0?(i-d):1;x<=i+d;x++)
				for (y=(j-d)>0?(j-d):1;y<=j+d;y++)
					k+=a[x][y];
			if (k>max)
			{
				max=k;
				num=1;
			}
			else if (k==max) num++;
		}
			
	printf("%ld %ld",num,max);
	return 0;
}
