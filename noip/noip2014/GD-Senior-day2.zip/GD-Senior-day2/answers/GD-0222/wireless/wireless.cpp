#include <cstdio>

FILE *fpr,*fpw;

long long int a[180][180],sum[180][180]; 

int main()
{
	fpr=fopen("wireless.in","r");
	fpw=fopen("wireless.out","w");
	long long int n=129,m,d;
	long long int i,j,x,y,k;
	long long int max=0,num=0;
	fscanf(fpr,"%lld%lld",&d,&m);
	d*=2;d++;
	for (i=1;i<=m;i++)
	{
		fscanf(fpr,"%lld%lld%lld",&x,&y,&k);
		a[x+1][y+1]+=k;
	}
	for (i=1;i<=n+(d-1)/2;i++)
		for (j=1;j<=n+(d-1)/2;j++)
			sum[i][j]=sum[i-1][j]+sum[i][j-1]-sum[i-1][j-1]+a[i][j];
	for (i=1;i<=n+(d-1)/2;i++)
		for (j=1;j<=n+(d-1)/2;j++)
		{
			if (i==7&&j==7)
				k++;
			k=sum[i][j]-sum[(i-d)>0?(i-d):0][j]-sum[i][(j-d)>0?(j-d):0]+sum[(i-d)>0?(i-d):0][(j-d)>0?(j-d):0];
			if (k>max)
			{
				max=k;
				num=1;
			}
			else if (k==max)
				num++;
		}
	fprintf(fpw,"%lld %lld",num,max);
	return 0;
}
