#include <cstdio>
#include <cstdlib>
#include <ctime>

int main()
{
	long int i,n=129,m=10000,d;
	long int a,b,c;
	srand(time(0));
	d=rand()%21;
	freopen("wireless.in","w",stdout);
	printf("%ld %ld\n",d,m);
	for (i=1;i<=m;i++)
	{
		a=rand()%n;
		b=rand()%n;
		c=(rand()*rand())%1000000;
		printf("%ld %ld %ld\n",a,b,c);
	}
	return 0;
}
