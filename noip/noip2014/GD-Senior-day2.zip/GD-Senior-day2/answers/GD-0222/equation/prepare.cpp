#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>

FILE *fpr,*fpw;

long int n,m;

void f1()
{
	long int a,b,c,num=0,x[5];
	fscanf(fpr,"%ld%ld%ld",&a,&b,&c);
	long int i;
	for (i=1;i<=m;i++)
		if (i*i*a+i*b+c==0)
			x[++num]=i;
	printf("%ld\n",num);
	for (i=1;i<=num;i++)
		printf("%ld\n",x[i]);
}

struct bigint
{
	char s[366];
	long int len;
	void init()
	{memset(this,0,sizeof(bigint));}
	void print()
	{for (long int i=len;i;i--)
		printf("%d",s[i]);
		printf("\n");
	}
};

bool operator== (bigint a,bigint b)
{
	if (a.len!=b.len) return false;
	for (long int i=a.len;i;i--)
		if (a.s[i]!=b.s[i])
			return false;
	return true;
}

bigint operator* (bigint a,bigint b)
{
	bigint c;
	c.init();
	if (a==c||b==c)
		return c;
	long int i,j;
	for (i=1;i<=a.len;i++)
		for (j=1;j<=b.len;j++)
		{
			c.s[i+j-1]+=a.s[i]*b.s[j];
			c.s[i+j]+=c.s[i+j-1]/10;
			c.s[i+j-1]%=10;
		}
	if (c.s[a.len+b.len]) c.len=a.len+b.len;
	else c.len=a.len+b.len-1;
	return c;
}

bigint operator+ (bigint a,bigint b)
{
	bigint c;
	c.init();
	long int i;
	for (i=1;i<=(a.len>b.len?a.len:b.len);i++)
	{
		c.s[i]+=a.s[i]+b.s[i];
		c.s[i+1]+=c.s[i]/10;
		c.s[i]%=10;
	}
	if (c.s[i+1]) c.len=i+1;
	else c.len=i;
	return c;
}

long int que[102];
bigint a[115];
bool fu[115];
void f2()
{
	long int i,j,k,num=0;
	char tmp[128];
	bigint one,x,die,left,right;
	one.init();
	one.s[1]=1;one.len=1;
	for (i=1;i<=n;i++)
	{
		a[i].init();
		fscanf(fpr,"\n%s",tmp);
		if (tmp[0]=='-')
		{
			fu[i]=true;
			k=strlen(&tmp[1]);
			a[i].len=k;
			for (j=1;tmp[j];k--,j++)
			a[i].s[k]=tmp[j];
		}
		else
		{
			i=strlen(&tmp[0]);
			a[i].len=i;
			for (j=0;tmp[j];i--,j++)
			a[i].s[i]=tmp[j];
		}
	}
	for (x=one,i=1,die=one;i<=m;i++,x=x+one)
	{
		left.init();right.init();
		for (j=0;j<=n;j++)
		{
			if (fu[j])
				right=right+die*a[j];
			else left=left+die*a[j];
			die=die*x;
		}
		if (left==right)
			que[++num]=i;
	}
	printf("%ld\n",num);
	for (i=1;i<=num;i++)
		printf("%ld\n",que[i]);
}

int main()
{
	fpr=fopen("equation.in","r");
	fpw=fopen("equation.out","w");
	fscanf(fpr,"%ld%ld",&n,&m);
	if (n==2) f1();
	else if (n<=100&&m<=100) f2();
	else printf("0");
	return 0;
}
