#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>

FILE *fpr,*fpw;

long int n,m;

void f1()
{
	long int a,b,c,num=0,x[5];
	fscanf(fpr,"%ld%ld%ld",&a,&b,&c);
	long int i;
	for (i=1;i<=m;i++)
		if (i*i*a+i*b+c==0)
			x[++num]=i;
	fprintf(fpw,"%ld\n",num);
	for (i=1;i<=num;i++)
		fprintf(fpw,"%ld\n",x[i]);
}
/*
struct bigint
{
	char s[366],f;
	long int len;
	void init()
	{memset(this,0,sizeof(bigint));}
};

bool operator== (bigint a,bigint b)
{
	if (a.len!=b.len) return false;
	if (a.f!=b.f) return false;
	for (long int i=a.len;i;i--)
		if (a.s[i]!=b.s[i])
			return false;
	return true;
}

bool operator> (bigint a,bigint b)
{
	if (a.f==1)
}

bigint operator* (bigint a,bigint b)
{
	bigint c;
	c.init();
	if (a==c||b==c)
		return c;
	long int i,j;
	for (i=1;i<=a.len;i++)
		for (j=1;j<=b.len;j++)
		{
			c.s[i+j-1]+=a.s[i]*b.s[i];
			c.s[i+j]+=c.s[i+j-1]/10;
			c.s[i+j-1]%=10;
		}
	if (c.s[a.len+b.len]) c.len=a.len+b.len;
	else c.len=a.len+b.len-1;
	return c;
}

bigint operator- (bigint a,bigint b)
{
	bigint c;
	c.init();
	long int i;
	c.len=a.len>b.len?a.len:b.len;
	for (i=1;i<=c.len;i++)
	{
		c.s[i]+=a.s[i]-b.s[i];
		if (c.s[i]<0)
		{
			c.s[i+1]-=1;
			c.s[i]+=10;
		}
	}
	while (!c.s[c.len]) c.len--;
	return c;
}

bigint operator+ (bigint a,bigint b)
{
	bigint c;
	c.init();
	if (a.f^b.f)
	{
		if (a>b)
			return a-b;
		else if (a==b)
			return c;
		else
		{
			c=b-a;
			c.f=true;
			return c;
		}
	}
	c.f=a.f;
	long int i;
	for (i=1;i<=alen>b.len?a.len:b.len;i++)
	{
		c.s[i]+=a.s[i]+b.s[i];
		c.s[i+1]+=c.s[i]/10;
		c.s[i]%=10;
	}
	if (c.s[i+1]) c.len=i+1;
	else c.len=i;
	return c;
}

long int que[102];
void f2()
{
	long int i,j,num=0;
	char tmp[128];
	bigint a[115],one,x,y,die;
	one.init();
	one.s[1]=1;one.len=1;
	for (i=1;i<=n;i++)
	{
		a[i].init();
		scanf("\n%s",tmp);
		if (tmp[0]=='-')
		{
			a[i].f=true;
			i=strlen(&tmp[1]);
			a[i].len=i;
			for (j=1;tmp[j];i--,j++)
			a[i].s[i]=tmp[j];
		}
		else
		{
			i=strlen(&tmp[0]);
			a[i].len=i;
			for (j=0;tmp[j];i--,j++)
			a[i].s[i]=tmp[j];
		}
	}
	for (x=one,i=1,die=one;i<=m;i++,x=x+one)
	{
		y.init();
		for (j=0;j<=n;j++)
		{
			y=y+die*a[j];
			die=die*x;
		}
		if (y.len==0)
			que[++num]=i;
	}
	printf("%ld\n",num);
	for (i=1;i<=num;i++)
		printf("%ld\n",que[i]);
}*/

int main()
{
	fpr=fopen("equation.in","r");
	fpw=fopen("equation.out","w");
	fscanf(fpr,"%ld%ld",&n,&m);
	if (n==2) f1();
	//else if (n<=100&&m<=100) f2();
	else fprintf(fpw,"0");
	return 0;
}
