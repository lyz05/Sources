#include <cstdio>
#include <cstring>

FILE *fpr,*fpw;

long int n,m,from,to;

long int head[10009],end;
struct MAP
{long int here,pre;
}map[200009];

void readin()
{
	long int i,a,b;
	fscanf(fpr,"%ld%ld",&n,&m);
	for (i=1;i<=m;i++)
	{
		fscanf(fpr,"%ld%ld",&a,&b);
		map[++end].here=b;
		map[end].pre=head[a];
		head[a]=end;
	}
	fscanf(fpr,"%ld%ld",&from,&to);
}

char bo[10009],reach[10009],del[10009];

void dfs(long int now)
{
	long int i;
	bo[now]=true;
	if (now==6)
		i=1;
	for (i=head[now];i;i=map[i].pre)
	{
		if (!bo[map[i].here])
			dfs(map[i].here);
		if (reach[map[i].here])
			reach[now]=true;
		else del[now]=true;
	}
}

long int dis[10009],que[10009],st,en;

void spfa()
{
	long int i,now;
	memset(dis,63,sizeof(dis));
	memset(bo,0,sizeof(bo));
	st=1;en=2;que[st]=from;
	dis[from]=0;
	while (st!=en)
	{
		now=que[st++];
		bo[now]=-1;
		for (i=head[now];i;i=map[i].pre)
			if (!del[map[i].here])
				if (dis[map[i].here]>dis[now]+1)
				{
					dis[map[i].here]=dis[now]+1;
					if (bo[map[i].here]==-1)
						que[--st]=map[i].here;
					else if (bo[map[i].here]==0)
						que[en++]=map[i].here;
					bo[map[i].here]=1;
				}
	}
}

void dij()
{
	memset(bo,0,sizeof(bo));
	memset(dis,63,sizeof(dis));
	dis[from]=0;
	long int i,j,now,min,flag;
	for (i=1;i<=n;i++)
	{
		min=n+1;flag=-1;
		for (j=1;j<=n;j++)
			if (dis[j]<min&&!bo[j])
			{
				min=dis[j];flag=j;
			}
		if (flag==-1) break;
		bo[flag]=true;
		for (j=head[flag];j;j=map[j].pre)
			if (!del[map[j].here])
				if (dis[map[j].here]>dis[flag]+1)
					dis[map[j].here]=dis[flag]+1;
	}
}

int main()
{
	fpr=fopen("road.in","r");
	readin();
	bo[to]=true;
	reach[to]=true;
	//dfs(from);
	/*for (long int i=1;i<=n;i++)
		printf("%ld:%d %d\n",i,reach[i],del[i]);*/
	if (del[from])
	{
		printf("-1");
		return 0;
	}
	dij();
	/*for (long int i=1;i<=n;i++)
		printf("%ld:%ld\n",i,dis[i]);*/
	if (dis[to]<dis[0])
		printf("%ld",dis[to]);
	else printf("-1");
	return 0;
}
