#include <cstdio>
#include <ctime>
#include <cstdlib>

int main()
{
	long int n=10000,m=20000;
	long int i,a,b;
	srand(time(0));
	freopen("road.in","w",stdout);
	printf("%ld %ld\n",n,m);
	for (i=1;i<=m;i++)
	{
		a=rand()%n;
		b=rand()%n;
		a++;b++;
		printf("%ld %ld\n",a,b);
	}
	a=rand()%n;a++;
	while (b==a)
	{
		b=rand()%n;
		b++;
	}
	printf("%ld %ld\n",a,b);
	return 0;
}
