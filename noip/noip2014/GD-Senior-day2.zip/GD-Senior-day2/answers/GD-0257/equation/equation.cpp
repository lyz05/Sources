#include<iostream>
#include<string.h>
#include<stdlib.h>
#include<stdio.h>
#define INF 99999999
using namespace std;
int n,m,a[110],ans[110];
int main()
{
   freopen("equation.in","r",stdin);
   freopen("equation.out","w",stdout);
   scanf("%d%d",&n,&m);
   if(n<=2)
   {
      for(int i=0;i<=n;i++)scanf("%d",&a[i]);
      for(int i=1;i<=m;i++)
      {
	     if(a[0]+a[1]*i+a[2]*i*i==0)
		 {
		   ans[0]++;
	       ans[ans[0]]=i;
	     }
	  }
	  printf("%d\n",ans[0]);
	  for(int i=1;i<=ans[0];i++)printf("%d\n",ans[i]);
   }
   else printf("0\n");
   return 0;
}
