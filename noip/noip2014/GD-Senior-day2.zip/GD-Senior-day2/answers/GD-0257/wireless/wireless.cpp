#include<iostream>
#include<string.h>
#include<stdlib.h>
#include<stdio.h>
using namespace std;
int map[130][130],f[130],tot,ans;
int main()
{
   freopen("wireless.in","r",stdin);
   freopen("wireless.out","w",stdout);
   int n,d,x,y;
   scanf("%d%d",&d,&n);
   for(int i=1;i<=n;i++)
   {
      scanf("%d%d",&x,&y);
      scanf("%d",&map[x][y]);
   }
   for(int i=0;i<=2*d;i++)
      for(int j=0;j<=2*d;j++)
      {
	     f[2*d]+=map[i][j];
	  }
   ans=f[2*d];tot=1;
   for(int i=2*d+1;i<=128;i++)
   {
      f[i]=f[i-1];
      for(int j=0;j<=2*d;j++)
      {
	     f[i]+=map[i][j];
	     f[i]-=map[i-2*d-1][j];
	  }
	  if(f[i]==ans)tot++;
	  else if(f[i]>ans)
	  { 
		 ans=f[i];
	     tot=1;
	  }
   }
   for(int i=2*d;i<=128;i++)
      for(int j=2*d+1;j<=128;j++)
      {
	     for(int t=0;t<=2*d;t++)
	     {
		    f[i]-=map[i-2*d+t][j-2*d-1];
		    f[i]+=map[i-2*d+t][j];
		 }
		 if(f[i]==ans)tot++;
	     else if(f[i]>ans)
	     {
	        
		    ans=f[i];
	        tot=1;
	     }
	  }
	printf("%d %d\n",tot,ans);
   return 0;
}
