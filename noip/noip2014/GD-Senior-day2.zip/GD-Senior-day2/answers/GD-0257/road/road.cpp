#include<iostream>
#include<string.h>
#include<stdlib.h>
#include<stdio.h>
#define INF 99999999
using namespace std;
struct Road
{
   int num;
   Road *nextit;
};
Road map[10010];
int q[400000],can[10010],vis[10010],dist[10010];
int main()
{
   freopen("road.in","r",stdin);
   freopen("road.out","w",stdout);
   int n,m,x,y;Road *p;
   scanf("%d%d",&n,&m);
   for(int i=1;i<=m;i++)
   {
      scanf("%d%d",&x,&y);
      if(x==y)continue;
	  p=new Road;
      p->nextit=map[y].nextit;
      p->num=x;
      map[y].nextit=p;
   }
   scanf("%d%d",&x,&y);
   {
      int head=0,rear=1,u;
      can[y]=1;q[0]=y;  
      while(head<rear)
      {
	     u=q[head];
	     p=map[u].nextit;
	     while(p!=NULL)
	     {
		    if(!can[p->num])
		    {
			   can[p->num]=1;
			   if(!vis[p->num])
			   {
			     vis[p->num]=1;
			     q[rear++]=p->num;
			   }
		    }
		    p=p->nextit;
		 }
	     head++;
	     vis[u]=0;
	  }
	  memset(vis,0,sizeof(vis));
      head=0;rear=0;
	  for(int i=1;i<=n;i++)
	  {
		 if(can[i]==0) 
		    q[rear++]=i;   
	  }	  
      while(head<rear)
      {
	     u=q[head];
         p=map[u].nextit;
		 while(p!=NULL)
		 {
		    can[p->num]=0;
		    p=p->nextit;
	     }
	     head++;
	  }
	  if(!can[x])
	  {
	     printf("-1\n");
		 return 0;
	  }
	  head=0;rear=1;
      can[y]=1;q[0]=y;  
      while(head<rear)
      {
	     u=q[head];
	     p=map[u].nextit;
		 while(p!=NULL)
	     {
		    if(can[p->num])
		    {
			   if(dist[u]+1<dist[p->num]||!dist[p->num])
			   {
			       dist[p->num]=dist[u]+1;
				   if(!vis[p->num])
			       {
			          vis[p->num]=1;
			          q[rear++]=p->num;
			       }
			   }
		    }
		    p=p->nextit;
		 }
	     head++;
	     vis[u]=0;
	  }
	  if(!dist[x])
	  {
	     printf("-1\n");
		 return 0;
	  }
	  printf("%d\n",dist[x]);
   }
   return 0;
}
