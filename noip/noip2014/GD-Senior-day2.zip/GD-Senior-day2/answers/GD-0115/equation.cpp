#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

int n, ans[100000], m, fu[200], an;
char s[200];

struct Num {
	int l, a[100];
	void init(int x) {
		memset(a, 0, sizeof(a));
		if (x == 0) l = 0; else a[l = 1] = x;
	}
	void plus(Num b) {
		l = max(l, b.l);
		for (int i = 1; i <= l; i++) {
			a[i] = a[i] + b.a[i];
			if (a[i] > 10000) a[i + 1]++, a[i] -= 10000;
		}
		if (a[l + 1]) l++;
	}
} A, B, t, tmp, a[110];

int Mo(Num a, int x) {
	int yu = 0;
	for (int i = a.l; i >= 1; i--) {
		yu = yu * 10000 + a.a[i];
		if (yu >= x) yu %= x;
	}
	return yu;
}

Num mult(Num x, Num y) {
	tmp.init(0);
	for (int i = 1; i <= x.l; i++)
		for (int j = 1; j <= y.l; j++) {
			tmp.a[i + j - 1] += x.a[i] * y.a[j];
			tmp.a[i + j] += tmp.a[i + j - 1] / 10000;
			tmp.a[i + j - 1] %= 10000;
		}
	tmp.l = x.l + y.l;
	for (; !tmp.a[tmp.l]; tmp.l--);
	return tmp;
}

Num mult(Num x, int y) {
	for (int i = 1; i <= x.l; i++) {
		x.a[i] *= y;
		x.a[i + 1] += x.a[i] / 10000;
		x.a[i] %= 10000;
	}
	if (x.a[x.l + 1]) x.l++;
	return x;
}

void Brute() {
	for (int i = 0; i <= n; i++) {
		scanf("%s", &s);
		if (s[0] == '-') {
			fu[i] = -1;
			for (int j = strlen(s) - 1; j > 0; j -= 4) {
				++a[i].l;
				for (int k = max(j - 3, 1); k <= j; k++) 
					a[i].a[a[i].l] = a[i].a[a[i].l] * 10 + s[k] - '0';
			}
		} else {
			for (int j = strlen(s) - 1; j >= 0; j -= 4) {
				++a[i].l;
				for (int k = max(j - 3, 0); k <= j; k++) 
					a[i].a[a[i].l] = a[i].a[a[i].l] * 10 + s[k] - '0';
			}
		}
	}
	
	for (int i = 1; i <= m; i++) {
		if (Mo(a[0], i) != 0) continue;
		A.init(0);
		B.init(0);
		t.init(1);
		for (int j = 0; j <= n; j++) {
			if (fu[j] == -1) {
				B.plus(mult(t, a[j]));
			} else {
				A.plus(mult(t, a[j])); 
			}
			
			t = mult(t, i);
		}
		
		if (B.l == A.l) {
			bool ok = true;
			for (int j = 1; j <= B.l; j++) ok &= A.a[j] == B.a[j];
			if (ok) ans[++an] = i;
		}
	}
	
	printf("%d\n", an);
	for (int i = 1; i <= an; i++) printf("%d\n", ans[i]);
	
	
}

int main() {
	freopen("equation.in", "r", stdin);
	freopen("equation.out", "w", stdout);
	
	scanf("%d%d", &n, &m);
	if (m <= 100) Brute(); else puts("0");
	return 0;
}	

