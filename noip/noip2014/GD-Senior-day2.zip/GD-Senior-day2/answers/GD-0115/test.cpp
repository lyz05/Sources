#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

int a[100], n;

int main() {
	freopen("test.in", "r", stdin);
	freopen("test.out", "w", stdout);
	
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) scanf("%d", &a[i]);
	sort(a + 1, a + 1 + n);
	for (int i = 1; i <= n; i++) printf("%d ", a[i]);
	
	return 0;	
}

