#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

const int N = 100;
int a[N][3];
int d, n, ans, ci;

int main() {
	freopen("wireless.in", "r", stdin);
	freopen("wireless.out", "w", stdout);
	
	scanf("%d", &d);
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) scanf("%d%d%d", &a[i][0], &a[i][1], &a[i][2]);
	for (int i = 0; i <= 128; i++)
		for (int j = 0; j <= 128; j++) {
			int s = 0;
			for (int k = 1; k <= n; k++) {
				if (a[k][0] >= i - d && a[k][0] <= i + d && a[k][1] >= j - d && a[k][1] <= j + d)
					s += a[k][2];
			}
			if (s > ans) {ans = s, ci = 1;} else if (s == ans) ci++;
		}
		
	printf("%d %d\n", ci, ans);
	return 0;	
}

