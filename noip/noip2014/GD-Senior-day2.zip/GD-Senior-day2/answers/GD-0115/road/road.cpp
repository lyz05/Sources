#include <cstdio>
#include <cstring>
#include <algorithm>
#define memcle(a) memset(a, 0, sizeof(a))
using namespace std;

const int N = 21000, M = 410000;
int adj[M], next[M], last[N], mm;
int bfs[N], cov[N], lab[N], n, m, S, T, e[M][2];

void Link(int x, int y) {
	adj[++mm] = y; next[mm] = last[x]; last[x] = mm;	
}

void Bfs(int S) {
	int l = 0, r = 1;
	bfs[1] = S;
	cov[S] = 1;
	for (; l < r; )	 {
		int u = bfs[++l];
		for (int p = last[u]; p; p = next[p]) {
			if (!cov[adj[p]]) {
				cov[adj[p]] = 1;
				bfs[++r] = adj[p];	
			}
		}
	}
}

void Check() {
	for (int i = 1; i <= n; i++) {
		if (cov[i]) {
			lab[i] = 1;
			for (int p = last[i]; p; p = next[p]) 
				if (!cov[adj[p]]) lab[i] = 0;
		}
	}
}

void Sp() {
	memset(cov, -1, sizeof(cov));
	cov[S] = 0;
	bfs[1] = S;
	int l = 0, r = 1;
	for (; l < r; ) {
		int u = bfs[++l];
		if (!lab[u]) continue;
		for (int p = last[u]; p; p = next[p]) {
			if (cov[adj[p]] == -1 && lab[adj[p]]) cov[adj[p]] = cov[u] + 1, bfs[++r] = adj[p];
		}
	}
	
	printf("%d\n", cov[T]);
}

int main() {
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= m; i++) scanf("%d%d", &e[i][0], &e[i][1]), Link(e[i][1], e[i][0]);
	scanf("%d%d", &S, &T);
	Bfs(T);
	memcle(last);
	mm = 0;
	for (int i = 1; i <= m; i++) Link(e[i][0], e[i][1]);
	Check();
	Sp();
	
	return 0;	
}

