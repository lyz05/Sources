#include<fstream>
#include<vector>
#include<queue>
using namespace std;
ifstream fin("road.in");
ofstream fout("road.out");
int n,m,s,t,bol=0;
vector<int> pos[10010],nea[10010];
int vis[10010]={},ok[10010]={},vib[10010]={};
void in(){
	fin>>n>>m;
	for(int i=1;i<=m;++i){
		int x,y;
		fin>>x>>y;
		pos[x].push_back(y);
		nea[y].push_back(x);
	}
	fin>>s>>t;
}
void dfs(int k){
	vis[k]=1;
	int leg=nea[k].size();
	for(int i=0;i<leg;++i){
		if(!vis[nea[k][i]])
			dfs(nea[k][i]);
	}
}
void tip(){
	for(int i=1;i<=n;++i){
		int k=pos[i].size();
		for(int j=0;j<k;++j){
			if(!vis[pos[i][j]])
				ok[i]=1;
		}
	}
}
void bfs(){
	int ans=0;
	queue<int> q;
	q.push(s);
	while(!q.empty()){
		ans++;
		int h=q.size();
		for(int j=0;j<h;++j){
			int k=q.front();q.pop();
			if(k==t){
				fout<<ans;
				bol=1;
				break;
			}
			vib[k]=1;
			int g=pos[k].size();
			for(int i=0;i<g;++i){
				if(!vib[pos[k][i]])q.push(pos[k][i]);
			}
		}
		if(bol)break;
	}
}
int main(){
	in();
	dfs(t);
	tip();
	bfs();
	if(!bol)fout<<-1;
	fin.close();
	fout.close();
	return 0;
}