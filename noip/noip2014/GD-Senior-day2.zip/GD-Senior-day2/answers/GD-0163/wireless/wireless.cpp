#include<fstream>
#include<algorithm>
using namespace std;
ifstream fin("wireless.in");
ofstream fout("wireless.out");
int d,n;
long long num[20001]={};
void in(){
	fin>>d>>n;
	int x,y;
	long long k;
	for(int i=1;i<=n;++i){
		fin>>x>>y>>k;
		for(int a=x-d;a<=x+d;++a){
			if(a<0)continue;
			if(a>128)break;
			for(int b=y-d;b<=y+d;++b){
				if(b<0)continue;
				if(b>128)break;
					num[a*129+b]+=k;
			}
		}
	}
}
void work(){
	long long a=num[20000];
	int i=0;
	while(true){if(num[20000-i]!=a)break;++i;}
	fout<<i<<endl<<a;
}
int main(){
	in();
	sort(num,num+20001);
	//for(int i=20000;i>=19900;--i)
		//fout<<num[i]<<" ";
	work();
	fin.close();
	fout.close();
	return 0;
}