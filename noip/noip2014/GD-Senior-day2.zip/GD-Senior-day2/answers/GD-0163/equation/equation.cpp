#include<fstream>
#include<string>
using namespace std;
ifstream fin("equation.in");
ofstream fout("equation.out");
int n,m;
const int wei=100000000;
long long a[110][1701]={},na[110]={};
long long s[1701]={},ns=0,cnt=0;
long long vis[1000010]={};
void in(){
	fin>>n>>m;
	for(int i=0;i<=n;++i){
		string str;
		fin>>str;
		int j=0,leg=str.size();
		if(str[0]=='-')na[i]=1;
			for(;((j+1)*8<=leg&&(!na[i]))||((j+1)*8<=leg-1&&(na[i]));j++){
				a[i][j]=
				(str[leg-j*8-1]-'0')
				+(str[leg-j*8-2]-'0')*10
				+(str[leg-j*8-3]-'0')*100
				+(str[leg-j*8-4]-'0')*1000
				+(str[leg-j*8-5]-'0')*10000
				+(str[leg-j*8-6]-'0')*100000
				+(str[leg-j*8-7]-'0')*1000000
				+(str[leg-j*8-8]-'0')*10000000;
			}
			int mo=na[i]?(leg-1)%8:leg%8;
			long long po=1;
			for(int k=mo+na[i]-1;k>=na[i];k--){
				a[i][j]+=po*(str[k]-'0');
				po*=10;
			}
	}
}
void jiaf(int i){
	for(int j=0;j<1700;j++){
		s[j]+=a[i][j];
		s[j+1]+=s[j]/wei;
		s[j]%=wei;
	}		
}
void zdjf(int i){
	for(int j=0;j<1700;j++){
		if(s[j]>=a[i][j]){
			s[j]-=a[i][j];
		}
		else{
			s[j+1]-=1;
			s[j]=s[j]+wei-a[i][j];
		}
	}
}
void bdj(int i){
	int k=0;
	for(int j=0;j<1700;j++){
		if(s[j]+k<=a[i][j]){
			s[j]=a[i][j]-s[j]-k;
			k=0;
		}
		else {
			s[j]=a[i][j]+wei-s[j]-k;
			k=1;
	}
	}
}
bool chuf(long long x){
	for(int i=1700;i>0;--i){
		s[i-1]+=s[i]%x*wei;
		s[i]/=x;
	}
	if(!(s[0]%x)){
		s[0]/=x;
		return true;
	}
	else return false;
}
int pre(int i){
	for(int j=1700;j>=1;j--){
		if(s[j]>a[i][j])return 1;
		if(s[j]<a[i][j])return -1;	
	}
	return 0;
}
void jianfa(int i){
	if(ns!=na[i])jiaf(i);
	else{
		if(pre(i)==1)zdjf(i);
		else {
			bdj(i);
			ns=!ns;
		}
	}
}
void work(){
	for(long long x=1;x<=m;++x){
		for(int ijk=1700;ijk>=0;ijk--)s[ijk]=0;
		ns=1;
		int ok=1;
		for(int j=0;j<n;++j){
			jianfa(j);
			int booo=chuf(x);
			if(!booo){ok=0;break;}
		}
		if(ok&&pre(101)==0&&ns==0){vis[x]=1;cnt++;}
	}
}
void out(){
	fout<<cnt<<endl;
	for(long long i=1;i<=m;++i)if(vis[i])fout<<i<<endl;
}
int main(){
	a[101][0]=1;
	in();
	work();
	out();
	fin.close();
	fout.close();
	return 0;
}