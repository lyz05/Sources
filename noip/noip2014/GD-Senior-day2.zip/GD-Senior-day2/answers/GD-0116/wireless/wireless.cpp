#include<cstring>
#include<cstdio>
#include<algorithm>
using namespace std;
int n,D;
long long ans2 , ans;
int a[200][200];

int main()
{
	freopen("wireless.in" , "r" , stdin);
	freopen("wireless.out" , "w" , stdout);
	scanf("%d" , &D);
	scanf("%d" , &n);
	memset(a , 0 , sizeof a);
	for (int i = 1 ; i <= n ; i ++)
	{
		int x , y , k;
		scanf("%d%d%d" , &x , &y , &k);
		a[x][y] += k;
	}
	
	ans2 = 0 ; ans = 0;
	for (int x = 0 ; x <= 128 ; x ++)
		for (int y = 0 ; y <= 128 ; y ++)
		{
			long long st = 0;
			for (int i = x - D; i <= x + D; i ++)
			{
				if (i < 0 || i > 128) continue;
				for (int j = y - D; j <= y + D; j ++)
				{
					if (j < 0 || j > 128) continue;
					st += a[i][j];
				}
			}
			if (st > ans) ans2 = 1 , ans = st; else 
				{if (st == ans) ans2 ++;}
		}
	printf("%lld %lld" , ans2 , ans);
	return 0;
}
