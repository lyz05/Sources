#include<cstring>
#include<cstdio>
#include<algorithm>
using namespace std;

int n,m,tt,ret;
bool bz[1001000],op[200];

struct Node
{
	int num[10010];
}a[200],b[200];
char s1[11000];

void Get(int x)
{
	scanf("%s" , s1);
	if (s1[0] == '-') op[x] = 1 ; else op[x] = 0;
	int len = strlen(s1) , pos , jishu = len;
	if (op[x]) a[x].num[0] = len - 1 ; else a[x].num[0] = len;
	if (op[x]) pos = 1 , jishu --; else pos = 0;
	for (pos ; pos < len ; pos ++)
	{
		a[x].num[jishu] = (int)s1[pos] - (int)'0';
		jishu --;
	}
}

void Mu(Node &a , int x)
{
	for (int i = a.num[0] ; i ; i --)
	{
		int t = a.num[i] % x;
		if (i == 1 && t != 0) ret = 0;
		a.num[i] /= x;
		if (i != 1) a.num[i] += t;
	}
}

int max(int x , int y)
{
	if (x > y) return x ;return y;
}

void Add(Node &a , Node &b)
{
	int t = max(a.num[0] , b.num[0]);
	for (int i = 1 ; i <= t ; i ++) a.num[i] += b.num[i];
	for (int i = 1 ; i <= t ; i ++) a.num[i + 1] += (a.num[i]/10) , a.num[i] %= 10;
	a.num[0] = t;
	if (a.num[t + 1] > 0) a.num[0] ++;
}

int De(Node &a , Node &b)
{
	if (a.num[0] != b.num[0]) return 0;
	for (int i = 0 ; i <= a.num[0] ; i ++)
		if (a.num[i] != b.num[i]) return 0;
	return 1;
}

int pd(int x)
{
	for (int i = 0 ; i <= n ; i ++)
	{
		b[i].num[0] = a[i].num[0];
		for (int j = 1 ; j <= b[i].num[0] ; j ++) b[i].num[j] = a[i].num[j];
	}
	for (int i = 0 ; i <= 11000 ; i ++) b[n + 1].num[i] = b[n + 2].num[i] = 0;
	Node st;
	st.num[0] = 0;
	int now = x;
	while (now != 0)
	{
		st.num[0] ++;
		st.num[st.num[0]] = now % 10;
		now /= 10;
	}
	for (int i = 0 ; i < n ; i ++)
	{
		for (int j = i ; j <= n - i - 1 ; j ++)
		{
			ret = 1;
			Mu(b[j],x);
			if (ret = 0) return 2;
		}
	}
	for (int i = 0 ; i <= n ; i ++)
	{
		if (op[i]) Add(b[n + 1] , b[i]); else Add(b[n + 2] , b[i]);
	}
	if (De(b[n + 1] , b[n + 2])) return 1 ; else return 0;
}

int main()
{
	freopen("equation.in" , "r" , stdin);
	freopen("equation.out" , "w" , stdout);
	scanf("%d%d" , &n , &m);
	if (n <= 2)
	{
		int x[3];
		for (int i = 0 ; i <= n ; i ++ ) scanf("%d" , &x[i]);
		tt = 0;
		memset(bz , 0 , sizeof bz);
		for (int i = 1 ; i <= m ; i ++)
		{
			long long k = 1 , st = 0;
			for (int j = 0 ; j <= n ; j ++)
			{
				st += k * x[j];
				k *= i;
			}
			if (st == 0) bz[i] = 1 , tt ++; else bz[i] = 0;
		}
		printf("%d\n" , tt);
		for (int i = 1 ; i <= m ; i ++)
			if (bz[i]) printf("%d\n" , i);
	} else
	{
		memset(bz, 1 , sizeof bz);
		memset(op, 0 , sizeof op);
		for (int i = 0 ; i <= n ; i ++)
		{
			Get(i);
		}
		for (int i = 1 ; i <= m ; i ++)
		{
			if (bz[i])
			{
				int flag = pd(i);
				if (flag == 1) { tt ++ ; continue;}
				if (flag == 0) {bz[i] = 0 ; continue;}
				for (int j = 1 ; j <= m / i ; j ++)
				{
					bz[j * i] = 0;
				}
			}
		}
		
		printf("%d\n" , tt);
		for (int i = 1 ; i <= m ; i ++)
			if (bz[i]) printf("%d\n" , i);
		
	}
	return 0;
}
