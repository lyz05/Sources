#include<cstring>
#include<cstdio>
#include<algorithm>
using namespace std;
const int maxn = 30000;
const int maxm = 201000;

int head[maxn],last[maxn],chu[maxn],sum[maxn],f[maxn],dis[maxn];
int g[maxm],next[maxm];
int n,m,t,tt,S,T,ans,tot;
bool bz[maxn];

struct Node
{
	int s,t;
}a[maxm];

bool cmp(Node x , Node y)
{
	if (x.s < y.s || (x.s == y.s && x.t <= y.t)) return 0;
	return 1;
}

void Clear()
{
	memset(head , 255 , sizeof head);
	memset(next , 255 , sizeof next);
	memset(last , 0 , sizeof last);
	memset(g , 0 ,  sizeof g);
	memset(chu , 0 , sizeof chu);
	tot = 0;
}

void ince(int x , int y)
{
	g[++ tot] = y , chu[x] ++;
	if (head[x] == -1) head[x] = tot;
	next[last[x]] = tot , last[x] = tot;
}

void spfa()
{
	int x = 0 , y = 0 ;
	for (int i = 1 ; i <= m ; i ++)
	{
		if (a[i].s == a[i].t) continue;
		if (x == a[i].s && y == a[i].t) continue;
		x = a[i].s , y = a[i].t;
		ince(y , x);
	}
	
	int l = 0 , r = 1;
	memset(bz,0,sizeof bz);
	bz[T] = 1 , f[1] = T;
	while (l < r)
	{
		int now = f[++l];
		for (int y = head[now] ; y != -1 ; y = next[y])
		{
			if (!bz[g[y]])
			{
				bz[g[y]] = 1;
				f[++r] = g[y];
			}
		}
	}
}

void pre()
{
	int x = 0 , y = 0 ;
	for (int i = 1 ; i <= m ; i ++)
	{
		if (a[i].s == a[i].t) continue;
		if (x == a[i].s && y == a[i].t) continue;
		x = a[i].s , y = a[i].t;
		ince(x , y);
	}
	
	memset(sum , 0 , sizeof sum);
	for (int i = 1 ; i <= n ; i ++)
	{
		for (int y = head[i] ; y != -1 ; y = next[y])
		{
			if (bz[g[y]]) sum[i] ++;
		}
	}
}

void work()
{
	int l = 0 , r = 1;
	memset(dis , 255 , sizeof dis);
	memset(bz , 0 , sizeof bz);
	dis[S] = 0 , ans = -1;
	if (chu[S] != sum[S]) return;
	f[1] = S , bz[S] = 1;
	while (l < r)
	{
		int now = f[++l];
		if (now == T)
		{
			ans = dis[now];
			break;
		}
		for (int y = head[now] ; y != -1 ; y = next[y])
		{
			if (chu[g[y]] != sum[g[y]]) continue;
			if (!bz[g[y]])
			{
				if (dis[g[y]] == -1) dis[g[y]] = dis[now] + 1;
				bz[g[y]] = 1;
				f[++r] = g[y];
			}
		}
	}
}

int main()
{
	freopen("road.in" , "r" , stdin);
	freopen("road.out" , "w" , stdout);
	
	scanf("%d%d" , &n , &m);
	t = n , tt = m;
	memset(a,0,sizeof a);
	for (int i = 1 ; i <= m ; i ++) scanf("%d%d" , &a[i].s , &a[i].t);
	scanf("%d%d" , &S, &T);
	
	sort(a + 1 , a + 1 + tt , cmp);

	Clear();
	spfa();
	Clear();
	pre();
	work();
	printf("%d" , ans);
	
	return 0;
}
