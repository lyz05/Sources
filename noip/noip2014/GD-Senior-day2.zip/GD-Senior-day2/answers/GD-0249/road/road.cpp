#include <fstream>
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <map>
#include <stack>
#include <queue>
#include <deque>

using namespace std;

typedef long long LL;
typedef double dbl;

template<class Tp>
inline void upMin(const Tp &t,Tp &T) {
	if ( t < T ) T = t;
}

template<class Tp>
inline void upMax(const Tp &t,Tp &T) {
	if ( t > T ) T = t;
}

void setIO(string St) {
	freopen((St + ".in").c_str(),"r",stdin);
	freopen((St + ".out").c_str(),"w",stdout);
}

struct TypeE{
	static const int MaxV = 10008,MaxE = 200008;
	int e,s[MaxE],ne[MaxE],nd[MaxV];
	void Cls() {
		e = 0;
		memset(nd,0,sizeof(nd));
	}
	void Ins(int x,int y) {
		s[++e] = y;
		ne[e] = nd[x];
		nd[x] = e;
	}
} teS,teT;

const int MaxN = 10008;
const int oo = 100000000;

int N,M,YES1[MaxN],vS,vT,Dis[MaxN],Go[MaxN];
queue<int> Que;

void GetGo() {
	Que.push(vT);
	YES1[vT] = 1;
	while ( !Que.empty() ) {
		int U = Que.front(); Que.pop();
		for (int i = teT.nd[U]; i; i = teT.ne[i]) {
			int V = teT.s[i];
			if ( !YES1[V] ) {
				YES1[V] = 1;
				Que.push(V);
			}
		}
	}
	/*
	for (int i = 1; i <= N; i++)
		cout << YES[i] << " ";
	cout <<endl;*/
}

void BFS() {
	
	for (int k = 1; k <= N; k++)
		if ( YES1[k] ) {
			Go[k] = 1;
			for (int i = teS.nd[k]; i; i = teS.ne[i]) {
				int V = teS.s[i];
				if ( !YES1[V] ) {
					Go[k] = 0;
					break;
				}
			}
		}
	
	if ( YES1[vS] != 1 || !Go[vS] ) {
		puts("-1");
		return;
	}
	
	for (int i = 1; i <= N; i++)
		Dis[i] = oo;
	Dis[vS] = 0;
	Que.push(vS);
	while ( !Que.empty() ) {
		int U = Que.front(); Que.pop();
		for (int i = teS.nd[U]; i; i = teS.ne[i]) {
			int V = teS.s[i];
			if ( Dis[V] == oo && Go[V] == 1 ) {
				Dis[V] = Dis[U] + 1;
				Que.push(V);
			}
		}
	}
	cout << Dis[vT] <<endl;
}

int main() {
	setIO("road");
	teS.Cls() , teT.Cls();
	scanf("%d%d",&N,&M);
	cerr << N << M;
	for (int i = 1; i <= M; i++) {
		int x,y;
		scanf("%d%d",&x,&y);
		if ( x == y ) continue;
		teS.Ins(x,y);
		teT.Ins(y,x);
	}
	scanf("%d%d",&vS,&vT);
	GetGo();
	BFS();
	return 0;
}
