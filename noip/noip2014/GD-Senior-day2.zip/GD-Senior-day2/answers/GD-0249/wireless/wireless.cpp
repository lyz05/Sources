#include <fstream>
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <map>
#include <stack>
#include <queue>
#include <deque>

using namespace std;

typedef long long LL;
typedef double dbl;

template<class Tp>
inline void upMin(const Tp &t,Tp &T) {
	if ( t < T ) T = t;
}

template<class Tp>
inline void upMax(const Tp &t,Tp &T) {
	if ( t > T ) T = t;
}

template<class Tp>
inline Tp Abs(const Tp &t) {
	return (t > 0) ? t : -t;
}	

void setIO(string St) {
	freopen((St + ".in").c_str(),"r",stdin);
	freopen((St + ".out").c_str(),"w",stdout);
}

int d,n,X[25],Y[25],K[25],Ans = 0,Ans1 = 0;

int main() {
	setIO("wireless");
	cin >> d >> n;
	for (int i = 0; i != n; i++)
		cin >> X[i] >> Y[i] >> K[i];
	for (int x = 0; x <= 128; x++)	
		for (int y = 0; y <= 128; y++) {
			int Sum = 0;
			for (int i = 0; i != n; i++) {
				if ( Abs(x - X[i]) <= d && Abs(y - Y[i]) <= d )
					Sum += K[i];
			}
			if ( Sum == Ans ) Ans1++;
			if ( Sum > Ans ) {
				Ans = Sum;
				Ans1 = 1;
			}
		}
	cout << Ans1 << " " << Ans <<endl;
	return 0;
}
