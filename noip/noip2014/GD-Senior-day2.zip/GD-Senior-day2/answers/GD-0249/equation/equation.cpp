#include <fstream>
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <map>
#include <stack>
#include <queue>
#include <deque>

using namespace std;

typedef long long LL;
typedef double dbl;

template<class Tp>
inline void upMin(const Tp &t,Tp &T) {
	if ( t < T ) T = t;
}

template<class Tp>
inline void upMax(const Tp &t,Tp &T) {
	if ( t > T ) T = t;
}

void setIO(string St) {
	freopen((St + ".in").c_str(),"r",stdin);
	freopen((St + ".out").c_str(),"w",stdout);
}

struct BigNum{
	int c,p[10008];
	
	void Cls() {
		memset(p,0,sizeof(p));
		c = 1; p[0] = 1;
	}
	
	void Read() {
		int t = getchar();
		if ( t == '-' ) c = -1 , t = getchar();
			else c = 1;
		p[0] = 0;
		for (; '0' <= t && t <= '9'; t = getchar())
			p[++p[0]] = t - '0';
		int hf = p[0] >> 1;
		for (int i = 1; i <= hf; i++)
			swap(p[i],p[p[0] - i + 1]);
	}
	
	friend LL operator% (const BigNum &a,const LL b) {
		LL t = 0;
		for (int i = a.p[0]; i; i--)
			t = (t * 10LL + (LL)a.p[i]) % b;
		return t;
	}
	
	void Print() {
		if ( c == -1 && !(p[0] == 1 && p[1] == 0) )
			putchar('-');
		for (int i = p[0]; i; i--)
			putchar(p[i] + '0');
		putchar('\n');
	}
} a[108];

const int MaxN = 5;
const LL Prime[5] = {9819611,6277501,3485921,2597059,8888851};

LL P[108][MaxN];
vector<int> Ans;
int N,M;
bool Throw[1000008];

int main() {
	setIO("equation");
	scanf("%d %d\n",&N,&M);
	for (int i = 0; i <= N; i++) {
		a[i].Cls();
		a[i].Read();
		//a[i].Print();
		for (int j = 0; j != MaxN; j++) {
			P[i][j] = a[i] % Prime[j];
			if ( a[i].c == -1 )
				P[i][j] = Prime[j] - P[i][j];
			//cout << P[i][j] << " ";
		}
		//cout <<endl;
	}
	
	int M1 = min(M,100000);
	
	for (int i = 1; i <= M; i++) {
			bool YES = 1;
			for (int j = 0; j != MaxN; j++) {
				LL Sum = P[0][j] , t = (LL)i % Prime[j];
				for (int k = 1; k <= N; k++) {
					Sum = (Sum + P[k][j] * t) % Prime[j];
					t = t * (LL)i % Prime[j];
				}
				if ( Sum != 0 ) {
					YES = 0;
					break;
				}
			}
			if ( YES ) Ans.push_back(i);
		}
		
	int n = Ans.size();
	printf("%d\n",n);
	for (int i = 0; i != n; i++)
		printf("%d\n",Ans[i]);
		
	return 0;
}
