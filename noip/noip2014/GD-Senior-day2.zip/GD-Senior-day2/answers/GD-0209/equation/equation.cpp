#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
using namespace std;
struct node
{
	int ll[101];
	int len;
	node()
	{
		memset(ll,0,sizeof(ll));
		len=0;
	}
	bool fh;
};
int n,m;
char a[101][101];
int lans;
int ans[10001];

int qmax(int x,int y){return x>y?x:y;}

node mult(node n1,node n2)
{
	node tno;
	tno.len=n1.len+n2.len-1;
	
	int i,j;
	for (i=1;i<=n1.len;i++)
	{
		for (j=1;j<=n2.len;j++)
		{
			tno.ll[i+j-1]=n1.ll[i]*n2.ll[j];
		}
	}
	for (i=1;i<=tno.len;i++)
	{
		tno.ll[i+1]+=tno.ll[i]/10;
		tno.ll[i]%=10;
	}
	i=tno.len;
	while (tno.ll[i]>=10)
	{
		tno.ll[i+1]=tno.ll[i]/10;
		tno.ll[i]%=10;
		i++;
	}
	tno.len=i;
	
	while (tno.ll[i]==0 && i>=1)i--;
	tno.len=i;
	
	if (tno.len==0){tno.ll[1]=0;tno.len=1;}
	return tno;
}

node pplus(node n1,node n2)
{
	node tno;
	tno.len=qmax(n1.len,n2.len);
	
	int i,j;
	for (i=1;i<=tno.len;i++)
	{
		tno.ll[i]=n1.ll[i]+n2.ll[i];
	}
	for (i=1;i<=tno.len;i++)
	{
		tno.ll[i+1]+=tno.ll[i]/10;
		tno.ll[i]%=10;
	}
	i=tno.len;
	while (tno.ll[i]>=10)
	{
		tno.ll[i+1]=tno.ll[i]/10;
		tno.ll[i]%=10;
		i++;
	}
	tno.len=i;
	
	while (tno.ll[i]==0 && i>=1)i--;
	tno.len=i;
	
	if (tno.len==0){tno.ll[1]=0;tno.len=1;}
	return tno;
}

node del(node n1,node n2)
{
	node tno;
	tno.len=qmax(n1.len,n2.len);
	
	int i,j;
	for (i=1;i<=tno.len;i++)
	{
		tno.ll[i]=n1.ll[i]-n2.ll[i];
	}
	for (i=1;i<=tno.len;i++)
	{
		tno.ll[i+1]+=tno.ll[i]/10;
		tno.ll[i]%=10;
	}
	i=tno.len;
	while (tno.ll[i]>=10)
	{
		tno.ll[i+1]=tno.ll[i]/10;
		tno.ll[i]%=10;
		i++;
	}
	tno.len=i;
	
	while (tno.ll[i]==0 && i>=1)i--;
	tno.len=i;
	
	if (tno.len==0){tno.ll[1]=0;tno.len=1;}
	return tno;
}

int qcf(int x,int y)
{
	int i,sum=1;
	for (i=1;i<=y;i++)
	sum*=x;
	return sum;
}

node llcf(int x,int y)
{
	int i,j,sum=1;
	char sx[101];
	
	node tnosum;
	node nx;
	
	if (x<10)
	{
		nx.len=1;
		nx.ll[1]=x;
	}
	else if (x<100)
	{
		nx.len=2;
		nx.ll[1]=x%10;
		nx.ll[2]=x/10;
	}
	else if (x<1000)
	{
		nx.len=3;
		nx.ll[1]=x%10;
		nx.ll[2]=x/10%10;
		nx.ll[3]=x/100;
	}
	
	for (i=1;i<=y;i++)
	tnosum=mult(tnosum,nx);
	
	return tnosum;
}

node chan(char ss[101],int len)
{
	node tno;
	int j;
	if (ss[0]!='-')
	{
			tno.fh=1;
			for (j=0;j<len;j++)
			tno.ll[j+1]=ss[len-j-1];
			tno.len=len;
	}
	else
	{
			tno.fh=0;
			for (j=1;j<len;j++)
			tno.ll[j+1]=ss[len-j-1];
			tno.len=len-1;
	}
	return tno;
}

int main()
{
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	int i,j;
	scanf("%d%d",&n,&m);
	for (i=0;i<=n;i++)
	{
		scanf("%s",a[i]);
	}
	lans=0;
	if (n<=2)
	{
		int cc[3];
		for (i=0;i<=3;i++)cc[i]=atoi(a[i]);
		
		for (i=1;i<=m;i++)
		{
			int sum=cc[0];
			for (j=1;j<=n;j++)
			{
				sum=sum+cc[j]*qcf(i,j);
			}
			if (sum==0)
			{
				lans++;
				ans[lans]=i;
			}
		}
		printf("%d\n",lans);
		for (i=1;i<=lans;i++)
		printf("%d\n",ans[i]);
	}
	
	else if (n<=50)
	{
		for (i=1;i<=m;i++)
		{
			node sum2;
			int lla=strlen(a[0]);
			
			if (a[0][0]!='-')
			{
				sum2.fh=1;
				for (j=0;j<lla;j++)
				sum2.ll[j+1]=a[0][lla-j-1];
				sum2.len=lla;
			}
			else
			{
				sum2.fh=0;
				for (j=1;j<lla;j++)
				sum2.ll[j+1]=a[0][lla-j-1];
				sum2.len=lla-1;
			}
			
			for (j=1;j<=n;j++)
			{
				sum2=pplus( sum2 , mult( chan(a[j],strlen(a[j])) , llcf(i,j) ) );
			}
			if (sum2.ll[1]==0 && sum2.len==1)
			{
				lans++;
				ans[lans]=i;
			}
		}
		printf("%d\n",lans);
		for (i=1;i<=lans;i++)
		printf("%d\n",ans[i]);
	}
	else printf("0\n");
	return 0;
}
