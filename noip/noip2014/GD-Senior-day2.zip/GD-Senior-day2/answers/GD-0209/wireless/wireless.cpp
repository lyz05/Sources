#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
using namespace std;
const int maxn=21;
const int bl=129;

int d,n;
int lmap[bl][bl];
//int sum[bl][bl];
int ans=0;
int maxsum,plu;

int qmax(int x,int y){return x>y?x:y;}

void findit(int x,int y)
{
	int i,j;
	int stx,sty;
	int edx,edy;
	
	if (x-d<0)stx=0;else stx=x-d;
	if (y-d<0)sty=0;else sty=y-d;
	if (x+d>128)edx=128;else edx=x+d;
	if (y+d>128)edy=128;else edy=y+d;
	
	int sum=0;
	for (i=stx;i<=edx;i++)
	{
		for (j=sty;j<=edy;j++)
		{
			sum+=lmap[i][j];
		}
	}
	if (sum>maxsum)
	{
		maxsum=sum;
		plu=1;
	}
	else if (sum==maxsum)plu++;
}

int main()
{
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	int i,j;
	int x,y,k;
	scanf("%d",&d);
	scanf("%d",&n);
	maxsum=0;plu=0;
	memset(lmap,0,sizeof(lmap));
	for (i=1;i<=n;i++)
	{
		scanf("%d%d%d",&x,&y,&k);
		lmap[x][y] = k;
	}
	for (i=0;i<bl;i++)
	{
		for (j=0;j<bl;j++)
		{
			findit(i,j);
		}
	}
	printf("%d %d\n",plu,maxsum);
	return 0;
}
