#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
using namespace std;
const int maxm=200001;
const int maxn=10001;
struct node
{
	int x,y,next;
}a[maxm];
int first[maxn],len;

int n,m;
int st,ed;
bool v[maxn],de[maxn];
int d[maxn];

int qmin(int x,int y){return x>y?y:x;}

void ins(int x,int y)
{
	len++;
	a[len].x=x;
	a[len].y=y;
	a[len].next=first[x];
	first[x]=len;
}

bool solve(int x,int fa)
{
	int k,minn=maxn,p=0;
	int y;
	bool ok=0;
	if (x==ed){v[ed]=1;d[x]=0;return 1;}
	for (k=first[x];k;k=a[k].next)
	{
		y=a[k].y;
		if (!de[y])
		{
			de[y]=1;
			bool c=solve(y,x);
			de[y]=0;
			if (c==1)
			{ 
				v[y] = 1; 
				if (d[y]+1<minn)
				{
					p=y;
					minn=d[y]+1;
				}
				ok=1; 
			}
		
			else return 0;
		}
		
	}
	if (ok)
	{
		 d[x]=qmin(d[x],d[p]+1);
		 return 1;
	}
	return 0;
}

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int i;
	int x,y;
	scanf("%d%d",&n,&m);
	memset(first,0,sizeof(first));len=0;
	memset(v,0,sizeof(v));
	memset(de,0,sizeof(de));
	memset(d,63,sizeof(d));
	for (i=1;i<=m;i++)
	{
		scanf("%d%d",&x,&y);
		ins(x,y);
	}
	scanf("%d%d",&st,&ed);
	bool ok=0;
	for (i=first[st];i;i=a[i].next)
	{
		de[a[i].y]=1;
		if (solve(a[i].y,st))
		{
			d[st]=qmin(d[st],d[a[i].y]+1);
			ok=1;
		}
		de[a[i].y]=0;
	}
	
	if (!ok){printf("-1\n");return 0;}
	else printf("%d\n",d[st]);
	return 0;
}
