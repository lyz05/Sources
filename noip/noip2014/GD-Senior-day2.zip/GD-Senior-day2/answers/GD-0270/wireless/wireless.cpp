/*


Created by WHJ


#include <RP>
int main(){
	RP rp;
	while (1) rp.get_RP_from_SHENBEN();
	return 0;
}
*/
#include <cstdio>
#include <iostream>
#define ele long long
using namespace std;
#define maxn 138
#define lim 128
ele d,n,a[maxn][maxn];
inline void init(){
	ele x,y,k;
	cin>>d>>n;
	for (ele i=0; i<maxn; ++i)
		for (ele j=0; j<maxn; ++j) a[i][j]=0;
	for (ele i=0; i<n; ++i){
		cin>>x>>y>>k;
		a[x][y]+=k;
	}
}
inline void solve(){
	ele _max=-1,way=0,x1,y1,x2,y2,sum;
	for (ele i=0; i<=lim; ++i)
		for (ele j=0; j<=lim; ++j){
			x1=i-d; y1=j-d;
			x2=i+d; y2=j+d;
			if (x1<0) x1=0;
			if (y1<0) y1=0;
			if (x2>lim) x2=lim;
			if (y2>lim) y2=lim;
			sum=0;
			for (ele p=x1; p<=x2; ++p)
				for (ele q=y1; q<=y2; ++q) sum+=a[p][q];
			if (sum>_max){ _max=sum,way=1; } else
				if (sum==_max) ++way;
		}
	cout<<way<<' '<<_max<<endl;
}
int main(){
	freopen("wireless.in","r",stdin); freopen("wireless.out","w",stdout);
	init();
	solve();
	return 0;
}

