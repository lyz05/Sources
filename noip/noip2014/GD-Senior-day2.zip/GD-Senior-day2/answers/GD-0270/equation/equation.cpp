/*
Created by WHJ
sro sro sro LRJ orz orz orz
sro sro sro CJL orz orz orz
sro sro sro ZKW orz orz orz
sro sro sro CQF orz orz orz
sro sro sro DWJ orz orz orz
while (1) ++rp,--bug;
*/
#include <cstdio>
#define ele int
using namespace std;
#define maxn 200
#define maxm 1000010
ele n,m,a[maxn],ans[maxm];
bool k;
inline bool init(){
	scanf("%d%d",&n,&m);
	if (n>2 || m>100) return false;
	for (ele i=0; i<=n; ++i) scanf("%d",a+i);
	return true;
}
inline void solve(){
	ele cnt=0,sum=0,xn=1;
	if (!k){
		printf("0\n");
		return;
	}
	for (ele i=1; i<=m; ++i){
		for (ele j=0; j<=n; ++j){
			sum+=xn*a[j];
			xn*=i;
		}
		if (sum==0) ans[cnt++]=i;
	}
	printf("%d\n",cnt);
	for (ele i=0; i<cnt; ++i) printf("%d\n",ans[i]);
}
int main(){
	freopen("equation.in","r",stdin); freopen("equation.out","w",stdout);
	k=init();
	solve();
	return 0;
}

