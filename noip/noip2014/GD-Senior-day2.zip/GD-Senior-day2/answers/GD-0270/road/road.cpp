/*
Created by WHJ
sro sro sro CCF orz orz orz
sro sro sro GSS orz orz orz
sro sro sro HWD orz orz orz
*/
#include <cstdio>
#include <queue>
#include <vector>
#define ele int
using namespace std;
#define maxn 10010
#define imp 100000000
#define ls vector<ele>
typedef ls graph[maxn];
ele n,m,s,t,dis[maxn];
bool con[maxn],save[maxn],vis[maxn];
graph g,g2;
queue<ele> q;
inline void init(){
	ele x,y,k,len;
	scanf("%d%d",&n,&m);
	for (ele i=0; i<m; ++i){
		scanf("%d%d",&x,&y);
		--x,--y;
		g[x].push_back(y);
		g2[y].push_back(x);
	}
	for (ele i=0; i<n; ++i) con[i]=false;
	scanf("%d%d",&s,&t);
	--s,--t;
	con[t]=true;
	q.push(t);
	while (!q.empty()){
		k=q.front(); q.pop();
		len=g2[k].size();
		for (ele i=0; i<len; ++i)
			if (!con[g2[k][i]]){
				con[g2[k][i]]=true;
				q.push(g2[k][i]);
			}
	}
	save[t]=true;
	for (ele i=0; i<n; ++i){
		save[i]=true;
		if (!con[i]) save[i]=false;
		len=g[i].size();
		for (ele j=0; j<len; ++j)
			if (!con[g[i][j]]){ save[i]=false; break; }
	}
}
inline ele solve(){
	ele len,k;
	if (!save[s]) return -1;
	for (ele i=0; i<n; ++i) dis[i]=imp,vis[i]=false;
	vis[s]=true; dis[s]=0;
	/*len=g[s].size();
	for (ele i=0; i<len; ++i) dis[g[s][i]]=1;*/
	q.push(s);
	while (!q.empty()){
		k=q.front(); q.pop();
		len=g[k].size();
		for (ele i=0; i<len; ++i)
			if (save[g[k][i]] && dis[g[k][i]]>dis[k]+1){
				dis[g[k][i]]=dis[k]+1;
				q.push(g[k][i]);
			}
	}
	if (dis[t]==imp) return -1;
	return dis[t];
}
int main(){
	freopen("road.in","r",stdin); freopen("road.out","w",stdout);
	init();
	printf("%d\n",solve());
	return 0;
}

