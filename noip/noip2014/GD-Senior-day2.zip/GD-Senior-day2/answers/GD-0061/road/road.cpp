#include<fstream>
#include<deque>
using namespace std;
ifstream cin("road.in");
ofstream cout("road.out");
struct
{
	int x,y;
} q[200005];
deque<int> d;
int n,m,xx[10005],yy[10005],s,t;
int le,ri,b[20005],di[10005];
bool f[20005],ch[20005];

void sort(int l,int r)
{
	int i,j,x,y;
	i=l; j=r; x=q[(i+j)/2].x;
	do
	{
		while (q[i].x<x) i++;
		while (x<q[j].x) j--;
		if (i<=j)
		{
			y=q[i].x; q[i].x=q[j].x; q[j].x=y;
			y=q[i].y; q[i].y=q[j].y; q[j].y=y;
			i++; j--;
		}
	} while (i<=j);
	if (l<j) sort(l,j);
	if (i<r) sort(i,r);
	return ;
}

void clb()
{
	int a;
	xx[q[1].x]=1;
	for (a=2;a<=m;a++)
		if (q[a].x!=q[a-1].x)
		{
			yy[q[a-1].x]=a-1;
			xx[q[a].x]=a;
		}
	yy[q[m].x]=m;
	return ;
}

void init()
{
	int a;
	cin>>n>>m;
	for (a=1;a<=m;a++)
	{
		cin>>q[a].y>>q[a].x;
	}
	cin>>s>>t;
	sort(1,m); clb();
	return ;
}

void bfs()
{
	int a;
	b[1]=t; f[t]=true; le=ri=1;
	while (le<=ri)
	{
		for (a=xx[b[le]];a<=yy[b[le]];a++)
			if (!f[q[a].y])
			{
				f[q[a].y]=true;
				ri++; b[ri]=q[a].y;
			}
		le++;
	}
	return ;
}

void spfa()
{
	int a,i,j;
	for (a=1;a<=n;a++) f[a]=0;
	f[s]=true; d.push_front(s);
	for (a=1;a<=n;a++) di[a]=100000000; di[s]=0;
	while (!d.empty())
	{
		i=d.front(); d.pop_front();
		for (a=xx[i];a<=yy[i];a++)
		{
			j=q[a].y;
			if (ch[j] && di[i]+1<di[j])
			{
				if (!f[j]) f[j]=true; d.push_back(j);
				di[j]=di[i]+1;
			}
		}
		f[i]=false;
	}
	return ;
}

void doit()
{
	int a,i;
	bfs();
	for (a=1;a<=n;a++) ch[a]=true;
	for (a=1;a<=n;a++)
		if (!f[a])
		{
			ch[a]=false;
			for (i=xx[a];i<=yy[a];i++)
				ch[q[i].y]=false;
		}
	if (!ch[s]) { cout<<-1; return ; }
	for (a=1;a<=n;a++) xx[a]=yy[a]=0;
	for (a=1;a<=m;a++) { i=q[a].x; q[a].x=q[a].y; q[a].y=i; }
	sort(1,m); clb();
	spfa();
	if (di[t]==100000000) cout<<-1; else cout<<di[t];
	return ;
}

int main()
{
	ios::sync_with_stdio(false);
	init();
	doit();
	cin.close(); cout.close();
	return 0;
}