#include<fstream>
#include<cmath>
#include<cstring>
using namespace std;
ifstream cin("equation.in");
ofstream cout("equation.out");
char st[11005];
int n,m,q[105][11005],wei[105];
int ans[11005],ansi,gc[11005],num[11005],sum[1000005];

void init()
{
	int a,i,le;
	cin>>n>>m;
	for (a=0;a<=n;a++)
	{
		cin>>st; le=strlen(st);
		if (st[0]!='-')
		{
			for (i=le-1;i>=0;i--) q[a][le-i]=st[i]-48;
			q[a][0]=1; wei[a]=le;
		} else
		{
			for (i=le-1;i>=1;i--) q[a][le-i]=st[i]-48;
			q[a][0]=-1; wei[a]=le-1;
		}
	}
	return ;
}

void djc(int x)
{
	int i,j;
	j=0;
	for (i=1;i<=num[0];i++)
	{
		num[i]=num[i]*x+j;
		j=num[i]/10; num[i]=num[i]%10;
	}
	while (j!=0) { num[0]++; num[num[0]]=j%10; j=j/10; }
	return ;
}

void gjc(int x)
{
	int i,j,k;
	for (i=1;i<=num[0];i++)
	for (j=1;j<=wei[x];j++)
	{
		k=i+j-1;
		gc[k]=gc[k]+num[i]*q[x][j];
		gc[k+1]+=gc[k]/10;
		gc[k]=gc[k]%10;
	}
	k=num[0]+wei[x];
	while (gc[k]>9) { k++; gc[k]=gc[k-1]/10; gc[k-1]=gc[k-1]%10; }
	if (gc[k]==0) gc[0]=k-1; else gc[0]=k;
	return ;
}

void jia()
{
	int a,k;
	if (ansi>gc[0]) k=ansi; else { k=gc[0]; ansi=k; }
	for (a=1;a<=k;a++)
	{
		ans[a]=ans[a]+gc[a];
		ans[a+1]+=ans[a]/10;
		ans[a]=ans[a]%10;
	}
	while (ans[ansi]>9) { ans[ansi+1]=ans[ansi]/10; ans[ansi]=ans[ansi]%10; ansi++; }
	return ;
}

void jian()
{
	bool ch;
	int a,k;
	ch=false;
	if (gc[0]>ansi) ch=true; else
	if (gc[0]==ansi)
	{
		a=gc[0];
		while (ans[a]==gc[a] && a>0) a--;
		if (gc[a]>ans[a]) ch=true;
	}
	if (ch)
	{
		ans[0]=-ans[0]; k=0;
		for (a=1;a<=gc[0];a++)
		{
			ans[a]=gc[a]-ans[a]+k;
			if (ans[a]<0) { ans[a]=ans[a]+10; k=-1; } else k=0;
		}
		a=gc[0]; while (ans[a]==0) a--; ansi=a;
	} else
	{
		for (a=1;a<=ansi;a++)
		{
			ans[a]=ans[a]-gc[a];
			if (ans[a]<0) { ans[a]=ans[a]+10; ans[a+1]=ans[a+1]-1; }
		}
		a=gc[0]; while (ans[a]==0) a--; ansi=a;
	}
	return ;
}

void doit()
{
	int a,i,j;
	for (a=1;a<=m;a++)
	{
		for (i=1;i<=11000;i++) num[i]=0; num[1]=1; num[0]=1;
		for (i=0;i<=wei[0];i++) ans[i]=q[0][i]; ansi=wei[0];
		for (i=1;i<=n;i++)
		{
			djc(a);
			for (j=0;j<=11000;j++) gc[j]=0;
			gjc(i);
			if (q[i][0]*ans[0]==1) jia(); else jian();
			if (ansi==0) ansi=1;
		}
		if (ansi==1 && ans[1]==0) { sum[0]++; sum[sum[0]]=a; }
	}
	cout<<sum[0]<<endl;
	for (a=1;a<=sum[0];a++) cout<<sum[a]<<endl;
	return ;
}

int main()
{
	ios::sync_with_stdio(false);
	init();
	doit();
	cin.close(); cout.close();
	return 0;
}
