#include<fstream>
using namespace std;
ifstream cin("wireless.in"); ofstream cout("wireless.out");
int n,m,f[135][135],w[135][135],num,ans[3];

void init()
{
	int a,i,j,k;
	cin>>n>>m;
	for (a=1;a<=m;a++) { cin>>i>>j>>k; f[i+1][j+1]=k; }
	for (i=1;i<=129;i++)
	{
		w[i][1]=f[i][1];
		for (j=2;j<=129;j++)
			w[i][j]=w[i][j-1]+f[i][j];
	}
	return ;
}

void doit()
{
	int i,j,k,shang,xia,zuo,you;
	for (i=1;i<=129;i++)
		for (j=1;j<=129;j++)
		{
			num=0;
			shang=i-n; if (shang<1) shang=1;
			xia=i+n; if (xia>129) xia=129;
			zuo=j-n-1; if (zuo<0) zuo=0;
			you=j+n; if (you>129) you=129;
			for (k=shang;k<=xia;k++)
				num+=w[k][you]-w[k][zuo];
			if (num>ans[1]) { ans[0]=1; ans[1]=num; }
			else if (num==ans[1]) { ans[0]++; }
		}
	return ;
}

int main()
{
	ios::sync_with_stdio(false);
	init();
	doit();
	cout<<ans[0]<<' '<<ans[1];
	cin.close(); cout.close();
	return 0;
}