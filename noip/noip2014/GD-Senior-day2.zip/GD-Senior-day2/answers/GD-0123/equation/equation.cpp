#include<cstdio>
using namespace std ;

int n , m , tot , get [ 1000 ] , a [ 1000 ] ;

void Init () {
	scanf ( "%d%d" , & n , & m ) ;
	for ( int i = 0 ; i <= n ; i ++ ) scanf ( "%d" , & a [ i ] ) ;
}

bool Check ( int x ) {
	int sum = a [ 0 ] ;
	for ( int i = 1 ; i <= n ; i ++ ) {
		sum += a [ i ] * x ;
		x *= x ;
	}
	if ( sum == 0 ) return true ; else return false ;
}

void Work () {
	for ( int ans = 1 ; ans <= m ; ans ++ ) 
		if ( Check ( ans ) ) get [ ++ tot ] = ans ;
	printf ( "%d\n" , tot ) ;
	for ( int i = 1 ; i <= tot ; i ++ ) printf ( "%d\n" , get [ i ] ) ;
}

int main () {
	freopen ( "equation.in" , "r" , stdin ) ;
	freopen ( "equation.out" , "w" , stdout ) ;
	Init () ;
	Work () ;
}
