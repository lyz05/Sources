#include<cstdio>
#include<iostream>
#include<cstring>
#define MO 2000000
#define maxn 200200
using namespace std ;

int n , m , s , t , num , lim , ans , tot ;
int dis [ maxn ] , y [ maxn ] , next [ maxn ] , g [ maxn ] , cost [ maxn ] ;
int list [ maxn * 10 ] ;
bool vis [ maxn ] , ban [ maxn ] ;

struct data {
	int x , y ;
} edge [ maxn ] ;

void Init () {
	scanf ( "%d%d" , & n , & m ) ;
	int u , v ;
	for ( int i = 1 ; i <= m ; i ++ ) {
		scanf ( "%d%d" , & u , & v ) ;
		if ( u == v ) continue ;
		edge [ ++ num ] . x = u ;
		edge [ num ] . y = v ;
	}
	scanf ( "%d%d" , & s , & t ) ;
}

void Ins ( int u , int v ) {
	y [ ++ tot ] = v ;
	next [ tot ] = g [ u ] ;
	g [ u ] = tot ;
	cost [ tot ] = 1 ;
}

void Spfa () {
	memset ( vis , false , sizeof ( vis ) ) ;
	memset ( dis , 60 , sizeof ( dis ) ) ;
	lim = dis [ 2 ] - 10 ;
	vis [ t ] = true ;
	int l = 1 , r = 1 , lq = 0 , rq = 0 , now , son ;
	list [ l ] = t ;
	dis [ t ] = 0 ;
	while ( lq * MO + l <= rq * MO + r ) {
		now = list [ l ++ ] ;
		if ( l > MO ) {
			lq ++ ;
			l = 1 ;
		}
		for ( int t = g [ now ] ; t != 0 ; t = next [ t ] ) {
			son = y [ t ] ;
			if ( ban [ son ] ) continue ;
			if ( dis [ now ] + cost [ t ] < dis [ son ] ) {
				dis [ son ] = dis [ now ] + cost [ t ] ;
				if ( ! vis  [ son ] ) {
					vis [ son ] = true ;
					r ++ ;
					if ( r > MO ) {
						rq ++ ;
						r = 1 ;
					}
					list [ r ] = son ;
				}
			}
		}
		vis [ now ] = false ;
	}
}

void Rebuild () {
	int u , v ;
	for ( int i = 1 ; i <= num ; i ++ ) {
		u = edge [ i ] . x ;
		v = edge [ i ] . y ;
		if ( dis [ v ] >= lim ) {
			ban [ u ] = true ;
			ban [ v ] = true ;
		}
	}
}

void Work () {
	for ( int i = 1 ; i <= num ; i ++ ) Ins ( edge [ i ] . y , edge [ i ] . x ) ;
	Spfa () ;
	Rebuild () ;
	Spfa () ;
	ans = dis [ s ] ;
	if ( ans >= lim ) cout << -1 ; else cout << ans ;
}

int main () {
	freopen ( "road.in" , "r" , stdin ) ;
	freopen ( "road.out" , "w" , stdout ) ;
	Init () ;
	Work () ;
}
