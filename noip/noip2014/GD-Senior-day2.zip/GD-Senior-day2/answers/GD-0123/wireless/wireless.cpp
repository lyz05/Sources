#include<cstdio>
#include<iostream>
#include<algorithm>
#define lim 129
#define maxn 150
using namespace std ;

typedef long long ll ;

ll ma , num , a [ maxn ] [ maxn ] , sum [ maxn ] [ maxn ] ;
int d , n ;

void Init () {
	scanf ( "%d" , & d ) ;
	scanf ( "%d" , & n ) ;
	int u , v , z ;
	for ( int i = 1 ; i <= n ; i ++ ) {
		scanf ( "%d%d%d" , & u , & v , & z ) ;
		u ++ ; 
		v ++ ;
		a [ u ] [ v ] = z ;
	}
}

void Pre () {
	for ( int i = 1 ; i <= lim ; i ++ ) 
	for ( int j = 1 ; j <= lim ; j ++ ) {
		sum [ i ] [ j ] += sum [ i - 1 ] [ j ] ;
		sum [ i ] [ j ] += sum [ i ] [ j - 1 ] ;
		sum [ i ] [ j ] -= sum [ i - 1 ] [ j - 1 ] ;
		sum [ i ] [ j ] += a [ i ] [ j ] ;
	}
}

void Deal ( int x , int y ) {
	int left_x = max ( 1 , x - d ) ;
	int left_y = max ( 1 , y - d ) ;
	int right_x = min ( lim , x + d ) ;
	int right_y = min ( lim , y + d ) ;
	ll q = sum [ right_x ] [ right_y ] ;
	q -= sum [ left_x - 1 ] [ right_y ] ;
	q -= sum [ right_x ] [ left_y - 1 ] ;
	q += sum [ left_x - 1 ] [ left_y - 1 ] ;
	if ( q == ma ) num ++ ;
	if ( q > ma ) {
		ma = q ;
		num = 1 ;
	}
}

void Work () {
	ma = 0 ;
	num = 0 ;
	for ( int i = 1 ; i <= lim ; i ++ ) 
	for ( int j = 1 ; j <= lim ; j ++ ) 
		Deal ( i , j ) ;
	cout << num << ' ' << ma ;
}

int main () {
	freopen ( "wireless.in" , "r" , stdin ) ;
	freopen ( "wireless.out" , "w" , stdout ) ;
	Init () ;
	Pre () ;
	Work () ;
}

