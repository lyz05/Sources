#include<cstdio>
#include<queue>
using namespace std ;

int main () {
	printf ("Goodbye Canton");
	priority_queue < int > node ;
	node.push ( 2 ) ;
	printf ( "%d" , node.top () ) ;
}
