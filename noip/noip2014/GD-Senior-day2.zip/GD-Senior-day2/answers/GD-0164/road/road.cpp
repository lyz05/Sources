#include<cstring>
#include<iostream>
#include<algorithm>
#include<cstdio>
#include<vector>

#define FOR(i,j,k) for(i=j;i<=k;++i)
#define FORD(i,j,k) for(i=j;i>=k;--i)
#define IOS ios_base::sync_with_stdio(0)
#define PB push_back

using namespace std;
typedef long long int LL;
const int N=10100;
const int sb=N*100;
int f[N];
vector<int> a[N];
bool LT[N],LJ[N],bj[N];

int n,m,s,t,ans=0x3fffffff,L,r;
int q[sb];

void dfs(int u)
{
    if(u==t)
    {
        LT[u]=1;
        LJ[u]=1;
        return;
    }
    vector<int>::iterator it;
    LT[u]=0;
    LJ[u]=1;
    for(it=a[u].begin();it!=a[u].end();++it)
    {
        if(!bj[(*it)])
        {
            bj[(*it)]=1;
            dfs((*it));
        }
        if(LT[(*it)])LT[u]=1;
        if(!LT[(*it)])LJ[u]=0;
    }
    if(LT[u]==0) LJ[u]=0;
    //bj[u]=0;
    return;
}

void SPFA()
{
    L=-1;r=0;
    f[s]=0;
    q[0]=s;
    bj[s]=1;
    vector<int>::iterator it;
    while(L<r)
    {
        L=(L+1)%sb;
        for(it=a[q[L]].begin();it!=a[q[L]].end();++it)
        if(LJ[(*it)])
        {
            if((f[(*it)]==-1)||(f[q[L]]+1<f[(*it)]))
            {
                f[(*it)]=f[q[L]]+1;
                bj[(*it)]=1;
                r=(r+1)%sb;
                q[r]=(*it);
            }
        }
        bj[q[L]]=0;
    }
    return;
}

int main()
{
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    IOS;
    cin >> n >> m;
    int i,x,y;
    FOR(i,1,m)
    {
        cin >> x >> y;
        if(x!=y)
        a[x].PB(y);
    }
    cin >> s >> t;
    memset(LT,0,sizeof(LT));
    memset(LJ,0,sizeof(LJ));
    memset(bj,0,sizeof(bj));
    memset(f,-1,sizeof(f));
    bj[s]=1;
    dfs(s);
    if(!LT[s])
    {
        cout << -1 << endl;
        return 0;
    }
    
    memset(bj,0,sizeof(bj));
    
    SPFA();
    cout << f[t] << endl;
    return 0;
}


