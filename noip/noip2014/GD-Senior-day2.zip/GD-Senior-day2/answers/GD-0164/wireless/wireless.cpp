#include<cstring>
#include<iostream>
#include<algorithm>
#include<cstdio>
#include<vector>

#define FOR(i,j,k) for(i=j;i<=k;++i)
#define FORD(i,j,k) for(i=j;i>=k;--i)
#define IOS ios_base::sync_with_stdio(0)

using namespace std;
typedef long long int LL;

LL a[150][150];
LL d,n,ans=0,anss=0;
LL s[150][150];

int main()
{
    freopen("wireless.in","r",stdin);
    freopen("wireless.out","w",stdout);
    IOS;
    cin >> d >> n;
    LL i,x,y;
    memset(a,0,sizeof(a));
    FOR(i,1,n)
    {
        cin >> x >> y;
        cin >> a[x][y];
    }
    LL j,k,ss,L,H1,H;
    
    FOR(i,0,128)
    {
        s[i][0]=a[i][0];
        FOR(j,1,128)s[i][j]=s[i][j-1]+a[i][j];
    }
    
    FOR(i,1,128)
    {
        FOR(j,1,128)
        {
            ss=0;
            if((i-d)>=0) L=i-d;
            else L=0;
            if((i+d)<=128) H=i+d;
            else H=128;
            if((j+d)<=128)H1=j+d;
            else H1=128;
            FOR(k,L,H)
            {
                if((j-1-d)<0)
                ss+=s[k][H1];
                else ss+=s[k][H1]-s[k][j-d-1];
            }
            if(ss==ans)
            {
                ++anss;
            }
            if(ss>ans)
            {
                ans=ss;
                anss=1;
            }
        }
    }
    cout << anss << " " << ans << endl;
    return 0;
}


