#include<cstring>
#include<iostream>
#include<algorithm>
#include<cstdio>
#include<vector>
#include<cmath>

#define FOR(i,j,k) for(i=j;i<=k;++i)
#define FORD(i,j,k) for(i=j;i>=k;--i)
#define IOS ios_base::sync_with_stdio(0)

using namespace std;
typedef long long int LL;
LL a[200],n,m;
LL ans[1000100];

LL mi(LL d,LL z)
{
    if(z==0) return 1;
    LL g=mi(d,z/2);
    if(z&1)
    {
        return g*g*d;
    }
    return g*g;
}

int main()
{
    freopen("equation.in","r",stdin);
    freopen("equation.out","w",stdout);
    IOS;
    cin >> n >> m ;
    LL i;
    FOR(i,0,n)
    {
        cin >> a[i];
    }
    LL t,j;
    FOR(i,1,m)
    {
        t=0;
        FOR(j,0,n)
        t+=a[j]*mi(i,j);
        if(t==0)
        {
            ++ans[0];
            ans[ans[0]]=i;
        }
    }
    cout << ans[0] << endl;
    FOR(i,1,ans[0]) cout << ans[i] << endl;
    return 0;
}


