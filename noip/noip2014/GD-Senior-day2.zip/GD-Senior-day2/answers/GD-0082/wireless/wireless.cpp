#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <algorithm>

using namespace std;

int N,D;
int X[205],Y[205],K[205];

int main()
{
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	scanf("%d",&D);
	scanf("%d",&N);
	for (int i=1; i<=N; i++) scanf("%d%d%d",&X[i],&Y[i],&K[i]);
	int Ans=0, Num=0;
	for (int i=0; i<129; i++)
		for (int j=0; j<129; j++)
		{
			int s=0;
			for (int k=1; k<=N; k++)
				if ((X[k]>=i-D) && (X[k]<=i+D) && (Y[k]>=j-D) && (Y[k]<=j+D))
					s+=K[k];
			if (s>Ans) 
			{
				Ans=s;
				Num=1;
			}
			else
				if (s==Ans) Num++;
		}
	cout << Num << ' ' << Ans << endl;
	return 0;
}

