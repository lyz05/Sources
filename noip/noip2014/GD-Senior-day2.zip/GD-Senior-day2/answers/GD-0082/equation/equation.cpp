#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <algorithm>

using namespace std;

const long long P[5]={14877491,17388601,34308887,42747589,42747841};

int N,M,Num;
int res[1000005],b[105];
int sum[405],s[405],ssum[405],t[405],t1[405],c[405];
int a[105][405];
char st[10005];
long long A[105][10];

int Mul(int k1,int k2)
{
	memset(sum,0,sizeof(sum));
	for (int i=1; i<=t1[0]; i++)
		for (int j=1; j<=t[0]; j++)
		{
			sum[i+j-1]+=t1[i]*t[j];
			sum[i+j]+=sum[i+j-1]/10;
			sum[i+j-1]%=10;
		}
	sum[0]=t1[0]+t[0];
	for (; (sum[0]>1) && (sum[sum[0]]==0); ) sum[0]--;
	return k1*k2;
}

void Plus()
{
	memset(ssum,0,sizeof(ssum));
	int len=sum[0];
	if (s[0]>len) len=s[0];
	for (int i=1; i<=len; i++)
	{
		ssum[i]+=sum[i]+s[i];
		ssum[i+1]+=ssum[i]/10;
		ssum[i]%=10;
	}
	ssum[0]=len;
	for (; ssum[ssum[0]+1]>0; ) ssum[0]++;
	memcpy(s,ssum,sizeof(s));
}

bool Bigger()
{
	if (sum[0]>s[0]) return true;
	if (sum[0]<s[0]) return false;
	for (int i=s[0]; i>=1; i--)
		if (sum[i]>s[i]) return true;
		else if (sum[i]<s[i]) return false;
	return true;
}

int Minu(int k1,int k2)
{
	if (!Bigger())
	{
		memcpy(ssum,sum,sizeof(ssum));
		memcpy(sum,s,sizeof(sum));
		memcpy(s,ssum,sizeof(s));
		swap(k1,k2);
	}
	memset(ssum,0,sizeof(ssum));
	for (int i=1; i<=sum[0]; i++)
	{
		ssum[i]+=sum[i]-s[i];
		if (ssum[i]<0) 
		{
			ssum[i+1]--;
			ssum[i]+=10;
		}
	}
	ssum[0]=sum[0];
	for (; (ssum[0]>1) && (ssum[ssum[0]]==0); ) ssum[0]--;
	memcpy(s,ssum,sizeof(s));
	return k1;
}

void Solve1()
{
	for (int i=0; i<=N; i++)
	{
		scanf("%s",st+1);
		if (st[1]=='-') 
		{
			b[i]=-1;
			a[i][0]=strlen(st+1)-1;
			for (int j=2; j<=a[i][0]+1; j++) a[i][a[i][0]-j+2]=(int)(st[j]-'0');
		}
		else 
		{
			b[i]=1;
			a[i][0]=strlen(st+1);
			for (int j=1; j<=a[i][0]; j++) a[i][a[i][0]-j+1]=(int)(st[j]-'0');
		}
	}
	int Num=0;
	for (int i=1; i<=M; i++)
	{
		c[0]=0;
		for (int x=i; x>0; )
		{
			c[0]++;
			c[c[0]]=x % 10;
			x/=10;
		}
		memcpy(s,a[0],sizeof(s));
		memcpy(t,c,sizeof(t));
		int k=b[0];
		for (int j=1; j<=N; j++)
		{
			memcpy(t1,a[j],sizeof(t1));
			int op=Mul(b[j],1);
			if (op==k) Plus(); else k=Minu(op,k);
			memcpy(t1,c,sizeof(t1));
			Mul(1,1);
			memcpy(t,sum,sizeof(sum));
		}
		if ((s[0]==1) && (s[1]==0))
		{
			Num++;
			res[Num]=i;
		}
	}
	cout << Num << endl;
	for (int i=1; i<=Num; i++) printf("%d\n",res[i]);
}

void Solve2()
{
	for (int i=0; i<=N; i++)
	{
		scanf("%s",st+1);
		int k;
		int len=strlen(st+1);
		for (int p=0; p<5; p++)
		{
			long long s=0;
			if (st[1]=='-') 
			{
				k=-1;
				for (int j=2; j<=len; j++) 
					s=(s*10LL+(long long)(st[j]-'0')) % P[p];
			}
			else 
			{
				k=1;
				for (int j=1; j<=len; j++) 
					s=(s*10LL+(long long)(st[j]-'0')) % P[p];
			}
			A[i][p]=(long long)k*s;
			A[i][p]=(A[i][p]+P[p]) % P[p];
		}
	}
	Num=0;
	for (int i=1; i<=M; i++)
	{
		bool flag=true;
		for (int p=0; p<5; p++)
		{
			long long S=A[0][p],tt=1LL;
			for (int j=1; j<=N; j++)
			{
				tt=(tt*(long long)i) % P[p];
				long long tmp=(tt*A[j][p]) % P[p];
				S=(S+tmp) % P[p];
			}
			if (S!=0)
			{
				flag=false;
				break;
			}
		}
		if (flag)
		{
			Num++;
			res[Num]=i;
		}
	}
	cout << Num << endl;
	for (int i=1; i<=Num; i++) printf("%d\n",res[i]);
}

int main()
{
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	scanf("%d%d",&N,&M);
	if (M<=100) Solve1(); else Solve2(); 
	return 0;
}

