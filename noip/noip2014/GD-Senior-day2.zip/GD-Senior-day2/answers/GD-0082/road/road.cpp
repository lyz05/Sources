#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <algorithm>

using namespace std;

const int oo=1<<30;

int N,M,Cou,Cou1,S,T;
bool yes[10005],CanGet[10005],vis[10005];
int c[200005];
int v[200005],next[200005],root[10005],v1[200005],next1[200005],root1[10005];
int dis[10005];

void insert(int father, int son)
{
	Cou++;
	v[Cou]=son;
	next[Cou]=root[father];
	root[father]=Cou;
}

void insert1(int father, int son)
{
	Cou1++;
	v1[Cou1]=son;
	next1[Cou1]=root1[father];
	root1[father]=Cou1;
}

void BFS1()
{
	memset(CanGet,false,sizeof(CanGet));
	int tail=1;
	c[1]=T;
	CanGet[T]=true;
	for (int head=1; head<=tail; head++)
		for (int x=root1[c[head]]; x>0; x=next1[x])
			if (!CanGet[v1[x]])
			{
				CanGet[v1[x]]=true;
				tail++;
				c[tail]=v1[x];
			}
	memset(yes,true,sizeof(yes));
	for (int i=1; i<=N; i++)
		for (int x=root[i]; x>0; x=next[x])
			if (!CanGet[v[x]])
			{
				yes[i]=false;
				break;
			}
}

void BFS2()
{
	for (int i=1; i<=N; i++) dis[i]=oo;
	if (!yes[S]) return;
	memset(vis,true,sizeof(vis));
	int tail=1;
	c[1]=S;
	dis[S]=0;
	vis[S]=false;
	for (int head=1; head<=tail; head++)
	{
		for (int x=root[c[head]]; x>0; x=next[x])
			if (yes[v[x]])
				if (dis[c[head]]+1<dis[v[x]])
				{
					dis[v[x]]=dis[c[head]]+1;
					if (vis[v[x]])
					{
						tail++;
						c[tail]=v[x];
						vis[v[x]]=false;
					}
				}
		vis[c[head]]=true;
	}
}

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d%d",&N,&M);
	for (int i=1; i<=M; i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		insert(x,y);
		insert1(y,x);
	}
	scanf("%d%d",&S,&T);
	BFS1();
	BFS2();
	if (dis[T]==oo) cout << -1 << endl; else cout << dis[T] << endl;
	return 0;
}

