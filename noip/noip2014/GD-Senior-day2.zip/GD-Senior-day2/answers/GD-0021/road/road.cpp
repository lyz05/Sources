#include <cstring>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <iostream>
#include <fstream>

#define rep(i, l, r) for (int i = l; i <= r; i++)
#define down(i, l, r) for (int i = l; i >= r; i--)
#define MS 12345
#define MAX 1073741823

using namespace std;

struct node
{
	int x, y;
	bool operator < (const node &k) const { return x < k.x; }
} c[234567];
int n, m, k[MS], d[MS], s, t;
bool b[MS], bb[MS];

void Search(int x)
{
	bb[x] = true;
	rep(i, k[x], k[x+1]-1) if (bb[c[i].y] == false) Search(c[i].y);
}

void Search2(int x)
{
	rep(i, k[x], k[x+1]-1) if (b[c[i].y] && d[c[i].y] > d[x]+1) d[c[i].y] = d[x]+1;
	rep(i, k[x], k[x+1]-1) if (b[c[i].y] && d[c[i].y] == d[x]+1) Search2(c[i].y);
}

int main()
{
	freopen("road.in", "r", stdin); freopen("road.out", "w", stdout);
	scanf("%d%d", &n, &m);
	rep(i, 1, m) scanf("%d%d", &c[i].y, &c[i].x);
	sort(c+1, c+1+m); c[m+1].x = MAX;
	k[1] = 1; rep(i, 2, n+1) 
	{
		k[i] = k[i-1];
		while(c[k[i]].x < i) k[i]++;
	}
	scanf("%d%d", &s, &t);
	Search(t); 
	rep(i, 1, n) b[i] = true;
	rep(i, 1, m) if (bb[c[i].x] == false) b[c[i].y] = false;
	rep(i, 1, n) d[i] = MAX; d[t] = 0;
	Search2(t);
	if (d[s] == MAX) printf("-1\n"); else printf("%d\n", d[s]);
	fclose(stdin); fclose(stdout);
	return 0;
}
