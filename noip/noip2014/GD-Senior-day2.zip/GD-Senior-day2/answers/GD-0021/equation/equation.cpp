#include <cstring>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <iostream>
#include <fstream>

#define rep(i, l, r) for (int i = l; i <= r; i++)
#define down(i, l, r) for (int i = l; i >= r; i--)
#define MS 12345
#define MAX 1073741823
#define B 100000000

using namespace std;

int n, m, k[123][2345], l, a, b, c, d, v[123456], vv;
char s[123456];
bool e, ans[1234567], kb[123], vb;

bool Big(int x)
{
	if (vv > k[x][0]) return false;
	if (vv < k[x][0]) return true;
	down(i, vv, 1) 
	{
		if (v[i] > k[x][i]) return false;
		if (v[i] < k[x][i]) return true;
	}
	return false;
}

void Del(int x)
{
	if (vb != kb[x])
	{
		rep(i, 1, max(k[x][0], vv)) v[i] += k[x][i]; vv = max(k[x][0], vv);
		rep(i, 1, vv-1) if (v[i] >= B) v[i+1] += v[i] / B, v[i] %= B; 
		while (v[vv] >= B) v[vv+1] += v[vv] / B, v[vv] %= B, vv++;
	}
	else if (Big(x))
	{
		rep(i, 1, max(k[x][0], vv)) v[i] = k[x][i] - v[i]; vv = max(k[x][0], vv);
		while (v[vv] == 0 && vv > 1) vv--;
		rep(i, 1, vv-1) while (v[i] < 0) v[i] += B, v[i+1] -= 1;
		vb = !kb[x];
	}
	else
	{
		rep(i, 1, max(k[x][0], vv)) v[i] = v[i] - k[x][i]; vv = max(k[x][0], vv);
		while (v[vv] == 0 && vv > 1) vv--;
		rep(i, 1, vv-1) while (v[i] < 0) v[i] += B, v[i+1] -= 1;
	}
}

bool Chu(int x)
{
	long long a = 0;
	down(i, vv, 1) 
	{
		a = a * B + v[i];
		v[i] = a / x;
		a %= x;
	}
	while (v[vv] == 0 && vv > 1) vv--;
	if (a == 0) return true; else return false;
}

bool Same()
{
	if (kb[n] != vb) return false;
	if (vv != k[n][0]) return false;
	rep(i, 1, vv) if (v[i] != k[n][i]) return false;
	return true;
}

int main()
{
	freopen("equation.in", "r", stdin); freopen("equation.out", "w", stdout);
	scanf("%d%d", &n, &m);
	rep(i, 0, n)
	{
		scanf("%s", s); l = strlen(s);
		if (s[0] == '-') 
		{
			kb[i] = true;
			a = l-1; b = c = d = 1;
			while (a >= 1)
			{
				k[i][d] += b * (s[a]-'0');
				b *= 10; c++;
				if (c > 8) b = c = 1, d++;
				a--;
			}
			k[i][0] = d;
		}
		else
		{
			kb[i] = false;
			a = l-1; b = c = d = 1;
			while (a >= 0)
			{
				k[i][d] += b * (s[a]-'0');
				b *= 10; c++;
				if (c > 8) b = c = 1, d++;
				a--;
			}
			k[i][0] = d;
		}
	}
	rep(x, 1, m)
	{
		ans[x] = false;
		rep(i, 1, vv) v[i] = 0; vv = 1; e = vb = false;
		rep(i, 0, n-1) 
		{
			Del(i);
			if (Chu(x) == false) { e = true; break; }
		}
		if (e) continue;
		if (Same()) ans[x] = true;
	}
	a = 0; rep(i, 1, m) if (ans[i]) a++; printf("%d\n", a);
	rep(i, 1, m) if (ans[i]) printf("%d\n", i);
	fclose(stdin); fclose(stdout);
	return 0;
}
