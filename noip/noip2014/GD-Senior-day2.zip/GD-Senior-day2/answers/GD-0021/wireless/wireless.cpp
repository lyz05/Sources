#include <cstring>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <iostream>
#include <fstream>

#define rep(i, l, r) for (int i = l; i <= r; i++)
#define down(i, l, r) for (int i = l; i >= r; i--)
#define MS 234
#define MAX 1073741823

using namespace std;

int n, d, c, a, ans, x[MS], y[MS], z[MS];

int main()
{
	freopen("wireless.in", "r", stdin); freopen("wireless.out", "w", stdout);
	scanf("%d%d", &d, &n);
	rep(i, 1, n) scanf("%d%d%d", &x[i], &y[i], &z[i]);
	ans = c = a = 0;
	rep(i, 0, 128) rep(j, 0, 128) 
	{
		a = 0;
		rep(k, 1, n) if (abs(x[k]-i) <= d && abs(y[k]-j) <= d) a += z[k];
		if (ans < a) ans = a, c = 1; else if (ans == a) c++;
	}
	printf("%d %d\n", c, ans);
	fclose(stdin); fclose(stdout);
	return 0;
}
