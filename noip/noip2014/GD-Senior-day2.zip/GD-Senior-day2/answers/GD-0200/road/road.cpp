#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<iostream>
#define fo(i,a,b) for(int i=a;i<=b;i++)
#define fd(i,a,b) for(int i=a;i>=b;i--)
using namespace std;
typedef long long ll;
const int N=21000,M=410000;
int TT,st[N],en[M],S,T,next[M],d[N],list[N+100];
bool ok[N],hash[N];
void insert(int x,int y)
{
	next[++TT]=st[x];
	st[x]=TT;
	en[TT]=y;
}
void spfa()
{
	int top=0,tail=1;
	memset(d,-1,sizeof(d));
	memset(hash,0,sizeof(hash));
	d[T]=0;
	list[1]=T;
	hash[T]=1;
	if (ok[S]==0) return;
	while (top!=tail)
	{
		top=(top+1)%N;
		int x=list[top];
		for(int i=st[x];i;i=next[i])
		if (ok[en[i]] && (d[en[i]]==-1||d[x]+1<d[en[i]]))
		{
			d[en[i]]=d[x]+1;
			if (hash[en[i]]==0)
			{
				hash[en[i]]=1;
				tail=(tail+1)%N;
				list[tail]=en[i];
			}
		}
		hash[x]=0;
	}
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
    int n,m;
    scanf("%d%d",&n,&m);
    fo(i,1,m)
    {
    	int x,y;
    	scanf("%d%d",&x,&y);
    	insert(y,x);
    }
    fo(i,0,n) ok[i]=1;
    cin>>S>>T;
    spfa();
    fo(i,1,n) if (d[i]==-1)
    {
    	ok[i]=0;
    	int x=i;
    	for(int i=st[x];i;i=next[i])
    	ok[en[i]]=0;
    }
    spfa();
    cout<<d[S];
    return 0;
}
