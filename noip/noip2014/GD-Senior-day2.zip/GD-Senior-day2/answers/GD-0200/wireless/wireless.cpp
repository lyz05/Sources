#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<iostream>
#define fo(i,a,b) for(int i=a;i<=b;i++)
#define fd(i,a,b) for(int i=a;i>=b;i--)
using namespace std;
typedef long long ll;
const int n=128;
ll a[200][200];
int main()
{
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	int d,m;
	cin>>d>>m;
	fo(i,1,m)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		scanf("%lld",&a[x][y]);
	}
	ll ans=0,num=0;
	fo(i,0,n)
	    fo(j,0,n)
	    {
	    	ll sum=0;
	    	fo(k,max(i-d,0),min(i+d,n))
	    	   fo(l,max(j-d,0),min(j+d,n))
	    	   sum+=a[k][l];
	    	if (sum>ans) ans=sum,num=1; else
	    	if (sum==ans) num++;
	    }
	cout<<num<<' '<<ans;
	return 0;
}
















