#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<iostream>
#define fo(i,a,b) for(int i=a;i<=b;i++)
#define fd(i,a,b) for(int i=a;i>=b;i--)
using namespace std;
typedef long long ll;
int ch[110][55000];
ll a[110];
int len[110];
const ll mol=6,
moarr[]={1e9+7,1e7+7,((1ll)<<31)-1,66666667,1e7+9,99999997};
bool ok[1100000];
int main()
{
	freopen("equation.in","r",stdin);
	freopen("equationpio.out","w",stdout);
	int n,m;
	cin>>n>>m;
	n++;
	fo(i,1,n)
	{
		cin>>a[i];
	}
	int outp=0;
	fo(i,1,m)
	{
		ll sum=0,base=1;
		fo(j,1,n)
		sum+=base*a[j],base*=i;
		if (sum==0) ok[i]=1,outp++;
	}
	cout<<outp;
	printf("\n");
	fo(i,1,m)
	if (ok[i]) printf("%d\n",i);
}










