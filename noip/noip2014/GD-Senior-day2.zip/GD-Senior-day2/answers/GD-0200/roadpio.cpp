#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<iostream>
#define fo(i,a,b) for(int i=a;i<=b;i++)
#define fd(i,a,b) for(int i=a;i>=b;i--)
using namespace std;
typedef long long ll;
const int N=1000,M=400000;
int TT,S,T,d[N];
int f[N][N],a[N][N],ok[N];
int main()
{
	freopen("road.in","r",stdin);
	freopen("roadpio.out","w",stdout);
    int n,m;
    scanf("%d%d",&n,&m);
    memset(f,-1,sizeof(f));
    memset(a,-1,sizeof(a));
    fo(i,1,m)
    {
    	int x,y,k;
    	scanf("%d%d",&x,&y);
    	a[x][y]=f[x][y]=1;
    }
    fo(i,1,n)
       fo(j,1,n)
          fo(k,1,n)
          if (i!=j && j!=k && i!=k)
          if (f[j][i]!=-1 && f[i][k]!=-1)
          if (f[j][k]==-1 || f[j][i]+f[i][k]<f[j][k])
          f[j][k]=f[j][i]+f[i][k];
    cin>>S>>T;
    fo(i,1,n)
    if (i!=T && f[i][T]==-1) 
	{
		ok[i]=1;
		fo(j,1,n)
		if (a[j][i]!=-1) ok[j]=1;
	}
    memcpy(f,a,sizeof(f));
    fo(i,1,n)
       fo(j,1,n)
          fo(k,1,n)
          if (i!=j && j!=k && i!=k)
          if (!ok[i] && !ok[j] && !ok[k])
          if (f[j][i]!=-1 && f[i][k]!=-1)
          if (f[j][k]==-1 || f[j][i]+f[i][k]<f[j][k])
          f[j][k]=f[j][i]+f[i][k];
    cout<<f[S][T];
}







