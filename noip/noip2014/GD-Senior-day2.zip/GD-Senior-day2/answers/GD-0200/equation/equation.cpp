#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<iostream>
#define fo(i,a,b) for(int i=a;i<=b;i++)
#define fd(i,a,b) for(int i=a;i>=b;i--)
using namespace std;
typedef long long ll;
int ch[110][55000];
ll a[110][110];
int len[110];
const ll mol=6,
moarr[]={1e9+7,1e7+7,((1ll)<<31)-1,66666667,1e7+9,99999997};
bool ok[1100000];
int main()
{
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	int n,m;
	cin>>n>>m;
	n++;
	fo(i,1,n)
	{
		char p;
		while (p=getchar(),(p<'0' || p>'9')&&(p!='-'));
		int by;
		if (p=='-') by=-1; else
		ch[i][len[i]=1]=p-'0',by=1;
		while (p=getchar(),p>='0' && p<='9') ch[i][++len[i]]=by*(p-'0');
	}
	fo(l,0,mol-1)
	{
		ll mo=moarr[l];
		fo(i,1,n)
		{
			a[l][i]=0;
		    fo(j,1,len[i]) a[l][i]=(a[l][i]*10+(ll)ch[i][j])%mo;
		}
	}
	int outp=0;
	fo(j,1,m)
	{
	    fo(l,0,mol-1)
	    {
	    	ll mo=moarr[l];
			if (ok[j]==0)
			{
			    ll sum=0,base=1;
				fo(k,1,n)
				{
					sum=(sum+base*a[l][k])%mo;
					base=base*j%mo;
				}
				if (sum!=0) ok[j]=1;
			} else break;
   		}
		if (ok[j]==0) outp++;
		if (outp==n-1) break;
   	}
	cout<<outp<<"\n";
	fo(i,1,m) if (ok[i]==0)
	{
		outp--;
		printf("%d\n",i);
		if (outp==0) break;
	}
	return 0;
}/*







#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<iostream>
#define fo(i,a,b) for(int i=a;i<=b;i++)
#define fd(i,a,b) for(int i=a;i>=b;i--)
using namespace std;
typedef long long ll;
int ch[110][55000];
ll a[110][110];
int len[110];
const ll mol=6,
moarr[]={1e9+7,1e7+7,((1ll)<<31)-1,66666667,1e7+9,99999997};
bool ok[1100000];
int main()
{
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	int n,m;
	cin>>n>>m;
	n++;
	fo(i,1,n)
	{
		char p;
		while (p=getchar(),(p<'0' || p>'9')&&(p!='-'));
		int by;
		if (p=='-') by=-1; else
		ch[i][len[i]=1]=p-'0',by=1;
		while (p=getchar(),p>='0' && p<='9') ch[i][++len[i]]=by*(p-'0');
	}
	fo(l,0,mol-1)
	{
		ll mo=moarr[l];
		fo(i,1,n)
		{
			a[l][i]=0;
		    fo(j,1,len[i]) a[l][i]=(a[l][i]*10+(ll)ch[i][j])%mo;
		}
		fo(j,1,m)
		if (ok[j]==0)
		{
		    ll sum=0,base=1;
			fo(k,1,n)
			{
				sum=(sum+base*a[l][k])%mo;
				base=base*j%mo;
			}
			if (sum!=0) ok[j]=1;
		}
	}
	int outp=0;
	fo(i,1,m) if (ok[i]==0) outp++;
	cout<<outp<<"\n";
	fo(i,1,m) if (ok[i]==0)
	{
		printf("%d\n",i);
	}
	return 0;
}*/
