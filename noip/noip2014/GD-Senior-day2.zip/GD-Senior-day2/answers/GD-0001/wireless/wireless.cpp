# include<stdio.h>
# include<string.h>
# include<algorithm>
using namespace std;
const int maxn=150;
int d,m;
int n=128;
int a[maxn][maxn];
int main(){
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	scanf("%d%d",&d,&m);
	int x,y,k;
	memset(a,0,sizeof(a));
	for(int i=1;i<=m;i++){
		scanf("%d%d%d",&x,&y,&k);a[x][y]+=k;
	}
	int ans=-1;int num=0,tot;
	int L,R,U,D;
	for(int i=0;i<=n;i++)
		for(int j=0;j<=n;j++){
			tot=0;
			U=max(0,i-d);D=min(n,i+d);L=max(0,j-d);R=min(n,j+d);
			for(x=U;x<=D;x++)
				for(y=L;y<=R;y++)
					tot+=a[x][y];
			if(tot>ans) ans=tot,num=1;
			else if(tot==ans) num++;
		}
	printf("%d %d\n",num,ans);
	return 0;
}
