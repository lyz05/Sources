# include<stdio.h>
# include<string.h>
# include<algorithm>
using namespace std;
const int maxn=10010;
const int maxm=200010;
int d[maxn];
int st,ed;
bool used[maxn];
bool can[maxn];
struct Graph{
	int first[maxn],next[maxm],v[maxm],edge;
	void init() {memset(first,-1,sizeof(first));edge=0;}
	void add_edge(int a,int b){
		next[edge]=first[a];v[edge]=b;first[a]=edge++;
	}
}Face,Back;

int n,m;
int q[maxn];
void BFS1(){
	int front=0,rear=-1,x,v;
	q[++rear]=ed;
	used[ed]=1;
	while(front<=rear){
		x=q[front];//printf("x:%d\n",x);
		for(int e=Back.first[x];e!=-1;e=Back.next[e]){
			v=Back.v[e];
			if(!used[v]){
				//printf("v:%d\n",v);
				used[v]=1;q[++rear]=v;
			}
		}
		front++;
	}
	//for(int i=1;i<=n;i++) printf("%d %d\n",i,used[i]);
}

void BFS2(){
	int front=0,rear=-1,x,v;
	for(int i=1;i<=n;i++) d[i]=-1;
	q[++rear]=st;d[st]=0;
	while(front<=rear){
		x=q[front];
		for(int e=Face.first[x];e!=-1;e=Face.next[e]){
			v=Face.v[e];if(!can[v]) continue;
			if(d[v]==-1){
				d[v]=d[x]+1;
				q[++rear]=v;
			}
		}
		front++;
	}
}

int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int a,b;
	scanf("%d%d",&n,&m);
	Face.init();Back.init();
	for(int i=1;i<=m;i++){
		scanf("%d%d",&a,&b);
		Face.add_edge(a,b);Back.add_edge(b,a);
	}
	scanf("%d%d",&st,&ed);
	memset(used,false,sizeof(used));
	BFS1();
	
	memset(can,false,sizeof(can));
	can[ed]=0;
	bool ok;
	for(int i=1;i<=n;i++){
		if(!used[i]) continue;
		ok=true;
		for(int e=Face.first[i];e!=-1;e=Face.next[e]){
			if(!used[Face.v[e]]){
				ok=false;break;
			}
		}can[i]=ok;
	}
	
	if(!can[st]) {printf("-1\n");return 0;}
	BFS2();
	printf("%d\n",d[ed]);
	return 0;
}
