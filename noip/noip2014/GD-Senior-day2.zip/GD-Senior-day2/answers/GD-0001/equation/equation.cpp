# include<stdio.h>
# include<string.h>
# include<vector>
# include<algorithm>
using namespace std;
const int maxn=110;
const int maxb=1350;
typedef long long LL;
LL Bit=1;
int n,m;
char s[10010],t;
int len;

struct Big{
	LL a[maxb];int len;int op;
	void init(){memset(a,0,sizeof(a));len=1;a[1]=0;op=1;}
	
	void add(Big C){
		//printf("Add origin:%I64d ",a[1]);
		int t=max(C.len,len);
		for(int i=1;i<=t;i++){
			a[i]+=C.a[i];
		}
		for(int i=1;i<=t;i++)
			a[i+1]+=a[i]/Bit,a[i]%=Bit;
		for(len=t+1;a[len]>0;len++)
			a[len+1]+=a[len]/Bit,a[len]%=Bit;
		len--;
		//printf("C:%I64d end:%I64d\n",C.a[1],a[1]);
	}
	
	void Jian(Big C){
		//printf("JIan origin:%I64d ",a[1]);
		int t=len;
		for(int i=1;i<=t;i++)
			a[i]-=C.a[i];
		for(int i=1;i<=t;i++)
			if(a[i]<0) a[i+1]--,a[i]+=Bit;
		for(len=t;a[len]==0&&len>1;len--);
		//printf("C:%I64d end:%I64d\n",C.a[1],a[1]);
	}
	
	LL divide(int x){
		int t=len;LL now=0;
		for(int i=t;i>=1;i--){
			now=now*Bit+a[i];
			a[i]=now/x;
			now=now%x;
		}
		for(len=t;a[len]==0&&len>1;len--);
		//	printf("Divide x:%I64d len:%d a[1]:%I64d yushu:%I64d\n",x,len,a[1],now);
		return now;
	}
}B[maxn];
Big now,tt;
vector<int> ans;

bool cmp(Big A,Big B){
	if(A.len!=B.len) return A.len>B.len;
	else{
		for(int i=A.len;i>=1;i--)
			if(A.a[i]!=B.a[i]) return A.a[i]>B.a[i];
	}
	return 0;
}

int main(){
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	LL tot;
	for(int i=1;i<=11;i++) Bit=Bit*10;
	//printf("%lld\n",Bit);
	scanf("%d %d\n",&n,&m);
	for(int i=0;i<=n;i++){
		B[i].init();B[i].len=0;
		len=0;
		while((t=getchar())&&((t<'0'||t>'9')&&t!='-'));
		if(t=='-') {B[i].op=-1,t=getchar();}else B[i].op=1;
		s[len++]=t;while((t=getchar())&&(t>='0'&&t<='9')) s[len++]=t;
		//s[len]='\0';//puts(s);
		for(int t=len-1;t>=0;t-=10){
			tot=0;
			for(int j=max(0,t-9);j<=t;j++){
				tot=tot*10+s[j]-'0';
			}
		//	printf("tot:%I64d\n",tot);
			B[i].a[++B[i].len]=tot;
		}
		//printf("i:%d len:%d %I64d op:%d\n",i,len,B[i].a[1],B[i].op);
	}
	int st;
	for(int i=0;i<=n;i++){
		if(B[i].len!=1||B[i].a[1]>0)
		{st=i;break;}
	}
	
	bool ok,big;
	ans.clear();
	for(int x=1;x<=m;x++){
		now.init();
		now.len=1;now.a[1]=0;now.op=1;
		ok=true;
		//printf("x:%d\n",x);
		for(int i=st;i<=n;i++){
			//printf("i:%d now.len:%d now:%I64d op:%d\n",i,now.len,now.a[1],now.op);
			if(now.divide(x)) {ok=false;break;}
			big=cmp(now,B[i]);
			if((now.op==-1&&B[i].op==-1)||(now.op==1&&B[i].op==1)){
				now.add(B[i]);
			}
			else if(now.op==1&&B[i].op==-1){
				if(big) now.Jian(B[i]);
				else{
					tt=B[i];tt.Jian(now);tt.op=-1;now=tt;
				}
			}
			else if(now.op==-1&&B[i].op==1){
				if(big){
					now.Jian(B[i]);
				}
				else{
					tt=B[i];tt.Jian(now);tt.op=1;now=tt;
				}
			}
		}
		if(ok&&now.len==1&&now.a[1]==0) ans.push_back(x);
	}
	printf("%d\n",ans.size());
	for(int i=0;i<ans.size();i++) printf("%d\n",ans[i]);
	return 0;
}
