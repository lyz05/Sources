#include <stdio.h>
#include <string.h>
//ûʱ����- - �������� 
#include <stdlib.h>
#define size 10010
typedef struct _s{
	char c[size];
} mystring;
mystring a[101];
int n,m;
int count;
int result[1000000];
//�ַ��ӷ�
int jia(const char *a,const char *b,char *c)
{ //a,bΪ����
	int i;
	int la,lb;
	int offset=0;
	char buf[size];
	memset(buf,0,sizeof(buf));
	la=strlen(a);
	lb=strlen(b);
	if(la>lb)
	{
		for(i=0;i<la-lb;i++)
			*(buf+i)='0';
		for(i=0;i<lb;i++)
			*(buf+(la-lb)+i)=*(b+i);
		if(*a+*b>9+'0'*2) offset=1;
		for(i=la-1;i>=0;i--)
		{
			*(c+offset+i)=*(a+i)+*(buf+i)-'0';
			if(*(c+offset+i)>9+'0')
			{
				*(c+offset+i)-=10;
				*(c+offset+i-1)+=1;
			}
		}
	}
	else
	{
		for(i=0;i<lb-la;i++)
			*(buf+i)='0';
		for(i=0;i<la;i++)
			*(buf+(lb-la)+i)=*(a+i);
		if(*a+*b>9+'0'*2) offset=1;
		for(i=lb-1;i>=0;i--)
		{
			*(c+offset+i)=*(buf+i)+*(b+i)-'0';
			if(*(c+offset+i)>9+'0')
			{
				*(c+offset+i)-=10;
				*(c+offset+i-1)+=1;
			}
		}
	}
}
int main()
{
	int i,j;
	
	int d,b,c;
	
	count=0;
	memset(result,0,sizeof(result));
	memset(a,0,sizeof(a));
	
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	
	scanf("%d%d",&n,&m);
	for(i=0;i<=n;i++)
		scanf("%s",a[i].c);
	
	//30%......
	if(n>2){printf("0");return 0;}
	d=atoi(a[0].c);
	b=atoi(a[1].c);
	c=atoi(a[2].c);
	if(n==1)
	{
		for(i=1;i<=m;i++)
		{
			if(!(b*i+d))result[count++]=i;
		}
	}
	else
	{
		for(i=1;i<=m;i++)
		{
			if(!(c*i*i+b*i+d))result[count++]=i;
		}
	}
	printf("%d\n",count);
	for(i=0;i<count;i++)
		printf("%d\n",result[i]);
	return 0;
}
