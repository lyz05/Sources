#include <stdio.h>
#include <string.h>
int n,m;
int s,t;
int alive[10001];
int count[10001];
int loffset[10001]; 
int lin[200001],lout[200001];
const int oo=-1;
int dijstra(int beg,int end)
{
	int i;
	int temp;
	int sp;
	int min=-2;
	if(beg==end) return 0;
	alive[beg]=1;
	sp=loffset[beg-1]+1;
	for(i=0;i<count[beg];i++)
	{
		if(alive[lout[sp+i]]) continue;
		temp=dijstra(lout[sp+i],end);
		if(temp==oo&&beg!=s){min=-2;break;}
		if(temp!=oo&&(temp<min||min==-2)) min=temp;
	}
	alive[beg]=0;
	return min+1;
}
void qsort(int l,int r)
{
	int i,j,mid,temp;
	i=l;j=r;mid=(l+r)/2;
	while(i<=j)
	{
		while(lin[i]<lin[mid])i++;
		while(lin[j]>lin[mid])j--;
		while(i<=j){
			temp=lin[i];lin[i]=lin[j];lin[j]=temp;
			temp=lout[i];lout[i]=lout[j];lout[j]=temp;
			i++;j--;
		}
	}
	if(l<j) qsort(l,j);
	if(i<r) qsort(i,r);
}
int main()
{
	int i,j;
	
	memset(alive,0,sizeof(alive));
	memset(count,0,sizeof(count));
	memset(lin,0,sizeof(lin));
	memset(lout,0,sizeof(lout));
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	
	scanf("%d%d",&n,&m);
	for(i=1;i<=m;i++)
	{
		scanf("%d%d",&lin[i],&lout[i]);
		count[lin[i]]++;
	}
	scanf("%d%d",&s,&t);
	qsort(1,m);
	loffset[0]=count[0];
	for(i=1;i<10000;i++)
		loffset[i]=loffset[i-1]+count[i];
	j=dijstra(s,t);
	if(j==0) printf("-1"); else printf("%d",j);
	return 0;
}
