#include <stdio.h>
#include <string.h>
int r[129][129];
int d,n;
int sum[129][129];
void addsum(int x,int y)
{
	int i,j;
	int aa,bb,cc,dd;
	aa=x-d>0?x-d:0;
	bb=x+d<128?x+d:128;
	cc=y-d>0?y-d:0;
	dd=y+d<128?y+d:128;
	for(i=aa;i<=bb;i++)
	{
		for(j=cc;j<=dd;j++)
		{
			sum[i][j]+=r[x][y];
		}
	}
}
int main()
{
	int i,j;
	int xx,yy;
	int count,cursum;
	
	count=cursum=0;
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	
	scanf("%d%d",&d,&n);
	memset(r,0,sizeof(r));
	memset(sum,0,sizeof(sum));
	for(i=0;i<n;i++)
	{
		scanf("%d%d",&xx,&yy);
		scanf("%d",&r[xx][yy]);
		addsum(xx,yy);
	}
	
	for(xx=0;xx<=128;xx++)
	{
		for(yy=0;yy<=128;yy++)
		{
			if(sum[xx][yy]>cursum)
			{
				cursum=sum[xx][yy];
				count=1;
			}
			else if(sum[xx][yy]==cursum) count++;
		}
	}
	
	printf("%d %d",count,cursum);
	return 0;
}
