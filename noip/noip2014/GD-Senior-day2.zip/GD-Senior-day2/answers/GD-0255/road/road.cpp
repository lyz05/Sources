#include<cstdio>
#include<vector>
#include<queue>
#include<cstring>

const int N=10005;
std::vector<int> g[N];
int n,m,s,t,d[N],f[N];//f[a]: 0:unknown  1:can  2:to cannot  3:cannot
bool fl[N];

void dfs(int x){
	if(f[x]||fl[x]) return;
	fl[x]=true;
	bool F=false,G=false; //F:have invalid way  G:have way
	for(int i=0;i<g[x].size();i++) {
		if(!f[g[x][i]]) dfs(g[x][i]);
		switch(f[g[x][i]]) {
			case 1:
			case 2:G=true; break;
			case 3:F=true; break;
		}			
	}
	f[x]=G?F?2:1:3;
	fl[x]=false;
}

int main() {
	freopen("road.in","r",stdin); freopen("road.out","w",stdout);
	int i,j,x,y;
	scanf("%d%d",&n,&m);
	for(i=0;i<m;i++) scanf("%d%d",&x,&y),g[x].push_back(y);
	scanf("%d%d",&s,&t);
	f[t]=1;
	for(i=1;i<=n;i++) dfs(i);
	memset(fl,0,sizeof(fl));
	if(f[s]!=1) puts("-1"); else {
		std::queue<int> q;
		memset(d,0x3f,sizeof(d));
		q.push(s); fl[s]=true; d[s]=0;
		while(!q.empty()){
			x=q.front();
			for(i=0;i<g[x].size();i++){
				y=g[x][i];
				if(f[y]!=1) continue;
				if(d[y]>d[x]+1) {
					d[y]=d[x]+1;
					if(!fl[y]) q.push(y),fl[y]=true;
				}
			}
			q.pop(); fl[x]=false;
		}	
		printf("%d",d[t]);
	}
	fclose(stdin); fclose(stdout);
	return 0;
}
