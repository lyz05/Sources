#include<cstdio>

int main() {
	freopen(".in","r",stdin); freopen(".out","w",stdout);
	
	fclose(stdin); fclose(stdout);
	return 0;
}
