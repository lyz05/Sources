#include<cstdio>
#include<cstring>

const int BS=10;
struct hint{ int d,s; int a[12000]; } a[105],b[105],r;
int n,m,cnt=0;
char s[12000];
bool flag[1000005];

bool operator<(hint &x,hint &y) {
	if(x.d!=y.d) return x.d<y.d;
	int dd=x.d;
	while(x.a[dd]==y.a[dd]&&dd>=0)dd--;
	if(dd<0) return false;
	return x.a[dd]<y.a[dd];
}

void hintpl(hint &x,hint y){
	int i;
	if(x.s==y.s) {
		if(x.d<y.d) x.d=y.d;
		int i;
		for(i=0;i<x.d;i++) {
			x.a[i]+=y.a[i];
			x.a[i+1]=x.a[i]/BS;
			x.a[i]%=BS;
		}
		if(x.a[x.d]) x.d++;
	}
	else if(x<y) {
			for(i=0;i<y.d;i++){
				y.a[i]-=x.a[i];
				if(y.a[i]<0) y.a[i]+=BS,y.a[i+1]--;
			}
			while(!y.a[y.d-1]&&y.d) y.d--;
			x=y;
		}
		else {
			for(i=0;i<x.d;i++){
				x.a[i]-=y.a[i];
				if(x.a[i]<0) x.a[i]+=BS,x.a[i+1]--;
			}
			while(!x.a[x.d-1]&&x.d) x.d--;
		}
}

void hintmul(hint &x,int y){
	int i,u=0;
	for(i=0;i<x.d;i++){
		x.a[i]*=y; x.a[i]+=u;
		u=x.a[i]/BS;
		x.a[i]%=BS;
	}
	if(u>=BS) x.a[x.d++]=u%BS,x.a[x.d++]=u/BS;
	else if(u>0) x.a[x.d++]=u;
}

void gethint(hint &x){
	int len,i,dl;
	scanf("%s",s);
	len=strlen(s);
	if(s[0]=='-') x.s=-1,dl=1; else x.s=1,dl=0;
	for(i=0;i<len-dl;i++) x.a[i]=s[len-i-1]-'0';
	x.d=len-dl;
}

int main() {
	freopen("equation.in","r",stdin); freopen("equation.out","w",stdout);
	int i,j,k;
	scanf("%d%d",&n,&m);
	for(i=0;i<=n;i++) gethint(a[i]);
	for(i=1;i<=m;i++){
		r=a[n]; 
		for(j=n-1;j>=0;j--) hintmul(r,i),hintpl(r,a[j]);		
		if(!r.d) flag[i]=true,cnt++;
		if(cnt==n) break;
		if(i>1900) break;
	}
	printf("%d\n",cnt);
	for(i=1;i<=m;i++) if(flag[i]) printf("%d\n",i);
	fclose(stdin); fclose(stdout);
	return 0;
}
