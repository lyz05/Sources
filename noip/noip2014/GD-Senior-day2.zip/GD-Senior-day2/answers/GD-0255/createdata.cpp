#include<cstdio>
#include<cstdlib>
#include<ctime>

FILE* f;

int random(int x) { return ((rand()<<15)+rand())%x; }

int main() {
	srand(time(0));
	f=fopen("wireless.in","w");
	int i,j,n,m,k,d;
	n=20; d=random(20)+1;
	fprintf(f,"%d\n%d\n",d,n);
	for(i=0;i<n;i++) fprintf(f,"%d %d %d\n",random(129),random(129),random(1000000)+1);
	fclose(f);
	return 0;
}
	
