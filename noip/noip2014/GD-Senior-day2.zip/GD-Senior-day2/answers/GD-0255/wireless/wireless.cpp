#include<cstdio>
#include<cstring>

typedef int arr[200];
int n,ans,cnt,d;
arr A[200],B[200],*a=A+30,*b=B+30; //  so that a[-20][-20] is ok

inline void maxz(int &x,int y) { if(x<y) x=y,cnt=1; else if(x==y) cnt++; }

int main() {
	freopen("wireless.in","r",stdin); freopen("wireless.out","w",stdout);
	int i,j,x,y,z;
	memset(A,0,sizeof(A)); memset(B,0,sizeof(B));
	scanf("%d%d",&d,&n);
	for(i=0;i<n;i++) scanf("%d%d%d",&x,&y,&z),a[x][y]=z;
	for(i=0;i<129+d;i++) for(j=0;j<129+d;j++) 
		b[i][j]=b[i-1][j]+b[i][j-1]-b[i-1][j-1]+a[i][j];
	ans=0;
	for(i=0;i<129;i++) for(j=0;j<129;j++) 
		maxz(ans,b[i+d][j+d]-b[i-d-1][j+d]-b[i+d][j-d-1]+b[i-d-1][j-d-1]);
	printf("%d\n%d",cnt,ans);
	fclose(stdin); fclose(stdout);
	return 0;
}
