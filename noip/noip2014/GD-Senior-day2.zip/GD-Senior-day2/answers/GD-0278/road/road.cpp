#include<iostream>
#include<fstream>
#include<string>
#include<cstring>
#include<ctime>
#include<cmath>
#include<cstdio>
#include<queue>
#include<set>
#include<map>
#include<vector>
#include<algorithm>
using namespace std;
#define st first
#define nd second
#define lson l,mid,rt<<1
#define rson mid+1,r,rt<<1|1
#define For(i,a,b)  for(int i=a,_b=b;i<=_b;i++)
#define Forr(i,a,b) for(int i=a,_b=b;i>=_b;i--)
typedef long long LL;
typedef unsigned long long USLL;

const int maxn=10005;
vector<int> e[maxn];
//vector<int> E[maxn];
int m,n,f,t,s;
int d[maxn];
int in[maxn];
int inm[maxn];
void search(int w)
{
	in[w]=1;
	For(i,0,d[w]-1)
	  if (in[e[w][i]]==0) search(e[w][i]);
}

void deal()
{
	For(i,1,n)
	  if (in[i]==0) {
	  	inm[i]=0;
	  For(j,0,d[i]-1) inm[e[i][j]]=0;
}
    
    
	}

int spfa(int t,int s)
{
    queue <int> q;
	int inq[maxn];
	int dis[maxn];
	memset(inq,0,sizeof(inq));
	memset(dis,-1,sizeof(dis));
	q.push(t);
	dis[t]=0;
	inq[t]=1;
	while (!q.empty())
	{
		int u=q.front();q.pop();
		For(i,0,d[u]-1)
		{
			if (inm[e[u][i]]==0||inq[e[u][i]]==1) continue;
			int &z=e[u][i];
			dis[z]=dis[u]+1;
			if (z==s) return dis[z];
			q.push(z);
			inq[z]=1;
		}
		
	}
	
		
	return -1;
	
}


int main()
{
	ifstream fin("road.in");
	ofstream fout("road.out");
	memset(inm,-1,sizeof(inm));
	memset(in,0,sizeof(in));
	memset(d,0,sizeof(d));
	fin>>n>>m;
	For(i,1,m)
	{
		fin>>t>>f;
		e[f].push_back(t);
		d[f]++;
	}
	fin>>s>>t;
	
	search(t);
	deal();
	fout<<spfa(t,s);
	
	
	return 0;
}
