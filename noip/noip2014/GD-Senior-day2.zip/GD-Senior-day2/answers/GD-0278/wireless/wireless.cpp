#include<iostream>
#include<fstream>
#include<string>
#include<cstring>
#include<ctime>
#include<cmath>
#include<cstdio>
#include<queue>
#include<set>
#include<map>
#include<vector>
#include<algorithm>
using namespace std;
#define st first
#define nd second
#define lson l,mid,rt<<1
#define rson mid+1,r,rt<<1|1
#define For(i,a,b)  for(int i=a,_b=b;i<=_b;i++)
#define Forr(i,a,b) for(int i=a,_b=b;i>=_b;i--)
typedef long long LL;
typedef unsigned long long USLL;

ifstream fin("wireless.in");
	ofstream fout("wireless.out");




const int maxq=100;
struct bignum{
	int len,q,d[maxq];
	bool operator <(const bignum &x) const
	{
		if (x.q<q) return true;
		
		if (q==0)
		{
		if (x.len>len) return true;
        if (x.len<len) return false;
        Forr(i,len-1,0) {
        	if (x.d[i]>d[i]) return true;
        	if (x.d[i]<d[i]) return false;
        }
        return false;
		}
		
		if (q==1)
		{
		if (x.len>len) return false;
        if (x.len<len) return true;
        Forr(i,len-1,0) {
        	if (x.d[i]>d[i]) return false;
        	if (x.d[i]<d[i]) return true;
        }
        return false;	
			
		}
		
	}
	
	bool operator <=(const bignum&x)const
	{
		if (x.len>len) return true;
        if (x.len<len) return false;
        Forr(i,len-1,0) {
        	if (x.d[i]>d[i]) return true;
        	if (x.d[i]<d[i]) return false;
        }
        return false;	
	}
	
	void clear()
	{
		q=0;
		len=0;
		For(i,0,maxq-1) d[i]=0;
	}
	
	void push()
	{
		For(i,0,len-1)
		{
			d[i+1]+=d[i]/10;
			d[i]%=10;
	}
		if (d[len]!=0) len++;
		
   }
	
	bignum operator +(const bignum &x) const
	{
		bignum ans;
		ans.clear();
		
		if (q^x.q==0)
		{
		ans.len=max(len,x.len);
		For(i,0,ans.len-1)
		ans.d[i]+=d[i]+x.d[i];
		ans.push();
		ans.q=q;
		return ans;
	    }
	    
	    
	     
	    
	    if (this-> operator <=(x))
	    {
	    	ans.q=x.q;
	    
	    	ans.len=x.len;
	    	
	    	For(i,0,ans.len-1)
	    	{
	    		ans.d[i]=ans.d[i]+x.d[i]-d[i];
	    		if (ans.d[i]<0) 
				{
	    		ans.d[i]+=10;
				ans.d[i+1]--;	
	    		}
	    	}
	    	
	    	Forr(i,ans.len-1,0)
	    	if (ans.d[i]==0) ans.len--;
	    
	    	return ans;
	    }
	    //fout<<"******";
	    if (!this-> operator <=(x) )
	    {
	        //fout<<"x>y"	;
	    	ans.q=q;
	    	ans.len=len;
	    	For(i,0,ans.len-1)
	    	{
	    		ans.d[i]=ans.d[i]+d[i]-x.d[i];
	    		if (ans.d[i]<0) 
				{
	    		ans.d[i]+=10;
				ans.d[i+1]--;	
	    		}
	    	}
	    	Forr(i,ans.len-1,0)
	    	if (ans.d[i]==0) ans.len--;
	    	return ans;
	    }
	    
	    
	    
	}
	
	bignum operator *(const bignum &x)const
	{
		bignum ans;
		ans.clear();
		ans.q=q^x.q;
		ans.len=len+x.len-1;
		For(i,0,len-1)
		  For(j,0,x.len-1)
		  ans.d[i+j]+=d[i]*x.d[j];
		ans.push();
		return ans;
	}
	
	void print()
	{
		if (len==0) fout<<"0";
		if (q==1) fout<<"-";
		Forr(i,len-1,0)
		fout<<d[i];
	}
	
};

void change(char s[maxq],bignum &p)
{
	p.clear();
	p.len=strlen(s);
	if (s[0]!='-')
	For(i,0,p.len-1) p.d[i]=s[p.len-1-i]-'0';
	if (s[0]=='-')
	{
		p.len--;p.q=1;
		For(i,0,p.len-1) p.d[i]=s[p.len-i]-'0';
	}
	
}

void change1(int X,bignum &x)
{
  x.clear(); 
  if (X<0)  {x.q=1;X=abs(X); }
  while (X!=0)
  {
  	x.d[x.len++]=X%10;
  	X/=10;
  }
  	
}







int d;
const int maxn=128;
bignum a[150][150];
int x,y,k,n;
bignum max1;
int num=0;











int main()
{
	max1.clear();
	memset(a,0,sizeof(a));
	fin>>d;
	fin>>n;
	For(i,1,n) 
	{
		fin>>x>>y>>k;
		
		change1(k,a[x][y]);
	}
	
	For(i,0,maxn)
	  For(j,0,maxn)
	    {
	    	bignum ans;
	    	ans.clear();
		    For(k,max(i-d,0),min(i+d,maxn))
		      For(l,max(j-d,0),min(j+d,maxn))
		      {
		      	ans=ans+a[k][l];
		      } 
		    if ((!(ans<max1))&&(!(max1<ans))) num++; 
	        if (max1<ans) {num=1;max1=ans;}
		}
	fout<<num<<" ";
	max1.print();
	
	return 0;
}
