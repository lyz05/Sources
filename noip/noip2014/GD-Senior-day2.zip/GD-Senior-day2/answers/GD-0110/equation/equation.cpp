#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

typedef long long LL;

const int N = 105;
const int L = 10015;
const int M = int(1e6 + 5);
const int MD[5] = {int(1e9+7), int(1e8+7), int(9e8+7), int(8e8+3), int(1e9-3)};

int b[L];

struct HP
{
	int a[L];
	int i;
	
	void read()
	{
		int c; while(c=getchar(), c<'-');
		if(c=='-') i=1, a[0]=0; else i=0, a[a[0]=1]=c-'0';
		while(c=getchar(), c>='0') a[++a[0]]=c-'0';
		for(int j=1; j+j<=a[0]; j++) swap(a[j], a[a[0]-j+1]);
		
		b[0] = 0;
		for(int j=1; j<=a[0]; j+=8)
		{
			b[++b[0]] = 0;
			for(int k=j+7; k>=j; k--) (b[b[0]] *= 10) += a[k];
		}
		for(int j=b[0]+1; j<=a[0]; j++) a[j] = 0;
		for(int j=0; j<=b[0]; j++) a[j] = b[j];
	}
	
	int mod(int m)
	{
		LL lft(0);
		for(int j=a[0]; j; j--) lft = (lft * int(1e8) + a[j]) % m;
		return i ? int(-lft) : int(lft);
	}
}a[N];

int n, m, G;
int co[11][N];
int ans[M];

int main()
{
	freopen("equation.in", "r", stdin);
	freopen("equation.out", "w", stdout);
	
	scanf("%d%d", &n, &m);
	for(int i=0; i<=n; i++) a[i].read();
	
	G = 5;
	for(int i=0; i<G; i++) for(int j=0; j<=n; j++) co[i][j] = a[j].mod(MD[i]);
	
	ans[0] = 0;
	for(int i=1; i<=m; i++)
	{
		int ok(1);
		for(int j=0; j<G && ok; j++)
		{
			LL r(co[j][n]);
			//for(register int *k=co[j]+n-1; k!=co[j]-1; k--) r = (r*i + (*k)) % MD[j];
			for(int k=n-1; k>=0; k--) r = (r*i + co[j][k]) % MD[j];
			ok &= (r==0);
		}
		if(ok) ans[++ans[0]] = i;
	}
	
	printf("%d\n", ans[0]);
	for(int i=1; i<=ans[0]; i++) printf("%d\n", ans[i]);
	
	return 0;
}

