#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

const int N = 1005;

int x[N], y[N], cnt[N];
int n, k, d, axa, axb;

int abs(int x){return x>=0 ? x : -x;}

int main()
{
	freopen("wireless.in", "r", stdin);
	freopen("wireless.out", "w", stdout);
	
	scanf("%d%d", &d, &n);
	for(int i=1; i<=n; i++) scanf("%d%d%d", &x[i], &y[i], &cnt[i]);
	
	axa = axb = 0;
	for(int i=0; i<129; i++) for(int j=0; j<129; j++)
	{
		int r(0);
		for(int l=1; l<=n; l++) if(abs(x[l]-i) <= d && abs(y[l]-j) <= d) r += cnt[l];
		if(r > axb) axb = r, axa = 1; else if(r == axb) ++axa;
	}
	printf("%d %d\n", axa, axb);
	
	return 0;
}

