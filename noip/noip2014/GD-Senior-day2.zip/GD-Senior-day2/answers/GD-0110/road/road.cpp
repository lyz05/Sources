#include <cstdio>
#include <cstring>
using namespace std;

const int N = 10005;
const int M = 200005;

int to[M], next[M], end[N], tms;
int fto[M], fnext[M], fend[N], ftms;

int vs[N], g[N], q[N];
int n, m, s, t;

void spread(int x)
{
	q[1] = t, vs[t] = 1;
	for(int h=1, t=1, x; h<=t; ++h)
	{
		x = q[h];
		for(int p=fend[x]; p; p=fnext[p]) if(!vs[fto[p]]) vs[fto[p]]=1, q[++t]=fto[p];
	}
}

int dis[N];
int spfa(int s, int T)
{
	if(!g[s]) return -1;
	
	for(int i=1; i<=n; i++) dis[i] = 1e9, vs[i] = 0;
	dis[s] = 0, vs[s] = 1, q[1] = s;
	
	for(int h=0, t=1, x; h!=t; )
	{
		if(++h==N) h=0;
		x = q[h];
		for(int p=end[x]; p; p=next[p]) if(g[to[p]] && dis[to[p]]>dis[x]+1)
		{
			dis[to[p]] = dis[x]+1;
			if(!vs[to[p]])
			{
				vs[to[p]] = 1;
				if(++t==N) t=0;
				q[t] = to[p];
			}
		}
		vs[x] = 0;
	}
	return dis[T] >= 1e9 ? -1 : dis[T];
}

int main()
{
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	
	scanf("%d%d", &n, &m);
	for(int i=1, x,y; i<=m; i++)
	{
		scanf("%d%d", &x, &y);
		to[++tms]=y, next[tms]=end[x], end[x]=tms;
		fto[++ftms]=x, fnext[ftms]=fend[y], fend[y]=ftms;
	}
	scanf("%d%d", &s, &t);
	
	spread(t);
	
	for(int i=1; i<=n; i++)
	{
		g[i] = 1;
		for(int p=end[i]; p && g[i]; p=next[p]) g[i] &= vs[to[p]];
	}
	
	printf("%d\n", spfa(s, t));
	
	return 0;
}


