#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<stack>
#include<string>
#include<queue>
#include<vector>
#include<string>
#include<functional>
using namespace std;
const int M=1000010;
int n, d;
struct node
{
	int x;
	int y;
	int val;
};
node map[M];
int f[130][130];
int ans=0;
bool cmp(node a, node b)
{
	if (a.x==b.x) return a.y<b.y;
	return a.x<b.x;
}
void solve()
{
	int co=1;
	int maxx=0;
	for(int i=0; i<=128; i++)
	  for(int j=0; j<=128; j++)
	  {
	  	 node temp;
	  	 temp.x=i;
	  	 temp.y=j;
	  	 temp.val=0;
	  	 for(int k=1; k<=n; k++)
	     {
	     	if (map[k].x>=temp.x-d && map[k].x<=temp.x+d)
	     	if (map[k].y>=temp.y-d && map[k].y<=temp.y+d)
			temp.val+=map[k].val;
	     }
	     f[i][j]=temp.val;
	  }
	for(int i=0; i<=128; i++)
	   for(int j=0; j<=128; j++)
	 {

	 	
	 	if (ans<f[i][j]) {
	 	  ans=f[i][j];
	 	  co=1;
	    }
	 	else if (ans==f[i][j])  co++;
	 }
	 printf("%d %d", co, ans);
}
void init()
{
	scanf("%d", &d);
	scanf("%d", &n);
	for(int i=1; i<=n; i++)
	{
		scanf("%d %d %d", &map[i].x, &map[i].y, &map[i].val);
	}
	sort(map+1, map+n+1, cmp);
	memset(f, 0, sizeof(f));
}
int main()
{
	freopen("wireless.in","r", stdin);
	freopen("wireless.out","w", stdout);
	init();
	solve();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
