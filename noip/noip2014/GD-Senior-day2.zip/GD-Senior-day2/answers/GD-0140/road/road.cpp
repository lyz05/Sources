#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<stack>
#include<string>
#include<queue>
#include<vector>
#include<string>
#include<functional>
using namespace std;
const int M=5000;
int map[M][M];
int ap[M][M];
int f[M][M];
int vis[M];
int n, m;
int s, t;
int cost[M];
bool flag=1;
void init()
{
	
	memset(vis, 0, sizeof(vis));
	memset(map, 0, sizeof(map));
	memset(cost, 127, sizeof(cost));
	scanf("%d %d", &n, &m);
	if (n>=1000){
		flag=0;
		return;
	}
	for(int i=1; i<=m; i++)
	{
		int x, y;
		scanf("%d %d", &x, &y);
		map[x][y]=1;
		ap[x][y]=1;
	}
	scanf("%d %d",&s, &t);
}
void spfa()
{
	stack<int>s1;
	int v=s;
	s1.push(v);
	cost[s]=0;
	vis[s]=1;
	while (!s1.empty())
	{
		v=s1.top();
		s1.pop();
		vis[v]=1;
		for(int i=1; i<=n; i++)
		{
			if (!vis[i] && ap[v][i] && (map[i][t] || i==t) )
			if (cost[v]+ap[v][i]<cost[i])
			{
				cost[i]=cost[v]+map[v][i];
				s1.push(i);
			}
			else vis[i]=1;
		}
		vis[v]=0;
	}
	
}
void solve()
{
	for(int i=1; i<=n; i++)
	 for(int j=1; j<=n; j++)
	   for(int k=1; k<=n; k++)
	   {
	   	   if (map[i][k] && map[k][j] && i!=j)
	   	   map[i][j]=1;
	   }
	   for(int i=1; i<=n; i++)
	   {
	   	 if (!map[i][t] && i!=t)
	   	 {
	   	 	for(int j=1; j<=n; j++)
	   	 	{
	   	 		if (ap[j][i]) map[j][t]=0;
	   	 	}
	   	 }
	   }
	   if (!map[s][t]){
	   	printf("-1\n");
	   	return;
	   }
	   
      spfa();
      printf("%d\n",cost[t]);
}
int main()
{
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	init();
	if (!flag) printf("-1");
	else 
	solve();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
