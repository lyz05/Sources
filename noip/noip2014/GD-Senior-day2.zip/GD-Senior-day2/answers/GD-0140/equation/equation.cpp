#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<stack>
#include<string>
#include<queue>
#include<vector>
#include<string>
#include<functional>
using namespace std;
const int M=10005;
int n, m;
long long  a[M];
int b[M];
bool flag=1;
void init()
{
	memset(a,0,sizeof(a));
	memset(b,0,sizeof(b));
	scanf("%d %d", &n, &m); 
	if (n>=20) {
		flag=0;
		return;
	}
	for(int i=1; i<=n+1; i++) scanf("%lld", &a[i]);
}
bool check(int x)
{
	long long  temp=a[1];
	int k=x;
	for(int i=2; i<=n+1; i++)
	{
		temp+=a[i]*k;
		k*=k;
	}
	if (!temp) return true;
	else return false;
}
void solve()
{
	int ans=0;
	for(int i=1; i<=m; i++)
	{
		if (check(i)){
			ans++;
			b[ans]=i;
		}
	}
	printf("%d\n", ans);
	for(int i=1; i<=ans; i++) printf("%d\n", b[i]);
}
int main()
{
	freopen("equation.in", "r", stdin);
	freopen("equation.out", "w", stdout);
	init();
	if (flag) solve();
	else printf("0");
	fclose(stdin);
	fclose(stdout);
	return 0;
}
