#include<cstdio>
#include<cstring>
#include<algorithm>
#define to(i,l,r) for (int i=l;i<=r;i++)
using namespace std;
int n,m,s,t;
bool f[10001][10001],ff[10001];
int opt[10001][10001];
bool yon(int nn){
for (int i=1;i<=n;i++)
{ if (i==t) continue;if (!f[nn][i]&&f[i][t]) return false;}  return true;}
void dfs(int k){to(i,1,n) if (!f[i][k]&&yon(i)) {ff[i]=false; dfs(i);} }
void floyed(){to(i,1,n) to(j,1,n)
if (!f[i][j]) opt[i][j]=1;
else if (i!=j) opt[i][j]=999999;else opt[i][j]=0;     
to(k,1,n) to(i,1,n) to(j,1,n)
if (opt[i][k]!=999999&&opt[k][j]!=999999&&!ff[i]&&!ff[j]&&!ff[k])
opt[i][j]=min(opt[i][j],opt[i][k]+opt[k][j]);}
int main(){freopen("road.in","r",stdin);freopen("road.out","w",stdout);
memset(f,true,sizeof(f));memset(ff,true,sizeof(ff));scanf("%d%d",&n,&m);
to(i,1,m) {int x,y;scanf("%d%d",&x,&y);f[x][y]=false;}
scanf("%d%d",&s,&t);ff[s]=false;ff[t]=false;
to(i,1,n) if (!f[i][t]&&yon(i)){ ff[i]=false;dfs(i);}floyed();
if (opt[s][t]==0||opt[s][t]==999999)printf("%d\n",-1);
else printf("%d\n",opt[s][t]);fclose(stdin);fclose(stdout);return 0;}
