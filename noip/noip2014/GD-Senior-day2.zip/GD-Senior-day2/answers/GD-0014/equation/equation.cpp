#include<cstdio>
#include<cstring>
#include<algorithm>
#define to(i,l,r) for (int i=l;i<=r;i++)
using namespace std;
int main(){
freopen("equation.in","r",stdin);freopen("equation.out","w",stdout);
int n,m,a[1001],z=0,b[100];
scanf("%d%d",&n,&m);
to(i,0,n) scanf("%d",&a[i]);
to(i,1,m) { int sum=a[0],now=i;
sum=a[0]+a[1]*now;to(j,1,n-1){now*=now;sum+=a[j+1]*now;}
if (sum==0) b[z++]=i;}
printf("%d\n",z);to(i,0,z-1) printf("%d\n",b[i]);
fclose(stdin);fclose(stdout);return 0;}
