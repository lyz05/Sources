#include<cstdio>
#include<cstring>
#define to(i,l,r) for (int i=l;i<=r;i++)
using namespace std;
int main(){freopen("wireless.in","r",stdin);freopen("wireless.out","w",stdout);
	int d,n,a[300][300],ans=0,max=-50;
	memset(a,0,sizeof(a));
	scanf("%d",&d);scanf("%d",&n);
	to(i,1,n) { int x,y,z;scanf("%d%d%d",&x,&y,&z);a[x+50][y+50]=z;}  	
	to(i,50,178) to (j,50,178)
	  { int sum=0;to (k,i-d,i+d) to (k2,j-d,j+d) sum+=a[k][k2];
		  if (sum>max) {max=sum;ans=1;} else if (sum==max) ans++;}
	printf("%d %d\n",ans,max);fclose(stdin);fclose(stdout);return 0;}
