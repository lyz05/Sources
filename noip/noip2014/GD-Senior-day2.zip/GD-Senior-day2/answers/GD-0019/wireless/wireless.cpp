#include<iostream>
#include<fstream>
#include<algorithm>
#include<memory.h>
using namespace std;
const int MAXN=130;
int p[MAXN][MAXN];
int tl[MAXN][MAXN];
void knum(int,int);
int d=0,n=0;
int main()
{
	fstream file("wireless.in",ios::in);
    memset(p,0,sizeof(p));
    memset(tl,0,sizeof(tl));
    file>>d>>n;
    int x=0,y=0,k=0;
    for(int i=0;i<n;i++)
    {
        file>>x>>y>>k;
        p[x][y]=k;
    }
	int max=0,num=0;
    for(int i=0;i<8;i++)
        for(int j=0;j<8;j++)
		{
            knum(i,j);
			cout<<i<<','<<j<<":"<<tl[i][j]<<endl;
			if(tl[i][j]>max)
			{
				max = tl[i][j];
				num=1;
			}
			else if(tl[i][j]==max) num++;
		}
	file.close();
	file.clear();
	file.open("wireless.out",ios::out);
	file<<num<<" "<<max;
	file.close();
    return 0;
}

void knum(int x,int y)
{
    if(y==0&&x==0)//most left
    {
        for(int i = x;i<=x+2*d;i++)
            for(int j=y;j<=y+2*d;j++)
			{
                tl[x][y]+=p[i][j];
			}
        return ;
    }
   
    if(x!=0)
    {
        tl[x][y]=tl[x-1][y];
        for(int i=y;i<=y+2*d;i++)
        {
            tl[x][y]-=p[x-1][i];
            tl[x][y]+=p[x+2*d][i];
        }
    }
    else
    {
        tl[x][y]=tl[x][y-1];
        for(int i=x;i<=x+2*d;i++)
        {
            tl[x][y]-=p[i][y-1];
            tl[x][y]+=p[i][y+2*d];
        }
    }
}
