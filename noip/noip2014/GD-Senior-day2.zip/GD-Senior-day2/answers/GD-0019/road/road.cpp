#include<iostream>
#include<fstream>
#include<algorithm>
#include<memory.h>
#include<queue>
#include<utility>
using namespace std;
const int MAXN = 10005;
const int MAXM = 200005;
const int INF = (1<<30);
int first[MAXN],next[MAXM],enext[MAXM],efirst[MAXM],u[MAXM],v[MAXM];
int d[MAXN];
bool vis[MAXN];bool pvis[MAXN];
int n,m,s,t;
queue<int> q;
void saixuan();
int dai(int);
int main()
{
	memset(first,-1,sizeof(first));
	memset(next,-1,sizeof(next));
	memset(efirst,-1,sizeof(first));
	memset(enext,-1,sizeof(next));
	for(int i=0;i<MAXN;i++) d[i] = INF;
	memset(u,-1,sizeof(u));
	memset(v,-1,sizeof(v));
	memset(vis,true,sizeof(vis));
	fstream file("road.in",ios::in);
	file>>n>>m;
	for(int i=1;i<=m;i++)
	{
		file>>u[i]>>v[i];
		next[i]=first[u[i]];
		enext[i]=efirst[v[i]];
		first[u[i]]=i;
		efirst[v[i]]=i;
	}
	file>>s>>t;
	saixuan();
	file.close();file.clear();
	file.open("road.out",ios::out);
	if(!vis[s])
	{
		file<<"-1";
		return 0;
	}
	d[t]=0;
	dai(s);
	file<<d[s];
	file.close();
	return 0;
}

void saixuan()
{
	
	memset(pvis,false,sizeof(pvis));
	pvis[t]=true;
	for(int e=efirst[t];e!=-1;e=enext[e])
	{
		q.push(u[e]);
		pvis[u[e]]=true;
	}
	while(!q.empty())
	{
		int p=q.front();q.pop();
		for(int e=efirst[p];e!=-1;e=enext[e])
		{
			if(pvis[u[e]]) continue;
			q.push(u[e]);
			pvis[u[e]]=true;
		}
	}
	for(int i=1;i<=n;i++)
	{
		if(!pvis[i])
			for(int e=efirst[i];e!=-1;e=next[e])
			{
				vis[u[e]]=false;
				vis[i]=false;
			}
	}
}

int dai(int x)
{
	if(d[x]!=INF) return d[x];
	for(int e = first[x];e!=-1;e=next[e])
	{
		if(vis[v[e]])
			d[x]=min(d[x],dai(v[e])+1);
	}
	return d[x];
}
