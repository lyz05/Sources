#include<iostream>
#include<fstream>
#include<algorithm>
#include<memory.h>
#include<string>
#include<stdlib.h>
using namespace std;
const int MAXN = 102;
long long a[MAXN];
int ans[MAXN];
int n,m;
int main()
{
	fstream file("equation.in",ios::in);
	file>>n>>m;
	memset(ans,-1,sizeof(ans));
	memset(a,0,sizeof(a));
	for(int i=0;i<=n;i++)
	{
		file>>a[i];
	}
	
	int sum = 0;
	for(int x=1;x<=m;x++)
	{
		long long p=a[n];
		for(int i=n-1;i>=0;i--)
		{
			p=p*x+a[i];
		}
		if(!p) 
		{
				ans[sum]=x;
				sum++;
		}
	}
	file.close();
	file.clear();
	file.open("equation.out",ios::out);
	file<<sum<<endl;
	if(sum==0) return 0;
	for(int i=0;i<sum-1;i++)
	{
		file<<ans[i]<<endl;
	}
	file<<ans[sum-1];
	file.close();
	return 0;
}



