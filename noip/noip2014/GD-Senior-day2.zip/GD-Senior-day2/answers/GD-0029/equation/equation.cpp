#include<iostream>
#include<fstream>
#include<cstdlib>
#include<string>
using namespace std;
ifstream fin("equation.in");
ofstream fout("equation.out");



int n,m;
int a[10000];
int ans[10000],gs=0;

int cf(int x,int z) {
	int temp=1;
	for(int i=0;i<z;++i) {
		temp=temp*x;
	}
	return temp;
}


int qiuhe(int x) {
	int he=0;
	for(int i=0;i<=n;++i) {
		he+=a[i]*cf(x,i);
	}
	return he;
}

int jdz(int x) {
	return x>0?x:-x;
}

struct shuzu {
	int ip[10001],ws;
	bool zs;
	void output() {
		for(int i=0;i<ws;++i)  {
			cout<<ip[i];
		}
	}
	void operator=(shuzu other) {
		ws=other.ws;
		for(int i=0;i<ws;++i) {
			ip[i]=other.ip[i];
		}
		return;
	}
	void input(string ss) {
		ws=ss.length();
		if(ss[0]=='-') {
			ws--;
			zs=false;
			for(int i=ws-1;i>0;--i) {
				ip[ws-i-1]=(ss[i]-'0');
			}
		}
		else {
			zs=true;
			for(int i=ws-1;i>=0;--i) {
				ip[ws-i-1]=(ss[i]-'0');
			}
		}
		
		return;
	}
	friend shuzu operator+(shuzu xx,shuzu xy) {
		if((xx.zs==true && xy.zs==true)||(xx.zs==false&&xy.zs==false)) {
			if(xx.ws>xy.ws) {
				int i;
				for(i=0;i<xy.ws;++i) {
					xx.ip[i]+=xy.ip[i];
					if(xx.ip[i]>=10) {
						xx.ip[i+1]=xx.ip[i]/10;
						xx.ip[i]=xx.ip[i]%10;
					}
				}
				while(xx.ip[i+1]>=10) {
					xx.ip[i+2]=xx.ip[i+1]/10;
					xx.ip[i+1]=xx.ip[i+1]%10;
				}
				return xx;
			}
			else {
				int i;
				for(i=0;i<xx.ws;++i) {
					xy.ip[i]+=xx.ip[i];
					if(xy.ip[i]>=10) {
						xy.ip[i+1]=xy.ip[i]/10;
						xy.ip[i]=xy.ip[i]%10;
					}
				}
				while(xx.ip[i+1]>=10) {
					xy.ip[i+2]=xy.ip[i+1]/10;
					xy.ip[i+1]=xy.ip[i+1]%10;
				}
				return xy;
			}
		}
		else {
			if(xx.ws>xy.ws) {
				int i;
				for(i=0;i<xy.ws;++i) {
					xx.ip[i]+=xy.ip[i];
					if(xx.ip[i]>=10) {
						xx.ip[i+1]=xx.ip[i]/10;
						xx.ip[i]=xx.ip[i]%10;
					}
				}
				while(xx.ip[i+1]>=10) {
					xx.ip[i+2]=xx.ip[i+1]/10;
					xx.ip[i+1]=xx.ip[i+1]%10;
				}
				return xx;
			}
			else {
				int i;
				for(i=0;i<xx.ws;++i) {
					xy.ip[i]+=xx.ip[i];
					if(xy.ip[i]>=10) {
						xy.ip[i+1]=xy.ip[i]/10;
						xy.ip[i]=xy.ip[i]%10;
					}
				}
				while(xx.ip[i+1]>=10) {
					xy.ip[i+2]=xy.ip[i+1]/10;
					xy.ip[i+1]=xy.ip[i+1]%10;
				}
				return xy;
			}
		}
		
		
		
    }
	friend shuzu operator*(shuzu f1,int f) {
		if(f==0) {
			f1.input("0");
			return f1;
		}
		
		for(int i=0;i<f1.ws;++i) {
			f1.ip[i]*=f;
		}
		for(int i=0;i<f1.ws-1;++i) {
			if(f1.ip[i]>=10) {
				f1.ip[i+1]+=f1.ip[i]/10;
				f1.ip[i]=f1.ip[i]%10;
			}
		}
		while(f1.ip[f1.ws-1]>=10) {
			f1.ip[f1.ws]=f1.ip[f1.ws-1]/10;
			f1.ip[f1.ws-1]=f1.ip[f1.ws-1]%10;
			f1.ws++;
		}
		if(f1.zs==false && f<0) {
			f1.zs==true;
		}
		else {
			f1.zs=f1.zs*((f/jdz(f)+1)/2);
		}
		return f1;
	}
	
	friend shuzu operator*(shuzu a,shuzu b) {
		shuzu c;
		c.input("0");
		for(int i=0;i<b.ws;++i) {
			c=c+(a*b.ip[i])*cf(10,i);
		}
		if(a.zs==false && b.zs==false) {
			c.zs=true;
		}
		else {
			c.zs=a.zs*b.zs;
		}
		return c;
	}
};



int main() {
	fin>>n>>m;
	for(int i=0;i<=n;++i) {
		fin>>a[i];
	}
	for(int i=1;i<=m;++i) {
		if(qiuhe(i)==0) {
			ans[gs]=i;
			gs++;
		}
	}
	fout<<gs<<endl;
	for(int i=0;i<gs;++i) {
		fout<<ans[i]<<endl;
	}
    return 0;
}
