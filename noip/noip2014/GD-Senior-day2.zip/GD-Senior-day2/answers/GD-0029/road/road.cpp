#include<iostream>
#include<fstream>
#include<cstdlib>
#include<string>
using namespace std;
ifstream fin("road.in");
ofstream fout("road.out");

struct ddot {
	int next[10000],last[10000];
	int gs,lgs;
	
	void output() {
		cout<<gs<<" "<<lgs<<endl;
		for(int i=0;i<gs;++i) {
			cout<<next[i]<<" ";
		}
		cout<<endl;
		for(int i=0;i<lgs;++i) {
			cout<<last[i]<<"  "; 
		}
		cout<<endl<<"*"<<endl;
	}
	
};


ddot dot[10000];
bool ot[10000];
int n,m;
int s,t;



void cut(int id) {
	if(id==s) {
		return;
	}
	
	if(dot[id].lgs==1) {
		return;
	}
	for(int i=1;i<=dot[id].lgs;++i) {
		ot[dot[id].last[i]]=true;
		cut(dot[id].last[i]);
	}
	return;
}

void cut2(int id) {
	if(id==t) {
		return;
	}
	
	if(dot[id].gs==1) {
		return;
	}
	for(int i=1;i<=dot[id].gs;++i) {
		if(ot[dot[id].next[i]]==false) {
			ot[id]=false;
		}
		cut2(dot[id].next[i]);
	}
	return;
}



int qiuzhi(int id) {
	int chalu[10000];
	int miner=1000000;
	if(id==t) {
		return 0;
	}
	else {
		if(dot[id].gs==1) {
			return -1;
		}
		
		for(int i=1;i<=dot[id].gs;++i) {
			if(ot[dot[id].next[i]]) {
				chalu[i]=qiuzhi(dot[id].next[i]);
				if(miner>chalu[i] && chalu[i]>=0) {
					miner=chalu[i];
				}
			}
		}
		return miner+1;
	}
}




int main() {
	fin>>n>>m;
	int temp1,temp2;
	for(int i=1;i<=n;++i) {
		dot[i].gs=1;
		dot[i].lgs=1;
		ot[i]=false;
	}
	for(int i=1;i<=m;++i) {
		fin>>temp1>>temp2;
		dot[temp1].next[dot[temp1].gs]=temp2;
		dot[temp1].gs++;
		dot[temp2].last[dot[temp2].lgs]=temp1;
		dot[temp2].lgs++;
	}
    fin>>s>>t;
    cut(t);
    cut2(s);
    int ttp=qiuzhi(s);
    if(ttp>=100000) {
    	fout<<-1;
    }
    else {
    	fout<<ttp;
    }
    return 0;
}
