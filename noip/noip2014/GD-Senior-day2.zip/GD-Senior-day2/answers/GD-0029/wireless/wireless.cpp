#include<iostream>
#include<fstream>
#include<cstdlib>
#include<string>
using namespace std;
ifstream fin("wireless.in");
ofstream fout("wireless.out");



int d,n;
int xyk[20][3];

int jdz(int x) {
	return x>0?x:-x;
}


int search(int i,int j) {
	int geshu=0;
	for(int ii=0;ii<n;++ii) {
		if(jdz(i-xyk[ii][0])<=d && jdz(j-xyk[ii][1])<=d) {
			geshu+=xyk[ii][2];
		}
	}
	return geshu;
}



int main() {
	//input
    fin>>d>>n;
    int i,j;
    for(i=0;i<n;++i) {
    	fin>>xyk[i][0]>>xyk[i][1]>>xyk[i][2];
    }
    //input
    int temp,time=1,maxer=0;
    for(i=d;i<128-d;++i) {
    	for(j=d;j<128-d;++j) {
    		temp=search(i,j);
    		if(temp>maxer) {
    			maxer=temp;
    			time=1;
    		}
    		else if(temp==maxer) {
    			time++;
    		}
    	}
    }
    fout<<time<<" "<<maxer;
    return 0;
}
