#include <cstdio>
#include <cstring>
#include <iostream>
#include <cmath>
#include <algorithm>
#include <vector>
#include <queue>

using namespace std;

const int MAXN = 10001;
const int INF = 10000001;

int n,m,s,t;
int dist[MAXN];
bool inq[MAXN];
bool flag[MAXN];
vector <int> G[MAXN];
vector <int> M[MAXN];


void spfa_G(int s)
{
	memset(inq,false,sizeof(inq));
	for (int i=1;i<=n;i++) dist[i] = INF;
	queue <int> Q; Q.push(s);
	inq[s] = true; dist[s] = 0;
	while (!Q.empty())
	{
		int u = Q.front();Q.pop();
		inq[u] = false;
		for (int i=0;i<G[u].size();i++) if (dist[G[u][i]] > dist[u]+1)
		{
			dist[G[u][i]] = dist[u]+1;
			if (!inq[G[u][i]]) 
			{
				inq[G[u][i]] = true;
				Q.push(G[u][i]);
			}
		}
	}
}

void spfa_M(int s)
{
	memset(inq,false,sizeof(inq));
	for (int i=1;i<=n;i++) dist[i] = INF;
	queue <int> Q; Q.push(s);
	inq[s] = true; dist[s] = 0;
	while (!Q.empty())
	{
		int u = Q.front();Q.pop();
		inq[u] = false;
		for (int i=0;i<M[u].size();i++) if (dist[M[u][i]] > dist[u]+1)
		{
			dist[M[u][i]] = dist[u]+1;
			if (!inq[M[u][i]]) 
			{
				inq[M[u][i]] = true;
				Q.push(M[u][i]);
			}
		}
	}
}

void delete_road()
{
	memset(flag,true,sizeof(flag));
	queue <int> Q;
	for (int i=1;i<=n;i++) if (dist[i] == INF) 
	{
		flag[i] = false;
		for (int j=0;j<G[i].size();j++) flag[G[i][j]] = false;
	}
	for (int i=1;i<=n;i++) if (flag[i])
	    for (int j=0;j<G[i].size();j++) if (flag[G[i][j]]) M[G[i][j]].push_back(i);
}

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=m;i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		G[v].push_back(u);
	}
	scanf("%d%d",&s,&t);
	spfa_G(t);
	delete_road();
	spfa_M(s);
	if (dist[t] == INF) printf("-1\n");else printf("%d\n",dist[t]);
	return 0;
}
