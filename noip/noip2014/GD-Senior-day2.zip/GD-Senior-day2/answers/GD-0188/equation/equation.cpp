#include <cstdio>
#include <cstring>
#include <iostream>
#include <cmath>
#include <algorithm>

using namespace std;

const int MAXN = 110;
const int MAXLEN = 100001;

int n,m;
int root[MAXN];

struct BigNum
{
	int oper;
	int len;
	int bit[MAXLEN];
	bool operator < (const BigNum &rhs) const
	{
		if (len != rhs.len) return len < rhs.len;
		for (int i=len;i>=1;i++) if (bit[i] != rhs.bit[i]) return bit[i] < rhs.bit[i];
	}
};

BigNum a[MAXN];
BigNum ans,X,c;

BigNum operator * (BigNum a,BigNum b)
{
	int l = a.len+b.len-1;
	c.oper = a.oper;
	c.len = 0;
	memset(c.bit,0,sizeof(c.bit));
	for (int i=1;i<=a.len;i++)
	    for (int j=1;j<=b.len;j++) c.bit[i+j-1] = a.bit[i]*b.bit[j];
	for (int i=1;i<=l;i++)
	{
		c.bit[i+1] += c.bit[i]/10;
		c.bit[i] %= 10;
	}
	if (c.bit[l+1]) l++;
	c.len = l;
	return c;
}

BigNum operator - (BigNum a,BigNum b)
{
	int l = max(a.len,b.len);
	memset(c.bit,0,sizeof(c.bit));
	c.oper = c.len = 0;
	if (a < b) 
	{
		c.oper = 1;
		swap(a,b);
	}
	for (int i=1;i<=l;i++) c.bit[i] = a.bit[i]-b.bit[i];
	for (int i=1;i<=l;i++) if (c.bit[i] < 0)
	{
		c.bit[i] += 10;
		c.bit[i+1]--;
	}
	while (!c.bit[l] && l != 0) l--;
	c.len = l;
	return c;
}

BigNum operator + (BigNum a,BigNum b)
{
	if (a.oper == 1) return b-a;
	int l = max(a.len,b.len);
	c.oper = c.len = 0;
	memset(c.bit,0,sizeof(c.bit));
	for (int i=1;i<=l;i++) c.bit[i] = a.bit[i]+b.bit[i];
	for (int i=1;i<=l;i++)
	{
		c.bit[i+1] += c.bit[i]/10;
		c.bit[i] %= 10;
	}
	if (c.bit[l+1]) l++;
	c.len = l;
	return c;
}
void prepare()
{
	char ch[1001];
	for (int i=0;i<=n;i++) 
	{
		scanf("%s",ch);		
		if (ch[0] == '-') a[i].oper = 1;
		if (ch[0] == '-') 
		{
			for (int j=1;j<strlen(ch);j++) a[i].bit[strlen(ch)-j] = ch[j]-'0'; 
			a[i].len = strlen(ch)-1;
		}
		else
		{
			for (int j=0;j<strlen(ch);j++) a[i].bit[strlen(ch)-j] = ch[j]-'0';
			a[i].len = strlen(ch);
		}
	}
}

BigNum f(int x)
{
    memset(ans.bit,0,sizeof(ans.bit));
    memset(X.bit,0,sizeof(X.bit));
	X.bit[1] = x;X.len = 1;
	for (int i=n;i>=0;i--) 
	{
		if (a[i].oper == 0) ans = ans*X+a[i];
		else ans = ans*X-a[i];
	}
	return ans;
}

int main()
{
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	scanf("%d%d",&n,&m);
	prepare();
	int count = 0;
	for (int i=1;i<=m;i++) 
	{
		BigNum temp = f(i);
		if (temp.len == 0 && temp.bit[1] == 0) root[++count] = i;
	} 
	printf("%d\n",count);
	for (int i=1;i<=count;i++) printf("%d\n",root[i]);
	return 0;
}
