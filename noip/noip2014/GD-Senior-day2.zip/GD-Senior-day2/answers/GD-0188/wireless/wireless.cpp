#include <cstdio>
#include <cstring>
#include <iostream>
#include <cmath>
#include <algorithm>

using namespace std;

const int MAXN = 200;

int d,n;
int map[MAXN][MAXN];

int count(int x1,int y1,int x2,int y2)
{
    int ret = 0;
    for (int i=x1;i<=x2;i++)
        for (int j=y1;j<=y2;j++) ret += map[i][j];
    return ret;
}

int main()
{
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	scanf("%d",&d);
	scanf("%d",&n);
	for (int i=1;i<=n;i++)
	{
		int x,y,k;
		scanf("%d%d%d",&x,&y,&k);
		map[x][y] = k;
	}
	int _max = 0,total = 0;
	for (int i=0;i<=128;i++)
	    for (int j=0;j<=128;j++) 
	    {
	    	int temp = count(max(0,i-d),max(0,j-d),min(128,i+d),min(128,j+d));
	    	if (temp > _max)
	    	{
	    		_max = temp;
				total = 1;
	    	}
	    	else if (temp == _max) total++;
	    }
	printf("%d %d\n",total,_max);
	return 0;
}
