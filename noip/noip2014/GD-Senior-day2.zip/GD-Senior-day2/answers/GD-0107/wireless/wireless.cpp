#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstring>
using namespace std;
const int N = 25;

struct Node
{
	int x, y, Cnt;
} a[N];
int D, n, ResCnt, Res;

int main()
{
	freopen( "wireless.in", "r", stdin );
	freopen( "wireless.out", "w", stdout );
	ios :: sync_with_stdio( 0 );
	cin >> D >> n;
	for ( int i=0; i<n; ++i ) 
		cin >> a[i].x >> a[i].y >> a[i].Cnt;
	for ( int x=0; x<129; ++x )
		for ( int y=0; y<129; ++y )
		{
			int Cnt = 0;
			for ( int i=0; i<n; ++i )
			{
				if ( a[i].x<x-D || a[i].x>x+D ) continue;
				if ( a[i].y<y-D || a[i].y>y+D )	continue;
				Cnt += a[i].Cnt;
			}
			if ( Cnt>Res ) Res = Cnt, ResCnt = 1;
			else if ( Cnt==Res ) ++ResCnt;
		}
	cout << ResCnt << " " << Res << endl;
 	fclose( stdin ); fclose( stdout );
	return 0;
}

