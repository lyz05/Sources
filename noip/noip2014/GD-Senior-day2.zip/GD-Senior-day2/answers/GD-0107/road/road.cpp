#include <cstdio>
#include <algorithm>
#include <cstring>
#include <utility>
#include <vector>
#include <set>
using namespace std;
const int N = 10005;

#define mkp( A, B ) make_pair( A, B )
#define _x first
#define _y second

set < pair< int, int > > SET;
vector < int > e[N], _e[N];
int que[N], Dis[N];
int n, m, S, T;
bool Ava[N];

void preprocessing()
{
	scanf( "%d%d", &n, &m );
	for ( int i=0, x, y; i<m; ++i )
	{
		scanf( "%d%d", &x, &y );
		if ( x==y /*|| SET.find( mkp( x, y ) )!=SET.end()*/ ) continue;
		//SET.insert( mkp( x, y ) );
		e[x].push_back( y ), _e[y].push_back( x );
	}
	scanf( "%d%d", &S, &T );
	Ava[ que[0] = T ] = 1; int hd=0, tl=1;
	for ( int hd=0, tl=1, x=T; hd<tl; x=que[ ++hd ] )
		for ( int j=0; j<_e[x].size(); ++j )
		{
			if ( Ava[ _e[x][j] ] ) continue;
			Ava[ que[ tl++ ] = _e[x][j] ] = 1;
		}
	tl = 0;
	for ( int i=1; i<=n; ++i )
		if ( !Ava[i] ) que[ tl++ ] = i;
	for ( int i=0; i<tl; ++i )
		for ( int j=0; j<_e[ que[i] ].size(); ++j )
			Ava[ _e[ que[i] ][j] ] = 0;
}

int solve()
{
	if ( !Ava[S] ) return -1;
	fill( Dis, Dis + N, N ); Dis[S] = 0;
	for ( int hd=0, tl=1, x=S; hd<tl; x=que[ ++hd ] )
		for ( int j=0; j<e[x].size(); ++j )
		{
			if ( Dis[ e[x][j] ] < N || !Ava[ e[x][j] ] ) continue;
			Dis[ que[ tl++ ] = e[x][j] ] = Dis[x] + 1;
		}
	if ( Dis[T]==N ) return -1;
	else return Dis[T];
}
	
int main()
{
	freopen( "road.in", "r", stdin );
	freopen( "road.out", "w", stdout );
	preprocessing();
	printf( "%d\n", solve() );
	fclose( stdin ); fclose( stdout );
	return 0;
}

