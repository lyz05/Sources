#include<cstring>
#include<iomanip>
#include<fstream>
#include<cmath>
#include<cstdio>
#include<cstdlib>
using namespace std;
ifstream cin("wireless.in");
ofstream cout("wireless.out");
long a[200][200],n,d;
long long maxx,ans,sum;
int main()
{
	long i,j,k,s,t,b,c,e,f;
	ios::sync_with_stdio(false);
	memset(a,0,sizeof(a));
	cin>>d>>n;
	for (i=1;i<=n;i++)
	{
		cin>>j>>k>>s;
		a[j][k]=s;
	}
	maxx=ans=0;
	for (i=0;i<=128;i++)
		for (j=0;j<=128;j++)
		{
			s=i-d;if (s<0)	s=0;
			t=i+d;if (t>128)	t=128;
			b=j-d;if (b<0)	b=0;
			c=j+d;if (c>128)	c=128;
			sum=0;
			for (e=s;e<=t;e++)
				for (f=b;f<=c;f++)
					sum+=a[e][f];
			if (sum>maxx)	{	maxx=sum;ans=1;	}
			else
				if (sum==maxx)	ans++;
		}
	cout<<ans<<' '<<maxx;
	cin.close();cout.close();
return 0;	
}