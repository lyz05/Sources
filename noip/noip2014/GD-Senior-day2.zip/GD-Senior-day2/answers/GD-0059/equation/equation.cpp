#include<cstring>
#include<iomanip>
#include<fstream>
#include<cmath>
#include<cstdio>
#include<cstdlib>
using namespace std;
ifstream cin("equation.in");
ofstream cout("equation.out");
long a[305],b[305][305],len[305],l,l2,c[305],d[305],e[305],g[305],v[305],lo[305],n,m,ans=0;
char ch[305];
void doit()
{
	long i,j,s,t;
	memset(d,0,sizeof(d));
	s=t=300;
	while (s>0 && a[s]==0)	s--;
	while (t>0 && e[t]==0)	t--;
	for (i=1;i<=s;i++)
		for (j=1;j<=t;j++)
		{
			d[i+j-1]+=a[i]*e[j];
			d[i+j]+=d[i+j-1]/10;
			d[i+j-1]=d[i+j-1]%10;
		}
	memcpy(e,d,sizeof(d));
}
void doit2(long k)
{
	long i,j,s,t;
	memset(d,0,sizeof(d));
	s=t=300;
	while (s>0 && b[k][s]==0)	s--;
	while (t>0 && e[t]==0)	t--;
	for (i=1;i<=s;i++)
		for (j=1;j<=t;j++)
		{
			d[i+j-1]+=b[k][i]*e[j];
			d[i+j]+=d[i+j-1]/10;
			d[i+j-1]=d[i+j-1]%10;
		}
	memcpy(v,d,sizeof(d));
}
void add(long z)
{
	long i,s,t;
	memset(d,0,sizeof(d));
	s=t=300;
	while (s>0 && v[s]==0)	s--;
	while (t>0 && c[t]==0)	t--;
	if (s<t)	s=t;
	if (lo[z]==0)
	{
		for (i=1;i<=s;i++)
		{
			d[i]+=v[i]+c[i];
			d[i+1]+=d[i]/10;
			d[i]=d[i]%10;
		}
		d[s+2]+=d[s+1]/10;
		d[s+1]=d[s+1]%10;
	}
	else
	{
		for (i=1;i<=s;i++)
		{
			d[i]=c[i]-v[i];
			if (d[i]<0)
			{
				d[i]+=10;
				d[i+1]-=1;
			}
		}
	}
	memcpy(c,d,sizeof(d));
}
bool check()
{
	long i;
	i=500;
	while (i>0	&&	c[i]==0)	i--;
	if (i>0)	return false;
	else return true;
}
int main()
{
	long i,j,a2,b2,c2;
	ios::sync_with_stdio(false);
	cin>>n>>m;
	if (n==2)
	{
		cin>>c2>>b2>>a2;
		for (i=1;i<=m;i++)
			if (a2*i*i+b2*i+c2==0)	ans++;
		cout<<ans<<endl;
		for (i=1;i<=m;i++)
			if (a2*i*i+b2*i+c2==0)	cout<<i<<endl;
	}
	else
		if (n==1)
		{
			cin>>b2>>a2;
			for (i=1;i<=m;i++)
				if (a2*i+b2==0)	ans++;
			cout<<ans<<endl;
			for (i=1;i<=m;i++)
				if (a2*i+b2==0)	cout<<i<<endl;
		}
		else
		{
			memset(b,0,sizeof(b));
			memset(c,0,sizeof(c));
			memset(d,0,sizeof(d));
			memset(v,0,sizeof(v));
			memset(g,0,sizeof(g));
			memset(lo,0,sizeof(lo));
			for (i=1;i<=n+1;i++)
			{
				cin>>ch;
				len[i]=strlen(ch);
				if (ch[0]=='-')
				{
					lo[i]=1;
					for (j=len[i];j>1;j--)	b[i][len[i]-j+1]=ch[j-1]-'0';
				}
				else	for (j=len[i];j>=1;j--)	b[i][len[i]-j+1]=ch[j-1]-'0';
			}
			for (i=1;i<=m;i++)
			{
				memset(a,0,sizeof(a));
				l=0;
				j=i;
				while (j>0)
				{
					l++;
					a[l]=j%10;
					j=j/10;
				}
				memcpy(c,b[1],sizeof(b[1]));
				memset(e,0,sizeof(e));
				e[1]=1;
				for (j=2;j<=n+1;j++)
				{
					doit();
					doit2(j);
					add(j);
				}
				if (check())
				{
					ans++;
					g[ans]=i;
				}
			}
			cout<<ans<<endl;
			for (i=1;i<=ans;i++)	cout<<g[i]<<endl;
		}
cin.close();cout.close();
return 0;	
}