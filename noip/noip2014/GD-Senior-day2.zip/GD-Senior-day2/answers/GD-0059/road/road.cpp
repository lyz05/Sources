#include<cstring>
#include<iomanip>
#include<fstream>
#include<cmath>
#include<cstdio>
#include<cstdlib>
using namespace std;
ifstream cin("road.in");
ofstream cout("road.out");
struct yjw
{
	long y,next;
}a[200005],b[200005];
bool q[10005],o[10005];
long n,m,c,d,h[10005],dist[10005],tot,tot2,h2[10005],line[20000],l,r;
void add(long i,long j)
{
	tot++;
	a[tot].y=j;
	a[tot].next=h[i];
	h[i]=tot;
}
void add2(long i,long j)
{
	tot2++;
	b[tot2].y=j;
	b[tot2].next=h2[i];
	h2[i]=tot2;
}
int main()
{
	long i,j,k;
	ios::sync_with_stdio(false);
	memset(h,0,sizeof(h));
	memset(h2,0,sizeof(h2));
	memset(q,false,sizeof(q));
	memset(line,0,sizeof(line));
	cin>>n>>m;
	for (i=1;i<=m;i++)
	{
		cin>>j>>k;
		if (j!=k)
		{
			add(j,k);
			add2(k,j);
		}
	}
	cin>>c>>d;
	line[1]=d;q[d]=true;
	l=1;r=2;
	while (l!=r)
	{
		i=line[l];
		j=h2[i];
		while (j>0)
		{
			if (!q[b[j].y])
			{
				q[b[j].y]=true;
				line[r]=b[j].y;
				r++;
			}
			j=b[j].next;
		}
		l++;
	}
	for (i=1;i<=n;i++)
		if (!q[i])
		{
			j=h2[i];
			while (j>0)
			{
				q[b[j].y]=false;
				j=b[j].next;
			}
		}
	if (!q[c])	cout<<"-1";
	else
	{
		memset(line,0,sizeof(line));
		memset(o,false,sizeof(o));
		memset(dist,-1,sizeof(dist));
		l=1;r=2;
		line[1]=c;o[c]=true;
		dist[c]=0;
		while (l!=r)
		{
			i=line[l];
			o[i]=false;
			j=h[i];
			while (j>0)
			{
				if (q[a[j].y])
					if (dist[a[j].y]==-1 || dist[i]+1<dist[a[j].y])
					{
						dist[a[j].y]=dist[i]+1;
						if (!o[a[j].y] && (dist[d]==-1 || dist[a[j].y]<dist[d]))	
						{	
							o[a[j].y]=true;
							line[r]=a[j].y;
							r++;
							if (r>19500)	r=1;
						}
					}
				j=a[j].next;
			}
			l++;
			if (l>19500)	l=1;
		}
		cout<<dist[d];
	}
	cin.close();cout.close();
	return 0;
}