#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#define ms(x,y) memset(x,y,sizeof(x))
#define fo(i,a,b) for(int i=a;i<=b;i++)
using namespace std;

const int N = 205;
int n , d;
int a[N][N] , sum[N][N];

void Init()
{
	scanf("%d",&d);
	scanf("%d",&n);
	fo(i,1,n)
	{
		int x,y,z;
		scanf("%d%d%d",&x,&y,&z);
		x++ , y++;
		a[x][y] += z;
	}
	
	fo(i,1,129)
		fo(j,1,129)
		sum[i][j] = sum[i-1][j] + sum[i][j-1] - sum[i-1][j-1] + a[i][j];
}

void Work()
{
	int big = 0 , many = 0;
	fo(i,1,129)
		fo(j,1,129)
		{
			int l = max(i-d , 1) , r = min(129 , i+d);
			int up = max(j-d, 1) , down = min(129 , j+d);
			int add = sum[down][r] - sum[down][l-1] - sum[up-1][r] + sum[up-1][l-1];
			if (add > big)
			{
				big = add; many = 1;
			} else 
			if (add == big) many++;
		}
	printf("%d %d",many,big);
}

int main()
{
	freopen("wireless.in","r",stdin); freopen("wireless.out","w",stdout);
	
	Init();
	Work();
	
	return 0;
}
