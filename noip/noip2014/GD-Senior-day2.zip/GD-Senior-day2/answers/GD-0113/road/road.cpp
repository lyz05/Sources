#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
#define ms(x,y) memset(x,y,sizeof(x))
#define fo(i,a,b) for(int i=a;i<=b;i++)
using namespace std;

const int maxlong = int(1e9);
const int N = int(4e5)+5;
int adj[N] , next[N] , g[N] , antiadj[N] , antinext[N] , antig[N] , tot , antitot;
int n , m , s , t , bf[N] , d[N];
bool anti[N] , v[N] , ok[N];

void ins(int x,int y)
{
	adj[++tot]=y; next[tot]=g[x]; g[x]=tot;
}

void antiins(int x,int y)
{
	antiadj[++antitot]=y; antinext[antitot]=antig[x]; antig[x]=antitot;
}

void Init()
{
	scanf("%d%d",&n,&m);
	fo(i,1,m)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		ins(x,y); antiins(y,x);
	}
	scanf("%d%d",&s,&t);
}

void antidfs(int x)
{
	anti[x] = 1;
	for(int p=antig[x];p!=0;p=antinext[p])
	if (!anti[antiadj[p]]) antidfs(antiadj[p]);
}

void spfa()
{
	fo(i,1,n) d[i] = maxlong;
	if (!ok[s]) return;
	ms(v,1);
	v[s] = 0; d[s] = 0;
	bf[1] = s;
	int i = 0 , j = 1;
	while (i!=j)
	{
		i++;if(i==N)i=1;
		int x = bf[i];
		for(int p=g[x];p!=0;p=next[p])
		if (ok[adj[p]] && d[adj[p]] > d[x] + 1)
		{
			d[adj[p]] = d[x] + 1;
			if (v[adj[p]])
			{
				v[adj[p]]=0;
				j++;if(j==N)j=1;
				bf[j]=adj[p];
			}
		}
		v[x]=1;
	}
}

void Work()
{
	ms(anti,0);
	antidfs(t);
	ms(ok,0);
	fo(i,1,n)
	{
		ok[i] = 1;
		for(int p=g[i];p!=0;p=next[p])
		ok[i] &= anti[adj[p]];
	}
	
	spfa();
	if (d[t] == maxlong) puts("-1");else printf("%d\n",d[t]);
}

int main()
{
	freopen("road.in","r",stdin); freopen("road.out","w",stdout);
	
	Init();
	Work();
	
	return 0;
}
