#include<cstdio>
#include<cstring>
#include<algorithm>
#define fo(i,a,b) for(int i=a;i<=b;i++)
using namespace std;

const int N = 105;
int n , m;
int a[N][N*N] , ans[N] , k[N*N] , c[N*N] , sum[N*N] , t[N*N] , sum1[N*N] , aa[N];
bool ok[N];
char s[N*N];

void Init()
{
	scanf("%d%d",&n,&m);
}

void mul(int *a,int *b)
{
	fo(i,1,a[0]+b[0]) c[i]=0;
	fo(i,1,a[0])
		fo(j,1,b[0])
		c[i+j-1] += a[i]*b[j];
	c[0]=a[0]+b[0]-1;
	fo(i,1,c[0])
	{
		c[i+1]+=c[i]/10;
		c[i]%=10;
	}
	if (c[c[0]+1]) c[0]++;
	a[0]=c[0];
	fo(i,1,a[0]) a[i]=c[i];
}

void mul(int *a,int b)
{
	fo(i,1,a[0]) a[i]*=b;
	fo(i,1,a[0])
	{
		a[i+1]+=a[i]/10;
		a[i]%=10;
	}
	a[0]++;
	while (a[a[0]]>=10)
	{
		a[a[0]+1]+=a[a[0]]/10;
		a[a[0]]%=10;
		a[0]++;
	}
	if (!a[a[0]])--a[0];
}

void add(int *a,int *b)
{
	fo(i,1,max(a[0],b[0])+1) c[i]=0;
	fo(i,1,max(a[0],b[0]))
	{
		c[i]+=a[i]+b[i];
		c[i+1]+=c[i]/10;
		c[i]%=10;
	}
	c[0]=max(a[0],b[0]);
	if (c[c[0]+1]) c[0]++;
	a[0]=c[0];
	fo(i,1,a[0]) a[i]=c[i];
}

bool compare(int *a,int *b)
{
	fo(i,0,a[0]) if (a[i]!=b[i]) return 0;
	return 1;
}

void Work()
{
	fo(i,0,n)
	{
		scanf("%s",s+1); 
		a[i][0] = strlen(s+1);
		int st;
		if (s[1]=='-')st=2;else st=1;
		fo(j,st,a[i][0]) a[i][a[i][0]-j+1] = s[j]-'0';
		if (st==2) ok[i]=1 , a[i][0]--;
	}
	
	fo(x,1,m)
	{
		fo(j,1,k[0]) k[j]=0; 
		fo(j,1,sum[0]) sum[j]=0; 
		fo(j,1,sum1[0]) sum1[j]=0;
		k[0]=1;k[1]=1;
		sum[0]=1;sum[1]=0;
		sum1[0]=1;sum1[1]=0;
		fo(i,0,n)
		{
			fo(j,1,t[0]) t[j]=0;
			t[0]=k[0];
			fo(j,1,t[0]) t[j]=k[j];
			mul(t,a[i]);
			if (!ok[i])add(sum,t);else add(sum1,t);
			mul(k,x);
		}
		if (compare(sum,sum1)) ans[++ans[0]]=x;
	}
	printf("%d\n",ans[0]);
	fo(i,1,ans[0]) printf("%d\n",ans[i]);
}

void work()
{
	fo(i,0,n) scanf("%d",&aa[i]);
	fo(x,1,m)
	{
		long long k = 1 , sum = 0;
		fo(i,0,n) sum += k*aa[i] , k*=x;
		if (!sum) ans[++ans[0]] = x;
	}
	printf("%d\n",ans[0]);
	fo(i,1,ans[0]) printf("%d\n",ans[i]);
}

int main()
{
	freopen("equation.in","r",stdin); freopen("equation.out","w",stdout);
	
	Init();
	if (n>2)Work();else work();
	
	return 0;
}
