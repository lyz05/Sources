#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>

const int maxn=5000;
const int maxl=300000;
bool link[maxn+10][maxn+10],reach[maxn+10];
int st[maxn+10];
int s,t,n,m;

void dfs1(int prev) {
	int i;
	for(i=1;i<=n;i++) 
		if(link[i][prev]&&reach[i]==0) {
			reach[i]=1;
			dfs1(i);
		}
}

void dfs2(int now,int time) {
	int i;
	for(i=1;i<=n;i++) {
		if(link[now][i]&&reach[i]&&st[i]>time+1) {
			st[i]=time+1;
			dfs2(i,time+1);
		}
	}
}

int main() {
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int i,j,x,y;
	memset(link,0,sizeof(link));
	memset(reach,0,sizeof(reach));
	scanf("%d%d",&n,&m);
	for(i=1;i<=m;i++) {
		scanf("%d%d",&x,&y);
		if(x!=y) link[x][y]=1;
	}
	scanf("%d%d",&s,&t);
	reach[t]=1;
	dfs1(t);
	for(i=1;i<=n;i++) {
		st[i]=maxl;
		for(j=1;j<=n;j++)
			if(reach[i]==0&&link[j][i])
				reach[j]=0;
	}
	st[s]=0;
	dfs2(s,0);
	if(st[t]==maxl) 
		printf("-1\n");	
	else printf("%d\n",st[t]);
	return 0;
}
