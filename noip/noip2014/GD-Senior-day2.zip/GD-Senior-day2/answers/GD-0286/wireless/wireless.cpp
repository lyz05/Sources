#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>

const int MAXN=128;
int rs[MAXN+5][MAXN+5];
int main() {
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	int d,n,i;
	memset(rs,0,sizeof(rs));
	scanf("%d%d",&d,&n);
	for(i=1;i<=n;i++) {
		int x,y,g,j;
		scanf("%d%d%d",&x,&y,&g);
		for(j=y;j>=0;j--) {
			rs[x][j]=rs[x][j]+g;
		}
	}
	
	int max=0; int num=0;
	for(i=0;i<=MAXN-2*d;i++) {
		int j,k;
		for(j=0;j<=MAXN-2*d;j++) {
			int f=0;
			for(k=i;k<=i+2*d;k++) {
				f=f+(rs[k][j]-rs[k][j+2*d+1]);
			}
			//printf("%d %d %d %d %d\n",i,j,f,max,num);
			if(f>max) {
				max=f; num=1;
			}
			else if(f==max&&max!=0) {
				num++;
			}
		}
	}
	printf("%d %d\n",num,max);
	return 0;
}
