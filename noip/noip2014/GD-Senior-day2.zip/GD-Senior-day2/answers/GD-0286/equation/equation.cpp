#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
const int maxn=10;
int a[maxn+5];
int sl[maxn+5];

int cf(int x,int times) {
	int i,d=1;
	for(i=1;i<=times;i++) {
		d*=x;
	}
	return d;
}

int main() {
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	//30% program
	int n,m,i,j,num=0;
	scanf("%d%d",&n,&m);
	if(n>2) {
		printf("0");
		return 0;
	}
	for(i=0;i<=n;i++) {
		scanf("%d",&a[i]);
	}
	
	memset(sl,0,sizeof(sl));
	for(i=1;i<=m;i++) {
		int d=a[0];
		for(j=1;j<=n;j++) {
			d+=cf(i,j)*a[j];
			//printf("%d %d %d\n",i,j,d);
		}
		if(d==0) {
			num++;
			sl[num]=i;
		}
	}
	
	printf("%d\n",num);
	for(i=1;i<=num;i++) {
		printf("%d\n",sl[i]);
	}
	return 0;
}
