#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#define MAXX 128

int a[MAXX+10][MAXX+10];
int n, d;
using namespace std;

int sum(int x, int y)
{
    int x1=x-d, x2=x+d, y1=y-d, y2=y+d;
    if (x1<0) x1=0; if (y1<0) y1=0;
    if (x2>MAXX) x2=MAXX; if (y2>MAXX) y2=MAXX;
    int s=0;
    for (int i=x1; i<=x2; i++)
    	for (int j=y1; j<=y2; j++)
		s+=a[i][j];	
    return s;
}

int main()
{
	freopen("wireless.in", "r", stdin);
	freopen("wireless.out", "w", stdout);
	scanf("%d%d", &d, &n);
	memset(a, 0, sizeof(a));
	for (int i=1; i<=n; i++)
	{
	     int x, y;
	     scanf("%d%d", &x, &y);
	     scanf("%d", &a[x][y]);
	}
	
	int ans=0, num=0;
	for (int i=0; i<=MAXX; i++)
	{
	     for (int j=0; j<=MAXX; j++)
	     {
		  int p=sum(i, j);
	     	  if (p>ans) 
		  {
	               ans=p;
		       num=1;
		  }else
		  if (p==ans) num++;
	     }
	}
	printf("%d %d", num, ans);
	return 0;
}

