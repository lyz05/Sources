#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<vector>
#include<set>
#include<queue>
#define MAXN 10100

using namespace std;
struct node{
	int d, f;
};
set<int> s;
vector<int> G[MAXN], G2[MAXN], G3[MAXN];
bool v[MAXN];
queue<node> q;

void dfs(int k)
{
	if (v[k]) return;
	v[k]=true;
	int lenn=G2[k].size();
	for (int i=0; i<lenn; i++)
	{
		int p=G2[k][i];
		G[p].push_back(k);
		dfs(p);	
	}
	v[k]=false;
	return;
}

int main()
{
	freopen("road.in",  "r", stdin);
	freopen("road.out", "w", stdout);
	int n, m, s, t;
	scanf("%d%d", &n,  &m);
	for (int i=1; i<=m; i++)
	{
		int x, y;
		scanf("%d%d", &x, &y);
		G2[y].push_back(x);
		G3[x].push_back(y);
	}
	scanf("%d%d", &s, &t);
	memset(v, 0, sizeof(v));
	dfs(t);
	for (int i=1; i<=n; i++)
	{
		int lenn=G[i].size();
		for (int j=0; j<lenn; j++)
			printf("%d -> %d\n", i, G[i][j]); 
	}
	printf("\n");
	for (int i=1; i<=n; i++)
	{
		int lenn=G3[i].size();
		for (int j=0; j<lenn; j++)
			printf("%d -> %d\n", i, G3[i][j]); 
	}


	bool bk=false;
	q.push((node){s, 0});
	while (!q.empty())
	{
		node x=q.front(); q.pop();
		if (x.d==t) 
		{
			printf("%d\n", x.f);
			bk=true;
			break;
		}
		if (G[x.d].size()!=G3[x.d].size()) continue;
		int lenn=G[x.d].size();
		for (int i=0; i<lenn; i++)
			q.push((node){G[x.d][i], x.f+1});
	}
	if (!bk) printf("-1\n");
	return 0;
}

