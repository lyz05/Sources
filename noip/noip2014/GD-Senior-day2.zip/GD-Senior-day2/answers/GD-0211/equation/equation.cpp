#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<vector>

using namespace std;

int a[110];
vector<int>ans;
int n, m;
bool pd(int k)
{
	long long s=a[0], p=1;
	for (int i=1; i<=n; i++)
	{
		p*=k;
		s+=a[i]*p;
	}
	if (s==0) return 1; 
	return 0;
}

int main()
{
	freopen("equation.in", "r", stdin);
	freopen("equation.out", "w", stdout);
	scanf("%d%d", &n, &m);
	if (n>5) {printf("0"); return 0;}
	for (int i=0; i<=n; i++)
		scanf("%d", &a[i]);
	for (int i=1; i<=m; i++)
		if (pd(i)) ans.push_back(i);
	int lenn=ans.size();
	printf("%d\n", lenn);
	for (int i=0; i<lenn; i++)
		printf("%d\n", ans[i]);
	return 0;
}

