#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<vector>

using namespace std;

vector<int>ans;

struct node
{
	int lenn, s[10010];
	node()
	{
		lenn=0;
		memset(s, 0, sizeof(s));
	}
}a[110];
char s[20000];

node jia(node a, node b)
{
	node no;
	no.lenn=max(a.lenn, b.lenn);
	for (int i=1; i<=no.lenn; i++)
	{
		no.s[i]+=a.s[i]+b.s[i];
		if (no.s[i]>=10) 
		{
			no.s[i]-=10;
			no.s[i+1]++;
		}
	}
	if (no.s[no.lenn+1]) no.lenn++;
	return no;
}

node cheng(node a, node b)
{
	node no;
	no.lenn=max(a.lenn, b.lenn);
	for (int i=1; i<=a.lenn; i++)
	{
		int k=i;
		for (int j=1; j<=b.lenn; j++)
		{
			no.s[k]+=a.s[i]*b.s[j];
			no.s[k+1]+=no.s[k]/10;
			no.s[k]%=10;
			k++;
		}
	}
	while (no.s[no.lenn+1]) 
	{
		no.s[no.lenn+1]+=no.s[no.lenn]/10;
		no.s[no.lenn]%=10;	
		no.lenn++;
	}
	return no;
}

void out(node a)
{
	for(int i=a.lenn; i>=1; i--)
		printf("%d", a.s[i]);
}

int n, m;
bool pd(node k)
{
	node s=a[0], p;
	p.lenn=1; p.s[1]=1;
	for (int i=1; i<=n; i++)
	{
		p=cheng(p, k);
		s=jia(s, cheng(a[i], p));
	}
	if (s.lenn==1 && s.s[1]==0) return 1; 
	return 0;
}

node make(int k)
{
	node no;
	while (k)
	{
		no.s[++no.lenn]=k%10;
		k/=10;
	}
	return no;
}

int main()
{
	//freopen("equation.in", "r", stdin);
	//freopen("equation.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (int i=0; i<=n; i++)
	{
		scanf("%s", &s);
		if (s[0]!='-')
		{
			a[i].lenn=strlen(s);
			for (int j=0; j<a[i].lenn; j++)
				a[i].s[a[i].lenn-j]=s[j]-'0';
		}
		else 
		{
			a[i].lenn=strlen(s);
			for (int j=1; j<a[i].lenn; j++)
				a[i].s[a[i].lenn-j]=-s[j]+'0';
		}
	}
	
	for (int i=1; i<=m; i++)
	{
		node no;
		no=make(i);
		if (pd(no)) ans.push_back(i);
	}
	int lenn=ans.size();
	printf("%d\n", lenn);
	for (int i=0; i<lenn; i++)
		printf("%d\n", ans[i]);
	return 0;
}

