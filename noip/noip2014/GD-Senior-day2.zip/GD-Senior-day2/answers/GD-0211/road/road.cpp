#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<vector>
#include<set>
#include<queue>
#define MAXN 10100

using namespace std;
struct node{
	int d, f;
};
set<int> s, s1;
vector<int> G[MAXN], G2[MAXN], G3[MAXN];
bool v[MAXN];
int pp[MAXN];
queue<node> q;

void dfs(int k)
{
	pp[k]=1;
	if (v[k]) return;
	v[k]=true;
	int lenn=G2[k].size();
	for (int i=0; i<lenn; i++)
	{
		int p=G2[k][i];
		dfs(p);	
	}
	v[k]=false;
	return;
}

int main()
{
	freopen("road.in",  "r", stdin);
	freopen("road.out", "w", stdout);
	int n, m, s, t;
	scanf("%d%d", &n,  &m);
	for (int i=1; i<=m; i++)
	{
		int x, y;
		scanf("%d%d", &x, &y);
		if (!s1.count(x*10000+y))
		{
			G2[y].push_back(x);
			G[x].push_back(y);
			s1.insert(x*10000+y);
		}
	}
	scanf("%d%d", &s, &t);
	memset(v, 0, sizeof(v));
	memset(pp, 0, sizeof(pp));
	dfs(t);

	for (int i=1; i<=n; i++)
		if (!pp[i])
		{
			int lenn=G2[i].size();
			for (int j=0; j<lenn; j++)
				if (pp[G2[i][j]]==1) pp[G2[i][j]]=2;
		}

	/*for (int i=1; i<=n; i++) printf("%d\n", pp[i]); 
	printf("\n");*/

	bool bk=false;
	q.push((node){s, 0});
	while (!q.empty())
	{
		node x=q.front(); q.pop();
		if (pp[x.d]!=1) continue;
		if (x.d==t) 
		{
			printf("%d\n", x.f);
			bk=true;
			break;
		}
		int lenn=G[x.d].size();
		for (int i=0; i<lenn; i++)
			if (pp[G[x.d][i]]==1)
				q.push((node){G[x.d][i], x.f+1});
	}
	if (!bk) printf("-1\n");
	return 0;
}


