#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<vector>

using namespace std;

struct node
{
	int lenn, s[10010];
	node()
	{
		lenn=0;
		memset(s, 0, sizeof(s));
	}
}a, b;
char x[20000], y[20000];

node jia(node a, node b)
{
	node no;
	no.lenn=max(a.lenn, b.lenn);
	for (int i=1; i<=no.lenn; i++)
	{
		no.s[i]+=a.s[i]+b.s[i];
		if (no.s[i]>=10) 
		{
			no.s[i]-=10;
			no.s[i+1]++;
		}
	}
	if (no.s[no.lenn+1]) no.lenn++;
	return no;
}

node cheng(node a, node b)
{
	node no;
	no.lenn=max(a.lenn, b.lenn);
	for (int i=1; i<=a.lenn; i++)
	{
		int k=i;
		for (int j=1; j<=b.lenn; j++)
		{
			no.s[k]+=a.s[i]*b.s[j];
			no.s[k+1]+=no.s[k]/10;
			no.s[k]%=10;
			k++;
		}
	}
	while (no.s[no.lenn+1]) 
	{
		no.s[no.lenn+1]+=no.s[no.lenn]/10;
		no.s[no.lenn]%=10;	
		no.lenn++;
	}
	return no;
}

void out(node a)
{
	for(int i=a.lenn; i>=1; i--)
		printf("%d", a.s[i]);
}

int main()
{
	///freopen("in.txt", "r", stdin);
	///freopen("out.txt", "w", stdout);
	gets(x);
	a.lenn=strlen(x);
	for (int i=0; i<a.lenn; i++)
		a.s[a.lenn-i]=x[i]-'0';
		
	gets(y);
	b.lenn=strlen(y);
	for (int i=0; i<b.lenn; i++)
		b.s[b.lenn-i]=y[i]-'0';
	
	node ans=jia(a, b);
	out(ans);
	printf("\n");
	ans=cheng(a, b);
	out(ans);
	return 0;
}

