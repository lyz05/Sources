#include <cstdio>
#include <cstring>
#include <cmath>
#define MAX(A,B) ((A)>(B)?(A):(B))
#define MIN(A,B) ((A)<(B)?(A):(B))
#define MAXN 110
#define MAXM 10010
using namespace std;

int n,m;

void work1 (){
	int a0,a1,ans;
	scanf ("%d%d",&a0,&a1);
	ans=(-a0)/a1;
	if ( (a0+a1*ans==0) && ans>=1 && ans<=m )
		printf("%d\n%d\n",1,ans);
	else
		printf("0\n");
}

void work2 (){
	int a0,a1,a2,x1,x2,dt,cnt=0,ans[3],t;
	scanf ("%d%d%d",&a0,&a1,&a2);
	
	for (int i=1;i<=m;i++){
		if (a0+a1*i+a2*i*i==0)
			ans[cnt++]=i;
	}
	
	printf("%d\n",cnt);
	for (int i=0; i<cnt; ++i){
		printf("%d\n",ans[i]);
	}
}


int main(){
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	scanf ("%d%d",&n,&m);
	if (n==1) work1();
	else if (n==2) work2();
	else printf("Lao zi bu hui!\n");
	return 0;
}

