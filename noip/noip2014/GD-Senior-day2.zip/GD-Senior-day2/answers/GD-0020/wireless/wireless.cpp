#include <cstdio>
#include <cstring>
#define MAXN 155
using namespace std;

bool done[MAXN];
int f[MAXN][MAXN];
int d,n;

int main(){
	int x,y,k,ans=0,cnt=0;
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	
	memset(f,0,sizeof(f));
	memset(done,false,sizeof(done));
	
	scanf ("%d%d",&d,&n);
	for (int i=0; i<n; ++i ){
		scanf ("%d%d%d",&x,&y,&k);
		f[x][y]=k;
	}
	
	for (int i=0; i<MAXN; ++i){
		for (int j=1; j<MAXN; ++j){
			f[i][j]+=f[i][j-1];
		}
	}
	
	for (int i=0; i<=128; ++i ){
		for (int j=0; j<=128; ++j ){
			int tmp=0;
			x= (i-d<0)?0:(i-d);
			y= j+d;
			for (;x<=i+d;++x){
				tmp+=f[x][y];
				if (j-d>0) tmp-=f[x][j-d-1];
				
			}
			if (ans==tmp) ++cnt;
			else if (ans<tmp) {
				ans=tmp;
				cnt=1;
			}
		}
	}
	
	printf("%d %d\n",cnt,ans);
	return 0;
}

