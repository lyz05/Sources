#include <cstdio>
#include <queue>
#include <vector>
#include <cstring>
#define MAXN 10010
#define INF (1<<29)
using namespace std;

struct Node {
	int d,u;
	bool operator < (const Node & rhs ) const {
		return d>rhs.d;
	}
};

vector<int> G[MAXN];
int n,m,s,t;
bool ok[MAXN];
vector<int> p[MAXN];
int d[MAXN];
int done[MAXN];

void dele(int u){
	ok[u]=false;
	for (int i=0; i<p[u].size(); ++i){
		if (!ok[p[u][i]]) continue;
		dele(p[u][i]);
	}
}

void Dijkstra () {
	priority_queue<Node> Q;
	memset(done,0,sizeof(done));
	for (int i=1; i<=n; ++i) d[i]=INF;
	d[s]=0;
	Q.push( (Node){0,s} );
	while (!Q.empty()){
		Node x=Q.top();	Q.pop();
		int u=x.u;
		if (done[u]) continue;
		done[u];
		for (int i=0; i<G[u].size(); ++i){
			int v=G[u][i];
			if (ok[v]){
				if (d[v]>d[u]+1){
					d[v]=d[u]+1;
					Q.push((Node){d[v],v} );
				}
			}
		}
	}
}

int main(){
	int u,v;
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	memset(ok,true,sizeof(ok));
	scanf ("%d%d",&n,&m);
	
	for (int i=0; i<m; ++i){
		scanf ("%d%d",&u,&v);
		p[v].push_back(u);
		G[u].push_back(v);
	}
	scanf ("%d%d",&s,&t);
	
	for (int i=1; i<=n; ++i ){
		if (i!=t&&G[i].empty()){
			dele(i);
		}
	}
	ok[s]=true;
	Dijkstra();
	if (d[t]>=INF) {
		printf("-1\n");
	}
	else printf("%d\n",d[t]);
	return 0;
}

