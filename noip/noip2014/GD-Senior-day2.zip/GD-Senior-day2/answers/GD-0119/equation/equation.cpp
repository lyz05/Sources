#include<cstdio>
#include<cstring>
#include<algorithm>

using namespace std;

const int MAXN = 10005;

bool Minus[105];
int A[105][10005],Pos[105],Mo[105],Seed[25],Pass[MAXN],Cu[MAXN],Count,N,M,tot,P;

void Rand_For_Seed()
{
	Seed[1] = 2,Seed[2] = 3,Seed[3] = 7,Seed[4] = 19;
	Seed[5] = 1171,Seed[6] = 7193,Seed[7] = 36457,Seed[8] = 43633;
	Seed[9] = 5179,Seed[10] = 3301;
	for(int i = 11;i <= 17;i ++) Seed[i] = rand() % 5000 + 4; 
	tot = 17;
}

bool cmp(int a,int b) {return a > b;}

void Get_Mo(int Cur)
{
	for(int i = 0;i <= N;i ++)
	{
		int least = 0;
		int *a = A[i];
		for(int j = 1;j <= Pos[i];j ++) least = (least * 10 + *(a + j)) % Cur;
		Mo[i] = least;
	}
}

int quick(int a,int b)
{
	if (!b) return 1;
	long long mid = quick(a,b / 2);
	if (b & 1) return mid * mid % P * a % P;
	return mid * mid % P;
}

bool Pas(int j,int Cur)
{
	long long Tmp = 0,Tmp1 = 0;
	Cur = Seed[Cur],P = Cur;
	for(int i = 0;i <= N;i ++) 
	{
		int Bak = Mo[i] * (long long)quick(j,i) % Cur;	
		if (!Minus[i]) Tmp = (Tmp + Bak) % Cur; else
		{
			Tmp1 = (Tmp1 + Bak) % Cur;
		}
	}
	return Tmp == Tmp1;
}

void Test(int Cur)
{
	Get_Mo(Seed[Cur]);
	if (Cur == 1)
	{
		for(int j = 1;j <= min(Seed[Cur],M);j ++)
		if (Pas(j,Cur)) Pass[++ Count] = j;
		for(int j = 1;j <= Count;j ++)
		{
			if (Pass[j] + Seed[Cur] <= M) Pass[++ Count] = Pass[j] + Seed[Cur];
		}	
	} else
	{
		int cnt = 0;
		for(int j = 1;j <= Count;j ++)
		if (Pas(Pass[j],Cur)) Cu[++ cnt] = Pass[j];
		memcpy(Pass,Cu,sizeof(int) * (cnt + 2));
		Count = cnt;
	}
}

int main()
{
	srand(52191314);
	freopen("equation.in","r",stdin),freopen("equation.out","w",stdout);
	Rand_For_Seed();
	scanf("%d%d", &N, &M);
	for(int i = 0;i <= N;i ++)
	{
		char c;
		while (c = getchar(),c != '-' && (c < '0' || c > '9'));
		if (c == '-') Minus[i] = 1; else A[i][++ Pos[i]] = c - 48;
		while (c = getchar(),c >= '0' && c <= '9') A[i][++ Pos[i]] = c - 48;
	}
	sort(Seed + 1,Seed + tot + 1,cmp);
	for(int i = 1;i <= tot;i ++)
	{
		Test(i);
		if (!Count) break;
	}
	printf("%d\n", Count);
	for(int i = 1;i <= Count;i ++) printf("%d\n", Pass[i]);
	return 0;
}

