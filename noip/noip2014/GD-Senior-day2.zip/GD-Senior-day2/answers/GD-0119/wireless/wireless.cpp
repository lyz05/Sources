#include<cstdio>
#include<cstring>
#include<algorithm>

using namespace std;

const int MAXN = 150;

int Ans,A[MAXN][MAXN][MAXN],First[MAXN][MAXN];
int D,N,M,Count;

int Calc(int x,int y)
{
	int tx = x - D,ty = y - D,sx = x + D,sy = y + D;
	if (tx < 1) tx = 1;if (ty < 1) ty = 1;
	if (sx > M) sx = M;if (sy > M) sy = M;
	return A[tx][sx][sy] - A[tx][sx][ty - 1];
}

int main()
{
	freopen("wireless.in","r",stdin),freopen("wireless.out","w",stdout);
	scanf("%d%d", &D, &N);
	M = 129;
	for(int i = 1;i <= N;i ++)
	{
		int x,y;scanf("%d%d", &x, &y);
		x ++,y ++;
		scanf("%d", &First[x][y]);
	}
	for(int i = 1;i <= M;i ++)
		for(int j = 1;j <= M;j ++) First[i][j] += First[i][j - 1];
	for(int i = 1;i <= M; i ++)
		for(int k = 1;k <= M;k ++)
		{
			A[i][i][k] = First[i][k];
			for(int j = i + 1;j <= M;j ++)
				A[i][j][k] = A[i][j - 1][k] + First[j][k];
		}
	for(int i = 1;i <= M;i ++)
		for(int j = 1;j <= M;j ++)
		{
			int C = Calc(i,j);
			if (C > Ans) Ans = C,Count = 1; else
				if (C == Ans) Count ++;
		}
	printf("%d %d\n", Count, Ans);
	return 0;
}

