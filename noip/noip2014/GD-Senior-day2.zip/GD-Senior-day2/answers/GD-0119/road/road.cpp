#include<cstdio>
#include<cstring>
#include<algorithm>

using namespace std;

const int MAXN = 300005;

struct Edge
{
	int To[MAXN],Next[MAXN],Final[MAXN],tot;
}E,Pr;

bool Walk[MAXN],Ok[MAXN],To[MAXN];
int Q[MAXN],Step[MAXN],N,M,S,T;

void link(Edge &a,int u,int v)
{
	a.To[++ a.tot] = v,a.Next[a.tot] = a.Final[u],a.Final[u] = a.tot;
}

void Bfs_For_Ok()
{
	int fi = 0,en = 1;Q[1] = T;To[T] = 1;
	while (fi != en)
	{
		int u = Q[++ fi];To[u] = 1;
		for(int i = Pr.Final[u];i;i = Pr.Next[i])
		if (!To[Pr.To[i]]) To[Pr.To[i]] = 1,Q[++ en] = Pr.To[i];
	}
	for(int i = 1;i <= N;i ++)
	{
		Ok[i] = 1;
		for(int j = E.Final[i];j;j = E.Next[j])
		if (!To[E.To[j]]) Ok[i] = 0;
	}
}

void Bfs_For_Step()
{
	int fi = 0,en = 1;Q[1] = S;
	if (!Ok[S]) {printf("-1\n");return;}
	if (S == T) {printf("0\n");return;}
	while (fi != en)
	{
		int u = Q[++ fi];Walk[u] = 1;
		for(int i = E.Final[u];i;i = E.Next[i])
		if (Ok[E.To[i]] && !Walk[E.To[i]])
		{
			Walk[E.To[i]] = 1;
			if (E.To[i] == T)
			{
				printf("%d\n", Step[fi] + 1);
				return;
			}
			Step[++ en] = Step[fi] + 1,Q[en] = E.To[i];
		}
	}
	printf("-1\n");
}

int main()
{
	freopen("road.in","r",stdin),freopen("road.out","w",stdout);
	scanf("%d%d", &N, &M);
	for(int i = 1;i <= M;i ++)
	{
		int u,v;scanf("%d%d", &u, &v);
		link(E,u,v),link(Pr,v,u);
	}
	scanf("%d%d", &S, &T);
	Bfs_For_Ok();
	Bfs_For_Step();
	return 0;
}

