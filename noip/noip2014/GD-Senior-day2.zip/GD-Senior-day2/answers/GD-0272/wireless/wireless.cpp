#include <cstdio>
#include <cstring>
#include <cmath>
#include <iostream>
#include <algorithm>

using namespace std;
const int maxx=129;
const int maxy=129;
int d,n,x,y,k,maxnum,ans;
int sum[150][150],map[150][150];
int main()
{
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	scanf("%d",&d);
	scanf("%d",&n);
	for (int i=1; i<=n; i++)
	{
		scanf("%d%d%d",&x,&y,&k);
		map[x+1][y+1]=k;
	}
	for (int i=1; i<=maxx; i++)
	  for (int j=1; j<=maxy; j++)
	    sum[i][j]=sum[i-1][j]+sum[i][j-1]+map[i][j]-sum[i-1][j-1];
	
	maxnum=0;
	ans=0;
	for (int i=1; i<=maxx; i++)
	  for (int j=1; j<=maxy; j++)
	  {
	  	int x1,x2,y1,y2;
	  	x1=i-d; y1=j-d;
	  	x2=i+d; y2=j+d;
	  	if (x1<1) x1=1;
	  	if (y1<1) y1=1;
	  	if (x2>maxx) x2=maxx;
	  	if (y2>maxy) y2=maxy;
	  	int tmp=sum[x2][y2]-sum[x2][y1-1]-sum[x1-1][y2]+sum[x1-1][y1-1];
	  	if (tmp>maxnum)
	  	{
	  		maxnum=tmp;
	  		ans=1;
		} else
		if (tmp==maxnum) ans++;
	  }
	printf("%d %d\n",ans,maxnum);
	return 0;
}
