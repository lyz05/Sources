#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <iostream>

using namespace std;

const int oo=1000000;
int open[10000+100],h1[10000+100],h2[10000+100],dis[10000+100];
int e[200000+100][2],g[200000+100][2];
bool boo[10000+100],check[10000+100];
int now1,now2,st,ta,n,m,x,y;

void init()
{
	for (int i=1; i<=10000+5; i++) h1[i]=-1;
	for (int i=1; i<=10000+5; i++) h2[i]=-1;
	for (int i=1; i<=10000+5; i++) boo[i]=0;
	for (int i=1; i<=10000+5; i++) check[i]=1;
	for (int i=1; i<=10000+5; i++) dis[i]=oo;
	now1=0; now2=0;
}
void insert1(int x,int y)
{
	now1++;
	e[now1][0]=y;
	e[now1][1]=h1[x];
	h1[x]=now1;
}
void insert2(int x,int y)
{
	now2++;
	g[now2][0]=y;
	g[now2][1]=h2[x];
	h2[x]=now2;
}
void bfs()
{
	open[1]=ta; boo[ta]=1;
	int head=1,tail=1;
	for (; head<=tail; head++)
	{
		int tmp=h2[open[head]];
		for (; tmp!=-1; tmp=g[tmp][1])
		{
			if (!boo[g[tmp][0]])
			{
				boo[g[tmp][0]]=1;
				tail++;
				open[tail]=g[tmp][0];
			}
		}
	}
}
void work()
{
	for (int i=1; i<=n; i++)
	  if (!boo[i])
	  {
	  	 check[i]=0;
	  	 int tmp=h2[i];
	  	 for (; tmp!=-1; tmp=g[tmp][1]) check[g[tmp][0]]=0;
	  }
	
	if (!check[st]) 
	{
		printf("%d\n",-1);
		return;
	}
	open[1]=st;
	int head=1,tail=1;
	dis[st]=0;
	for (; head<=tail; head++)
	{
		int tmp=h1[open[head] ];
		for (; tmp!=-1; tmp=e[tmp][1])
		{
			if (check[e[tmp][0]] && dis[e[tmp][0]]==oo)
			{
				dis[e[tmp][0]]=dis[open[head]]+1;
				tail++;
				open[tail]=e[tmp][0];
			}
		}
	}
	if (dis[ta]==oo) printf("%d\n",-1); 
	  else printf("%d\n",dis[ta]);
	
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	init();
	scanf("%d%d",&n,&m);
	for (int i=1; i<=m; i++)
	{
		scanf("%d%d",&x,&y);
		insert1(x,y);
		insert2(y,x);
	}
	scanf("%d%d",&st,&ta);
	bfs();
	work();
	return 0;
}
