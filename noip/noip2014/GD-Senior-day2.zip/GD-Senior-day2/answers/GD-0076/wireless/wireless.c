#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <malloc.h>
#include <string.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

#define MAX 2000000
int n,d;
int A[129][129];
int bn=0;

int main(int argc, char *argv[]) {
	int i,j,k,x,y,z,ans=0,m=-1;
	int xmin=214748,xmax=-1,ymin=214748,ymax=-1;
	FILE *in,*out;
	in=fopen("wireless.in","a+");
	out=fopen("wireless.out","w+");
	fscanf(in,"%d",&d);
	fscanf(in,"%d",&n);
	for(i=0;i<129;j++)
		for(j=0;j<129;j++)
			A[i][j]=0;
	for(i=0;i<n;i++)
	{
		fscanf(in,"%d %d %d",&x,&y,&A[i][j]);
		if(x<xmin)
			xmin=x;
		else if(x>xmax)
			xmax=x;
		if(y<ymin)
			ymin=y;
		else if(y>ymax)
			ymax=y;
	}
	
	for(i=xmin;i<=xmax;i++)
	{
		for(j=i;j<=xmax-2*d;j+=2*d)
		{
			for(k=j;k<=j+2*d;k++)
			{
				for(x=ymin;x<=ymax;x++){
					for(y=x;y<=ymax-2*d;y+=2*d)
					{
						for(z=y;z<=y+2*d;z++)
						{
							ans+=A[z][k];
						}
							if(m<ans)
							{
								m=ans;
								bn=1;
							}
							else if(m==ans)
							{
							bn++;
							}
					}
				}
			}
		
		}
		
	}
	
	printf("%d %d",bn,m);
	
	return 0;
}
