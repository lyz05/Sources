#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <malloc.h>
#include <string.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

#define MAX 1000010
int n,m,xn=0;
int A[MAX];
int x[MAX];
int e(int a,int k)
{
	int i,ans=1;
	for(i=k;i>=1;i--)
		ans*=a;
	return ans;
}

void f(int a,int b)
{
	int i,ans1=0,ans2=0;
	if(a<b)
	{
	
	for(i=0;i<=n;i++){
		ans1+=A[i]*e(a,i);
		ans2+=A[i]*e(b,i);
	}
	if(ans1==0)
		x[xn++]=a;
	if(ans2==0)
		x[xn++]=b;
	
	}
}


int main(int argc, char *argv[]) {
	int i;
	FILE *in,*out;
	in=fopen("equation.in","a+");
	out=fopen("equation.out","w+");
	
	fscanf(in,"%d %d",&n,&m);
	for(i=0;i<=n;i++)
		fscanf(in,"%d",&A[i]);
	f(1,m);
	printf("%d\n",xn);
	for(i=0;i<xn;i++)
		fprintf(out,"%d\n",x[i]);

	
	return 0;
}
