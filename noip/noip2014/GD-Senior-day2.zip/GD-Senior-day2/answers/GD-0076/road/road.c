#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <malloc.h>
#include <string.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

#define MAX 200010

typedef struct node
{
	int vertex;
	struct node *next;
}Enode;

typedef struct
{
	int vertex,colour,flag1,flag2;
	Enode *first;
	int pre,d;
}Vnode;

typedef struct qn
{
	int v;
	struct qn *next;
}Qnode;

Vnode G[MAX];
int n,m,s,t;
Qnode *head,*tail;
int Qn=0;


void ENQUEUE(int x)
{
	Qnode *tmp;
	if(Qn==0)
	{
		head=(Qnode *)malloc(sizeof(Qnode));
		tail=head;
		head->v=x;
	}
	else
	{
		tmp=(Qnode *)malloc(sizeof(Qnode));
		tmp->v=x;
		tail->next=tmp;
		tail=tail->next;
	}

	Qn++;
}

int DEQUEUE()
{
	int x;
	x=head->v;
	Qnode *tmp;
	tmp=head;
	head=head->next;
	free(tmp);
	Qn--;
	return x;
}

void DFS_Visit(int u)
{
	Enode *v;
	if(u!=t){
	G[u].colour=1;
	v=G[u].first;
	while(v!=NULL)
	{
		if(G[v->vertex].colour==0)
		{
			G[v->vertex].pre=u;
			DFS_Visit(v->vertex);
		}

		v=v->next;
	}
	v=G[u].first;
	while(v!=NULL)
	{
		if(G[v->vertex].flag1==1)
			G[u].flag1=1;
		v=v->next;
	}	
	}
	
	
}

void DFS(void)
{
	int i;
	Enode *v;
	for(i=1;i<=n;i++)
	{
		G[i].colour=0;
		G[i].flag1=0;
		G[i].pre=-1;
		G[i].flag2=0;
	}
	G[t].flag1=1;
	G[t].flag2=1;
	for(i=1;i<=n;i++)
	{
		if(G[i].colour==0&&i!=t)
			DFS_Visit(i);
	}
	for(i=1;i<=n;i++)
	{
		v=G[i].first;
		if(v!=NULL)
			G[i].flag2=1;
		while(v!=NULL&&v->vertex!=t)
		{
			if(G[v->vertex].flag1==0)
				G[i].flag2=0;
				
			v=v->next;
		}
	}
	
}

void BFS(void)
{
	int i,u;
	Enode *v;
	for(i=1;i<=n;i++)
	{
		G[i].colour=0;
		G[i].pre=-1;
		G[i].d=0;
	}
	G[s].d=0;
	ENQUEUE(s);
	G[s].colour=1;
	while(Qn!=0)
	{
		u=DEQUEUE();
		v=G[u].first;
		while(v!=NULL)
		{
			if(G[v->vertex].colour==0&&G[v->vertex].flag2==1)
			{
				G[v->vertex].d=G[u].d+1;
				G[v->vertex].pre=u;
				ENQUEUE(v->vertex);
				G[v->vertex].colour=1;
			}
			v=v->next;
		}
	}
}

int main(int argc, char *argv[]) {
	int i,x,y;
	Enode *v,*tmp;
	FILE *in,*out;
	in=fopen("road.in","a+");
	out=fopen("road.out","w+");
	
	fscanf(in,"%d %d",&n,&m);
	for(i=1;i<=n;i++)
	{
		G[i].vertex=i;
		G[i].first=NULL;
		G[i].colour=0;
	}
	for(i=0;i<m;i++)
	{
		fscanf(in,"%d %d",&x,&y);
		v=(Enode *)malloc(sizeof(Enode));
		v->vertex=y;
		v->next=NULL;
		tmp=G[x].first;
		if(tmp==NULL)
			G[x].first=v;
		else
		{
			while(tmp->next!=NULL)
			{
				tmp=tmp->next;
			}
			tmp->next=v;
		}
	}
	fscanf(in,"%d %d",&s,&t);

	DFS();

	if(G[s].flag2==0)
		fprintf(out,"-1");

	else 
	{
		BFS();
		fprintf(out,"%d",G[t].d);
	}

	
	return 0;
}
