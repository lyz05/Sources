#include<cstdio>

int main() {
    freopen("equation.in","r",stdin);
    freopen("equation.out","w",stdout);
    printf("0");
    return 0;
}
