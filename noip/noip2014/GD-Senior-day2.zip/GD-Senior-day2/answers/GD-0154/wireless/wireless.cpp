#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<string>
#include<algorithm>
#define fr(i,m,n) for(int i=m; i<=n; i++)
#define dfr(i,m,n) for(int i=m; i>=n; i--)
#include<iostream>
#define local
using namespace std;

typedef long long ll;
const int N=134;
const int X=128;
const int Y=128;

int dp[N][N];
int mp[N][N];
int sumx[N][N],sumy[N][N];
int mx=0,my=0;

int d,n,x,y,k;
int maxx=0;

int main() {
    freopen("wireless.in","r",stdin);
    freopen("wireless.out","w",stdout);
    memset(dp,0,sizeof(dp));
    memset(mp,0,sizeof(mp));
    memset(sumx,0,sizeof(sumx));
    memset(sumy,0,sizeof(sumy));
    scanf("%d%d",&d,&n);
    fr(i,1,n) {
        scanf("%d%d%d",&x,&y,&k);
        mp[x][y]=k;
        mx=max(mx,x);
        my=max(my,y);
    }
    fr(i,0,X) {
        fr(j,0,Y) {
            if (i>0) sumy[i][j]=sumy[i-1][j]+mp[i][j]; else sumy[i][j]=mp[i][j];
            if (j>0) sumx[i][j]=sumx[i][j-1]+mp[i][j]; else sumx[i][j]=mp[i][j];
        }
    }
    #ifdef local2
        fr(i,0,12) {
            fr(j,0,12) printf("%d ",sumx[i][j]);
            printf("\n");
        }
        printf("\n");
        fr(i,0,12) {
            fr(j,0,12) printf("%d ",sumy[i][j]);
            printf("\n");
        }
    #endif
    fr(i,0,2*d) dp[0][0]+=sumx[i][2*d]; 
    fr(i,0,X-2*d) {
        fr(j,0,Y-2*d) {
            if (i==0) {if (j!=0) dp[0][j]=dp[0][j-1]-sumy[2*d][j-1]+sumy[2*d][j+2*d]; }
            else {
                if (j==0) dp[i][0]=dp[i-1][0]-sumx[i-1][2*d]+sumx[i+2*d][2*d];
                else dp[i][j]=dp[i-1][j]+(sumx[i+2*d][j+2*d]-sumx[i+2*d][j-1])-(sumx[i-1][j+2*d]-sumx[i-1][j-1]);
            }
            maxx=max(dp[i][j],maxx);
        }
    }
    #ifdef local2
        fr(i,0,12) {
            fr(j,0,12) printf("%d ",dp[i][j]);
            printf("\n");
        }
        printf("\n");
    #endif
    int ans=0;
    fr(i,0,X-2*d) {
        fr(j,0,Y-2*d) if (dp[i][j]==maxx) ans++;
    }
    printf("%d %d",ans,maxx);
    return 0;
    
    
}
