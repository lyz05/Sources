#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<string>
#include<algorithm>
#define fr(i,m,n) for(int i=m; i<=n; i++)
#define dfr(i,m,n) for(int i=m; i>=n; i--)
#include<queue>
#include<vector>
#define local

using namespace std;


const int N=10010;
vector<int> G[N];
vector<int> F[N];

int n,m;
int s,t;

bool ok[N],vis[N]; 

struct Headnode {
    int d,u;
    bool operator < (const Headnode& rhs) const {
        return d>rhs.d;
    }
};

void F_dfs(int u) {
    if (vis[u]) return;
    vis[u]=1;
    fr(i,0,(int)F[u].size()-1) {
        int v=F[u][i];
        F_dfs(v);
    }
}

int d[N];

void Dijkstra() {
    memset(d,0x7f,sizeof(d));
    d[s]=0;
    priority_queue<Headnode> Q;
    Q.push((Headnode){0,s});
    while(!Q.empty()) {
        Headnode x=Q.top(); Q.pop();
        int u=x.u;
        if (x.d!=d[u]) continue;
        fr(i,0,(int)G[u].size()-1) {
            int v=G[u][i];
            if (!ok[v]) continue;
            if (d[v]>d[u]+1) {
                d[v]=d[u]+1;
                Q.push((Headnode){d[v],v});
            }
        }
    }
}

int main() {
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
        
    scanf("%d%d",&n,&m);
    memset(ok,1,sizeof(ok));
    memset(vis,0,sizeof(vis));
    
    fr(i,1,n) {G[i].clear(); F[i].clear();}
    fr(i,1,m) {
        int u,v;
        scanf("%d%d",&u,&v);
        G[u].push_back(v);
        F[v].push_back(u);
    }
    scanf("%d%d",&s,&t);
    
    F_dfs(t);
    if (!vis[s]) {printf("-1"); return 0;}
    
    fr(u,1,n) if (!vis[u]) {
        ok[u]=0;
        fr(j,0,(int)F[u].size()-1) ok[F[u][j]]=0;
    }
    Dijkstra();
    
    printf("%d",d[t]);
    return 0;
    
    
    
    
}
