#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int range(int from, int to) {
	return (rand() ^ rand()) % (to - from + 1) + from;
}

int main() {
	srand(clock() * time(NULL));
	int n = range(1, 10000), m = range(1, 200000);
	freopen("road.in","w",stdout);
	printf("%d %d\n",n,m);
	for (int i = 0;i < m;i++) {
		printf("%d %d\n", range(1,n),range(1,n));
	}
	printf("%d %d\n", range(1,n),range(1,n));
}
