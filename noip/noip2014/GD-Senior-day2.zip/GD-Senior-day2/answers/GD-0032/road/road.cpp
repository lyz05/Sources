#include <stdio.h>
#include <string.h>
#include <vector>
#include <queue>
using namespace std;

typedef struct Edge {
	int from, to, another;
}Edge;

vector<Edge> G[10010];

int n, m, s, t;
int visited[10010];
int visited2[10010];

void addEdge(int from, int to) {
	int fromsize = G[from].size();
	int tosize = G[to].size();
	G[from].push_back((Edge){from, to, tosize});
	G[to].push_back((Edge){from, to, fromsize});
}

void reverseDFS(int from) {
	visited[from] = 1;
	vector<Edge>::iterator end = G[from].end();
	for (vector<Edge>::iterator it = G[from].begin();it != end;it++) {
		Edge edge = *it;
		if (edge.to == from && !visited[edge.from]) {
			reverseDFS(edge.from);
		}
	}
}

typedef struct State {
	int cur;
	int depth;
}State; 

int BFS() {
	queue<State> que;
	que.push((State){s, 0});
	while(!que.empty()) {
		State cur = que.front();
		que.pop();
		if (cur.cur == t) {
			return cur.depth;
		}
		visited2[cur.cur] = 1;
		vector<Edge>::iterator end = G[cur.cur].end();
		for (vector<Edge>::iterator it = G[cur.cur].begin();it != end;it++) {
			Edge edge = *it;
			if (edge.from == cur.cur && !visited2[edge.to]) {
				que.push((State){edge.to, cur.depth+1});
			}
		}	
	}
	return -1;
}

int main() {
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i = 0;i < m;i++) {
		int from, to;
		scanf("%d%d",&from,&to);
		addEdge(from,to);
	}
	scanf("%d%d",&s,&t);
	memset(visited,0,sizeof(visited));
	reverseDFS(t);
	if (!visited[s]) {
		printf("-1\n");
		return 0;
	}
	memset(visited2,0,sizeof(visited2));
	for (int i = 1;i <= n;i++) {
		if (!visited[i]) {
			vector<Edge>::iterator end = G[i].end();
			for (vector<Edge>::iterator it = G[i].begin();it != end;it++) {
				Edge edge = *it;
				if (edge.to == i) {
					visited2[edge.from] = 1;
				}
			}
		}
	}
	printf("%d\n",BFS());
}


