#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int range(int from, int to) {
	return (rand() ^ rand()) % (to - from + 1) + from;
}

int main() {
	srand(clock() * time(NULL));
	int d = range(1, 20), n = range(1, 20);
	freopen("wireless.in","w",stdout);
	printf("%d %d\n",d,n);
	for (int i = 0;i < n;i++) {
		printf("%d %d %d\n", range(0,128),range(0,128),range(1,1000000));
	}
}
