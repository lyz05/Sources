#include <stdio.h>
#include <fstream>
using namespace std;

int d,n;
long long map[130][130] = {{0}};

bool inRange(int x, int y) {
	return 0 <= x && x <= 128 && 0 <= y && y <= 128;
}

int main() {
	ios::sync_with_stdio(false);
	ifstream in("wireless.in");
	ofstream out("wireless.out");
	in >> d >> n;
	long long max = 0,way = 0;
	for (int i = 0;i < n;i++) {
		int x,y,k;
		in >> x >> y >> k;
		for (int dx = -d;dx <= d;dx++) for (int dy = -d;dy <= d;dy++) if (inRange(x+dx,y+dy)) {
			map[x+dx][y+dy] += k;
			if (map[x+dx][y+dy] > max) {
				max = map[x+dx][y+dy];
				way = 1;
			} else if (map[x+dx][y+dy] == max) {
				way++;
			}
		}
	}
	out << way << " " << max << endl;
}
