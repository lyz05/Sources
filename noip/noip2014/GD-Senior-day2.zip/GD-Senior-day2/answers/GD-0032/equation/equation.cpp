#include <string.h>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
using namespace std;

typedef struct BigInteger {
	int num[10010];
	int length;
}BigInteger;

const int jinzhi = 100000;

BigInteger Plus(BigInteger& one, BigInteger &two) {
	BigInteger result;
	memset(result.num,0,sizeof(result.num));
	result.length = max(one.length, two.length);
	for (int i = 0;i < result.length;i++) {
		result.num[i] += one.num[i] + two.num[i];
		result.num[i+1] += result.num[i] / jinzhi;
		result.num[i] %= jinzhi;
	}
	while (result.num[result.length]) {
		result.length++;
	}
	while (result.length && !result.num[result.length-1]) {
		result.length--;
	}
	return result;
}

BigInteger multiply(BigInteger& one, BigInteger& two) {
	BigInteger result;
	memset(result.num,0,sizeof(result.num));
	result.length = one.length + two.length;
	for (int i = 0;i < one.length;i++) {
		for (int j = 0;j < two.length;j++) {
			result.num[i+j] += one.num[i] * two.num[j];
			result.num[i+j+1] += result.num[i+j] / jinzhi;
			result.num[i+j] %= jinzhi;
		}
	}
	while (result.num[result.length]) {
		result.length++;
	}
	while (result.length && !result.num[result.length-1]) {
		result.length--;
	}
	return result;
}

BigInteger toBigInteger(int num) {
	BigInteger result;
	memset(result.num,0,sizeof(result.num));
	result.length = 0;
	while(num) {
		result.num[result.length++] += num % jinzhi;
		num /= jinzhi;
	}
	while (result.num[result.length]) {
		result.length++;
	}
	while (result.length && !result.num[result.length-1]) {
		result.length--;
	}
	return result;
}

BigInteger fromString(string str) {
	BigInteger result;
	memset(result.num,0,sizeof(result.num));
	
	bool symbol = true;
	const char *p = str.c_str();
	if (*p == '-') {
		symbol = false;
		p++;
	}
	result.length = strlen(p);
	for (int i = result.length - 1;i >= 0;i--) {
		result.num[i] = symbol ? (*p - '0') : -(*p-'0');
		p++;
	}
	for (int i = 0;i <= result.length / 5;i++) {
		result.num[i] = result.num[i*5]+result.num[i*5+1]*10+result.num[i*5+2]*100+result.num[i*5+3]*1000+result.num[i*5+4]*10000;
	}
	memset(&result.num[result.length/5+1],0,sizeof(result.num) - sizeof(int)*(result.length/5+1));
	result.length /= 5;
	while (result.num[result.length]) {
		result.length++;
	}
	while (result.length && !result.num[result.length-1]) {
		result.length--;
	}
	return result;
}


int main() {
	int n, m;
	string temp;
	ifstream in("equation.in");
	ofstream out("equation.out");
	in >> n >> m;
	vector<BigInteger> a;
	vector<int> ans;
	for (int i = 0;i <= n;i++) {
		in >> temp;
		a.push_back(fromString(temp));
	}
	for (int i = 1;i <= m;i++) {
		BigInteger ii = toBigInteger(i);
		BigInteger exp = ii;
		BigInteger sum = a[0];
		BigInteger temp;
		for (int j = 1;j <= n;j++) {
			temp = multiply(a[j],exp);
			sum = Plus(sum,temp);
			exp = multiply(exp,ii);
		}
		if (sum.length == 0 && sum.num[0] == 0) {
			ans.push_back(i);
		}
	}
	int size = ans.size();
	out << size << endl;
	for (int i = 0;i < size;i++) out << ans[i] << endl;
}
