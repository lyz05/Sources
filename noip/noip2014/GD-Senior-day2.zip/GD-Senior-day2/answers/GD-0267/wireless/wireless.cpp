#include <cstdio>
using namespace std;
int main ()
{
	freopen ("wireless.in","r",stdin);
	freopen ("wireless.out","w",stdout);
	scanf ("%d%d",&d,&n);
	int x,y,b;
	while (n--)
	{
		scanf ("%d%d%d",&x,&y,&b);
		for (int i = x;i <= 128;i++) sumx[i][y] += b;
		for (int i = y;i <= 128;i++) sumy[x][i] += b;
	}
	return 0;
}
