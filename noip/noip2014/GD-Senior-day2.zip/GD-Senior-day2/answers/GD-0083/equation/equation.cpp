#include <iostream>
#include <fstream>
#include <algorithm>
#include <ctime>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
using namespace std;
#define mmst(a, b) memset(a, b, sizeof(a))
#define mmcp(a, b) memcpy(a, b, sizeof(b))

typedef long long LL;

const int maxn = 1005, mod = 1000000007;

int n, m, b[105];

inline void swap(int &a, int &b)
{
	int t = a;
	
	a = b; b = t;
}

struct BigNum
{
	int n, a[maxn];
	
	void Input()
	{
		int i; char ch;
		
		for (ch = getchar(); ch != '-' && (ch > '9' || ch < '0'); ch = getchar());
		if (ch == '-') 
		{
			a[0] = -1; ch = getchar();
		}else a[0] = 1;
		for (n = 0; ch <= '9' && ch >= '0'; ch = getchar()) 
		{
			n++;
			a[n] = ch-'0';
		}
		for (i = 1; i <= n/2; i++) swap(a[i], a[n-i+1]);
		if (n == 0)
		{
			n++;
			a[n] = 0;
		}
	}
	
	void operator = (int x)
	{
		if (x >= 0) a[0] = 1; else a[0] = -1;
		for (n = 0; x; x /= 10)
		{
			n++; a[n] = x % 10;
		}
		if (n == 0) 
		{
			n++;
			a[n] = 0;
		}
		a[n+1] = 0;
	}
	
	void operator += (BigNum A)
	{
		int i, m; bool op;
		
		if (A.a[0] * a[0] == 1)
		{
			n = max(n, A.n);
			for (i = 1; i <= n; i++)
			{
				a[i] += A.a[i];
				a[i+1] += a[i] / 10;
				a[i] %= 10;
			}
			if (a[n+1] > 0) n++;
		} else {
			op = false;
			if (n > A.n) op = false;
			if (n < A.n) op = true;
			for (i = n; i >= 1; i--)
			{
				if (a[i] > A.a[i]) { op = false; break; }
				if (a[i] < A.a[i]) { op = true; break; }
			}
			
			if (op) 
			{
				a[0] = A.a[0];
				m = max(n, A.n);
				for (i = 1; i <= m; i++) swap(a[i], A.a[i]);
				swap(n, A.n);
			}
			
			for (i = 1; i <= A.n; i++) 
			{
				a[i] -= A.a[i];
				if (a[i] < 0) 
				{
					a[i] += 10; a[i+1]--;
				}
			}
			while (n > 1 && a[n] == 0) n--;
		}
	}
	
	friend BigNum operator * (const BigNum &A, const BigNum &B)
	{
		static BigNum C; int i, j;
		
		C.n = A.n+B.n-1;
		for (i = 1; i <= C.n+1; i++) C.a[i] = 0;
		for (i = 1; i <= A.n; i++)
			for (j = 1; j <= B.n; j++)
				C.a[ i+j-1 ] += A.a[i]*B.a[j];
		for (i = 1; i <= C.n; i++) 
		{
			C.a[i+1] += C.a[i] / 10;
			C.a[i] %= 10;
		}
		if (C.a[ C.n+1 ] > 0) C.n++;
		C.a[0] = A.a[0] * B.a[0];
		
		return C;
	}
	
	void Print()
	{
		int i;
		
		if (a[0] == -1) printf("-");
		for (i = n; i > 0; i--) printf("%d", a[i]);
		printf("\n");
	}
	
	int To(int mod)
	{
		int ret = 0, i;
		
		for (i = n; i > 0; i--) ret = (ret * 10 + a[i]) % mod;
		return ret * a[0];
	}
}t, sum, x, a[105];

int ans, root[maxn];

void Solve()
{
	int i, j;
	
	ans = 0;
	for (i = 1; i <= m; i++)
	{
		t = i; sum = 0; x = 1;
		for (j = 0; j <= n; j++)
		{
			sum += a[j] * x;
			//x.Print();
			//a[j].Print();
			//sum.Print();
			x = x * t;
		}
		if (sum.n == 1 && sum.a[1] == 0) 
		{
			ans++;
			root[ans] = i;
		} 
	}
	
	printf("%d\n", ans);
	for (i = 1; i <= ans; i++) printf("%d\n", root[i]);
}

void Solve2()
{
	int i, j; LL t, sum, x;
	
	ans = 0;
	for (i = 1; i <= m; i++)
	{
		t = i; sum = 0; x = 1;
		for (j = 0; j <= n; j++)
		{
			sum = (sum + b[j] * x % mod);
			x = x * t % mod;
		}
		if (sum == 0) 
		{
			ans++;
			root[ans] = i;
		} 
	}
	
	printf("%d\n", ans);
	for (i = 1; i <= ans; i++) printf("%d\n", root[i]);
}

int main()
{
	int i;
	
	freopen("equation.in", "r", stdin);
	freopen("equation.out", "w", stdout);
	
	scanf("%d%d", &n, &m);
	for (i = 0; i <= n; i++) 
	{
		a[i].Input();
		b[i] = a[i].To(mod);
	}
	
	Solve2();
	
	return 0;
}

