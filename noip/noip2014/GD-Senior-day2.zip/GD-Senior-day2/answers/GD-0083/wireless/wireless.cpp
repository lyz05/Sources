#include <iostream>
#include <fstream>
#include <algorithm>
#include <ctime>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
using namespace std;
#define mmst(a, b) memset(a, b, sizeof(a))
#define mmcp(a, b) memcpy(a, b, sizeof(b))

typedef long long LL;

const int maxn = 25;

int d, n, x[maxn], y[maxn], w[maxn];

inline int abs(int a)
{
	if (a >= 0) return a;
	return -a;
}

int main()
{
	int i, j, k, tmp, ans, num;
	
	freopen("wireless.in", "r", stdin);
	freopen("wireless.out", "w", stdout);
	
	scanf("%d%d", &d, &n);
	for (i = 1; i <= n; i++) scanf("%d%d%d", &x[i], &y[i], &w[i]);
	
	ans = 0; num = 0;
	for (i = 0; i <= 128; i++)
		for (j = 0; j <= 128; j++)
		{
			tmp = 0;
			for (k = 1; k <= n; k++)
				if (abs(x[k]-i) <= d && abs(y[k]-j) <= d) tmp += w[k];
			if (tmp > ans)
			{
				ans = tmp; num = 0;
			}
			if (tmp == ans) num++;
		}
	
	printf("%d %d\n", num, ans);
	
	return 0;
}

