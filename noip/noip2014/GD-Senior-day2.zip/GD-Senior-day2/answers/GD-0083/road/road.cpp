#include <iostream>
#include <fstream>
#include <algorithm>
#include <ctime>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
using namespace std;
#define mmst(a, b) memset(a, b, sizeof(a))
#define mmcp(a, b) memcpy(a, b, sizeof(b))

typedef long long LL;

const int maxn = 2*10005, maxm = 2*200005;

int n, m;
int N, first[maxn], head[maxn], o[maxn], dis[maxn];
bool vis[maxn], able[maxn];

struct Edge
{
	int v, ne;
	Edge(int _v = 0, int _ne = 0) : v(_v), ne(_ne) {}
}e[2*maxm];

void Insert(int *head, int u, int v)
{
	N++;
	e[N] = Edge(v, head[u]);
	head[u] = N;
}

int Bfs(int start, int tar)
{
	int h, t, i, u, v; bool flag;
	
	mmst(able, false);
	o[0] = tar; able[tar] = true;
	for (h = t = 0; h <= t; h++)
	{
		u = o[h];
		for (i = first[u]; i != -1; i = e[i].ne)
		{
			v = e[i].v;
			if (able[v]) continue;
			t++; o[t] = v;
			able[v] = true;
		}
	}
	
	mmst(vis, false); mmst(dis, 0);
	o[0] = start; vis[start] = true; dis[start] = 0;
	for (h = t = 0; h <= t; h++)
	{
		u = o[h];
		flag = false;
		for (i = head[u]; i != -1; i = e[i].ne)
			if (!able[ e[i].v ]) 
			{
				flag = true;
			}
		if (flag) continue;
		for (i = head[u]; i != -1; i = e[i].ne)
		{
			v = e[i].v;
			if (vis[v]) continue;
			vis[v] = true;
			t++; o[t] = v;
			dis[v] = dis[u]+1;
			if (v == tar) return dis[v]; 
		}
	}
	
	return -1;
}

int main()
{
	int i, u, v, s, t, ans;
	
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	
	N = -1; mmst(head, -1); mmst(first, -1);
	
	scanf("%d%d", &n, &m);
	for (i = 1; i <= m; i++)
	{
		scanf("%d%d", &u, &v);
		Insert(head, u, v);
		Insert(first, v, u);
	}
	scanf("%d%d", &s, &t);
	
	ans = Bfs(s, t);
	
	printf("%d\n", ans);
	
	return 0;
}

