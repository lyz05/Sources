#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#define ll long long
bool map[101][101];
bool v[101][101];
int r[101],c[101];int step[101];
int link[101][2001];
int pre[101][2001];
bool f[101];
bool vi[101];
int d[101];
int n,m,s,t;
using namespace std;
void init()
{
	cin>>n>>m;int i,x,y;
	for(i=1;i<=m;i++)
	   {
            scanf("%d%d",&x,&y);
            if(map[x][y])continue;
			map[x][y]=1;v[x][y]=1;
			c[x]++;r[y]++;	   
			link[x][c[x]]=y;
			pre[y][r[y]]=x;
       }
    cin>>s>>t;    
}
void dfs(int x)
{
	if(x==t)return;
	f[x]=1;
	for(int i=1;i<=r[x];i++)
	f[pre[x][i]]=1;
}
int main()
{
freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	init();
	int i,j,k;
   for(k=1;k<=n;k++)	   
	for(i=1;i<=n;i++)
	  for(j=1;j<=n;j++)
	     v[i][j]=v[i][j]||(v[i][k]&&v[k][j]);
//	for(i=1;i<=n;i++)
//	 for(j=1;j<=n;j++)  
	//    cout<<i<<","<<j<<": "<<v[i][j]<<endl; 
	    
	 if(!v[s][t])
	 {
	 cout<<-1<<endl;
	 return 0;
     }
    for(i=1;i<=n;i++)
	   {
	   	if(i==t)continue;
	   	if(!v[i][t])
	   	  {
	   	  	dfs(i);
	   	  }
	   } 
	  if(f[s])
	 {
	 cout<<-1<<endl;
	 return 0;
     } 
	 //for(i=1;i<=n;i++)cout<<f[i]<<endl;  
	 int head=0,tail=0;d[0]=s;vi[s]=1;
	 
	 do{
	 	
	 	for(i=1;i<=c[d[head]];i++)
	 	  {
	 	  	if(link[d[head]][i]==t)
	 	  	   {cout<<step[d[head]]+1<<endl;
	 	  	   return 0;
	 	  	   }
	 	  	if(!vi[link[d[head]][i]]&&!f[link[d[head]][i]])
	 	  	   {
	 	  	   	d[++tail]=link[d[head]][i];
	 	  	   	step[d[tail]]=step[d[head]]+1;
	 	  	   	vi[link[d[head]][i]]=1;
	 	  	   }
	 	  }
	 	 head++; 
	 } while(head<=tail) ;
	 cout<<-1<<endl;
	 return 0;    
	fclose(stdin);fclose(stdout);
}
