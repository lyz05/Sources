#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#define ll long long
ll n,d,ans,sum[1290][1209],tot,map[1029][1029];
using namespace std;
void init()
{
	cin>>d>>n;
	int x,y,z;
	int i,j;
	for(i=1;i<=n;i++)
	  {
	  	cin>>x>>y>>z;
	  	map[x][y]=z;
	  }
	sum[0][0]=map[0][0];  
    for(i=1;i<=128+d;i++)
	   {
	   sum[0][i]=sum[0][i-1]+map[0][i];
	   sum[i][0]=sum[i-1][0]+map[i][0];
       }
    for(i=1;i<=128+d;i++)
	   for(j=1;j<=128+d;j++)
	      sum[i][j]=sum[i-1][j]+sum[i][j-1]+map[i][j]-sum[i-1][j-1];   
	    
}
void test()
{
	for(int i=0;i<=10;i++){
	
	   for(int j=0;j<=10;j++)
	     cout<<j<<","<<i<<" : "<<sum[j][i]<<endl;
	 }
}
int main()
{
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	init();
//	test();
	int i,j;ll tmp=0;
	for(i=0;i<=128;i++)
	   for(j=0;j<=128;j++)
	      {
	      	tmp=sum[i+d][j+d];
	      	if(i-d>0&&j-d>0)
	      	  {
	      	  	tmp=tmp-sum[i+d][j-d-1]-sum[i-d-1][j+d]+sum[i-d-1][j-d-1];
	      	  }
	      	 if(i-d<=0&&j-d>0)
			   {
			   	tmp=tmp-sum[i+d][j-d-1];
			   } 
			 if(i-d>0&&j-d<=0)
			 {
			 	tmp-=sum[i-d-1][j+d];
			 } 
			if(tmp==ans)
			  tot++;  
	        
			if(tmp>ans)
			  {
			  	ans=tmp;tot=1;
			  } 
		 
           }
	cout<<tot<<" "<<ans<<endl;   
	return 0;    
	fclose(stdin);fclose(stdout);
}
