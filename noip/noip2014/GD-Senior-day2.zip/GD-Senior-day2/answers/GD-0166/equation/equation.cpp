#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#define ll long long
using namespace std;
ll a[10010],n,m,tot;
 int ans[10001];
int main()
{
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	cin>>n>>m;int i;
for(i=0;i<=n;i++)
	cin>>a[i];
	ll tmp,x;
for(i=1;i<=m;i++)
	{
	 tmp=0;
	 for(int j=0;j<=n;j++)
	 {x=1;
	 	for(int k=1;k<=j;k++)
	 	   x=x*i;
	 	tmp+=a[j]*x;   
	 }
	 if(tmp==0){
	 	ans[++tot]=i;
	 }
  }
  cout<<tot<<endl;i=1;
  while(i<=tot){cout<<ans[i++]<<endl;
  }
  return 0;
	fclose(stdin);fclose(stdout);
}
