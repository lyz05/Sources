#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
using namespace std;
int d,n;
int a[130][130];
int su;
int p;
int main()
{	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	cin>>d>>n;
	int x1,y1,k;
	for (int i=1;i<=n;i++)
	{	cin>>x1>>y1>>k;
		a[x1][y1]=k;
	}
	x1=0;
	y1=0;
	int x2=0,y2=0;
	int o;
	for (int i=0;i<=128;i++)
	{	for (int j=0;j<=128;j++)
		{	if (j>d) x1=j-d;
			else x1=0;
			if (j+d<128) x2=j+d;
			else x2=128;
			if (i>d) y1=i-d;
			else y1=0;
			if (i+d<128) y2=i+d;
			else y2=128;
			o=0;
			for (int t=y1;t<=y2;t++)
			{	for (int u=x1;u<=x2;u++)
				{	o+=a[t][u];
				}
			}
			if (su==o) p++;
			else if(su<o) {su=o;p=1;}
		}
	}
	cout<<p<<" "<<su;
	return 0;
}

