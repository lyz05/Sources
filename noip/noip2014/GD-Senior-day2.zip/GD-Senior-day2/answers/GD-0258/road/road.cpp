#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
using namespace std;
int f[1001][1001];
int d[1001][1001];
int u[1001];
int h[1001];
int r[1001];
int dist[1001];
int n,m;
int s,t;
int c[1001],front,rear;
int main()
{	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>m;
	int x1=0,y1=0;
	for (int i=1;i<=m;i++)
	{	scanf("%d%d",&x1,&y1);
		f[x1][y1]=1;
		d[y1][x1]=1;
	}
	x1=0;
	y1=0;
	cin>>s>>t;
	int v0=t;
	front=1;rear=1;
	c[front]=v0;
	u[v0]=1;
	h[v0]=1;
	r[v0]=1;
	while (front<=rear)
	{	v0=c[front];
		for (int i=1;i<=n;i++)
		{	if (d[v0][i]&&u[i]!=1) {rear++;c[rear]=i;u[i]=1;h[i]=1;}
		}
		front++;
	}
	if (h[s]==0) cout<<"-1";
	else 
	{	bool o=false;
		for(int i=1;i<=n;i++)
		{	if (i==t) continue;
			o=true;
			if (h[i]==1) 
			{	for (int j=1;j<=n;j++)
				{	if(f[i][j]==1&&h[j]!=1) o=false;
				}
				if (o)	r[i]=1;
			}
		}
		if (r[s]==0) cout<<"-1";
		else 
		{	v0=s;
			while (v0!=t)
			{	int su=9999999,k=0;
				for (int i=1;i<=n;i++)
				{	if (f[v0][i]==1&&r[i]==1&&dist[i]==0) dist[i]=1; 
					else if (f[v0][i]==1&&r[i]==1&&dist[v0]+f[v0][i]<dist[i]) dist[i]=dist[v0]+f[v0][i];
					if (r[i]==1&&dist[i]<su) {su=dist[i];k=i;}  
				}
				v0=k;
			}
			cout<<dist[t];
		}
		
	}
	return 0;
}

