#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<iostream>
#include<queue>
#include<string>

using namespace std;

int n,m,aa[110],sta[110];

void init()
{
	cin>>n>>m;
	memset(sta,0,sizeof(sta));
	for(int i=0;i<=n;++i) scanf("%d",&aa[i]);
	for(int x=1;x<=m;++x)
	{
		int now=1,sum=0;
		for(int i=0;i<=n;++i)
		{
			sum+=aa[i]*now;
			now*=x;
		}
		if(sum==0) sta[++sta[0]]=x;
	}
	for(int i=0;i<=sta[0];++i)
		printf("%d\n",sta[i]);
	return;
}

int main()
{
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	init();
	return 0;
}
