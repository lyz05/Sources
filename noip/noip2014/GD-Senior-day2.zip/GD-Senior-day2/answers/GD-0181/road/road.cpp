#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<iostream>
#include<queue>
#include<string>

using namespace std;

const int maxn=10000;

bool exi[maxn+10];
int n,ss,tt;
int h1[maxn+10],e1[200010],nex1[200010];
int h2[maxn+10],e2[200010],nex2[200010];

void init()
{
	memset(h1,0,sizeof(h1));
	memset(e1,0,sizeof(e1));
	memset(nex1,0,sizeof(nex1));
	memset(h2,0,sizeof(h2));
	memset(e2,0,sizeof(e2));
	memset(nex2,0,sizeof(nex2));
	int m,top=0,a,b;
	cin>>n>>m;
	for(int i=1;i<=m;++i)
	{
		scanf("%d%d",&a,&b);
		++top;
		e1[top]=b; nex1[top]=h1[a]; h1[a]=top;
		e2[top]=a; nex2[top]=h2[b]; h2[b]=top;
	}
	cin>>ss>>tt;
	return;
}

void bfs2()
{
	queue<int> q;
	bool vis[maxn+10];
	memset(vis,0,sizeof(vis));
	q.push(tt); vis[tt]=true;
	while(!q.empty())
	{
		int x=q.front(); q.pop();
		int i=h2[x];
		while(i)
		{
			if(!vis[e2[i]])
			{
				vis[e2[i]]=true;
				q.push(e2[i]);
			}
			i=nex2[i];
		}
	}
	memset(exi,0,sizeof(exi));
	for(int i=1;i<=n;++i)
	{
		if(!vis[i]) continue;
		exi[i]=true;
		int k=h1[i];
		while(k)
		{
			if(!vis[e1[k]])
			{
				exi[i]=false;
				break;
			}
			k=nex1[k];
		}
	}
	return;
}

int bfs1()
{
	if(!exi[ss]) return -1;
	int dis[maxn+10];
	queue<int> q;
	bool inq[maxn+10];
	memset(dis,0x7f,sizeof(dis));
	memset(inq,0,sizeof(inq));
	q.push(ss); dis[ss]=0; inq[ss]=true;
	while(!q.empty())
	{
		int x=q.front(); q.pop(); inq[x]=false;
		int i=h1[x];
		while(i)
		{
			if(exi[e1[i]]&&dis[e1[i]]>dis[x]+1)
			{
				dis[e1[i]]=dis[x]+1;
				if(!inq[e1[i]])
				{
					inq[e1[i]]=true;
					q.push(e1[i]);
				}
			}
			i=nex1[i];
		}
	}
	if(dis[tt]>20000000) return -1;
	return dis[tt];
}

void run()
{
	bfs2();
	printf("%d",bfs1());
	return;
}

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	init();
	run();
	return 0;
}
