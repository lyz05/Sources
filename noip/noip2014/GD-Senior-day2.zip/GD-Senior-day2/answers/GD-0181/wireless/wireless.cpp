#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<iostream>
#include<queue>
#include<string>

using namespace std;

int dd;
int mmp[150][150];

void init()
{
	int n,x,y,t;
	memset(mmp,0,sizeof(mmp));
	cin>>dd>>n;
	for(int i=1;i<=n;++i)
	{
		scanf("%d%d%d",&x,&y,&t);
		mmp[x+1][y+1]=t;
	}
	for(int i=1;i<=129;++i)
	{
		for(int k=1;k<=129;++k)
			mmp[i][k]+=mmp[i][k-1];
	}
	return;
}

void run()
{
	int ans=-200000000,fang=0;
	for(int i=1;i<=129;++i)
	{
		for(int k=1;k<=129;++k)
		{
			int bx=max(1,i-dd);
			int by=max(1,k-dd);
			int ex=min(129,i+dd);
			int ey=min(129,k+dd);
			int now=0;
			for(int j=bx;j<=ex;++j)
				now+=mmp[j][ey]-mmp[j][by-1];
			if(now>ans)
			{
				ans=now; fang=1;
			}
			else if(now==ans) ++fang;
		}
	}
	printf("%d %d",fang,ans);
	return;
}

int main()
{
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	init();
	run();
	return 0;
}
