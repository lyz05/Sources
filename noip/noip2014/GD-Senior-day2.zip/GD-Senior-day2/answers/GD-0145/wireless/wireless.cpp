#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <algorithm>

using namespace std;

const int Maxn=200;
int d,n,x,y,k,sum,ans,a[Maxn][Maxn],f[Maxn][Maxn];

int main()
{
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	scanf("%d%d",&d,&n);
	for (int i=1; i<=n; i++) 
	{
	    scanf("%d%d%d",&x,&y,&k);
	    a[x][y]+=k;
	}
	for (int i=0; i<=128; i++)
	for (int j=0; j<=128; j++)
	{
	    for (int p=i-d; p<=i+d; p++)
	    for (int q=j-d; q<=j+d; q++)
	      if (p>=0 && p<=128 && q>=0 && q<=128)
	        f[i][j]+=a[p][q];
	    ans=max(ans,f[i][j]);
    }
    for (int i=0; i<=128; i++)
    for (int j=0; j<=128; j++) if (f[i][j]==ans) sum++;
    printf("%d %d\n",sum,ans);
	return 0;
}
