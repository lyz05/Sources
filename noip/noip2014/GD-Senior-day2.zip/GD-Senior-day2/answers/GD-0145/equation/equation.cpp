#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <algorithm>

using namespace std;

const int Maxn=110;
int n,u,t,m,ll,rr,Mid,ans,Left[Maxn],Right[Maxn],Le[Maxn],Ri[Maxn];
struct Tpoint
{
    int x[10010];
} Temp,Te[Maxn],TE,a[Maxn],b[Maxn],w[Maxn],TT;
bool boo[Maxn],bb[Maxn];
char s[10010];

Tpoint Mul(Tpoint a,Tpoint b)
{
    for (int i=0; i<=10010; i++) TT.x[i]=0;
    int y;
    for (int i=1; i<=a.x[0]; i++)
    for (int j=1; j<=b.x[0]; j++)
    {
    	y=i+j-1;
        TT.x[y]+=a.x[i]*b.x[j];
        TT.x[y+1]+=TT.x[y]/10;
        TT.x[y]=TT.x[y]%10;
    }
    y=a.x[0]+b.x[0]-1;
    for ( ; TT.x[y+1]>0; ) y++;
    TT.x[0]=y;
    return TT;
}

Tpoint Add(Tpoint a,Tpoint b)
{
    for (int i=0; i<=10010; i++) TT.x[i]=0;
    int len=max(a.x[0],b.x[0]);
    for (int i=1; i<=len; i++)
    {
        TT.x[i]+=a.x[i]+b.x[i];
        TT.x[i+1]+=TT.x[i]/10;
        TT.x[i]=TT.x[i]%10;
    }
    for ( ; TT.x[len+1]>0; ) len++;
    TT.x[0]=len;
    return TT;
}

Tpoint De(Tpoint a,Tpoint b)
{
    for (int i=0; i<=10010; i++) Temp.x[i]=0;
    int len=max(a.x[0],b.x[0]);
    for (int i=1; i<=len; i++)
    {
    	for ( ; a.x[i]<b.x[i]; ) 
    	{
    	    a.x[i]+=10;
    	    a.x[i+1]--;
    	}
        Temp.x[i]+=a.x[i]-b.x[i];
        Temp.x[i+1]+=Temp.x[i]/10;
        Temp.x[i]=Temp.x[i]%10;
    }
    for ( ; Temp.x[len]==0 && len>0; ) len--;
    Temp.x[0]=len;
    return Temp;
}

Tpoint Div(Tpoint a,int b)
{
    for (int i=0; i<=10010; i++) Temp.x[i]=0;
    for (int i=a.x[0]; i>0; i--)
    {
        Temp.x[i]=a.x[i]/b;
        a.x[i-1]+=(a.x[i]-a.x[i]/b*b)*10;
    }
    int len=Temp.x[0];
    for ( ; Temp.x[len]==0 && len>0; ) len--;
    Temp.x[0]=len;
    return Temp;
}

bool CHECK(Tpoint a,Tpoint b)
{
    if (a.x[0]<b.x[0]) return false; else 
      if (a.x[0]>b.x[0]) return true;
    for (int i=a.x[0]; i>0; i--) 
	  if (a.x[i]>b.x[i]) return true; else 
	    if (a.x[i]<b.x[i]) return false;
    return true;
}

bool Check(int p)
{
	memset(Te,0,sizeof(Te));
	Te[0].x[0]=1;
	Te[0].x[1]=1;
	for (int i=0; i<=10010; i++) Temp.x[i]=0;
	Temp.x[0]=1;
	Temp.x[1]=p;
	for ( ; Temp.x[Temp.x[0]]>0; )
	{
	    int y=Temp.x[0];
	    Temp.x[y+1]+=Temp.x[y]/10;
	    Temp.x[y]=Temp.x[y]%10;
	    Temp.x[0]=y+1;
	}
	Temp.x[0]--;
	for (int i=1; i<=n; i++) 
	    Te[i]=Mul(Te[i-1],Temp);
	for (int i=0; i<=10010; i++) Temp.x[i]=0;
    for (int i=0; i<=n; i++) if (!boo[i])
    {
    	TE=Mul(a[i],Te[i]);
        Temp=Add(Temp,TE);
    }
    for (int i=0; i<=n; i++) if (boo[i])
    {
        TE=Mul(a[i],Te[i]);
        if (CHECK(Temp,TE)) Temp=De(Temp,TE); else return -1;
    }
    if (Temp.x[0]==0) return 0; else return 1;
}

int main()
{
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	scanf("%d%d",&n,&u);
	for (int i=0; i<=n; i++)
	{
	    scanf("%s",&s);
	    t=0;
	    for ( ; (s[t]>='0' && s[t]<='9'); ) t++;
	    t--;
	    for (int j=0; j<=t; j++) a[i].x[t+1-j]=int(s[j])-int('0');
	    if (s[0]=='-') 
		{
			t=1;
	        for ( ; (s[t]>='0' && s[t]<='9'); ) t++;
	        t--;
	        for (int j=0; j<=t; j++) a[i].x[t+1-j]=int(s[j])-int('0');
			a[i].x[0]=t; 
			boo[i]=true;
		} else a[i].x[0]=t+1;
	}
	for (int i=n; i>=2; i--)
	{
		memset(bb,0,sizeof(bb));
	    for (int j=1; j<=n; j++)
	    {
	    	for (int t=0; t<=10010; t++) Temp.x[t]=0;
	    	Temp.x[0]=1;
	    	Temp.x[1]=j;
	    	for ( ; Temp.x[Temp.x[0]]>=10; )
	    	{
	    	    int y=Temp.x[0];
	    	    Temp.x[y+1]+=Temp.x[y]/10;
	    	    Temp.x[y]=Temp.x[y]%10;
	    	    Temp.x[0]=y+1;
	    	}
	        b[j-1]=Mul(a[j],Temp);
	        bb[j-1]=boo[j];
	    }
	    w[i]=a[0];
	    for (int j=0; j<=n; j++) a[j]=b[j];
	    for (int j=0; j<=n; j++) boo[j]=bb[j];
	}
	m=1;
	Left[1]=1; Right[1]=u;
	for (int i=1; i<=n; i++)
	{
	    for (int j=1; j<=m; j++)
	    {
	        ll=Left[j]; rr=Right[j];
	        for ( ; ll<=rr; )
	        {
	            Mid=(ll+rr)/2;
	            if (Check(Mid)==0) 
				{
				    ll=Mid; rr=Mid;
				    break;
				}
				Check(1);
	            if (Check(Mid)==Check(ll)) ll=Mid+1; else rr=Mid-1;
	        }
	        Le[m]=rr; Ri[m]=ll;
	    }
	    Left[1]=1; Right[1]=Le[1];
	    for (int j=2; j<=m; j++) 
	    {
	        Left[j]=Ri[j-1];
	        Right[j]=Le[j];
	    }
	    m++;
	    Left[m]=Ri[m-1]; Right[m]=u;
	    
	    memset(b,0,sizeof(b));
	    memset(bb,0,sizeof(bb));
	    for (int j=1; j<=i+1; j++)
	    {
	        b[j]=Div(a[j+1],j+1);
	        bb[j]=boo[j+1];
	    }
	    b[0]=w[i+1];
	    for (int j=0; j<=n; j++) a[j]=b[j];
	    for (int j=0; j<=n; j++) boo[j]=bb[j];
	}
	for (int i=1; i<=m; i++) if (Left[i]==Right[i]) ans++;
	printf("%d\n",ans);
	for (int i=1; i<=m; i++) if (Left[i]==Right[i]) printf("%d\n",Left[i]);
	return 0;
}
