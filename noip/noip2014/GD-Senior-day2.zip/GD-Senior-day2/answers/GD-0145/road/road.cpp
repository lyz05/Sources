#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <algorithm>

using namespace std;

const int Maxn=20000,Maxm=300000;
int n,m,s,t,ans,head,tail,a[Maxn],b[Maxn],na[Maxn],nb[Maxn];
bool tf[Maxn],boo[Maxn];
struct Tpoint
{
    int x,y;
}A[Maxm],B[Maxm];

bool cmp(Tpoint a,Tpoint b)
{
    return a.x<b.x;
}

void BFS()
{
    head=1; tail=1;
    a[1]=t;
    memset(boo,0,sizeof(boo));
    boo[t]=true;
    for ( ; head<=tail; head++)
    {
        for (int i=nb[a[head]]; i<=m; i++) if (B[i].x==a[head])
        {
            if (!tf[B[i].y])
            {
            	tail++;
            	a[tail]=B[i].y;
            	boo[a[tail]]=true;
            }
        } else break;
	}
}

void DIST()
{
	if (!tf[s]) return;
    head=1; tail=1;
    memset(boo,0,sizeof(boo));
    memset(b,0,sizeof(b));
    memset(a,0,sizeof(a));
    a[1]=s;
    boo[s]=true;
    for ( ; head<=tail; head++)
    {
        for (int i=na[a[head]]; i<=m; i++) if (A[i].x==a[head])
        {
        	if (tf[A[i].y])
        	  if (!boo[A[i].y])
        	  {
        	      tail++;
        	      a[tail]=A[i].y;
        	      b[tail]=b[head]+1;
        	      if (a[tail]==t) ans=min(ans,b[tail]);
        	  }
        } else break;
    }
}

int main()
{
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    scanf("%d%d",&n,&m);
    for (int i=1; i<=m; i++)
    {
        scanf("%d%d",&A[i].x,&A[i].y);
        B[i].x=A[i].y; B[i].y=A[i].x;
    }
    scanf("%d%d",&s,&t);
    sort(A+1,A+m+1,cmp);
    sort(B+1,B+m+1,cmp);
    for (int i=1; i<=m; i++) if (A[i].x!=A[i-1].x) na[A[i].x]=i;
    for (int i=1; i<=m; i++) if (B[i].x!=B[i-1].x) nb[B[i].x]=i;
    BFS();
    memset(tf,1,sizeof(tf));
    for (int i=1; i<=m; i++) if (!boo[A[i].y]) tf[A[i].x]=false;
    ans=Maxn;
    DIST();
    if (ans==Maxn) printf("%d\n",-1); else printf("%d\n",ans);
    return 0;
}
