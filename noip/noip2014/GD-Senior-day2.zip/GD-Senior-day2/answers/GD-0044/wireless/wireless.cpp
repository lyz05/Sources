#include<fstream>
using namespace std;
int main()
{
	ifstream fin;
	ofstream fout;
	fin.open("wireless.in");
	fout.open("wireless.out");
	int i,j,k,l,m,d,n,p,q,kmax,knum;
	fin>>d>>n;
	int a[129][129]={0};
	for(i=0;i<=n-1;i++)
	{
		fin>>p>>q>>k;
		a[p][q]=k;
	}
	kmax=0;
	knum=0;
	for(i=d;i<=128-d;i++)
	{
		for(j=d;j<=128-d;j++)
		{
	       k=0;
		   for(l=i-d;l<=i+d;l++)
		      for(m=j-d;m<=j+d;m++)
		         k=k+a[l][m];
		   if(k>kmax)
		   {
			 kmax=k;
			 knum=0;
		   }
		   if(k==kmax)
		     knum++;
	    }
	}
	fout<<knum<<" "<<kmax<<endl;
	fin.close();
	fout.close();
	return 0;
}
