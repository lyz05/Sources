#include<fstream>
using namespace std;
int chu[10005][10005]={0};
int n,sum=0;
ifstream fin;
ofstream fout;
bool lian(int p,int q)
{
	int i,j;
	if(p==q)
	  return true;
    for(i=0;chu[p][i]!=0;i++)
	   if(chu[p][i]==q)
	     return true;
	for(i=0;chu[p][i]!=0;i++)
	{
    	for(j=0;chu[chu[p][i]][j]!=0;j++)
    	   if(chu[chu[p][i]][j]==p)
    	     return false;
		if(lian(chu[p][i],q)==true)
          return true;
    }
	return false;
}
int dis(int p,int q)
{
	int i,t,k=10005;
	for(i=0;chu[p][i]!=0;i++)
	{
		if(chu[p][i]==q) return 1;
		if(lian(chu[p][i],q)==false)
		  return -1;
		t=dis(chu[p][i],q);
		if(t==-1) continue;
		if(1+t<k)
		  k=1+t;
	}
	return k;
}
int main()
{
    fin.open("road.in");
    fout.open("road.out");
	int m,i,j,k,p,q;
	fin>>n>>m;
	for(i=0;i<=m-1;i++)
	{
		fin>>p>>q;
		for(j=0;;j++)
		   if(chu[p][j]==0)
		     break;
		chu[p][j]=q;
	}
	fin>>p>>q;
	k=dis(p,q);
	if(k==10005) 
	  fout<<-1<<endl;
	else 
	  fout<<k<<endl;
	fin.close();
	fout.close();
	return 0;
}
