#include<fstream>
using namespace std;
int pow(int a,int b)
{
	int i,k=1;
	for(i=1;i<=b;i++)
	   k=k*a;
	return k;
}
int main()
{
	ifstream fin;
	ofstream fout;
	fin.open("equation.in");
	fout.open("equation.out");
	int n,m,i,j,k,p=0;
	fin>>n>>m;
	int a[n+1],sum,num[n+1];
	for(i=0;i<=n;i++)
	{
	   fin>>a[i];
       num[i]=-1;
	}
	for(i=1;i<=m;i++)
    {
    	sum=0;
		for(j=0;j<=n;j++)
		   sum=sum+pow(i,j)*a[j];
        if(sum==0)
        {
        	num[p]=i;
			p++;
        }
    }
    fout<<p<<endl;
    for(i=0;i<=p-1;i++)
       fout<<num[i]<<endl;
	fin.close();
	fout.close();
	return 0;
}
