#include <fstream>
using namespace std;
ifstream cin("equation.in");
ofstream cout("equation.out");
int main()
{
	int n,m,temp,i,j;
	int a[100];
	cin>>n>>m;
	for(int i=0;i=n;i++)
	{
		cin>>a[i];
	}
	temp=a[n];
	for(i=1;i<=m;i++)
	{
		for(j=n;j>0;j--)
		{
			temp*=a[j-1];
			temp+=i;
		}
		if(temp==0)
		{
			cout<<i<<endl;
		}
	}
	return 0;
}
