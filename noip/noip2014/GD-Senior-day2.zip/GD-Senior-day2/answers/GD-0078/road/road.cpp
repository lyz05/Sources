#include <fstream>
#include <cstdlib>
#include <cstring>
#include <algorithm>
using namespace std;
ifstream cin("road.in");
ofstream cout("road.out");
typedef struct{
	int u,v;//edge from u to v  (reverse)from v to u
	bool is;
}edge;
typedef struct{
	int num;
	int *next;
	bool p;
}note;
edge *e=NULL;
note tt[10005];
int n,m,i,j,s,t;//from s to t
int *dist=NULL;
int *queue=NULL;
bool *is=NULL;
int head,tail,temp;
bool com(edge a,edge b)
{
	if(a.u<b.u)
	{
		return true;
	}
	else if(a.u>b.u)
	{
		return false;
	}
	else
	{
		if(a.v<b.v)
		{
			return true;
		}
		return false;
	}
	
}
bool relax(int a,int k)
{
	if(dist[a]+1<dist[tt[a].next[k]])
	{
		dist[tt[a].next[k]]=dist[a]+1;
		return true;
	}
	return false;
}
int main()
{
	cin>>n>>m;
	dist=(int*)calloc(n+2,sizeof(int));
	queue=(int*)calloc(n+2,sizeof(int));
	is=(bool*)calloc(n+2,sizeof(bool));
	e=(edge*)calloc(m+2,sizeof(edge));
	for(i=0;i<n;i++)
	{
		tt[i].num=0;
		tt[i].next=NULL;
		dist[i]=10001;
		tt[i].p=true;
	}
	for(i=0;i<m;i++)
	{
		cin>>e[i].u>>e[i].v;
		e[i].u--;
		e[i].v--;
		e[i].is=true;
	}
	sort(e,e+m,com);
	for(i=0;i<m;i++)
	{
		if(e[i].u==e[i+1].u&&e[i].v==e[i+1].v)
		{
			e[i+1].is=false;
		}
		if(e[i].is)
		{
			tt[e[i].v].num++;
		}
	}
	for(i=0;i<n;i++)
	{
		tt[i].next=(int*)calloc(tt[i].num+1,sizeof(int));
		tt[i].num=0;
	}
	for(i=0;i<m;i++)
	{
		if(e[i].is)
		{
			tt[e[i].v].next[tt[e[i].v].num++]=e[i].u;
		}
	}
	cin>>s>>t;// from t to s
	s--;
	t--;
	queue[0]=t;
	dist[t]=0;
	is[t]=true;
	head=0;
	tail=1;
	while(head!=tail)
	{
		temp=queue[head%n];
		is[head%n]=false;
		head=(head+1)%n;
		for(i=0;i<tt[temp].num;i++)
		{
			if(relax(temp,i)&&!is[tt[temp].next[i]])
			{
				queue[tail%n]=tt[temp].next[i];
				is[tt[temp].next[i]]=true;
				tail=(tail+1)%n;
			}
		}
	}
//--------------------------------------------------------------------
	for(i=0;i<n;i++)
	{
		if(dist[i]>n)
		{
			for(j=0;j<tt[i].num;j++)
			{
				tt[tt[i].next[j]].p=false;
			}
		}
//		dist[i]=10001;
	}
	for(i=0;i<n;i++)
	{
//		cout<<tt[i].p<<" ";
		dist[i]=10001;
		is[i]=false;
	}
	queue[0]=t;
	dist[t]=0;
	is[t]=true;
	head=0;
	tail=1;
	while(head!=tail)
	{
		temp=queue[head%n];
		is[head%n]=false;
		head=(head+1)%n;
//		cout<<temp+1<<endl;
		for(i=0;i<tt[temp].num;i++)
		{
			if(tt[tt[temp].next[i]].p&&relax(temp,i)&&!is[tt[temp].next[i]])
			{
				queue[tail%n]=tt[temp].next[i];
				is[tt[temp].next[i]]=true;
				tail=(tail+1)%n;
			}
		}
	}
	if(dist[s]>n)
	{
		cout<<-1<<endl;
	}
	else
	{
		cout<<dist[s]<<endl;
	}
	return 0;
}
/*
3 2
1 2
2 1
1 3

6 6
1 2
1 3
2 6
2 5
4 5
3 4
1 5
*/
