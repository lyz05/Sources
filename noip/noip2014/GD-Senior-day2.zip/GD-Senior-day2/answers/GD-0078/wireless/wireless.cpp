#include <fstream>
#include <cstdlib>
#include <cstring>
#define MAX 128
using namespace std;
ifstream cin("wireless.in");
ofstream cout("wireless.out");
int n,m,d,i,j,l,ans;
int xa,xb,ya,yb;
int x,y,k;//at(x,y) had a weight k
int num[130][130];
int main()
{
	memset(num,0,sizeof(num));
	cin>>d>>n;
	for(i=0;i<n;i++)
	{
		cin>>x>>y>>k;
		if(x>d)
		{
			xa=x-d;
		}
		else
		{
			xa=0;
		}
		if(x+d<MAX)
		{
			xb=x+d;
		}
		else
		{
			xb=MAX;
		}
		if(y>d)
		{
			ya=y-d;
		}
		else
		{
			ya=0;
		}
		if(y+d<MAX)
		{
			yb=y+d;
		}
		else
		{
			yb=MAX;
		}
		for(j=xa;j<=xb;j++)
		{
			for(l=ya;l<=yb;l++)
			{
				num[j][l]+=k;
			}
		}
	}
	x=ans=0;
	for(i=0;i<=128;i++)
	{
		for(j=0;j<=128;j++)
		{
//			cout<<num[i][j]<<"  ";
			if(num[i][j]==ans)
			{
				x++;
//				cout<<"("<<i<<","<<j<<")"<<x<<endl;
			}
			if(num[i][j]>ans)
			{
				ans=num[i][j];
				x=1;
//				cout<<"("<<i<<","<<j<<")"<<x<<endl;
			}			
		}
	}
	cout<<x<<" "<<ans<<endl;
	return 0;
}
/*
1
2
4 4 10
6 6 20
*/
