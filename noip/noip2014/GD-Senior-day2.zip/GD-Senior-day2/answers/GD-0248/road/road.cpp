#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <string>
#include <fstream>
using namespace std;

const int maxn = 10500;
const int maxe = 200500;

struct Tedge {
	int node,next;
	Tedge() {}
	Tedge(int tnode,int tnext) { node = tnode; next = tnext; }
}e[maxe];

struct Toppedge {
	int node,next,flag;
	Toppedge() {}
	Toppedge(int tnode,int tnext,int tflag) { node = tnode; next = tnext; flag = tflag; }
}oppe[maxe];

int n,m,fre,s,t,du[maxn],tdu[maxn],head[maxn],opphead[maxn],dis[maxn],q[2*maxe];
bool boo[maxn],isok[maxn];

void Addedge(int a,int b) {
	fre++;
	e[fre] = Tedge(b,head[a]);
	head[a] = fre;
	
	oppe[fre] = Toppedge(a,opphead[b],1);
	opphead[b] = fre;
}

void Init() {
	int a,b;
	fre = -1;
	memset(head,255,sizeof(head));
	memset(opphead,255,sizeof(opphead));
	scanf("%d%d",&n,&m);
	for (int i = 1; i <= m; i++) {
		scanf("%d%d",&a,&b);
		tdu[a]++;
		Addedge(a,b);
	}
	scanf("%d%d",&s,&t);
}

void Bfs() {
	int hh,tt,v;
	hh = 0; tt = 0;
	q[0] = t;
	for (; hh <= tt; hh++) {
		for (int now = opphead[ q[hh] ]; now != -1; now = oppe[now].next)
			if (oppe[now].flag) {
				oppe[now].flag = false;
				v = oppe[now].node;
				du[v] ++;
				q[ ++tt ] = v;
			}
	}
	
	for (int i = 1; i <= n; i++) 
		if (tdu[i] == du[i]) boo[i] =true;
}

bool Solve() {
	if ( (!boo[s]) || (!boo[t]) ) return false;
	memset(dis,255,sizeof(dis));
	int hh,tt,v;
	hh = 0; tt = 0;
	q[0] = s; dis[s] = 0; isok[s] = true;
	for (; hh <= tt; hh++) {
		for (int now = head[ q[hh] ]; now != -1; now = e[now].next) {
			v = e[now].node;
			if ( (boo[v]) && (!isok[v]) ) {
				isok[v] = true;
				q[ ++tt ] = v;
				dis[v] = dis[ q[hh] ] + 1;
				if (v == t) return true;
			}
		}
	}
	return (dis[t] != -1);
}

int main() {
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	
	Init();
	Bfs();
	if ( Solve() ) 
		printf("%d\n",dis[t]); 
	else printf("-1\n");
	
	return 0;
}

