#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <string>
#include <fstream>
using namespace std;

const int maxn = 550;

int d,n,maxp,app,g[maxn][maxn],sum[maxn][maxn];

void Init() {
	int x,y,k;
	scanf("%d%d",&d,&n);
	for (int i = 1; i <= n; i++) {
		scanf("%d%d%d",&x,&y,&k);
		g[x+1][y+1] += k;
	}
}

void PreSolve() {
	for (int i = 1; i < maxn; i++) 
		for (int j = 1; j < maxn; j++)
			sum[i][j] = sum[i][j-1] + g[i][j];
}

void Solve() {
	int tot;
	maxp = 0; app = 0;
	for (int i = 1; i <= 129; i++)
		for (int j = 1; j <= 129; j++) {
			tot = 0;
			for (int k = -d; k <= d; k++)
				if (i + k > 0) {
					if (j - d > 0)
						tot += sum[ i+k ][ j+d ] - sum[ i+k ][ j-d-1 ]; 
					else 
						tot += sum[ i+k ][ j+d ];
				}
			if (tot > maxp) {
				maxp = tot; app = 1;
			} 
			else
			if (tot == maxp) app++;
		}
}

int main() {
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	
	Init();
	PreSolve();
	Solve();
	printf("%d %d\n",app,maxp);
	
	return 0;
}

