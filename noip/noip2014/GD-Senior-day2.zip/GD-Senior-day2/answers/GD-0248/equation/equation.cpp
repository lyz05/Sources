#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <string>
#include <fstream>
using namespace std;

const int maxn = 255;
const int maxm = 105;

int n,m,ans;
int a[maxn][maxn],c[maxn],mu[maxn],tmp[maxn],s[2][maxn],q[maxm];
char ch[maxn];
bool flag;

void Init() {
	int len;
	scanf("%d%d\n",&n,&m);
	for (int i = 0; i <= n; i++) {
		scanf("%s\n",ch);
		len = strlen(ch);
		if (len > 200) { flag = true; return ; }
		if (ch[0] == '-') { 
			a[i][0] = -(len-1);
			for (int j = 1; j < len; j++) a[i][len-j] = ch[j] - 48;
		}
		else {
			a[i][0] = len;
			for (int j = 0; j < len; j++) a[i][len-j] = ch[j] - 48;
		}
	}
}

void Muleasy(int p) {
	memset(c,0,sizeof(c));
	for (int i = 1; i <= mu[0]; i++) {
		c[i] += p * mu[i];
		c[i+1] += c[i] / 10;
		c[i] %= 10;
	}
	c[0] = mu[0];
	for (; c[ c[0] + 1 ] > 0; ) {
		c[0]++;
		c[c[0]+1] += c[c[0]] / 10;
		c[c[0]] %= 10;
	}
	for (int i = 0; i <= c[0]; i++) mu[i] = c[i];
}

void Muldif(int p) {
	memset(tmp,0,sizeof(tmp));
	int len = abs(a[p][0]);
	for (int i = 1; i <= len; i++)
		for (int j = 1; j <= mu[0]; j++) {
			tmp[i+j-1] += a[p][i] * mu[j];
			tmp[i+j] += tmp[i+j-1] / 10;
			tmp[i+j-1] %= 10;
		}
	tmp[0] = len + mu[0] -1;
	for (; tmp[ tmp[0] + 1 ] > 0; ) {
		tmp[0]++;
		tmp[ tmp[0]+1 ] += tmp[tmp[0]] / 10;
		tmp[ tmp[0] ] %= 10;
	}
}

void Add(int p) {
	int len;
	if (tmp[0] > s[p][0]) len = tmp[0]; else len = s[p][0];
	memset(c,0,sizeof(c));
	for (int i = 1; i <= len; i++) {
		c[i] += tmp[i] + s[p][i];
		c[i+1] += c[i] / 10;
		c[i] %= 10;
	}
	c[0] = len;
	for (; c[ c[0] + 1 ] > 0; ) {
		c[0]++;
		c[c[0]+1] += c[c[0]] / 10;
		c[c[0]] %= 10;
	}
	for (int i = 0; i <= c[0]; i++) s[p][i] = c[i];
}

bool Check() {
	if (s[0][0] != s[1][0]) return false;
	for (int i = 1; i <= s[0][0]; i++)
		if (s[0][i] != s[1][i]) return false;
	return true;
}

void Solve() {
	int now;
	for (int i = 1; i <= m; i++) {
		now = i;
		memset(s[0],0,sizeof(s[0]));
		s[0][0] = 1;
		memset(s[1],0,sizeof(s[1]));
		s[1][0] = 1;
		if (a[0][0] < 0)
			for (int j = 0; j <= a[0][0]; j++) s[0][j] = a[0][j];
		else
			for (int j = 0; j <= a[0][0]; j++) s[1][j] = a[0][j];
			
		memset(mu,0,sizeof(mu));
		mu[0] = 1; mu[1] = 1;
		
		for (int j = 1; j <= n; j++) {
			Muleasy(now); // mu * now --> mu
			if (a[j][0] == 0) continue;
			Muldif(j); // a * mu --> tmp 
			int cho = (a[j][0] > 0);
			Add(cho); // s[cho] + tmp --> s[cho]
		}
		if ( Check() ) { // s[0] == s[1]
			ans++;
			q[ans] = i;
		}
	}
}

int main() {
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	
	Init();
	if (flag) { printf("0\n"); return 0; }
	Solve();
	printf("%d\n",ans);
	for (int i = 1; i <= ans; i++) printf("%d\n",q[i]);
	
	return 0;
}

