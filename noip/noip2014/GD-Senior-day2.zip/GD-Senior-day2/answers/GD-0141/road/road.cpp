#include<cstdio>
#include<vector>
#include<cstring>
using namespace std;

const int maxn=10100;
int n,s,t,reh[maxn],avi[maxn],que[maxn],dis[maxn],qt,qh;
vector<int> G1[maxn],G2[maxn];
void readin() {
	int m;
	scanf("%d%d",&n,&m);
	while(m--) {
		int a,b;
		scanf("%d%d",&a,&b);
		G1[a].push_back(b);
		G2[b].push_back(a);
	}
	scanf("%d%d",&s,&t);
}
void dfs(int u) {
	if(reh[u])
		return ;
	reh[u]=1;
	for(int i=0;i<G2[u].size();i++)
		dfs(G2[u][i]);
}
void bfs() {
	int i,u,v;
	que[0]=s;qt=0;qh=1;
	for(i=1;i<=n;i++)
		dis[i]=-1;
	if(!avi[s]) return ;
	dis[s]=0;
	while(qt<qh) {
		u=que[qt++];
		for(i=0;i<G1[u].size();i++) {
			v=G1[u][i];
			if(avi[v] && dis[v]==-1) {
				dis[v]=dis[u]+1;
				que[qh++]=v;
			}
		}
	}
}
void work() {
	memset(reh,0,sizeof(reh));
	dfs(t);
	for(int i=1;i<=n;i++) {
		avi[i]=1;
		for(int j=0;j<G1[i].size();j++)
			if(!reh[G1[i][j]]) {
				avi[i]=0;
				break;
			}
	}
	bfs();
}
void print() {
	printf("%d\n",dis[t]);
}
int main() {
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	
	readin();
	work();
	print();
	
	return 0;
}

