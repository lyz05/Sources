#include<cstring>
#include<fstream>
using namespace std;
ifstream fin("wireless.in");
ofstream fout("wireless.out");

int d;
long long hot[129][129],ans,tot;
void readin() {
	int n;
	fin>>d>>n;
	memset(hot,0,sizeof(hot));
	while(n--) {
		int x,y;
		long long k;
		fin>>x>>y>>k;
		hot[x][y]+=k;
	}
}
void work() {
	ans=tot=0;
	int i,j,k,l;
	long long tmp;
	for(i=d;i+d<129;i++)
		for(j=d;j+d<129;j++) {
			tmp=0;
			for(k=i-d;k<=i+d;k++)
				for(l=j-d;l<=j+d;l++)
					tmp+=hot[k][l];
			if(tmp>ans) {
				ans=tmp;
				tot=1;
			} else if(tmp==ans)
				tot++;
		}
}
void print() {
	fout<<tot<<" "<<ans<<endl;
}
int main() {
	readin();
	work();
	print();
	
	return 0;
}

