#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;

typedef long long ll;
const int LEN=10010,maxn=200,wc=10;
const ll yw=10000000000ll;
int n,m,mn[maxn],rt[maxn],tot;
ll pow[wc];
char s[LEN],*p;
struct BigNum {
	ll d[LEN/wc];
	int len;
	void Clear() { memset(d,0,sizeof(d));len=1; }
	void Init(char *p) {
		Clear();
		int cd=strlen(p),i;
		reverse(p,p+cd);
		for(i=0;i<cd;i++)
			d[i/wc]+=pow[i%wc]*(p[i]-'0');
		len=(cd-1)/wc+1;
	}
	void upd() {
		for(int i=0;i<len;i++) {
			d[i+1]+=d[i]/yw;
			d[i]%=yw;
		}
		for(;d[len];len++) {
			d[len+1]+=d[len]/yw;
			d[len]%=yw;
		}
	}
	void Mul(ll k) {
		for(int i=0;i<len;i++)
			d[i]*=k;
		upd();
	}
} a[maxn],Lf,Rt;
void Add(BigNum &a,BigNum &b) {
	for(int i=0;i<b.len;i++)
		a.d[i]+=b.d[i];
	a.len=max(a.len,b.len);
	a.upd();
}
bool IsRoot(int x) {
	Lf.Clear();
	Rt.Clear();
	for(int i=n;i>=0;i--) {
		Lf.Mul(x);
		Rt.Mul(x);
		if(mn[i])
			Add(Rt,a[i]);
		else
			Add(Lf,a[i]);
	}
	if(Lf.len!=Rt.len) return false;
	for(int i=0;i<Lf.len;i++)
		if(Lf.d[i]!=Rt.d[i])
			return false;
	return true;
}
void readin() {
	int i;
	pow[0]=1;
	for(i=1;i<wc;i++)
		pow[i]=pow[i-1]*10;
	memset(mn,0,sizeof(mn));
	scanf("%d%d",&n,&m);
	for(int i=0;i<=n;i++) {
		scanf("%s",s);
		p=s;
		if(s[0]=='-') {
			mn[i]=1;
			p++;
		}
		a[i].Init(p);
	}
}
void work() {
	tot=0;
	for(int i=1;i<=m;i++)
		if(IsRoot(i))
			rt[tot++]=i;
}
void print() {
	printf("%d\n",tot);
	for(int i=0;i<tot;i++)
		printf("%d\n",rt[i]);
}
int main() {
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	
	readin();
	work();
	print();
	
	return 0;
}

