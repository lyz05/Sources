#include <stdio.h>
#include <stdlib.h>

struct Node {
  int v;
  struct Node *next;
};
typedef struct {
  int v;
  int step;
} Queue;

FILE *fin, *fout;
struct Node *G[10050], 
            *GT[10050];
int reach[10050] = {0},
    select[10050];
int visited[10050]; /* DFS BFS */
Queue queue[10050]; /* BFS */
int n, s, t;

void openfile(void);
void readdata(void);
void DFSvisit(int vertex);
void findselect(void);
int BFS(void);
void closefile(void);

int main(void)
{
  int i, j;
  
  openfile();
  
  readdata();
  
  for (i = 1; i <= n; i++)
    visited[i] = 0;
  DFSvisit(t);
  
  findselect();
  
  if (select[s] == 0) {
    fprintf(fout, "-1\n");
    return 0;
  }
  else 
    fprintf(fout, "%d\n", BFS());
  
  closefile();
  
  return 0;
}

void openfile(void)
{
  fin = fopen("road.in", "r");
  fout = fopen("road.out", "w");
}

void readdata(void)
{
  int m, x, y;
  int i;
  struct Node *newp;
  
  fscanf(fin, "%d%d", &n, &m);
  
  for (i = 1; i <= n; i++) {
    G[i] = NULL;
    GT[i] = NULL;
  }
  
  for (i = 1; i <= m; i++) {
    fscanf(fin, "%d%d", &x, &y);
    /* Generate G */
    newp = (struct Node *) malloc(sizeof (struct Node));
    newp -> v = y;
    newp -> next = G[x];
    G[x] = newp;
    /* Generate GT */
    newp = (struct Node *) malloc(sizeof (struct Node));
    newp -> v = x;
    newp -> next = GT[y];
    GT[y] = newp;
  }
  
  fscanf(fin, "%d%d", &s, &t);
}
    
void DFSvisit(int vertex)
{
  struct Node *p;
  
  visited[vertex] = 1;
  reach[vertex] = 1;
  for (p = GT[vertex]; p != NULL; p = p -> next) {
    if (!visited[p -> v]) 
      DFSvisit(p -> v);
  }
}
 
void findselect(void)
{
  int i;
  struct Node *p;
  
  for (i = 1; i <= n; i++)
    select[i] = 1;
  
  for (i = 1; i <= n; i++) {
    if (reach[i] == 0) {
      select[i] = 0;
      for (p = GT[i]; p != NULL; p = p -> next) 
        select[p -> v] = 0;
    }
  }
}

int BFS(void)
{
  int curv, curstep;
  int i;
  int rear, front;
  struct Node *p;
  
  for (i = 1; i <= n; i++)
    visited[i] = 0;
  
  front = 0;
  rear = 1;
  queue[rear].step = 0;
  queue[rear].v = s;
  visited[s] = 1;
  
  if (s == t)
    return 0;
  
  while (front < rear) {
    front++;
    curv = queue[front].v;
    curstep = queue[front].step;
    for (p = G[curv]; p != NULL; p = p -> next) {
      if (!visited[p -> v] && select[p -> v] == 1) {
        rear++;
        visited[p -> v] = 1;
        queue[rear].v = p -> v;
        queue[rear].step = curstep + 1;
        if (p -> v == t) 
          return queue[rear].step;
      }
    }
  }
  
  return -1;
}   

void closefile(void)
{
  fclose(fin);
  fclose(fout);
}

