#include <stdio.h>
#include <math.h>

#define MAXx 128
#define MAXy 128

typedef struct {
  int x, y;
  int k;
} Public;

FILE *fin, *fout;
int d, n;
Public pub[50];

void openfile(void);
void closefile(void);
int isinrange(int kpub, int hx, int hy);

int main(void)
{
  int maxval, curval;
  int maxcount;
  int i, j, p;
  
  openfile();
  
  /* Read Data */
  fscanf(fin, "%d", &d);
  fscanf(fin, "%d", &n);
  for (i = 1; i <= n; i++) 
    fscanf(fin, "%d%d%d", &pub[i].x, &pub[i].y, &pub[i].k);
    
  /* Find max ksum */
  maxval = 0;
  for (i = 0; i <= MAXx; i++) {
    for (j = 0; j <= MAXy; j++) {
      curval = 0;
      for (p = 1; p <= n; p++) {
        if (isinrange(p, i, j))
          curval += pub[p].k;
      }
      if (curval > maxval)
        maxval = curval;
    }
  }
  
  /* Find max count */
  maxcount = 0;
  for (i = 0; i <= MAXx; i++) {
    for (j = 0; j <= MAXy; j++) {
      curval = 0;
      for (p = 1; p <= n; p++) {
        if (isinrange(p, i, j))
          curval += pub[p].k;
      }
      if (curval == maxval)
        maxcount++;
    }
  }
  
  fprintf(fout, "%d %d\n", maxcount, maxval);
  
  closefile();
  
  return 0;
}

void openfile(void)
{
  fin = fopen("wireless.in", "r");
  fout = fopen("wireless.out", "w");
}

void closefile(void)
{
  fclose(fin);
  fclose(fout);
}

int isinrange(int kpub, int hx, int hy)
{
  return (abs(pub[kpub].x - hx) <= d) && (abs(pub[kpub].y - hy) <= d);
}

