#include <stdio.h>

#define PRIMECNT 5428

FILE *fin, *fout;
int n, m;
char a[101][10050];
int solution[101];
int prime[PRIMECNT + 50];

void openfile(void);
void closefile(void);
void generateprime(void);
int func(int x, int mod); /* compute f(x) % mod */
int amodm(int ai, int mod); /* compute a[i] % mod */

int main(void)
{
  int mod;
  int count;
  int i, j;
  
  openfile();
  
  /* Read Data */
  fscanf(fin, "%d%d", &n, &m);
  for (i = 0; i <= n; i++) 
    fscanf(fin, "%s", a[i]);
    
  /* Compute */
  generateprime();
  count = 0;
  for (i = 1; i <= m; i++) {
    for (j = PRIMECNT; j >= 1; j--) 
      if (func(i, prime[j]) != 0)
        break;

    if (j < 1) {
      count++;
      solution[count] = i;
      if (count == n)
        break;
    }
  }
  
  fprintf(fout, "%d\n", count);
  for (i = 1; i <= count; i++)
    fprintf(fout, "%d\n", solution[i]);
  
  closefile();
  
  return 0;
}

void openfile(void)
{
  fin = fopen("equation.in", "r");
  fout = fopen("equation.out", "w");
}

void closefile(void)
{
  fclose(fin);
  fclose(fout);
}

void generateprime(void)
{
  int i, j, k;
  int lim = PRIMECNT + 10;
  
  prime[1] = 2; prime[2] = 3;
  j = 2;
  for (i = 5; j < lim;) {
    for (k = 1; prime[k] * prime[k] <= i; k++)
      if (i % prime[k] == 0)
        break;
    if (prime[k] * prime[k] > i) {
      j++;
      prime[j] = i;
    }
    i += 2;
    for (k = 1; prime[k] * prime[k] <= i; k++)
      if (i % prime[k] == 0)
        break;
    if (prime[k] * prime[k] > i) {
      j++;
      prime[j] = i;
    }
    i += 4;
  }
}

int func(int x, int mod)
{
  int i;
  long long int ans;
  
  ans = amodm(n, mod);
  for (i = n - 1; i >= 0; i--) {
    ans = (ans * x) % mod;
    ans = (ans + amodm(i, mod)) % mod;
  }
  
  return (int) ans;
}
    
int amodm(int ai, int mod)
{
  int sign;
  int ans;
  int i;
  
  if (a[ai][0] == '-') {
    sign = -1;
    i = 1;
  }
  else {
    sign = 1;
    i = 0;
  }
    
  ans = a[ai][i] - '0';
  for (i++; a[ai][i] != '\0'; i++) {
    ans = ans * 10 % mod;
    ans = (ans + a[ai][i] - '0') % mod;
  }
  
  ans *= sign;
  ans = (ans + mod) % mod;
  
  return ans;
}

