#include <cstdio>
#include <cstring>
#define repu(i,x,y) for (int i=x; i<=y; ++i)
#define repe(x) for (edge *i=first[x]; i; i=i->next)
using namespace std;

int n,m,x,s,t,dis[10100],q[10100],head,tail;
bool v[10100],flag[10100];
struct edge
{
    int v;
    edge *next;
} pool[200100],*tp=pool,*first[10100];

void bfs1()
{
    for (q[0]=t,v[t]=true; head<=tail; ++head)
        repe(q[head])
            if (!v[i->v])
                v[i->v]=true,q[++tail]=i->v;
}

void bfs2()
{
    memset(dis,-1,sizeof(dis)),dis[t]=0;
    for (q[head=tail=0]=t; head<=tail; ++head)
        repe(q[head])
            if (flag[i->v] && dis[i->v]==-1)
                dis[i->v]=dis[q[head]]+1,q[++tail]=i->v;
}

int main()
{
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    scanf("%d%d",&n,&m);
    repu(i,1,m)
    {
        scanf("%d%d",&tp->v,&x);
        tp->next=first[x],first[x]=tp++;
    }
    scanf("%d%d",&s,&t);
    bfs1();
    memset(flag,true,sizeof(flag));
    repu(j,1,n)
        if (!v[j])
            repe(j)
                flag[i->v]=false;
    bfs2();
    printf("%d\n",dis[s]);
    return 0;
}
