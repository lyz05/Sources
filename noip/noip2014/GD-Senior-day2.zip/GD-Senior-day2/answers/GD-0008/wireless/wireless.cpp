#include <cstdio>
#include <algorithm>
#define repu(i,x,y) for (int i=x; i<=y; ++i)
using namespace std;

int d,n,x[100],y[100],k[100],t,ans,cnt;

int calc(int x1,int y1,int x2,int y2)
{
    int ret=0;
    repu(i,1,n)
        if (x1<=x[i] && x2>=x[i] && y1<=y[i] && y2>=y[i])
            ret+=k[i];
    return ret;
}

int main()
{
    freopen("wireless.in","r",stdin);
    freopen("wireless.out","w",stdout);
    scanf("%d%d",&d,&n);
    repu(i,1,n)
        scanf("%d%d%d",&x[i],&y[i],&k[i]);
    repu(i,0,128)
        repu(j,0,128)
        {
            t=calc(max(0,i-d),max(0,j-d),min(128,i+d),min(128,j+d));
            if (t==ans)
                ++cnt;
            if (t>ans)
                ans=t,cnt=1;
        }
    printf("%d %d\n",cnt,ans);
    return 0;
}
