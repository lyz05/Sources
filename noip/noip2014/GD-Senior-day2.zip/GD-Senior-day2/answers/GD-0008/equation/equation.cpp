#include <cstdio>
#include <cctype>
#include <cstring>
#include <algorithm>
#define repu(i,x,y) for (int i=x; i<=y; ++i)
#define repd(i,x,y) for (int i=x; i>=y; --i)
using namespace std;

typedef long long LL;
const int maxnum=(1<<30)-1;
int n,m,ans[1000100];
char ch;
struct bigint
{
    int len;
    LL num[3000];
    bool flag;
    void read()
    {
        char ch;
        while (!isdigit(ch=getchar()) && ch!='-');
        if (ch=='-')
            flag=false,ch=getchar();
        else
            flag=true;
        num[0]=ch-'0';
        while (isdigit(ch=getchar()))
        {
            repd(i,len,0)
                num[i]*=10;
            num[0]+=ch-'0';
            for (int i=0; i<=len; ++i)
                num[i+1]+=num[i]>>30,num[i]&=maxnum;
            if (num[len+1]>0)
                ++len;
        }
    }
} a[110],sum1,sum2,sum3,sum4,x,t1,t2,t3,nul;
bool flag;

void work1()
{
    int a0,a1,a2;
    if (n==1)
    {
        scanf("%d%d",&a0,&a1);
        repu(i,1,m)
            if (a0+a1*i==0)
                ans[++ans[0]]=i;
    }
    else
    {
        scanf("%d%d%d",&a0,&a1,&a2);
        repu(i,1,m)
            if (a0+a1*i+a2*i*i==0)
                ans[++ans[0]]=i;
    }
}

/*void get_prime()
{
    repu(i,2,m)
    {
        if (!flag[i])
            prm[++tot]=i;
        for (int j=1; j<=tot && i*prm[j]<=m; ++j)
        {
            flag[i*prm[j]]=true;
            if (!(i%prm[j]))
                break;
        }
    }
}*/

void copy(bigint &x,const bigint &y)
{
    repu(i,y.len+1,x.len)
        x.num[i]=0;
    repu(i,0,y.len)
        x.num[i]=y.num[i];
    x.len=y.len;
}

void mul(const bigint &x,const bigint &y,bigint &z)
{
    z.flag=(x.flag==y.flag);
    copy(z,nul);
    repu(i,0,x.len)
        repu(j,0,y.len)
        {
            z.num[i+j]+=x.num[i]*y.num[j];
            z.num[i+j+1]+=z.num[i+j]>>30,z.num[i+j]&=maxnum;
        }
    repu(i,0,x.len+y.len+1)
       z.num[i+1]+=z.num[i]>>30,z.num[i]&=maxnum;
    repd(i,x.len+y.len+1,0)
        if (z.num[i])
        {
            z.len=i;
            break;
        }
}

void plus(const bigint &x,const bigint &y,bigint &z)
{
    z.flag=x.flag;
    repu(i,max(x.len,y.len)+1,z.len)
        z.num[i]=0;
    z.len=max(x.len,y.len);
    repu(i,0,z.len)
    {
        z.num[i]=x.num[i]+y.num[i];
        z.num[i+1]+=z.num[i]>>30,z.num[i]&=maxnum;
    }
    if (z.num[z.len+1])
        ++z.len;
}

void work2()
{
    repu(i,0,n)
        a[i].read();
    repu(i,1,m)
    {
        x.len=0,x.num[0]=i,x.flag=true;;
        copy(t1,nul),t1.flag=true,t1.num[0]=i;
        if (a[0].flag)
            copy(sum1,a[0]),copy(sum3,nul);
        else
            copy(sum3,a[0]),copy(sum1,nul);
        repu(j,1,n)
            if (j&1)
            {
                mul(t1,x,t2);
                mul(t2,a[j],t3);
                if (t3.flag)
                    plus(sum1,t3,sum2),copy(sum4,sum3);
                else
                    plus(sum3,t3,sum4),copy(sum2,sum1);
            }
            else
            {
                mul(t2,x,t1);
                mul(t1,a[j],t3);
                if (t3.flag)
                    plus(sum2,t3,sum1),copy(sum3,sum4);
                else
                    plus(sum4,t3,sum3),copy(sum1,sum2);
            }
        flag=true;
        if (n&1)
        {
            if (sum2.len!=sum4.len)
                continue;
            repu(j,0,sum2.len)
                if (sum2.num[j]!=sum4.num[j])
                {
                    flag=false;
                    break;
                }
        }
        else
        {
            if (sum1.len!=sum3.len)
                continue;
            repu(j,0,sum1.len)
                if (sum1.num[j]!=sum3.num[j])
                {
                    flag=false;
                    break;
                }
        }
        if (flag)
            ans[++ans[0]]=i;
    }
}

int main()
{
    freopen("equation.in","r",stdin);
    freopen("equation.out","w",stdout);
    scanf("%d%d",&n,&m);
    if (n<=2)
        work1();
    else
        work2();
    printf("%d\n",ans[0]);
    repu(i,1,ans[0])
        printf("%d\n",ans[i]);
    return 0;
}
