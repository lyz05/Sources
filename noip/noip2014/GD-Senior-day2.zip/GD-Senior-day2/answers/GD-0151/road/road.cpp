#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <queue>
using namespace std;

struct node
{
	int x, y, d, next;
}a[200010]; int fir[10100], len;

struct rnode
{
	int x, y, d, next;
}ra[200010]; int rfir[10100], rlen;

int n, m;
int be, ed;
bool v[10100];
bool vv[10100];
int fv[10100];
int d[10100];
queue<int> dl;

void ins ( int x, int y, int d )
{
	len ++;
	a[len].x = x; a[len].y = y; a[len].d = d;
	a[len].next = fir[x]; fir[x] = len;
}

void rins ( int x, int y, int d )
{
	rlen ++;
	ra[len].x = x; ra[len].y = y; ra[len].d = d;
	ra[len].next = rfir[x]; rfir[x] = len;
}

void dfs ( int x )
{
    int k;
    for ( k = rfir[x]; k; k = ra[k].next )
    {
    	int y = ra[k].y;
        if ( !v[y] ) { v[y] = 1; dfs(y); } 
	}
}

int main ()
{
	freopen ( "road.in", "r", stdin );
	freopen ( "road.out", "w", stdout );
	memset ( fir, 0, sizeof(fir) ); len = 0;
	memset ( rfir, 0, sizeof(rfir) ); rlen = 0;
	scanf ( "%d%d", &n, &m );
	int i, j;
	for ( i = 1; i <= m; i ++ )
	{
		int xx, yy;
	    scanf ( "%d%d", &xx, &yy );
		if ( xx != yy) ins ( xx, yy, 1 ), rins(yy,xx,1);
	}
	scanf ( "%d%d", &be, &ed );
	memset ( v, 0, sizeof(v) ); 
	v[ed] = 1; dfs(ed);
	
	for ( i = 1; i <= n; i ++ ) fv[i] = v[i];
	for ( i = 1; i <= n; i ++ )
	if ( fv[i] )
	{
		for ( int k = fir[i]; k; k = a[k].next )
		 if ( !v[a[k].y] ) { fv[i] = 0; break; }
	}
	
	if ( !fv[be] ) { printf ( "-1\n" ); return 0; }
	while ( !dl.empty() ) dl.pop();
	dl.push(be);
	memset ( vv, 0, sizeof(vv));
	memset ( d, 63, sizeof(d) );
	d[be] = 0; vv[be] = 1;
	
	//for ( i = 1; i <= n; i ++ ) printf ( "%d ", fv[i] ); printf ( "\n" );
	//for ( i = 1; i <= n; i ++ ) printf ( "%d ", v[i] ); printf ( "\n" );
	while ( !dl.empty() )
	{
		int x = dl.front();
		for ( int k = fir[x]; k; k = a[k].next )
		{
			int y = a[k].y;
			if ( fv[y] )
			{
				if ( d[y] > d[x]+1 )
				{
				    d[y] = d[x]+1;
			        if ( !vv[y] ) vv[y] = 1, dl.push(y);
				}
			}
		}
		dl.pop();
	}
	printf ( "%d\n", d[ed] );
	return 0;
}
