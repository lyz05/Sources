#include <cstdio>
#include <cstdlib>
#include <cstring>
using namespace std;

int n;
int a[110];
int b[1000010], len = 0;

int cf ( int x, int y )
{
	int now = 1;
	for ( int i = 1; i <= y; i ++ )
	 now = now*x;
	return now;  
}

int main ()
{
	freopen ( "equation.in", "r", stdin );
	freopen ( "equation_vio.out", "w", stdout );
	int n, m;
	scanf ( "%d%d", &n, &m );
	int i, j;
	for ( i = 0; i <= n; i ++ )
	 scanf ( "%d", &a[i] );
	for ( i = 1; i <= m; i ++ )
	{
		int now = 0;
		for ( j = 0; j <= n; j ++ )
		 now += a[j]*cf(i,j);
		if ( now == 0 ) b[++len] = i;
	}
	printf ( "%d\n", len );
	for ( i = 1; i <= len; i ++ )
	 printf ( "%d\n", b[i] );
	return 0;
}
