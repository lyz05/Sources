#include <cstdio>
#include <cstdlib>
#include <cstring>
#define LL long long
using namespace std;

LL d, n;
LL sum[150][150];
LL mmax, Num;

LL _min ( LL x, LL y ) { return x < y ? x : y; }
LL _max ( LL x, LL y ) { return x > y ? x : y; }

int main ()
{
	freopen ( "wireless.in", "r", stdin );
	freopen ( "wireless.out", "w", stdout );
	memset ( sum, 0, sizeof(sum) );
    scanf ( "%lld%lld", &d, &n );
	LL i, j, k;
	for ( i = 1; i <= n; i ++ )
	{
		LL xx, yy, dd;
		scanf ( "%lld%lld%lld", &xx, &yy, &dd );
		xx ++; yy ++;
		sum[xx][yy] = dd;
	}	
	for ( i = 1; i <= 129; i ++ )
	 for ( j = 2; j <= 129; j ++ )
	  sum[i][j] += sum[i][j-1];

    mmax = -999999999, Num = 0;
    for ( i = 1; i <= 129; i ++ )
     for ( j = 1; j <= 129; j ++ )
     {
     	LL now = 0;
     	for ( k = _max(i-d,1); k <= _min(i+d,129); k ++ )
     	 now += sum[k][_min(j+d,129)] - sum[k][_max(j-d-1,0)];
     	if ( now > mmax ) { mmax = now; Num = 0; }
		if ( now == mmax ) Num ++;
     } 
    //for ( i = 1; i <= 10; i ++ ) printf ( "%lld ", sum[5][i] ); 
    //for ( i = 1; i <= 10; i ++ ) printf ( "%lld ", sum[7][i] ); 
    printf ( "%lld %lld\n", Num, mmax );
    //printf ( "%I64d %I64d\n", Num, mmax );
    //mmax = 9; printf ( "%lld %I64d\n", mmax, mmax );
	return 0;
}  
