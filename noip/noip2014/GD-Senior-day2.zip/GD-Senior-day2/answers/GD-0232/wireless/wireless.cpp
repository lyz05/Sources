#include <cstdio>
#include <cstring>

const int maxn=25;

int d;
int n;
//int x[maxn], y[maxn], k[maxn];
int map[130][130];
int f[130][130];
int maxv=0, cntv=0;

int max(const int x, const int y) {
    return x>y?x:y;
}

void input() {
    int x, y, k;
    FILE *fin=fopen("wireless.in", "r");
    memset(map, 0, sizeof(map));
    fscanf(fin, "%d%d", &d, &n);
    for(int i=1; i<=n; i++) {
        fscanf(fin, "%d%d%d", &x, &y, &k);
        map[x][y]=k;
    }
    fclose(fin);
    return;
}

void output() {
    FILE *fout=fopen("wireless.out", "w");
    fprintf(fout, "%d %d", cntv, maxv);
    fclose(fout);
}

int heng(int x, int y) {
    int sum=0;
    for(int i=x; i<=x+2*d; i++)
        sum+=map[i][y];
    return sum;
}

int shu(int x, int y) {
    int sum=0;
    for(int i=y; i<=y+2*d; i++)
        sum+=map[x][i];
    return sum;
}

void dp() {
    memset(f, 0, sizeof(f));
    for(int i=0; i<=2*d; i++)
        for(int j=0; j<=2*d; j++) {
            f[0][0]+=map[i][j];
            if(f[0][0]>maxv) {
                maxv=f[0][0];
                cntv=1;
            } else if(f[0][0]==maxv) {
                cntv++;
            }
        }
    for(int i=1; i<=128-2*d; i++) {
        f[i][0]=f[i-1][0]-shu(i-1, 0)+shu(i+2*d, 0);
        if(f[i][0]>maxv) {
            maxv=f[i][0];
            cntv=1;
        } else if(f[i][0]==maxv) {
            cntv++;
        }
    }
    for(int i=0; i<=128-2*d; i++) {
        for(int j=1; j<=128-2*d; j++) {
            f[i][j]=f[i][j-1]-heng(i, j-1)+heng(i, j+2*d);
            if(f[i][j]>maxv) {
                maxv=f[i][j];
                cntv=1;
            }
            else if(f[i][j]==maxv)
                cntv++;
        }
    }
    return;
}

int main() {
    input();
    dp();
    output();
    return 0;
}
