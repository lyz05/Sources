#include <cstdio>
#include <cstring>
#include <queue>

using namespace std;

const int maxn=10010, maxm=200010, INF=2000000000;

int n, m;
int u[maxm], v[maxm];
int s, t;
int first1[maxn], next1[maxm];
int first2[maxn], next2[maxm];
int dt[maxn], ds[maxn];
bool tovis[maxn];

void input() {
    int x, y;
    FILE *fin=fopen("road.in", "r");
    fscanf(fin, "%d%d", &n, &m);
    memset(first1, -1, sizeof(first1));
    memset(first2, -1, sizeof(first2));
    memset(next1, -1, sizeof(next1));
    memset(next2, -1, sizeof(next2));
    for(int i=1; i<=m; i++) {
        fscanf(fin, "%d%d", &x, &y);
        u[i]=x; v[i]=y;
        next1[i]=first1[u[i]];
        first1[u[i]]=i;
        next2[i]=first2[v[i]];
        first2[v[i]]=i;
    }
    fscanf(fin, "%d%d", &s, &t);
    fclose(fin);
    return;
}

/*
void output() {
    FILE *fout=fopen("road.out", "w");
    fprintf(fout, "%d", ds[t]);
    fclose(fout);
}
*/

void spfa_t() {
    queue<int> q;
    bool inq[maxn];
    for(int i=1; i<=n; i++)
        dt[i]=(i==t?0:INF);
    memset(inq, false, sizeof(inq));
    q.push(t);
    inq[t]=true;
    while(!q.empty()) {
        int x=q.front(); q.pop();
        inq[x]=false;
        for(int e=first2[x]; e!=-1; e=next2[e])
            if(dt[u[e]]>dt[x]+1) {//if(d[u[e]]>d[x]+w[e])
                dt[u[e]]=dt[x]+1;
                if(!inq[u[e]]) {
                    q.push(u[e]);
                    inq[u[e]]=true;
                }
            }
    }
    return;
}

void spfa_s() {
    queue<int> q;
    bool inq[maxn];
    for(int i=1; i<=n; i++)
        ds[i]=(i==s?0:INF);
    memset(inq, false, sizeof(inq));
    q.push(s);
    inq[s]=true;
    while(!q.empty()) {
        int x=q.front(); q.pop();
        inq[x]=false;
        for(int e=first1[x]; e!=-1; e=next1[e])
            if(tovis[v[e]] && ds[v[e]]>ds[x]+1) {//if(d[u[e]]>d[x]+w[e])
                ds[v[e]]=ds[x]+1;
                if(!inq[v[e]]) {
                    q.push(v[e]);
                    inq[v[e]]=true;
                }
            }
    }
    return;
}

/*
void dfs(int step, int node) {
    if(step>2)
        return;
    tovis[node]=false;
    for(int e=first2[node]; e!=-1; e=next2[e]) {
        //tovis[u[e]]=false;
        dfs(step+1, u[e]);
    }
    return;
}
*/

void clear(int node) {
    tovis[node]=false;
    for(int e=first2[node]; e!=-1; e=next2[e])
        tovis[u[e]]=false;
    return;
}

int main() {
    FILE *fout=fopen("road.out", "w");    
    input();
    spfa_t();
    memset(tovis, true, sizeof(tovis));
    for(int i=1; i<=n; i++)
        if(dt[i]==INF) {
            if(i==s) {
                fprintf(fout, "-1");
                return 0;
            }
            else
                clear(i);//dfs(1, i);
        }
    if(!tovis[s]) {
        fprintf(fout, "-1");
        return 0;
    }
    spfa_s();
    if(ds[t]==INF)
        fprintf(fout, "-1");
    else
        fprintf(fout, "%d", ds[t]);
    fclose(fout);
    return 0;
}
