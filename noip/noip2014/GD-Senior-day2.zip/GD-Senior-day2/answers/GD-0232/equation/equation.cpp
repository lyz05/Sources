#include <cstdio>

const int maxn=110;

int n, m;
long long a[maxn];

void input() {
    FILE *fin=fopen("equation.in", "r");
    char ch;
    fscanf(fin, "%d", &n);
    fscanf(fin, "%d", &m);
    for(int i=0; i<=n; i++)
        fscanf(fin, "%lld", &a[i]);
    fclose(fin);
    return;
}

long long value(long long x) {
    long long ans=a[n]*x+a[n-1];
    for(int i=n-2; i>=0; i--)
        ans=ans*x+a[i];
    return ans;
}

int main() {
    FILE *fout=fopen("equation.out", "w");
    //int left, right, mid;
    input();
    //left=1; right=m;
    //mid=(left+right)>>1;
    //while(left<right) {
    //    if(value(mid)==0)
    //        output(mid);
    //}
    if(m>100) {
        fprintf(fout, "0");
        return 0;
    }
    long long count=0, list[1000];
    for(long long i=1; i<=m; i++) {
        if(value(i)==0){
            list[count++]=i;
        }
    }
    fprintf(fout, "%lld\n", count);
    for(long long i=0; i<count; i++)
        fprintf(fout, "%lld\n", list[i]);
    fclose(fout);
    return 0;
}
