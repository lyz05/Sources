#include <fstream>
#include <stdio.h>
#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
#include <string.h>
#include <cmath>
#include <algorithm>
#include <vector>
#include <cstdlib>
#include <ctime>
using namespace std;
ifstream fin("wireless.in");
ofstream fout("wireless.out");

const int maxN = 25;
int d, n;
struct Crossing {
	       int x, y, k;
       } a[maxN];

void init()
{
	fin >> d >> n;
	for (int i=1; i<=n; i++) 
	  fin >> a[i].x >> a[i].y >> a[i].k;
}

void work()
{
	int maxSum = 0, cnt = 0;
	for (int i = 0; i <= 128; i++)
	  for (int j = 0; j <= 128; j++)
	  {
	  	  int tt = 0;
	  	  for (int g = 1; g <= n; g ++)
	  	    if (abs (a[g].x-i) <= d && abs (a[g].y-j) <= d)
	  	      tt += a[g].k;
	  	  if (tt > maxSum) { maxSum = tt; cnt = 0; }
	  	  if (tt == maxSum) cnt ++;
	  }
	fout << cnt << " " << maxSum << endl;
}

int main()
{
	
	init();
	work();
	
	return 0;
}

