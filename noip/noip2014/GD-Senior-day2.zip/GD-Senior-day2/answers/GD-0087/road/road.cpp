#include <fstream>
#include <stdio.h>
#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
#include <string.h>
#include <cmath>
#include <algorithm>
#include <vector>
#include <cstdlib>
#include <ctime>
using namespace std;

const int maxN = 10005, maxM = 200005;
int n, m, s, t, Now, Head[maxN], Now2, Head2[maxN], q[maxN], dis[maxN];
bool vis[maxN], OK_reach[maxN], OK_path[maxN];
struct Edge {
	int v, next;
} e[maxM], e2[maxM];

void addEdge (int u, int v)
{
	Now++; e[Now].v = v; e[Now].next = Head[u]; Head[u] = Now;
}

void addEdge2 (int u, int v)
{
	Now2++; e2[Now2].v = v; e2[Now2].next = Head2[u]; Head2[u] = Now2;
}

void init()
{
	scanf ("%d%d", &n, &m);
	Now = Now2 = 0;
	for (int i = 0; i <= n; i++) Head[i] = Head2[i] = 0;
	for (int i = 0; i < m; i++)
	{
		int u, v;
		scanf ("%d%d", &u, &v);
		addEdge (u, v); addEdge2 (v, u);
	}
	scanf ("%d%d", &s, &t);
}

void bfs_t()
{
	for (int i = 0; i <= n; i++) OK_reach[i] = false;
	q[1] = t; OK_reach[t] = true;
	for (int He=1, Ta=1; He<=Ta; He++)
	{
		int u = q[He];
		for (int i = Head2[u]; i; i = e2[i].next)
		{
			int v = e2[i].v;
			if (OK_reach[v]) continue ;
			OK_reach[v] = true;
			Ta++; q[Ta] = v;
		}
	}
}

void check_path()
{
	for (int i = 1; i <= n; i++)
	{
		OK_path[i] = OK_reach[i];
		for (int j = Head[i]; j; j = e[j].next)
		{
			int v = e[j].v;
			if (!OK_reach[v]) 
			{ OK_path[i] = false; break; }
		}
	}
}

int bfs_s()
{
	if (!OK_path[s]) return -1; //!!
	for (int i = 0; i <= n; i++) vis[i] = 0;
	q[1] = s; vis[s] = true; dis[s] = 0;
	for (int He=1, Ta=1; He<=Ta; He++)
	{
		int u = q[He];
		for (int i = Head[u]; i; i = e[i].next)
		{
			int v = e[i].v;
			if ((!OK_path[v]) || vis[v]) continue ;
			vis[v] = true;
			dis[v] = dis[u] + 1;
			Ta++; q[Ta] = v;
			if (v == t) return dis[t];
	    }
	}
	return -1;
}

int main()
{
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	
	init();
	bfs_t();
	check_path();
	int ans = bfs_s();
	printf ("%d\n", ans);
	
	return 0;
}

