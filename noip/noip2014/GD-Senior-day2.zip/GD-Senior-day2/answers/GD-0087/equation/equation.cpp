#include <fstream>
#include <stdio.h>
#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
#include <string.h>
#include <cmath>
#include <algorithm>
#include <vector>
#include <cstdlib>
#include <ctime>
using namespace std;

typedef long long LL;
const int maxN=105, maxLa=10004, maxNum=11005, maxM=1000005, val=1000000; //??
int n, m, s[maxN], maxs;
char a[maxN][maxLa];
bool OK_num[maxM];
struct largeNum 
      {
      	  int n, k;
      	  short a[maxNum];
      	  void Clear ()
      	  {
      	  	  n = 1; k = 1;
      	  	  for (int i=0; i<maxNum; i++) a[i] = 0;
      	  }
      	  /*
      	  void Print ()
      	  {
      	  	  if (k==-1) printf("-");
      	  	  for (int i=n; i>=1; i--) printf("%d", a[i]); printf("\n");
      	  }
      	  */
      } ;
largeNum operator * (largeNum u, largeNum v)
{
	largeNum res;
	res.Clear ();
	int L = u.n + v.n - 1;
	for (int i=1; i<=u.n; i++)
	  for (int j=1; j<=v.n; j++)
	    res.a[i+j-1] += u.a[i] * v.a[j];
	for (int i=1; i<=L; i++)
	{
		res.a[i+1] += res.a[i] / 10;
		res.a[i] %= 10;
	}
	while (res.a[L+1]) 
	{
		L++;
		res.a[L+1] += res.a[L] / 10;
		res.a[L] %= 10;
	}
	res.n = L;
	res.k = u.k * v.k;
	return res;
}
largeNum operator + (largeNum u, largeNum v)// |u| + |v|
{
	largeNum res;
	res.Clear ();
	int L = max (u.n, v.n);
	for (int i=1; i<=L; i++)
	{
	    res.a[i] += u.a[i] + v.a[i];
	    res.a[i+1] += res.a[i] / 10;
	    res.a[i] %= 10;
	}
	while (res.a[L+1])
	{
		L++;
		res.a[L+1] += res.a[L] / 10;
		res.a[L] %= 10;
	}
	res.n = L;
	return res;
}

largeNum operator - (largeNum u, largeNum v) // |u| - |v| (|u| > |v|)
{
	largeNum res;
	res.Clear ();
	int L = u.n;
	for (int i=1; i<=L; i++)
	    res.a[i] = u.a[i] - v.a[i];
	res.n = L;
	for (int i=1; i<=L; i++)
	  if (res.a[i]<0)
	  {
	  	  res.a[i] += 10;
	  	  res.a[i+1] --;
	  }
	while (L>1 && res.a[L] == 0) L--;
	res.n = L;
	return res;
}

bool operator < (largeNum u, largeNum v) //|u| <= |v|
{
	if (u.n < v.n) return true;
	if (u.n > v.n) return false;
	for (int i=u.n; i>=1; i--)
	  if (u.a[i] < v.a[i]) return true;
	  else if (u.a[i] > v.a[i]) return false;
	return true;
}

void init()
{
	scanf ("%d%d", &n, &m);
	maxs = 0;
	for (int i=0; i<=n; i++) 
	{
	    scanf ("%s", &a[i]);
	    s[i] = strlen(a[i]);
	    maxs = max(maxs, s[i]);
	}
}

int str_int (char s[])
{
	int L=strlen(s), k=1, i=0, tmp=0;
	if (s[0] == '-') { k=-1; i++; } 
	for (int j=i; j<L; j++)
	  tmp = tmp*10 + (s[j]-'0');
	return tmp*k;
}

void solve_1_3()
{
	int A=str_int (a[2]), B=str_int(a[1]), C=str_int(a[0]);
	int ans = 0;
	for (int i = 1; i <= m; i++)
	  if ((A*i*i + B*i + C) == 0)
	  	  ans ++;
	printf ("%d\n", ans);
	for (int i = 1; i <= m; i++)
	  if ((A*i*i + B*i + C) == 0)
	    printf ("%d\n", i);
}

largeNum str_largeNum(char s[])
{
	largeNum res;
	res.Clear();
	int L = strlen(s), i = 0, j, k;
	if (s[0] == '-') { i++; res.k = -1; }
	else res.k = 1;
	for (j=L-1, k=1; j>=i; j--, k++) res.a[k] = s[j]-'0';
	res.n = k-1;
	return res;
}

void solve_4_5()
{
	for (int i = 1; i <= m; i++) OK_num[i] = false;
	int ans = 0;
	largeNum Sum, Cur, x_cur, Now;
	for (int i = 1; i <= m; i++)
	{
		Sum.Clear() ;
		Cur.Clear() ;
		x_cur.Clear() ;
		x_cur.n = 0; x_cur.k = 1;
		for (int tmp = i; tmp > 0; tmp = tmp/10)
		{
			x_cur.n ++;
			x_cur.a[x_cur.n] = tmp % 10;
		}
		//printf("i=");x_cur.Print();
		Cur.n = 1; Cur.k = 1; Cur.a[1] = 1;
		Sum.n = 1; Sum.k = 1; Sum.a[1] = 0;
		for (int j = 0; j <= n; j++)
		{
			Now = str_largeNum (a[j]);
			//printf(" j=%d\n", j);Now.Print();
			Now = Now * Cur;
			//printf(" NOW:");Now.Print();
			//printf(" SUM:");Sum.Print(); printf(" ?%d\n", Sum.k);
			Cur = Cur * x_cur;
			if (Sum.k > 0 && Now.k > 0) { Sum = Sum+Now; Sum.k = 1; }
			else if (Sum.k < 0 && Now.k < 0) { Sum = Sum+Now; Sum.k = -1; }
			     else if (Sum.k < 0 && Now.k > 0)
			         {
			         	if (Sum < Now) { Sum = Now - Sum; Sum.k = 1; }
			         	else { Sum = Sum - Now; Sum.k = -1; }
			         }
			         else
			         {
			         	if (Sum < Now) { Sum = Now - Sum; Sum.k = -1; } 
			         	else { Sum = Sum - Now; Sum.k = 1; }
			         }
			//printf(" SUM:");Sum.Print();
			//printf(" Cur:");Cur.Print();
		}
		if (Sum.n == 1 && Sum.a[1] == 0) { OK_num[i] = true; ans ++; }
	}
	printf ("%d\n", ans);
	for (int i = 1; i <= m; i++)
	  if (OK_num[i]) printf("%d\n", i);
}

bool check_6_10 (int i)
{
	LL x_0 = 1, res = 0;
	for (int g = 0; g <= n; g++)
	{
		LL tmp = 0;
		int k = 0; if (a[g][0] == '-') k++;
		for (int j=max(k,s[g]-6); j<s[g]; j++)
		  tmp = tmp*10 + (a[g][j]-'0');
		if (a[g][0] == '-') k = -1; else k = 1;
		res = (res + ((x_0 * tmp * k) % val)) % val;
		x_0 = (x_0 * i) % val;
	}
	return res == 0;
}

void solve_6_10()
{
	for (int i = 1; i <= m; i++) OK_num[i] = false;
	int ans = 0;
	largeNum Sum, Cur, x_cur, Now;
	for (int i = 1; i <= m; i++)
	{
		if (!check_6_10(i)) continue ;
		Sum.Clear() ;
		Cur.Clear() ;
		x_cur.Clear() ;
		x_cur.n = 0; x_cur.k = 1;
		for (int tmp = i; tmp > 0; tmp = tmp/10)
		{
			x_cur.n ++;
			x_cur.a[x_cur.n] = tmp % 10;
		}
		//printf("i=");x_cur.Print();
		Cur.n = 1; Cur.k = 1; Cur.a[1] = 1;
		Sum.n = 1; Sum.k = 1; Sum.a[1] = 0;
		for (int j = 0; j <= n; j++)
		{
			Now = str_largeNum (a[j]);
			//printf(" j=%d\n", j);Now.Print();
			Now = Now * Cur;
			//printf(" NOW:");Now.Print();
			//printf(" SUM:");Sum.Print(); printf(" ?%d\n", Sum.k);
			Cur = Cur * x_cur;
			if (Sum.k > 0 && Now.k > 0) { Sum = Sum+Now; Sum.k = 1; }
			else if (Sum.k < 0 && Now.k < 0) { Sum = Sum+Now; Sum.k = -1; }
			     else if (Sum.k < 0 && Now.k > 0)
			         {
			         	if (Sum < Now) { Sum = Now - Sum; Sum.k = 1; }
			         	else { Sum = Sum - Now; Sum.k = -1; }
			         }
			         else
			         {
			         	if (Sum < Now) { Sum = Now - Sum; Sum.k = -1; } 
			         	else { Sum = Sum - Now; Sum.k = 1; }
			         }
			//printf(" SUM:");Sum.Print();
			//printf(" Cur:");Cur.Print();
		}
		if (Sum.n == 1 && Sum.a[1] == 0) { OK_num[i] = true; ans ++; }
	}
	printf ("%d\n", ans);
	for (int i = 1; i <= m; i++)
	  if (OK_num[i]) printf("%d\n", i);
}

int main()
{
	freopen("equation.in", "r", stdin);
	freopen("equation.out", "w", stdout);
	
	init();
	if (n <= 2 && maxs<=4) { solve_1_3(); return 0; }
	if (m <= 100) { solve_4_5(); return 0; }
	solve_6_10();
		
	return 0;
}

