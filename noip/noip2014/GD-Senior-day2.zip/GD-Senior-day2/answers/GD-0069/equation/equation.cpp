#include<fstream>
#include<string>
using namespace std;
ifstream fin("equation.in");
ofstream fout("equation.out");
string b[101];
int cz[20001],cf[20001],c[25001];
long n,m,a[1000001],ans=0,ansd[1000001];
long ncf(long x,long y)
{  long i,s=1;
	for(i=1;i<=y;i++) s=s*x;
	return s;
}
void gzj()
{  long i=20001,s=20001,t,k;
	while(i>0&&cz[i]==0) i--;
	while(s>0&&cf[s]==0) s--;
	if(i>s){
		k=0;
		for(t=1;t<=i+1;t++){
			c[t]=cz[t-1]-cf[t]+10+k;
			if(c[t]>=10) k=-1;
			c[t]%=10;
		}
	}
	else if(i<s){
		k=0;
		for(t=1;t<=i+1;t++){
			c[t]=cf[t]-cz[t-1]+10+k;
			if(c[t]>=10) k=-1;
			c[t]%=10;
		}
	}
	else{
		for(t=i;t>=0;t--){
			if(cz[t]>cf[t]){
				k=0;
				for(t=1;t<=i+1;t++){
					c[t]=cz[t-1]-cf[t]+10+k;
					if(c[t]>=10) k=-1;
					c[t]%=10;
				}
				break;
			}
			if(cf[t]>cz[t]){
				k=0;
				for(t=1;t<=i+1;t++){
					c[t]=cf[t]-cz[t-1]+10+k;
					if(c[t]>=10) k=-1;
					c[t]%=10;
				}
				break;
			}
		}
	}
}
long mo(long x)
{  gzj();
	long i=25001,s,k=0;
	while(i>0&&c[i]==0) i--;
	for(s=i;s>=1;s--){
		k=k*10+c[s];
		if(k>x) k=k%x;
	}
	return k;
}
int main()
{  long i,s,k,t,sum,p;
	fin>>n>>m;
	if(n<=2){
		for(i=0;i<=n;i++) fin>>a[i];
		for(i=1;i<=m;i++) {
			sum=0;
			for(s=0;s<=n;s++){
				t=1;
				for(k=1;k<=s;k++) t=t*i;
				sum+=a[s]*t;
			}
			if(sum==0) {ans++; ansd[ans]=i;}
	    }
	    fout<<ans<<endl;
	    for(i=1;i<=ans;i++) fout<<ansd[i]<<endl;
	}
	else {
		for(i=0;i<=n;i++) fin>>b[i];
        for(i=0;i<=20001;i++) cz[i]=cf[i]=0;
		for(i=0;i<=n;i++){
			if(b[i][0]=='-'){
				t=0;
			    for(s=1;s<b[i].size();s++){
					cf[s]+=b[i][s]+t;
					t=cf[s]/10;
					cf[s]%=10;
				} 
				cf[s]+=t;
			}
			else {
				t=0;
			    for(s=0;s<b[i].size();s++){
					cz[s]+=b[i][s]+t;
					t=cz[s]/10;
					cz[s]%=10;
				}
				cf[s]+=t;
			}
		}
		bool ff=true;
		for(i=1;i<=20001;i++) if(cz[i-1]!=cf[i]) {ff=false; break;}
		if(ff) {ans++; ansd[ans]=1;}
		if(m<=100){
			for(i=2;i<=m;i++){
				ff=true;
				for(s=1;s<=n;s++){
					for(k=0;k<=20001;k++) cz[k]=cf[k]=0;
					for(k=0;k<s;k++){
						if(b[k][0]=='-'){
							t=0;
							for(p=1;p<b[k].size();p++){
								cf[p]+=b[k][p]+t;
								t=cf[p]/10;
								cf[p]%=10;
							}
					        cf[p]+=t;
						}
						else {
							t=0;
							for(p=0;p<b[k].size();p++){
								cz[p]+=b[k][p]+t;
								t=cz[p]/10;
								cz[p]%=10;
							}
					        cz[p]+=t;
						}
					}
					if(mo(ncf(i,s))!=0) {ff=false; break;}
				}
				if(ff) {ans++; ansd[ans]=1;}
			}
			fout<<ans<<endl;
			for(i=1;i<=ans;i++) fout<<ansd[i]<<endl;
		}
		else {
			fout<<ans<<endl;
			for(i=1;i<=ans;i++) fout<<ansd[i]<<endl;
		}
	}
	fin.close();
	fout.close();
    return 0;	
}
