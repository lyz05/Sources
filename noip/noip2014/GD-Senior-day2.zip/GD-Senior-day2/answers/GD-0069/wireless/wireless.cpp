#include<fstream>
using namespace std;
ifstream fin("wireless.in");
ofstream fout("wireless.out");
long d,n,x[21],y[21],k[21],ma=0,ans=0;
long f[128][128],t[128][128];
int main()
{  long i,s,p;
	fin>>d>>n;
	for(i=0;i<=128;i++){
		for(s=0;s<=128;s++) f[i][s]=t[i][s]=0;
	}
	for(i=1;i<=n;i++){
		fin>>x[i]>>y[i]>>k[i];
		f[x[i]][y[i]]=k[i];
	}
	for(i=0;i<=d*2;i++){
		for(s=0;s<=d*2;s++){
			t[d*2][d*2]+=f[i][s];
		}
	}
	if(t[d*2][d*2]>=ma) {
		if(t[d*2][d*2]==ma)ans++;
		else ans=1;
		ma=t[d*2][d*2]; 
	}
	for(i=d*2;i<=128;i++){
		for(s=d*2;s<=128;s++){
			if(i!=d*2||s!=d*2){
				if(s-1>=d*2){
					t[i][s]=t[i][s-1];
					for(p=i-d*2;p<=i;p++) t[i][s]=t[i][s]-f[p][s-1-d*2]+f[p][s];
				}
				else{
					t[i][s]=t[i-1][s];
					for(p=s-d*2;p<=s;p++) t[i][s]=t[i][s]-f[i-1-d*2][p]+f[i][p];
				}
				if(t[i][s]>=ma) {
					if(t[i][s]==ma) ans++;
					else ans=1;
					ma=t[i][s];
				}
			}
		}
	}
	fout<<ans<<' '<<ma<<endl;
	fin.close();
	fout.close();
	return 0;
}
