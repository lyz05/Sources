#include<fstream>
using namespace std;
ifstream fin("road.in");
ofstream fout("road.out");
long n,m,x[10001],y[10001],b,d,mi=99999999;
int f[10001][1001],l[10001];
bool z[10001],go[10001],found=false;
void bi(long x)
{  long i;
	for(i=0;i<l[x];i++) {
		if(!z[f[x][i]]) bi(f[x][i]);
		z[f[x][i]]=1;
	}
}
void gg(long x,long step)
{  if(x==b) {if(step<mi) mi=step; found=true;}
	else{
		long i;
		for(i=0;i<l[x];i++){
			if(go[f[x][i]]){
				gg(f[x][i],step+1);
			} 
		}
	}
}
int main()
{  long i;
	fin>>n>>m;
	for(i=1;i<=n;i++) {l[i]=0; z[i]=0; go[i]=1;}
	for(i=1;i<=m;i++) {
		fin>>x[i]>>y[i];
		f[y[i]][l[y[i]]]=x[i]; l[y[i]]++;
	}
	fin>>b>>d;
	z[d]=1;
	bi(d);
	for(i=1;i<=m;i++){
		if(!z[y[i]]) go[x[i]]=go[y[i]]=0;
	}
	gg(d,0);
	if(!found) fout<<"-1"<<endl;
	else fout<<mi<<endl;
	fin.close();
	fout.close();
	return 0;
}
