#include<fstream>
using namespace std;
int n,m,i,j,k,l;
short a,b;
int shu[3];
int f1(int x)
{return (shu[0]+shu[1]*x);}
int f2(int x)
{return (shu[0]+(shu[1]+shu[2]*x)*x);}
int main()
{ifstream fin("equation.in.txt");
ofstream fout("equation.out.txt");
fin>>n>>m;
for(i=0;i<=n;i++)
fin>>shu[i];
if(n==1)
{for(i=1;i<=m;i++)
{if(f1(i)==0)
a=i;}
if(a==0)
fout<<"0";
else
fout<<"1"<<" "<<a;}
if(n==2)
{for(i=1;i<=m;i++)
if(f2(i)==0)
{if(a==0)
a=i;
else 
b=i;}
if(b!=0)
fout<<"2"<<" "<<a<<" "<<b;
else
{if(b==0 and a!=0)
fout<<"1"<<" "<<a;
else
fout<<"0";}}
fin.close();
fout.close();
return 0;}
