#include<fstream>
using namespace std;
int mappub[250][250];
long long target[250][250];
int d,i,j,k,l,n,x,y,a1,a2;
int amount;
long long mx;
int main()
{ifstream fin("wireless.in.txt");
ofstream fout("wireless.out.txt");
fin>>d;
fin>>n;
for(i=1;i<=n;i++)
{fin>>x>>y>>k; x+=100; y+=100; mappub[x][y]=k;}
for(i=101;i<=228;i++)
for(j=101;j<=228;j++)
for(k=i-d;k<=i+d;k++)
for(l=j-d;l<=j+d;l++)
target[i][j]+=mappub[k][l];
for(i=101;i<=228;i++)
for(j=101;j<=228;j++)
{if(target[i][j]==mx)
amount++;
if(target[i][j]>mx)
{mx=target[i][j];amount=1;a1=i;a2=j;}}
fout<<amount<<" "<<target[a1][a2];
fin.close();
fout.close();
return 0;}
