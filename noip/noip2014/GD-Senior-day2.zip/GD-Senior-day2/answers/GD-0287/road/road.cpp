#include<fstream>
using namespace std;
short map[101][101];
int n,m,x,y,i,j,l,k,s,t,ans;
bool flag[101];
bool check(int x)
{if(map[x][t]!=0)
return 1;
else
{for(i=1;i<=n;i++)
if(map[x][i]!=0 and i!=t)
return check(i);
return 0;}}
int search(int x)
{if(map[x][t]==1)
return 1;
for(i=1;i<=n;i++)
{if(map[x][i]!=0 and flag[i]==0)
l++;flag[x]=1;return 1+search(i);
if(l<ans)
ans=l;
flag[i]==0;}
return ans;}
int main()
{ifstream fin("road.txt");
ofstream fout("road.txt");
fin>>n>>m;
for(i=1;i<=m;i++)
fin>>x>>y;map[x][y]=1;
fin>>s>>t;
if(search(s))
fout<<search(s);
else
fout<<"-1";
fin.close();
fout.close();
return 0;}
