#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#define dg 10000
using namespace std;

struct node
{
	int a[3010],len,f;
	node(){f=len=1;memset(a,0,sizeof(a));}
}a[110];int n,m;
int hh[1000010];
node pluss(node n1,node n2)
{
	node no;int i;
	no.len=(n1.len<n2.len)?n2.len:n1.len;
	for (i=0;i<no.len;i++)
	{
	   no.a[i]+=n1.a[i]+n2.a[i];
	   no.a[i+1]+=no.a[i]/dg;
	   no.a[i]%=dg;
	}i=no.len-1;
	while (no.a[i+1]>0) {i++;no.a[i+1]+=no.a[i]/dg;no.a[i]%=dg;}
	no.len=i+1;no.f=n1.f;
	return no;
}
node multt(node n1,node n2)
{
	node no;int i,j;
	no.len=n1.len+n2.len-1;
	for (i=0;i<n1.len;i++)
	 for (j=0;j<n2.len;j++)
	  no.a[i+j]=n1.a[i]*n2.a[j];
	for (i=0;i<no.len;i++)
	{ no.a[i+1]+=no.a[i]/dg;no.a[i]%=dg;}
	i=no.len-1;
	while (no.a[i+1]>0) {i++;no.a[i+1]+=no.a[i]/dg;no.a[i]%=dg;}
	no.len=i+1;no.f=n1.f*n2.f;
	return no;
}
node zh(int x)
{
	node no;
	int t=0;
	while (x)
	{
		no.a[t]=x%10;
		x/=10;t++;
	}no.len=t;
	return no;
}
int cmp(node n1,node n2)
{
	if (n1.len>n2.len) return 1;
	if (n2.len>n1.len) return -1;
	for (int i=0;i<n1.len;i++)
	{
		if (n1.a[i]>n2.a[i]) return 1;
		if (n1.a[i]<n2.a[i]) return -1;
	}return 0;
}
node jf(node n1,node n2)
{
	node no;
	int i,k=cmp(n1,n2);
	if (k==0) return no;
	if (k==1) no.f=1;
	else {no.f=-1;node tt=n1;n1=n2;n2=tt;}
	no.len=n1.len;
	for (i=0;i<n1.len;i++)
	{
		if (n1.a[i]<n2.a[i]){n1.a[i]+=dg;n1.a[i+1]-=1;}
		no.a[i]=n1.a[i]-n2.a[i];
	}i=no.len-1;
	while (no.a[i]==0) i--;
	no.len=i+1;return no;
}
bool trid(int x)
{
	node t,ans;t.a[0]=1;
	for (int i=0;i<=n;i++)
	{
		if (a[i].f==ans.f) ans=pluss(ans,multt(a[i],t));
		else if (ans.f==1) ans=jf(ans,multt(a[i],t));
		else if (a[i].f==1) ans=jf(multt(a[i],t),ans);
		t=multt(t,zh(x));
	}if (ans.len==1 && ans.a[0]==0) return true;
	return false; 
}
int main()
{
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	int i,j,l,ans=0;char s[10010];
	scanf("%d%d\n",&n,&m);
	for (i=0;i<=n;i++)
	{
		gets(s);
		l=strlen(s);
		if (s[0]!='-') 
		{
			a[i].f=1;a[i].len=l;
			for (j=0;j<l;j++) a[i].a[j]=s[j]-'0';
		}else 
		{
			a[i].f=-1;a[i].len=l-1;
			for (j=1;j<l;j++)
			 a[i].a[j-1]=s[j]-'0';
		}
	}
	for (i=1;i<=m;i++)
	 if (trid(i)) hh[++ans]=i;
	printf("%d\n",ans);
	for (i=1;i<=ans;i++)
	 printf("%d\n",hh[i]);
	return 0;
}
