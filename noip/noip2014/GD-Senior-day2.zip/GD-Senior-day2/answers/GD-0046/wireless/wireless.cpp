#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;

int a[140][140];
int tj(int x,int y,int d)
{
	int i,j,xi,xj,mi,mj,ans=0;
	if (x-d>=0) xi=x-d;else xi=0;
	if (y-d>=0) xj=y-d;else xj=0;
	if (x+d<=128) mi=x+d;else mi=128;
	if (y+d<=128) mj=y+d;else mj=128;
	for (i=xi;i<=mi;i++)
	 for (j=xj;j<=mj;j++)
	  ans+=a[i][j];
	return ans;
}
int main()
{
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	int d,n,i,j,x,y,k,ans,maxx;
	ans=0;maxx=-1;
	memset(a,0,sizeof(a));
	scanf("%d%d",&d,&n);
	for (i=1;i<=n;i++)
	{
	 	scanf("%d%d%d",&x,&y,&k);
	 	a[x][y]+=k;
	}
	for (i=0;i<=128;i++)
	 for (j=0;j<=128;j++)
	 {
	 	int tt=tj(i,j,d);
	 	if (tt>maxx) {maxx=tt;ans=1;}
	 	else if (tt==maxx) ans++;
	}printf("%d %d\n",ans,maxx);
	return 0;
}
