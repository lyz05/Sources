#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#define Maxn 10010
#define Maxm 200010
using namespace std;

struct node
{
	int x,y,next;
}a[Maxm];int len,first[Maxn];
int st,ed,n,m,d[Maxn];
bool bo[Maxn],sta[Maxn];
void ins(int x,int y)
{
	len++;
	a[len].x=x;a[len].y=y;
	a[len].next=first[x];first[x]=len;
}
bool dfs(int x)
{
	if (x==ed) return true;
	sta[x]=true;bool g=false,bk=true;
	for (int k=first[x];k!=-1;k=a[k].next)
	{
		int y=a[k].y;
		if (!sta[y]) {if (!dfs(y)) bo[y]=bk=false;
		else bo[y]=true;g=true;}
	}if (!g) return false;
	return bk; 
}
int found(int x,int s)
{
	if (x==ed) return s;sta[x]=true;
	int minn=0x5fffffff,bz=-1;
	for (int k=first[x];k!=-1;k=a[k].next)
	{
		int y=a[k].y;
		if (!sta[y] && bo[y]) 
		{
		   int tt=found(y,s+1);
		   if (tt!=-1) {bz=1;minn=(minn<tt)?minn:tt;}
		}
	}if (bz!=-1) return minn;
	else return bz;sta[x]=false;
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int i,x,y;scanf("%d%d",&n,&m);
	len=0;memset(first,-1,sizeof(first));
	for (i=1;i<=m;i++)
	{
		scanf("%d%d",&x,&y);
		ins(x,y);
	}scanf("%d%d",&st,&ed);
	memset(d,-1,sizeof(d));
	memset(bo,false,sizeof(bo));	
	for (i=1;i<=n;i++)
	{
		memset(sta,false,sizeof(sta));
		if (dfs(i)) bo[i]=true;
	}memset(sta,false,sizeof(sta));
	printf("%d\n",found(st,0));
	return 0;
}
