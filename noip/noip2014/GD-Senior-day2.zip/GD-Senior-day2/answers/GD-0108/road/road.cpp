#include <cstdio>
#include <algorithm>

const int N = 10000 + 10, M = 200000 + 10, E = M * 2, INF = 1000000;

int n, m, s, t, x[M], y[M];

int adj[N];
int to[E], next[E], cnt;

inline void link(int a, int b) {
	to[++cnt] = b;
	next[cnt] = adj[a];
	adj[a] = cnt;
}

bool flag[N], mark[N];

int q[N];

void preprocessing() {
	cnt = 0;
 	std::fill(adj + 1, adj + n + 1, 0);
	for (int i = 1; i <= m; ++i) link(y[i], x[i]);
	int *qf, *qr;
	qf = qr = q;
	for (flag[*qr++ = t] = true; qf < qr;) {
		int a = *qf++;
		for (int it = adj[a]; it; it = next[it]) {
			int b = to[it];
			if (!flag[b]) flag[*qr++ = b] = true;
		}
	}
}

int bfs(const int s, const int t) {
	if (!mark[s]) return -1;
	int *qf, *qr;
	static int dis[N];
	std::fill(dis + 1, dis + n + 1, INF);
	qf = qr = q;
	for (dis[*qr++ = s] = 0; qf < qr;) {
		int a = *qf++;
		for (int it = adj[a]; it; it = next[it]) {
			int b = to[it];
			if (mark[b] && dis[b] == INF) dis[*qr++ = b] = dis[a] + 1;
		}
	}
	return dis[t] == INF ? -1 : dis[t];
}

int main() {
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= m; ++i) scanf("%d%d", x + i, y + i);
	scanf("%d%d", &s, &t);
	preprocessing();
	cnt = 0;
 	std::fill(adj + 1, adj + n + 1, 0);
	for (int i = 1; i <= m; ++i) link(x[i], y[i]);
	for (int a = 1; a <= n; ++a) {
		mark[a] = true;
		for (int it = adj[a]; it && mark[a]; it = next[it])
		 	mark[a] &= flag[to[it]];
	}
	printf("%d\n", bfs(s, t));
	return 0;
}
