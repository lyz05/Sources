#include <cstdio>
#include <algorithm>

const int N = 128 + 10;

int d, n;

int x[N], y[N], k[N];

int ans[N];

inline int cal(int a, int b) {
	int res = 0;
	for (int i = 1; i <= n; ++i)
		if (std::max(std::abs(a - x[i]), std::abs(b - y[i])) <= d) res += k[i];
	return res;
}

int main() {
	freopen("wireless.in", "r", stdin);
	freopen("wireless.out", "w", stdout);
	scanf("%d%d", &d, &n);
	for (int i = 1; i <= n; ++i) scanf("%d%d%d", x + i, y + i, k + i);
	int ans, cnt;
	ans = cnt = 0;
	for (int i = 0; i <= 128; ++i) {
		for (int j = 0; j <= 128; ++j) {
			int tmp = cal(i, j);
			if (tmp > ans) ans = tmp, cnt = 0;
			if (tmp == ans) cnt++;
		}
	}
	printf("%d %d\n", cnt, ans);
	return 0;
}
