#include <cstdio>
#include <cstring>
#include <vector>
#include <algorithm>

typedef long long int64;

const int N = 100 + 10, L = 10000 + 10;
const int64 MOD = 1000000000;
const int64 map[] = {1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000};

int n, m;

struct bigint {
	int64 num[L];
	int tot;
	bigint() {
		num[1] = 0;
		tot = 1;
	}
	void init(const char *s) {
		int len = strlen(s);
		tot = 0;
		for (register int i = len - 1, cnt = 0; i >= 0; --i) {
			if (cnt % 9 == 0) num[++tot] = 0;
			num[tot] += map[cnt % 9] * (s[i] - '0');
			++cnt;
		}
	}
	void mul(int64 x) {
		register int64 g = 0;
		for (register int i = 1; i <= tot; ++i) {
			num[i] = num[i] * x + g;
			g = num[i] / MOD;
			num[i] %= MOD;
		}
		while (g) {
			num[++tot] = g % MOD;
			g /= MOD;
		}
	}
	void add(const bigint &x) {
		tot = std::max(tot, x.tot);
		register int64 g = 0;
		for (register int i = 1; i <= tot; ++i) {
			num[i] += x.num[i] + g;
			g = num[i] / MOD;
			num[i] %= MOD;
		}
		while (g) {
			num[++tot] = g % MOD;
			g /= MOD;
		}
	}
} a[N], b[N];

inline bool eq(const bigint &a, const bigint &b) {
	if (a.tot != b.tot) return false;
	for (register int i = 1; i <= a.tot; ++i) if (a.num[i] != b.num[i]) return false;
	return true;
}

inline bool check(int64 x) {
	bigint lt = a[n], rt = b[n];
	for (register int i = n - 1; i >= 0; --i) {
		lt.mul(x);
		lt.add(a[i]);
		rt.mul(x);
		rt.add(b[i]);
	}
	return eq(lt, rt);
}

int main() {
	freopen("equation.in", "r", stdin);
	freopen("equation.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (int i = 0; i <= n; ++i) {
		static char s[L];
		scanf(" %s", s);
		if (s[0] == '-') b[i].init(s + 1); else a[i].init(s);
	}
	static std::vector<int> ans;
	for (int i = 1; i <= m; ++i) {
		if (check(i)) ans.push_back(i);
		if (ans.size() == n) break;
	}
	printf("%d\n", ans.size());
	for (int i = 0; i < ans.size(); ++i) printf("%d\n", ans[i]);
	return 0;
}
