#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <cstdlib>
#include <algorithm>
#include <string>

using namespace std;

const int maxdot=10005;
const int maxedge=200005*2;

int tree1,v1[maxedge],next1[maxedge],node1[maxedge];
int head,tail,que1[maxdot],deep1[maxdot];
int que2[maxdot],deep2[maxdot];
int tree2,v2[maxedge],next2[maxedge],node2[maxedge];
int n,m,s,t;

void insert1(int x,int y)
{
	tree1++;
	v1[tree1]=y;
	next1[tree1]=node1[x];
	node1[x]=tree1;
	return ;
}

void insert2(int x,int y)
{
	tree2++;
	v2[tree2]=y;
	next2[tree2]=node2[x];
	node2[x]=tree2;
	return ;
}

void init1(int x,int de)
{
	que1[++tail]=x;
	deep1[x]=de;
	return ;
}

void init2(int x,int de)
{
	que2[++tail]=x;
	deep2[x]=de;
}

int bfs1(int s)
{
	head=1;tail=0;
	init1(s,1);
	for (;head<=tail;head++)
	{
		for (int z=node1[que1[head]];z!=0;z=next1[z])
		if (deep1[v1[z]]==0)
		 init1(v1[z],deep1[que1[head]]+1);
	}
	return (deep1[t]-1);
}

void bfs2(int s)
{
	head=1;tail=0;
	init2(s,1);
	for (;head<=tail;head++)
	{
		for (int z=node2[que2[head]];z!=0;z=next2[z])
		 if (deep2[v2[z]]==0)
		 	init2(v2[z],deep2[que2[head]]+1);
	}
	
	for (int i=1;i<=n;i++)
	 {
	 	 for (int z=node1[i];z!=0;z=next1[z])
	 	  if (deep2[v1[z]]==0)
	 	  {
	 	  	deep1[i]=-1;break;
	 	  }
	 }
	return ;
}

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin >> n >> m;
	for (int i=1;i<=m;i++) 
	{
		int x,y;
		scanf("%d%d",&x,&y);
		insert1(x,y);
		insert2(y,x);
	}
	cin >> s >> t;
	bfs2(t);
	cout << (bfs1(s)) << endl;
	return 0;
}

