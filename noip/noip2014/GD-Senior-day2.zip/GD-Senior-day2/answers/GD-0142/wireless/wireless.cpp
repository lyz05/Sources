#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <cstdlib>
#include <algorithm>
#include <string>

using namespace std;

const int maxdot=205;

struct Tnode 
{
	int x,y,num;
	Tnode () {x=y=num=0;}
} a[maxdot];

int d,n,ans1,ans2;

int main()
{
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	cin >> d;
	cin >> n;
	
	for (int i=1;i<=n;i++)
	{
		int x,y,k;
		cin >> a[i].x >> a[i].y >> a[i].num;

	}
	ans1=ans2=0;
    for (int i=0;i<=128;i++)
     for (int j=0;j<=128;j++)
     {
     	int sum=0;
     	for (int k=1;k<=n;k++)
     	if ((abs(a[k].x-i)<=d ) && ((abs(a[k].y-j))<=d))
     	{
     		sum+=a[k].num;
     	}
     	if (sum>ans2) {ans2=sum;ans1=1;}
     	else
     	if (sum==ans2) ans1++;
     }
    cout << ans1 << " " << ans2 << endl;
	return 0;
}

