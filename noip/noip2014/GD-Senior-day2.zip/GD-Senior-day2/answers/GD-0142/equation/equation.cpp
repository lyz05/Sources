#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <cstdlib>
#include <algorithm>
#include <string>

using namespace std;

typedef long long LL;

LL n,m,num,mm;
LL b[105],ans[1000005],ten[30];

char ch[11005];

struct Tnode 
{
	LL num;
	LL sign;
	LL a[11005];
	Tnode () {num=0LL;sign=0LL;memset(a,0,sizeof(a));}
} a[105];


bool check(LL x,LL y)
{
	LL sum=0LL;
	LL xx=1LL;
	for (LL i=0LL;i<=n;i++)
	{
		LL now=0LL;
		for (LL j=1LL;j<=y;j++)
		{
			now=now+ten[j-1LL]*a[i].a[j];
		}
		now=(now*a[i].sign) ;
		now=(now*xx) %ten[y];
		xx=(xx*x) %ten[y];
		sum=(sum+now) %ten[y];
	}
	return sum==0LL;
}

void find(LL k,LL now)
{
	if ((k>=6LL)|| (k>=mm))
	{
		ans[++num]=now;
		return ;
	}
	for (LL i=0LL;i<=9LL;i++)
	{
		LL now1=now+ten[k]*i;
		if (check(now1,k+1LL))
		 find(k+1LL,now1);
	}
	return ;
}

void doit1()
{
	for (LL i=0LL;i<=n;i++)
	{
		cin >> b[i];
	}
	for (LL i=1LL;i<=m;i++)
	{
		LL sum=0LL;
		LL p=1LL;
		for (LL j=0LL;j<=n;j++)
		{
		    sum=sum+p*b[j];
			p=p*i;
		}
		if (sum==0LL) 
		{
			ans[++num]=i;
	    }
	}
	cout << num << endl;
	for (LL i=1LL;i<=num;i++) cout << ans[i] << endl;
	
	return ;
	
	
}

void gogo(LL m)
{
	for (;m>0LL;m/=10LL) mm++;
}

int main()
{
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	cin >> n >> m;
	if (n<=2LL)
	{
		doit1();
		return 0;
	}
	gogo(m);
	for (LL i=0LL;i<=n;i++)
	{
		scanf("%s",&ch);
		if (ch[0]!='-')
		{
		 a[i].num=strlen(ch);
		 for (LL j=1LL;j<=a[i].num;j++)
		 {
			a[i].a[j]=ch[a[i].num-j]-48LL;
		 }
		 a[i].sign=1LL;
	    }
	    else
	    {
		  a[i].num=strlen(ch)-1LL;
		 for (LL j=1LL;j<=a[i].num;j++)
		 {
			a[i].a[j]=ch[a[i].num-j+1LL]-48LL;
		 }
		 a[i].sign=-1LL;
	    }
	}
	
	ten[0]=1LL;
	for (LL i=1LL;i<=11LL;i++)
	{
		ten[i]=ten[i-1LL]*10LL;
	}
	
    find(0LL,0LL);
    
    if (m==1000000LL)
    {
    	if (check(1000000LL,6LL)) 
    	{
    		ans[++num]=1000000LL;
    	}
    }
    
    for (LL i=1LL;i<=num;i++)
    {
    	if (!check(ans[i],9LL))
    	{
    		ans[i]=0LL;
    	}
    }
    
    sort(ans+1,ans+num+1);
    
    LL x1=1LL;
    for ( ;(x1<=num) && (ans[x1]==0);)x1++;
    
    for (LL i=num;i>=1LL;i--)
    if (ans[i]>m) {num--;}
    else
    break;
    
	cout << (num-x1+1LL) << endl;
	for (LL i=x1;i<=num;i++) cout << ans[i] << endl;
	return 0;
}

