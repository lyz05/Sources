#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <queue>
#include <algorithm>
#include <map>
//#define che 1
using namespace std;

const int maxn= 10000+10;
vector <int> G[maxn], G2[maxn];

int n,m ,sta, fnl;
bool vis[maxn], ok[maxn] ;
int h[maxn];

void init();
void delNod(int fnl);
int fPth(int sta, int fnl);

int main()
{
	freopen("road.in","rt",stdin);
	freopen("road.out","wt",stdout);
	init();
	
	int ans= fPth( sta, fnl);
	#ifdef che 
	printf("the h map:\n");
	for (int i=1; i<=n; i++)
		if ( ok[i])
			printf("\th[%d]=%d\n",i,h[i]);
	#endif
	printf("%d\n",ans);
	return 0;
}
void init()
{
	scanf("%d%d",&n,&m);
	for (int i=0; i<=n; i++)	
	{
		G[i].clear();
		G2[i].clear();
	}
	for (int i=0; i<m; i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		G[u].push_back( v);
		G2[v].push_back( u);
	}
	
	scanf("%d%d",&sta, &fnl);
	
	delNod(fnl);
	#ifdef che
	printf("The graph:\n");
	for (int u=1; u <=n ;u++)
	{
		printf("\t%d:",u);
		for (int i=0; i<G[u].size(); i++)
			printf("%d ", G[u][i]);
		printf("\n");
	}
	
	printf("The graph2:\n");
	for (int u=1; u<=n; u++)
	{
		printf("\t%d:",u);
		for (int i=0; i<G2[u].size(); i++)
			printf("%d ",G2[u][i]);
		printf("\n");
	}
	printf("After delete the Node , rest of them is :\n");
	for (int i=1; i<=n; i++)
		if ( ok[i])
			printf("%d ",i);
	printf("\n");
	#endif
}

void delNod(int fnl)
{
	queue <int> Q;
	Q.push( fnl);
	memset( vis, 0 ,sizeof(vis));
	vis[ fnl]= true;
	
	while ( Q.size())
	{
		int u= Q.front(); Q.pop();
		for (int i=0; i< G2[u].size(); i++)
		{
			int v= G2[u][i];
			if( vis[v] ) continue;
			vis[ v]= true;
			Q.push( v);
		}
	}
	
	for (int u=1 ; u<=n ;u++)
	if ( vis[u])
	{
		ok[u]= true;
		for (int i=0; i< G[u].size(); i++)
		{
			int v = G[u][i];
			if ( !vis[v] ) 
				ok[u]= false;
		}
	}
}

int fPth(int sta, int fnl)
{
	memset( vis, 0 ,sizeof(vis));
	memset( h, 0 ,sizeof(h));
	
	queue  <int> Q;
	Q.push( sta);
	vis[ sta]=true;
	while ( Q.size())
	{
		int u= Q.front() ; Q.pop();
		for (int i=0; i<G[u].size(); i++)
		{
			int v= G[u][i];
			if ( !ok[v] || vis[v] ) continue;
			vis[v] = true;
			h[v] = h[u]+ 1;
			if ( v== fnl) return h[v];
			Q.push( v);
		}
	}
	
	return -1;
}
