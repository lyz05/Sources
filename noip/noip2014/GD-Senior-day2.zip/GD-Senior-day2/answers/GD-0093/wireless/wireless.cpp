#include <cstdio>
#include <cstdlib>
#include <cstring>
//#define che 1
using namespace std;
const int maxn= 20+10;
int xx[maxn], yy[maxn], sums[maxn];
int d,n;
int ans=0, cnts=0;

inline int max( int a ,int b)
{
	return a > b?a:b;
}

inline int abs( int a )
{
	return a<0? -a:a;
}
void init();

int main()
{
	freopen("wireless.in","rt",stdin);
	freopen("wireless.out","wt",stdout);
	init();
	for (int x=0; x<=128; x++)
		for (int y=0; y<=128; y++)
		{
			int Tans =0;
			for (int i=0; i<n; i++)
				if ( max( abs(x-xx[i]),  abs(y-yy[i])) <=d)
					Tans += sums[i];
			if ( Tans > ans )
			{
				ans= Tans;
				cnts=1;
			} else
			if ( Tans == ans)
			{
				cnts++;
			}
		}
	printf("%d %d\n",cnts, ans);
	return 0;
}
void init()
{
	scanf("%d%d",&d ,&n);
	for (int i=0; i<n; i++)
	{
		scanf("%d%d%d",&xx[i], &yy[i], &sums[i]);
	}
}
