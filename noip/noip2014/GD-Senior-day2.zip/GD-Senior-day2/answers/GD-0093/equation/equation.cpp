#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cstring>
#include <string>
#include <fstream>
#include <iostream>
#include <vector>
//#define che 1
using namespace std;
typedef long long LL;
const int maxl= 1000+10, maxn= 100+10 ,maxbt=12;
const LL idx= 1000000000000LL;
             //123456789
ifstream fin("equation.in");
ofstream fout("equation.out");
struct Num
{
	LL arr[maxl];
	int dgt, lng;
}a[maxn];
int n,m;
vector <int> ans;
void init();
void printNum( Num a);
void change(string s, Num &c);
void add(Num a, Num b, Num &c);
void mul(Num a, LL x, Num &c);
int cmp(Num a, Num b);
void dec(Num a, Num b, Num &c);
bool modd(Num a, int x);

int main()
{
	init();
	
	Num tnu;
	
	
	for (int x=1; x<=m; x++)
	{
		tnu.dgt=1; 
		tnu.lng = 1;
		memset( tnu.arr, 0 ,sizeof(tnu.arr));
		
		if ( ! modd( a[0] , x) ) continue;
		for (int i=n; i>=0; i--)
		{
			#ifdef che
			printNum( tnu);
			fout<<" * " << x;
			#endif
			mul(tnu , x, tnu);
			
			#ifdef che 
			fout<<" = ";
			printNum( tnu);
			fout<<endl;
			printNum( tnu);
			fout<<" + ";
			printNum( a[i]);
			#endif
			add(tnu , a[i] , tnu);
			#ifdef che 
			fout<<" = ";
			printNum( tnu);
			fout<<endl;
			#endif
			
		}
		#ifdef che 
		fout<< "Check "<<x<<" get the tnu is"<<endl;
		printNum(tnu);
		fout<<endl;
		#endif
		if ( tnu.lng==1 && tnu.arr[1]==0)
			ans.push_back( x);
	}
	
	fout<<ans.size()<<endl;
	for (int i=0; i<ans.size(); i++)
	{
		fout<<ans[i]<<endl;
	}
	return 0;
}

void init()
{
	fin>>n>>m;
	string s;
	for (int i=0; i<=n; i++)
	{
		fin>>s;
		change( s, a[i]);
	}
	
	#ifdef che 
	fout<<"a:"<<endl;
	for (int i=0;i <=n; i++)
	{
		fout<<"\ta["<<i<<"]=";
		printNum(a[i]);
		fout<<endl;
	}
	fout<<"\t\tcompare ";
	printNum( a[1]);
	fout<< " to ";
	printNum( a[0]);
	fout<<" : "<<cmp(a[1],a[0]) << endl;
	#endif
}

void printNum( Num a)
{
	if (a.dgt==-1) fout<<"-";
	for (int i=a.lng ; i>0; i--)
		fout<<a.arr[i];
}
void change(string s, Num &c)
{
	int sta=0;
	c.dgt=1;
	if ( s[sta]=='-')
	{
		c.dgt=-1;
		sta++;
	}
	
	memset ( c.arr, 0 ,sizeof(c.arr));
	int p=0;
	for (int i=s.size()-1; i>=sta; )
	{
		p++;
		int j;
		LL cheng=1;
		for (j=0; j<maxbt && i-j >=sta; j++)
		{
			c.arr[p] += cheng*( s[i-j] -'0');
			cheng *= 10;
		}
		i -=j;
	}
	c.lng=p;
}
void add(Num a, Num b, Num &c)
{
	if ( a.dgt != b.dgt)
	{
		int d= cmp( a,b);
		if ( d==0)
		{
			c.lng=1; c.arr[1]=0;
			c.dgt=1;
		}	else
		if ( d<0)
		{
			if ( a.dgt==-1 ) 
			{
				a.dgt=1;
				dec(b,a,c);
			}else
			{
				b.dgt=1;
				dec(b,a,c);
				c.dgt=-1;
			}
		} else
		if ( d>0 )
		{
			if ( a.dgt==-1)
			{
				a.dgt=1;
				dec(a,b,c);
				c.dgt=-1;
			} else
			{
				b.dgt=1;
				dec( a,b,c);
			}
		}
	} else
	{
		c.dgt=1;
		memset( c.arr, 0, sizeof(c.arr));
		int len = max( a.lng, b.lng);
		for (int i=1; i<=len; i++)
		{
			c.arr[i]  += a.arr[i]+b.arr[i];
			c.arr[i+1] += c.arr[i]/idx;
			c.arr[i]%=idx;
		}
		if ( c.arr[len+1] > 0)
			len++;
		c.lng = len;
	}
}

void dec(Num a, Num b, Num &c)
{
	memset( c.arr, 0,sizeof(c.arr));
	int len=max( a.lng, b.lng);
	for (int i=1; i<= len; i++)
	{
		if ( i>b.lng)	
			b.arr[i]=0;
		if ( a.arr[i] < b.arr[i])
		{
			a.arr[i] +=idx;
			a.arr[i+1]--;
		}
		
		c.arr[i] = a.arr[i] - b.arr[i];
	}
	
	while ( c.arr[len] == 0 && len >1) len--;
	c.dgt=1;
	c.lng= len;
}
void mul(Num a, LL x, Num &c)
{
	int len= a.lng;
	memset( c.arr, 0 ,sizeof(c.arr));
	for (int i=1; i<=len ;i++)
	{
		c.arr[i] += a.arr[i] * x;
		c.arr[i+1] = c.arr[i]/idx;
		c.arr[i] %= idx;
	}
	while ( c.arr[len+1] > 0)
	{
		len++;
		c.arr[len+1]= c.arr[len]/idx;
		c.arr[len] %= idx;
	}
	
	while ( c.arr[len]==0 && len>1) len--;
	c.lng = len;
	c.dgt = a.dgt;
}
int cmp(Num a, Num b)   // just cmp the abs of num 
{
	if ( a.lng != b.lng )
		return a.lng < b.lng?-1:1;
	for (int i=a.lng; i>0; i--)
		if ( a.arr[i] != b.arr[i] )
			return a.arr[i] < b.arr[i] ? -1:1;
	return 0;
}

bool modd(Num a, int x)
{
	LL tmp= x, rst=0;
	for (int i=a.lng; i>0; i--)
	{
		rst = rst * idx + a.arr[i];
		rst %= tmp;
	}
	
	#ifdef che 
	fout << "rst"<<x<<" :"<< rst<<endl;
	#endif
	return rst ==0;
	
	
}
