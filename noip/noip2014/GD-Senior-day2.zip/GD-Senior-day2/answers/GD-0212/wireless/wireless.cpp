#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>

#define SIZE 100
using namespace std;

int d , n , X[ SIZE ] , Y[ SIZE ] , K[ SIZE ];
int main()
{
	freopen( "wireless.in","r",stdin );
	freopen( "wireless.out","w",stdout );

	scanf( "%d%d" , &d , &n );
	for ( int i = 1 ; i <= n ; i++ ) scanf( "%d%d%d" , &X[i] , &Y[i] , &K[i] );
	
	int num = 0 , ans = 0 ;
	for ( int i = 0 ; i <= 128 ; i++ )
		for ( int j = 0 ; j <= 128 ; j++ )
		{
			int tmp = 0 ;
			for ( int k = 1 ; k <= n ; k++ ) 
				if ( X[k] >= i - d && X[k] <= i + d && Y[k] >= j - d && Y[k] <= j + d )	tmp += K[k] ;
			if ( tmp > ans ) 
			{
				ans = tmp ;
				num = 1 ;
			}	else 
			if ( tmp == ans )
			{
				num ++ ;
			}
		}
	printf( "%d %d\n" , num , ans );
	return 0 ;
}
