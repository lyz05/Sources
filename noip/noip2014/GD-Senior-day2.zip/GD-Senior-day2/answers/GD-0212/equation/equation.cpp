#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>

using namespace std;

typedef long long LL ;
LL n , m , a[ 10 ] , ans[ 1100000 ] , cnt ;
void solve1()
{
	for ( LL i = 0 ; i <= n ; i++ ) scanf( "%lld" , &a[i] );
	
	cnt = 0 ;
	for ( LL i = 1 ; i <= m ; i++ ) 
	{	
		LL tmp = 0 , t = 1 ;
		for ( LL j = 0 ; j <= n ; j++ ) tmp += t * a[j] , t *= i ;
		if ( tmp == 0 ) ans[ ++cnt ] = i ;
	}
	printf( "%lld\n" , cnt );
	for ( LL i = 1 ; i <= cnt ; i++ ) printf( "%lld\n" , ans[i] );
}


const LL p[ 10 ] = { 
1000000007 , 
1000000297 ,
1000000891 ,
1000001449 , 
1000002823 , 
1000003967 ,
1000005329 ,
1000005991 , 
1000006697 ,
1000007447} ;

LL A[ 20 ][ 110 ] ;
char s[ 11000 ] ;
void solve2()
{
	if ( m <= 10000 ) {
		for ( LL i = 0 ; i <= n ; i++ ) {
			scanf( "%s" , s );
			LL len = strlen( s ) , o ;
			if ( s[0] == '-' ) o = 1 ; else o = 0 ;
			for ( LL j = 0 ; j < 10 ; j++ )
			{
				A[j][i] = 0 ;
				for ( LL k = o ; k < len ; k++ ) {
					A[j][i] = A[j][i] * 10 + s[k] - '0' ;
					A[j][i] %= p[j] ;
				}
				if ( o == 1 ) A[j][i] = -A[j][i] ;
			}
		}
		
		
		cnt = 0 ;
		for ( LL i = 1 ; i <= m ; i++ ) {
			LL OK = 1 ;
			
			for ( LL j = 0 ; j < 10 ; j++ ) {
				LL tmp = 0 , t = 1 ;
				for ( LL k = 0 ; k <= n ; k++ ) {
					tmp = tmp + t * A[j][k] ;
					tmp %= p[j] ;
					t = t * i % p[j] ;
				}
				
				if ( tmp ) { OK = 0 ; break ; }
			}
			if ( OK ) ans[ ++cnt ] = i ;
		}
		
		printf( "%lld\n" , cnt );
		for ( LL i = 1 ; i <= cnt ; i++ ) printf( "%lld\n" , ans[i] );
	}	
	
	else {
		for ( LL i = 0 ; i <= n ; i++ ) {
			scanf( "%s" , s );
			LL len = strlen( s ) , o ;
			if ( s[0] == '-' ) o = 1 ; else o = 0 ;
			A[0][i] = 0 ;
			for ( LL j = o ; j < len ; j++ ) {
				A[0][i] = A[0][i] * 10 + s[j] - '0' ;
				A[0][i] %= p[0] ;
 			}
 			if ( o ) A[0][i] = -A[0][i] ;
		}
		
		cnt = 0 ;
		for ( LL i = 1 ; i <= m ; i++ ) {
			LL t = 1 , tmp = 0 ;
			for ( LL j = 0 ; j <= n ; j++ ) {
				tmp += t * A[0][j] ;
				tmp %= p[0] ;
				t = t * i % p[0] ;
			}
			if ( tmp == 0 ) ans[ ++cnt ] = i ;
		}
		
		printf( "%lld\n" , cnt );
		for ( LL i = 1 ; i <= cnt ; i++ ) printf( "%lld\n" , ans[i] );
	}
	
	
}
int main()
{
	freopen( "equation.in","r",stdin );
	freopen( "equation.out","w",stdout );
	
	scanf( "%lld%lld" , &n , &m );
	if ( n <= 2 && m <= 100 ) solve1() ;
		else solve2();
	
	return 0;
}
