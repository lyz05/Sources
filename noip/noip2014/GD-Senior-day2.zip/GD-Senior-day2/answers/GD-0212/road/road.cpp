#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<vector>

#define pb push_back
#define SIZE 11000
#define inf 1000000000
using namespace std;

vector<int> e[ SIZE ] , re[ SIZE ] , q ;
int n , m , st , ed , vi[ SIZE ] , OK[ SIZE ] , d[ SIZE ];

void bfs( int S )
{
	q.clear();
	q.pb( S ) ;
	memset( vi , 0 , sizeof( vi ) );
	vi[ S ] = 1 ;
	
	for ( int i = 0 ; i < q.size() ; i++ ) {
		int u = q[i] ;
		for ( int k = 0 ; k < re[u].size() ; k++ ) {
			int v = re[u][k] ;
			if ( vi[v] ) continue ;
			q.pb( v ) ;
			vi[v] = 1 ;
		}
	}
	
	for ( int u = 1 ; u <= n ; u++ ) 
	{
		OK[u] = 1 ;
		for ( int k = 0 ; k < e[u].size() ; k++ ) {
			int v = e[u][k] ;
			if ( !vi[v] ) OK[u] = 0 ;
		}
	}
}

void bfs2( int S )
{
	q.clear();
	q.pb( S ) ;
	OK[S] = 0 ;
	
	for ( int i = 1 ; i <= n ; i++ ) d[i] = inf ;
	d[S] = 0 ;
	
	for ( int i = 0 ; i < q.size() ; i++ ) {
		int u = q[i] ;
		for ( int k = 0 ; k < e[u].size() ; k++ ) {
			int v = e[u][k] ;
			if ( OK[v] && d[v] > d[u] + 1 ) {
				d[v] = d[u] + 1 ;
				q.pb( v ) ;
				OK[v] = 0 ;
			}
		}
	}
	
	if ( d[ed] >= inf ) printf( "-1\n" ) ;
		else printf( "%d\n" , d[ed] );
}
int main()
{
	freopen( "road.in","r",stdin );
	freopen( "road.out","w",stdout );
	
	scanf( "%d%d" , &n , &m );
	
	for ( int i = 1 ; i <= n ; i++ ) e[i].clear() , re[i].clear();	
	
	for ( int i = 1 ; i <= m ; i++ )
	{
		int u , v ;
		scanf( "%d%d" , &u , &v );
		e[u].pb(v) ;
		re[v].pb(u) ;
	}
	
	scanf( "%d%d" , &st , &ed );
	bfs( ed ) ;
	
	if ( !OK[st] ) {
		printf( "-1\n" );
		return 0;
	}
	bfs2( st ) ;
	
	return 0;
}
