#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;
#define maxn 110
#define maxk 100000
struct bignum{
    int len;
    bool flag;
    int a[2100];
    bignum(){flag=0;len=0;memset(a,0,sizeof(a));}
    bool zero(){
	return (len==0)||(len==1&&a[1]==0);
    }
    int div(int x) {
	int mod=0;
        for (int i=len;i;i--) {
	    a[i]+=mod*maxk;
	    mod=a[i]%x;
	    a[i]/=x;
	}
	while (len&&a[len]==0) len--;
	return mod;
    }
}s[maxn];
bool operator < (const bignum x,const bignum y ){ // without sign
    if (x.len!=y.len) return x.len<y.len;
    for (int i=x.len;i;i--) {
	if (x.a[i]!=y.a[i]) return x.a[i]<y.a[i];
    }
    return 0;
}
bignum operator + (const bignum x,const bignum y ){// without sign
    int len=max(x.len,y.len);
    bignum ans;
    ans.a[0]=0;
    for (int i=1;i<=len;i++) {
	ans.a[i]=x.a[i]+y.a[i]+ans.a[i-1]/maxk;
	ans.a[i-1]%=maxk;
    }
    while (ans.a[len]/maxk) {
	ans.a[len+1]=ans.a[len]/maxk;
	ans.a[len]=ans.a[len]%maxk;
	len++;
    }
    ans.len=len;
    return ans;
}
bignum operator - (const bignum x,const bignum y ){// without sign and x>y;
    bignum ans;
    int len=x.len;
    for (int i=1;i<=x.len;i++) {
	ans.a[i]=x.a[i]-y.a[i];
	if (ans.a[i-1]<0) ans.a[i-1]+=maxk,ans.a[i]--;
    }
    while (len&&!ans.a[len]) len--;
    ans.len=len;
    return ans;
}
char st[maxk+10];
void read(bignum &x) {
    scanf("%s",st);
    int len=strlen(st);
    if (st[0]=='-' ) x.flag=1;
    int l=0;
    for (int i=1;i<=len-x.flag;i+=5) {
    	l++;
    	for (int j=min(len-x.flag,i+4);j>=i;j--)
    		x.a[l]=x.a[l]*10+st[len-j]-'0';
    }
    x.len=l;
    return ;
}

void write(bignum &x) {
    printf("%d %d ",x.len,x.flag);
	for (int i=1;i<=x.len;i++) printf("%d ",x.a[i]);    
	printf("\n");
    return ;
}

bignum dec(bignum x,bignum y) {
    bignum ans;
    if (x.flag==y.flag){
	if (y<x) {ans=x-y;ans.flag=x.flag;}
	else {ans=y-x;ans.flag=!x.flag;}
    }else {
	ans=x+y;ans.flag=x.flag;
    }
    return ans;
}
int n,m,cnt,t[maxk+10];
bool solve(int x){
    bignum tmp;
    for (int i=0;i<n;i++) {
	tmp=dec(tmp,s[i]);
	if (tmp.div(x)) return 0;
    }
    tmp=dec(tmp,s[n]);
    return tmp.zero();    
}
int main(){
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
    scanf("%d%d",&n,&m);
    for (int i=0;i<=n;i++) read(s[i]);
    for (int i=1;i<=m;i++) {
	if (solve(i)) t[++cnt]=i;
    }
    printf("%d\n",cnt);
    for (int i=1;i<=cnt;i++) printf("%d\n",t[i]);
    return 0;
}
