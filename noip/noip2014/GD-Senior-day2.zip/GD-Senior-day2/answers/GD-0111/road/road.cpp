#include<cstdio>
#include<iostream>
#include<cstring>
#include<algorithm>
#include<queue>
#include<vector>
using namespace std;
#define maxn 10100
vector<int> e[maxn];
bool b[maxn],del[maxn];
queue<int > q;
int dis[maxn];
int bfs(int x){
    while (!q.empty()) q.pop();
    b[x]=1;dis[x]=0;
    q.push(x);
    while (!q.empty()) {
	int u=q.front();q.pop();
	for (int i=0;i<e[u].size();i++) {
	    if (!del[e[u][i]]&&!b[e[u][i]]) {
		b[e[u][i]]=1;
		dis[e[u][i]]=dis[u]+1;
		q.push(e[u][i]);
	    }
	}
    }
    return 0;
}
int main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    int n,m;
    scanf("%d%d",&n,&m);
    for (int i=1;i<=m;i++) {
	int x,y;
	scanf("%d%d",&x,&y);
	e[y].push_back(x);
    }
    int s,t;
    scanf("%d%d",&s,&t);
    bfs(t);
    for (int i=1;i<=n;i++) {
	if (b[i]) continue;
       	del[i]=1;
	for (int j=0;j<e[i].size();j++) del[e[i][j]]=1;
    }
    memset(b,0,sizeof(b));
    bfs(t);
    if (!b[s]) {
	printf("%d\n",-1);
	return 0;
    }
    printf("%d\n",dis[s]);
    return 0;
}
