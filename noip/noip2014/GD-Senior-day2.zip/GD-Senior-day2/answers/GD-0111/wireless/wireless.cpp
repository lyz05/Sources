#include<cstdio>
#include<iostream>
#include<cstring>
#include<algorithm>
using namespace std;
#define maxn 129
int d,n,a[maxn+10][maxn+10];
long long s[maxn+10][maxn+10];
long long mx;
int cnt;
long long get(int x1,int y1,int x2,int y2) {
	if (x1<0) x1=0;
	if (y1<0) y1=0;
	if (x2>maxn) x2=maxn;
	if (y2>maxn) y2=maxn;
		
    return s[x2][y2]+s[x1][y1]-s[x2][y1]-s[x1][y2];
}
int main(){
    freopen("wireless.in","r",stdin);
    freopen("wireless.out","w",stdout);
    scanf("%d%d",&d,&n);
    for (int i=1;i<=n;i++) {
	int x,y,k;
	scanf("%d%d%d",&x,&y,&k);
	x++,y++;
	a[x][y]=k;
    }
    for (int i=1;i<=maxn;i++) 
	for (int j=1;j<=maxn;j++) {
	    s[i][j]=s[i-1][j]+s[i][j-1]-s[i-1][j-1]+a[i][j];
	}
    for (int i=1;i<=maxn;i++) 
	for (int j=1;j<=maxn;j++) {
	    long long sum=get(i-2,j-2,i+1,j+1);
	    if (sum>mx) {mx=sum;cnt=0;}
	    if (sum==mx) cnt++;
	}
	cout << cnt << ' ' << mx;
    return 0;
}
