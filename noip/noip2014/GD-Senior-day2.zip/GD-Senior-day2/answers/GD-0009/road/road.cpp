#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
using namespace std;
const int N=10005;
const int M=200005;
const int Q=2000005;
struct node {int x,y;} E[M];
struct edge {int x,next;} b[M];
int n,m,tot,s,t,q[Q],a[N],dis[N];
int v[N],stack[N],top; bool can[N];
int getint()
{
	char c=getchar(); int x=0; bool flag=false;
	while ((c!='-')&&((c<'0')||(c>'9'))) c=getchar();
	if (c=='-') flag=true,c=getchar();
	while ((c>='0')&&(c<='9')) x=x*10+c-'0',c=getchar();
	if (flag) return -x; else return x;
}
void addedge(int x,int y)
{
	tot++; b[tot].x=y; b[tot].next=a[x]; a[x]=tot;
}
bool cmp(const node &a,const node &b)
{
	if (a.x!=b.x) return a.x<b.x;
	return a.y<b.y;
}
void init()
{
	n=getint(); m=getint();
	for (int i=1; i<=m; i++) E[i].x=getint(),E[i].y=getint();
	s=getint(); t=getint(); sort(E+1,E+m+1,cmp); tot=0; E[0].x=E[0].y=0;
	for (int i=1; i<=m; i++) if (((E[i].x!=E[i-1].x)||(E[i].y!=E[i-1].y))&&(E[i].x!=E[i].y)) E[++tot]=E[i]; m=tot;
}
void topsort()
{
	tot=0; memset(a,0,sizeof(a));
	for (int i=1; i<=m; i++) addedge(E[i].y,E[i].x);
	top=1; stack[1]=t; can[stack[1]]=true;
	memset(v,0,sizeof(v)); v[stack[1]]=1;
	while (top>0)
	{
		int k=stack[top]; top--;
		for (int p=a[k];p;p=b[p].next)
		{
			int pp=b[p].x; if (v[pp]==1) continue;
			top++; stack[top]=pp; v[pp]=1;
		}
	}
	tot=0; memset(a,0,sizeof(a));
	for (int i=1; i<=m; i++) addedge(E[i].x,E[i].y);
	for (int i=1; i<=n; i++)
	{
		if (v[i]==0) continue; bool flag=true;
		for (int p=a[i];p;p=b[p].next)
		{
			int pp=b[p].x; 
			if (v[pp]==0) {flag=false; break;}
		}
		if (flag) can[i]=true;
	}
}
void rebuild()
{
	tot=0; memset(a,0,sizeof(a));
	for (int i=1; i<=m; i++)
	{
		int x=E[i].x,y=E[i].y;
		if ((can[x]==false)||(can[y]==false)) continue;
		addedge(x,y);
	}
}
void spfa()
{
	if (can[s]==false) {printf("-1\n"); return;}
	int head=0,tail=1; q[1]=s; memset(v,0,sizeof(v)); v[s]=1;
	memset(dis,127,sizeof(dis)); dis[s]=0;
	while (head<tail)
	{
		head++; if (head>=Q) head=1; int k=q[head]; v[k]=0;
		for (int p=a[k];p;p=b[p].next)
		{
			int pp=b[p].x; 
			if (dis[k]+1<dis[pp])
			{
				dis[pp]=dis[k]+1; if (v[pp]==1) continue;
				tail++; if (tail>=Q) tail=1; q[tail]=pp; v[pp]=1;
			}
		}
	}
	printf("%d\n",dis[t]);
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	init();
	topsort();
	rebuild();
	spfa();
	return 0;
}
