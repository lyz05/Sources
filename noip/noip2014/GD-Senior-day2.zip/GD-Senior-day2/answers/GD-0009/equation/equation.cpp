#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
using namespace std;
const int N=105;
const int M=100000000;
const int maxmod=10000007;
struct BigNumber
{
	int len; bool flag;
	long long a[10005]; long long x;
} a[N];
int n,m,ansT,anss[N];
int getint()
{
	char c=getchar(); int x=0; bool flag=false;
	while ((c!='-')&&((c<'0')||(c>'9'))) c=getchar();
	if (c=='-') flag=true,c=getchar();
	while ((c>='0')&&(c<='9')) x=x*10+c-'0',c=getchar();
	if (flag) return -x; else return x;
}
BigNumber times(BigNumber a,int b)
{
	for (int i=1; i<=a.len; i++) a.a[i]=a.a[i]*b;
	for (int i=1; i<=a.len; i++) a.a[i+1]+=a.a[i]/M,a.a[i]%=M;
	while (a.a[a.len+1]!=0) 
	{
		a.len++;
		a.a[a.len+1]=a.a[a.len]/M;
		a.a[a.len]%=M;
	}
	while ((a.len>1)&&(a.a[a.len]==0)) a.len--; return a;
}
BigNumber mul(const BigNumber &a,const BigNumber &b)
{
	BigNumber c; memset(c.a,0,sizeof(c.a)); 
	c.len=a.len+b.len;
	if (a.flag==b.flag) c.flag=false; else c.flag=true;
	for (int i=1; i<=a.len; i++)
	{
		for (int j=1; j<=b.len; j++) c.a[i+j-1]+=a.a[i]*b.a[j];
	}
	for (int i=1; i<=c.len; i++) c.a[i+1]+=c.a[i]/M,c.a[i]%=M;
	while (c.a[c.len+1]!=0) 
	{
		c.len++;
		c.a[c.len+1]=c.a[c.len]/M;
		c.a[c.len]%=M;
	}
	while ((c.len>1)&&(c.a[c.len]==0)) c.len--; return c;
}
BigNumber pluss(const BigNumber &a,const BigNumber &b)
{
	BigNumber c; memset(c.a,0,sizeof(c.a)); 
	c.len=max(a.len,b.len);
	for (int i=1; i<=c.len; i++)
	{
		c.a[i]+=a.a[i]+b.a[i];
		c.a[i+1]=c.a[i]/M;
		c.a[i]%=M;
	}
	while (c.a[c.len+1]!=0) 
	{
		c.len++;
		c.a[c.len+1]=c.a[c.len]/M;
		c.a[c.len]%=M;
	}
	return c;
}
int cmp(const BigNumber &a,const BigNumber &b)
{
	if (a.len>b.len) return 1;
	if (a.len<b.len) return -1;
	for (int i=a.len; i>=1; i--)
	{
		if (a.a[i]>b.a[i]) return 1;
		if (a.a[i]<b.a[i]) return -1;
	}
	return 0;
}
BigNumber subs(BigNumber a,BigNumber b)
{
	BigNumber c; c.flag=false; memset(c.a,0,sizeof(c.a)); 
	if (cmp(a,b)==-1) {c.flag=true; swap(a,b);} c.len=a.len;
	for (int i=1; i<=a.len; i++)
	{
		c.a[i]=a.a[i]-b.a[i];
		if (c.a[i]<0) {a.a[i+1]--; c.a[i]+=M;}
	}
	while ((c.len>1)&&(c.a[c.len]==0)) c.len--; return c;
}
BigNumber calc_plus(const BigNumber &a,const BigNumber &b)
{
	BigNumber c;
	if ((a.flag==true)&&(b.flag==true)) c=pluss(a,b),c.flag=true;
	if ((a.flag==true)&&(b.flag==false)) c=subs(b,a);
	if ((a.flag==false)&&(b.flag==true)) c=subs(a,b);
	if ((a.flag==false)&&(b.flag==false)) c=pluss(a,b),c.flag=false;
	return c;
}
void init()
{
	n=getint(); m=getint();
	for (int i=0; i<=n; i++)
	{
		char c=getchar(); int now=0;
		while ((c!='-')&&((c<'0')||(c>'9'))) c=getchar();
		if (c=='-') a[i].flag=true; else a[i].flag=false;
		if (c=='-') c=getchar();
		while ((c>='0')&&(c<='9'))
		{
			now++; if (now%8==1) a[i].len++;
			a[i].a[a[i].len]=a[i].a[a[i].len]*10+c-'0'; 
			c=getchar();
		}
		a[i].x=0;
		for (int j=a[i].len; j>=1; j--)
		{
			a[i].x=a[i].x*M+a[i].a[j];
			a[i].x=a[i].x%maxmod;
		}
		if (a[i].flag) a[i].x=-a[i].x;
	}
}
void solve()
{
	BigNumber zero; memset(zero.a,0,sizeof(zero.a)); zero.len=1;
	for (int i=1; i<=m; i++)
	{
		long long nowans=0,nowbase=1;
		for (int j=0; j<=n; j++)
		{
			nowans=(nowans+a[j].x*nowbase)%maxmod;
			nowbase=(nowbase*i)%maxmod;
		}
		if (nowans!=0) continue;
		BigNumber ans,base;
		base.len=1; memset(base.a,0,sizeof(base.a)); base.a[1]=1;
		ans.len=1; memset(ans.a,0,sizeof(ans.a));
		for (int j=0; j<=n; j++)
		{
			ans=calc_plus(ans,mul(base,a[j]));
			if (j!=n) base=times(base,i);
		}
		if (cmp(ans,zero)==0) {ansT++; anss[ansT]=i;}
		if (ansT==n) break;
	}
	printf("%d\n",ansT);
	for (int i=1; i<=ansT; i++) printf("%d\n",anss[i]);
}
int main()
{
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	init();
	solve();
	return 0;
}
