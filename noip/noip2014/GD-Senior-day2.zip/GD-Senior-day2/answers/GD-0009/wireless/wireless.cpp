#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
using namespace std;
const int N=30;
struct point {int x,y,z;} a[N];
int n,m,ansT,ans;
int getint()
{
	char c=getchar(); int x=0; bool flag=false;
	while ((c!='-')&&((c<'0')||(c>'9'))) c=getchar();
	if (c=='-') flag=true,c=getchar();
	while ((c>='0')&&(c<='9')) x=x*10+c-'0',c=getchar();
	if (flag) return -x; else return x;
}
void init()
{
	m=getint(); n=getint(); ansT=ans=0;
	for (int i=1; i<=n; i++) a[i].x=getint(),a[i].y=getint(),a[i].z=getint();
}
void solve()
{
	for (int i=0; i<=128; i++)
	{
		for (int j=0; j<=128; j++)
		{
			int nowans=0;
			for (int k=1; k<=n; k++)
			{
				if (a[k].x<i-m) continue;
				if (a[k].x>i+m) continue;
				if (a[k].y<j-m) continue;
				if (a[k].y>j+m) continue;
				nowans=nowans+a[k].z;
			}
			if (nowans>ans) {ansT=1; ans=nowans; continue;}
			if (nowans==ans) {ansT++; continue;}
		}
	}
	printf("%d %d\n",ansT,ans);
}
int main()
{
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	init();
	solve();
	return 0;
}
