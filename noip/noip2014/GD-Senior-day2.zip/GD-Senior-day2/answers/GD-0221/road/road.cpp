#include<cstdio>
#include<cstring>
#include<algorithm>
#define fo(i,a,b) for (int i = a;i <= b;i ++)

using namespace std;

const int maxn = 20005;
const int maxm = 200005;
const int inf = (int)1e9;

int N,M,S,T;
int q[maxm*20],dist[maxn];
bool flag[maxn],noreach[maxn];

struct Graph
{
	int tot,a[maxn],b[maxm],c[maxm];
	void Insert(int x,int y)
	{
		tot ++;
		b[tot] = y; c[tot] = a[x]; a[x] = tot;
	}
	void SPFA(int st,int sig)
	{
		memset(dist,60,(N+1)*4);
		memset(flag,0,(N+1));
		dist[st] = 0;
		q[1] = st; flag[st] = 1;
		int l = 0, r = 1;
		while (l < r)
		{
			int x = q[++l];
			if (sig == 1 && noreach[x]) continue;
			for (int i = a[x];i;i = c[i])
			{
				if (sig == 1 && noreach[b[i]]) continue;
				if (dist[x] + 1 < dist[b[i]])
				{
					dist[b[i]] = dist[x] + 1;
					if (!flag[b[i]])
					{
						flag[b[i]] = 1;
						q[++r] = b[i];
					}
				}
			}
			flag[x] = 0;
		}
	}
}A,B;

void Initialize()
{
	scanf("%d%d",&N,&M);
	fo(i,1,M)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		A.Insert(x,y);
		B.Insert(y,x);
	}
	scanf("%d%d",&S,&T);
	B.SPFA(T,0);
	fo(x,1,N)
		for (int i = A.a[x];i;i = A.c[i])
			if (dist[A.b[i]] > inf)
			{
				noreach[x] = 1;
				break;
			}
}

void Work()
{
	A.SPFA(S,1);
	if (dist[T] > inf) printf("-1\n");
	else printf("%d\n",dist[T]);
}

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	Initialize();
	Work();
	return 0;
}
