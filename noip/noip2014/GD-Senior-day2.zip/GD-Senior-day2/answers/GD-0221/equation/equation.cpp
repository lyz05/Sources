#include<cstdio>
#include<cstring>
#include<algorithm>
#define fo(i,a,b) for (int i = a;i <= b;i ++)

using namespace std;

const int maxn = 105;
const int maxl = 20005;
const int P = 10000;
const int ten[] = {1,10,100,1000};

int N,M,a[maxn][maxl],sig[maxn],sol[maxn];
char ch[maxl];

void Initialize()
{
	scanf("%d%d",&N,&M);
	fo(i,0,N)
	{
		scanf("%s",ch+1);
		int st = 1, len = strlen(ch+1);
		if (ch[1] == '-') sig[i] = 0, st = 2;
		else sig[i] = 1;
		a[i][0] = 0;
		int x = 0;
		for (int k = len,cnt = 1;k >= st;k --,cnt ++)
		{
			if (cnt > 4)
			{
				a[i][++a[i][0]] = x;
				cnt = 1, x = 0;
			}
			x += (ch[k]-48) * ten[cnt-1];
		}
		if (x) a[i][++a[i][0]] = x;
	}
}

int c[maxl],p[2][maxl],X[maxl],PX[maxl],temp[maxl];
void Mult(int *a,int *b)
{
	c[0] = a[0] + b[0] - 1;
	fo(i,1,c[0]+1) c[i] = 0;
	fo(i,1,a[0])
		fo(j,1,b[0])
		{
			c[i+j-1] += a[i] * b[j];
			c[i+j] += c[i+j-1] / P;
			c[i+j-1] %= P;
		}
	if (c[c[0]+1] > 0) c[0] ++;
}

void Add(int *a,int *b)
{
	c[0] = max(a[0],b[0]);
	fo(i,1,c[0]+1) c[i] = 0;
	fo(i,1,c[0])
	{
		c[i] += a[i] + b[i];
		c[i+1] += c[i] / P;
		c[i] %= P;
	}
	if (c[c[0]+1] > 0) c[0] ++;
}

bool Cmp()
{
	fo(i,0,p[0][0]) if (p[0][i] != p[1][i]) return 0;
	return 1;
}

long long res;
bool Divide(int x)
{
	res = 0;
	for (int i = a[0][0];i >= 1;i --)
	{
		res = res * P + a[0][i];
		res %= x;
	}
	return res == 0;
}

void Work()
{
	fo(x,1,M)
	{
		if (!Divide(x)) continue;
		fo(i,0,a[0][0]) p[sig[0]][i] = a[0][i];
		X[0] = 0; PX[PX[0]=1] = 1;
		for (int t = x;t;t /= P) X[++X[0]] = t % P;
		fo(i,1,N)
		{
			Mult(PX,X);
			fo(j,0,c[0]) PX[j] = c[j];
			Mult(PX,a[i]);
			fo(j,0,c[0]) temp[j] = c[j];
			Add(p[sig[i]],temp);
			fo(j,0,c[0]) p[sig[i]][j] = c[j];
		}
		if (Cmp()) sol[++sol[0]] = x;
		fo(i,1,p[0][0]) p[0][i] = 0;
		fo(i,1,p[1][0]) p[1][i] = 0;
		p[0][0] = p[1][0] = 0;
	}
	fo(i,0,sol[0]) printf("%d\n",sol[i]);
}

int main()
{
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	Initialize();
	Work();
	return 0;
}
