#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#define fo(i,a,b) for (int i = a;i <= b;i ++)

using namespace std;

const int maxn = 25;
const int maxl = 135;

int N,D,Sum;
long long a[maxl][maxl],Ans;

int main()
{
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	scanf("%d%d",&D,&N);
	fo(i,1,N)
	{
		int x,y,k;
		scanf("%d%d%d",&x,&y,&k);
		x ++, y ++;
		a[x][y] = k;
	}
	fo(i,1,129) fo(j,1,129)
		a[i][j] = a[i-1][j] + a[i][j-1] + a[i][j] - a[i-1][j-1];
	Ans = Sum = 0;
	fo(i,1,129)
		fo(j,1,129)
		{
			int x1,x2,y1,y2;
			x1 = max(1,i-D), y1 = max(1,j-D);
			x2 = min(129,i+D), y2 = min(129,j+D);
			long long t = a[x2][y2] - a[x2][y1-1] - a[x1-1][y2] + a[x1-1][y1-1];
			if (t > Ans) Ans = t, Sum = 1;
			else if (t == Ans) Sum ++;
		}
	cout << Sum << ' ' << Ans << endl;
	return 0;
}
