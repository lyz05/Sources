#include <iostream>
#include <cstdlib>
#include <cstdio>
using namespace std;

int n,d,c[20000010];
long sum,ma,m[200][200];

int main(){
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	
	long i,j,k,l;
	
	cin>>d>>n;
	for(i=1;i<=n;i++){
		cin>>j>>k>>l;
		m[j+20][k+20]=l;
	}
	/*
	for(i=1;i<=10;i++){
		for(j=1;j<=10;j++)
			cout<<m[i][j];
		cout<<endl;	
	}
	*/	
	
	for(i=20;i<=148;i++){
		for(j=20;j<=148;j++){
			sum=0;
			for(k=i-d;k<=i+d;k++){
				for(l=j-d;l<=j+d;l++){
					sum+=m[k][l];
				}
			}
			if(sum>ma)
				ma=sum;
			c[sum]++;
		}
	}
	
//	for(i=1;i<=ma;i++){
//		if(c[i]!=0)
//			cout<<i<<":"<<c[i]<<endl;
//	}
		
	cout<<c[ma]<<" "<<ma;
	return 0;
}
