#include <iostream>
#include <cstdlib>
#include <cstdio>
using namespace std;

long a[100],sum,n,m,ans,an[1000];

long v(long t,long x){
	if(t==n)
		return a[t];
	else
		return v(t+1,x)*x+a[t];
}

int comp(const void*a,const void*b){
	return (*(long*)a)-(*(long*)b);
};

int main(){
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);	
	long i,j;
	
	cin>>n>>m;
	for(i=0;i<=n;i++){
		cin>>a[i];
	}
	
	for(i=1;i<=m;i++){
		if(v(0,i)==0){
			ans++;
			an[ans]=i;
		}
	}
	
	if(ans==0){
		cout<<ans;
			return 0;
	}
	qsort(an+1,ans,sizeof(long),comp);
	cout<<ans<<endl;
	for(i=1;i<=ans;i++)
		cout<<an[i]<<endl;
	return 0;
}
