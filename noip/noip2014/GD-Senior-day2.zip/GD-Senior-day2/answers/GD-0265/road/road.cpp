#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cstring>
using namespace std;

long n,m,a[10010],al[10010],bl[10010],b[10010],s,t,head,tail,st[10010];
int q[200000];
bool done[10010],cango[10010],flag;

struct ss{
	int f,t;
};
ss s1[200010],s2[200010];

int comp1(const void* a,const void* b){
	return (*(ss*)a).f-(*(ss*)b).f;
}
int comp2(const void* a,const void* b){
	return (*(ss*)b).f-(*(ss*)a).f;
}

int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	long i;
	
	cin>>n>>m;
	for(i=1;i<=m;i++){
		cin>>s1[i].f>>s1[i].t;
		s2[i].f=s1[i].t;
		s2[i].t=s1[i].f;
	}
	
	qsort(s1+1,m,sizeof(ss),comp1);
	qsort(s2+1,m,sizeof(ss),comp2);
	/*
	for(i=1;i<=m;i++){
		cout<<s1[i].f<<" "<<s1[i].t<<endl;
	}
	
	cout<<endl;
	
	for(i=1;i<=m;i++){
		cout<<s2[i].f<<" "<<s2[i].t<<endl;
	}
	*/
	
	for(i=1;i<=m;i++){
		if(a[s1[i].f]==0){
			a[s1[i].f]=i;
		}
		al[s1[i].f]++;
	}
	for(i=1;i<=m;i++){
		if(b[s2[i].f]==0){
			b[s2[i].f]=i;
		}
		bl[s2[i].f]++;
	}
//	for(i=1;i<=n;i++){
//		cout<<b[i]<<" "<<bl[i]<<endl;
//	}
	
	cin>>s>>t;
//	cout<<s<<" "<<t;
	
	done[t]=1;
	head=0;tail=0;
	q[tail]=t;
	cango[t]=1;
	while(head<=tail){
		for(i=b[q[head]];i<b[q[head]]+bl[q[head]];i++){
			if(done[s2[i].t]==0){
				done[s2[i].t]=1;
				tail++;
				q[tail]=s2[i].t;
				cango[s2[i].t]=1;
			}
		}
		head++;
	}	
//	for(i=1;i<=n;i++)
//		cout<<cango[i]<<" ";
	
//SPFA
//	for(i=1;i<=n;i++)
//		cout<<q[i]<<" ";

	head=0;tail=0;
	memset(done,0,n);
	memset(q,0,200000);
//	for(i=1;i<=n;i++)
//		cout<<q[i]<<" ";
	for(i=1;i<=n;i++){
		st[i]=9999999;
	}
	st[s]=0;
	q[tail]=s;
	while(head<=tail){
		//cout<<q[head]<<endl;
		flag=1;
		for(i=a[q[head]];i<a[q[head]]+al[q[head]];i++){
		//	cout<<q[head]<<" "<<cango[s1[i].t]<<endl;
			if(cango[s1[i].t]==0){
				flag=0;
			}
		}
//		if(!flag)
//			cout<<q[head];
		if(flag){
			for(i=a[q[head]];i<a[q[head]]+al[q[head]];i++){
				if(done[s1[i].t]==0){
				//	cout<<q[head]<<endl;
					if(st[s1[i].t]>st[q[head]]+1){
						done[s1[i].t]==1;
						tail++;
						q[tail]=s1[i].t;
						st[s1[i].t]=st[q[head]]+1;
					}	
				}
			}
		}
		done[q[head]]==0;
		head++;
	}
	if(st[t]==9999999){
		cout<<"-1";
		return 0;
	}
		
	cout<<st[t];
	return 0;
}
