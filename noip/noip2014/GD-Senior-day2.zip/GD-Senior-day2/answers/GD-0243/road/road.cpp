#include <cstdio>
#include <cstdlib>
#include <cstring>

#define N 400020

using namespace std;

struct EDGE {
	int adj, w, next;
} edge[N];
int n, m, top, gh[N], dist[N], valid[N], X[N], Y[N], S, T;

void addedge(int x, int y, int w) {
	edge[++top].adj = y;
	edge[top].w = w;
	edge[top].next = gh[x];
	gh[x] = top;
}

int q[N], head, tail, v[N];

void spfa(int s) {
	memset(dist, 63, sizeof(dist));
	memset(v, 0, sizeof(v));
	dist[s] = 0;
	head = 0, tail = 1;
	q[1] = s;
	while (head != tail) {
		head = (head + 1) % N;
		int x = q[head];
		v[x] = 0;
		for (int p=gh[x]; p; p=edge[p].next)
			if ((valid[edge[p].adj]) && (dist[x] + edge[p].w < dist[edge[p].adj])) {
				dist[edge[p].adj] = dist[x] + edge[p].w;
				if (!v[edge[p].adj]) {
					v[edge[p].adj] = 1;
					tail = (tail + 1) % N;
					q[tail] = edge[p].adj;
				}
			}
	}
}

int main() {
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d%d", &n, &m);
	memset(gh, 0, sizeof(gh));
	top = 0;
	for (int i=1;i<=m;i++) {
		scanf("%d%d", &X[i], &Y[i]);
		addedge(Y[i], X[i], 1);
	}
	scanf("%d%d", &S, &T);
	for (int i=1;i<=n;i++)
		valid[i] = 1;
	spfa(T);
	for (int i=1;i<=n;i++)
		if (dist[i] >= 0x3f3f3f3f) {
			valid[i] = 0;
			for (int p=gh[i]; p; p=edge[p].next)
				valid[edge[p].adj] = 0;
		}
	memset(gh, 0, sizeof(gh));
	top = 0;
	for (int i=1;i<=m;i++)
		addedge(X[i], Y[i], 1);
	spfa(S);
	int ans = dist[T];
	if (ans >= 0x3f3f3f3f) ans = -1;
	printf("%d\n", ans);
	return 0;
}
