#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>

#define N 130

using namespace std;

int a[N][N], d, n, ans1, ans2;

int main() {
	freopen("wireless.in","r",stdin);
	freopen("wireless.ans","w",stdout);
	scanf("%d%d", &d, &n);
	for (int i=1;i<=n;i++) {
		int x, y, w;
		scanf("%d%d%d", &x, &y, &w);
		x++; y++;
		a[x][y] = w;
	}
	ans1 = ans2 = 0;
	for (int i=1;i<=129;i++)
		for (int j=1;j<=129;j++) {
			int ret = 0;
			for (int l1=max(i-d,1);l1<=min(i+d,129);l1++)
				for (int l2=max(j-d,1);l2<=min(j+d,129);l2++)
					ret += a[l1][l2];
			if (ret > ans1) {
				ans1 = ret;
				ans2 = 1;
			} else if (ret == ans1) {
				ans2 ++;
			}
		}
	printf("%d %d\n", ans2, ans1);
	return 0;
}
