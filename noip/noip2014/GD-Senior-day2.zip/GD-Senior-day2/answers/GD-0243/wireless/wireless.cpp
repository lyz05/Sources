#include <cstdio>
#include <cstdlib>
#include <cstring>

#define N 130

using namespace std;

int d, n, a[N][N], sum[N][N], ans1, ans2;

int ver(int x1, int y1, int x2, int y2) {
	if (x1 < 1) x1 = 1;
	if (y1 < 1) y1 = 1;
	if (x2 >= N) x2 = N-1;
	if (y2 >= N) y2 = N-1;
	return sum[x2][y2] + sum[x1-1][y1-1] - sum[x1-1][y2] - sum[x2][y1-1];
}

int main() {
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	scanf("%d%d", &d, &n);
	memset(a, 0, sizeof(a));
	for (int i=1;i<=n;i++) {
		int x, y, w;
		scanf("%d%d%d", &x, &y, &w);
		x++, y++;
		a[x][y] = w;
	}
	memset(sum, 0, sizeof(sum));
	for (int i=1;i<N;i++) {
		int k = 0;
		for (int j=1;j<N;j++) {
			k += a[i][j];
			sum[i][j] = sum[i-1][j] + k;
		}
	}
	ans1 = 0; ans2 = 0;
	for (int i=1;i<N;i++)
		for (int j=1;j<N;j++) {
			int ret = ver(i-d, j-d, i+d, j+d);
			if (ret > ans1) {
				ans1 = ret;
				ans2 = 1;
			} else if (ret == ans1) {
				ans2 ++;
			}
		}
	printf("%d %d\n", ans2, ans1);
	return 0;
}
