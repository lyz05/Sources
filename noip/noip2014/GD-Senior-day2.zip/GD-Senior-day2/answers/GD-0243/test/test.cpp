#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>

using namespace std;

int main() {
	freopen("test.in","r",stdin);
	freopen("test.out","w",stdout);
	int n, a[100];
	scanf("%d", &n);
	for (int i=0;i<n;i++) scanf("%d", &a[i]);
	sort(a, a+n);
	for (int i=0;i<n;i++) printf("%d ", a[i]);
	return 0;
}
