#include <cstdio>
#include <cstdlib>
#include <cstring>

#define N 105
#define K 12020

using namespace std;

int n, m, ans, ans2[K], h;
struct bigint {
	int d[K], size, gm;
	void init() {
		memset(d, 0, sizeof(d));
		size = 1;
	}
} a[N], s, tmp1, tmp2, tmp3;

char cmd[K];

int max(int x, int y) { return x > y ? x : y; }

void realplus() {
	tmp3.init();
	tmp3.size = max(tmp1.size, tmp2.size);
	for (int i=0;i<tmp3.size;i++) {
		tmp3.d[i] = tmp1.d[i] + tmp2.d[i];
		tmp3.d[i+1] += tmp3.d[i] / 10;
		tmp3.d[i] %= 10;
	}
	while (tmp3.d[tmp3.size]) tmp3.size++;
}

int cmp() {
	if (tmp1.size != tmp2.size)
		return tmp1.size < tmp2.size;
	for (int i=tmp1.size-1;i>=0;i--)
		if (tmp1.d[i] != tmp2.d[i]) {
			return tmp1.d[i] < tmp2.d[i];
		}
	return 0;
}

void realminus() {
	h = 0;
	if (cmp()) {
		h = 1;
		tmp3 = tmp1;
		tmp1 = tmp2;
		tmp2 = tmp3;
	}
	tmp3 = tmp1; tmp3.gm = 0;
	for (int i=0;i<tmp3.size;i++) {
		tmp3.d[i] -= tmp2.d[i];
		if (tmp3.d[i] < 0) tmp3.d[i] += 10, tmp3.d[i+1] --;
	}
	while (tmp3.size > 1 && tmp3.d[tmp3.size-1] == 0)
		tmp3.size --;
	if (h) tmp3.gm = 1;
}

void plus(bigint &a, const bigint &b) {
	if (a.gm == 0 && b.gm == 0) {
		tmp1 = a;
		tmp2 = b;
		realplus();
	}
	if (a.gm == 0 && b.gm == 1) {
		tmp1 = a;
		tmp2 = b;
		realminus();
	}
	if (a.gm == 1 && b.gm == 0) {
		tmp1 = b;
		tmp2 = a;
		realminus();
	}
	if (a.gm == 1 && b.gm == 1) {
		tmp1 = a;
		tmp2 = b;
		realplus();
		tmp3.gm = 1;
	}
	a = tmp3;
}

void times(bigint &a, int b) {
	for (int i=0;i<a.size;i++)
		a.d[i] *= b;
	int i = 0, g = 0;
	while (i < a.size || g > 0) {
		a.d[i] += g;
		g = a.d[i] / 10;
		a.d[i] %= 10;
		i++;
	}
	a.size = i+1;
	while (a.size > 1 && a.d[a.size-1] == 0) a.size --;
}

int valid(int c) {
	s.init();
	for (int i=n;i>=0;i--) {
		plus(s, a[i]);
		if (i) times(s, c);
	}
	for (int i=0;i<s.size;i++)
		if (s.d[i]) return 0;
	return 1;
}

int main() {
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	scanf("%d%d", &n, &m);
	for (int i=0;i<=n;i++) {
		scanf("%s", cmd);
		a[i].init();
		int g = 0;
		if (cmd[0] == '-') {
			a[i].gm = 1;
			g = 1;
		}
		int len = strlen(cmd);
		a[i].size = len-g;
		for (int j=len-1,k=0;j>=g;j--,k++) {
			a[i].d[k] = cmd[j]-'0';
		}
	}
	ans = 0;
	for (int i=1;i<=m;i++)
		if (valid(i)) ans2[++ans] = i;
	printf("%d\n", ans);
	for (int i=1;i<=ans;i++)
		printf("%d\n", ans2[i]);
	return 0;
}
