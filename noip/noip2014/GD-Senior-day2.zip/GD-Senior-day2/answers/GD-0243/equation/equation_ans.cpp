#include <cstdio>
#include <cstdlib>
#include <cstring>

#define N 102

using namespace std;

int n, m, a[N], ans, ans2[N];

int main() {
	freopen("equation.in","r",stdin);
	freopen("equation.ans","w",stdout);
	scanf("%d%d", &n, &m);
	for (int i=0;i<=n;i++) scanf("%d", &a[i]);
	for (int i=1;i<=m;i++) {
		int s = 0;
		for (int j=n;j>=0;j--) {
			s += a[j];
			if (j) s *= i;
		}
		if (s == 0) {
			ans++;
			ans2[ans] = i;
		}
	}
	printf("%d\n", ans);
	for (int i=1;i<=ans;i++)
		printf("%d\n", ans2[i]);
	return 0;
}
