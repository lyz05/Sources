#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;

const int maxn=105, mo=1e8;

struct BIG
{
	int sign, n, v[2500];
	
	void READ()
	{
		static char _s[10005];
		char *s=_s;
		scanf("%s",s);
		if (s[0]=='-')
			sign=-1, s++;
		else
			sign=1;
		for (int i=strlen(s)-1,j=100000000;i>=0;i--,j*=10)
		{
			if (j==100000000) j=1, n++;
			v[n]+=(s[i]-48)*j;
		}
	}
};

int N, M, ans, ANS[maxn];
BIG A[maxn], _big1, _big2;

inline bool operator<(const BIG &a, const BIG &b)
{
	if (a.n<b.n) return true;
	if (a.n>b.n) return false;
	for (register int i=a.n;i;i--)
	{
		if (a.v[i]<b.v[i]) return true;
		if (a.v[i]>b.v[i]) return false;
	}
	return false;
}

inline void MINUS(const BIG &a, const BIG &b, BIG &c)
{
	c.n=a.n;
	memset(c.v,0,(c.n+5)*sizeof(int));
	for (register int i=1;i<=a.n;i++)
	{
		c.v[i]+=a.v[i]-b.v[i];
		if (c.v[i]<0)
		{
			c.v[i]+=mo;
			c.v[i+1]--;
		}
	}
	while (c.n && !c.v[c.n]) c.n--;
}

inline void PLUS(const BIG &a, const BIG &b, BIG &c)
{
	if (a.sign!=b.sign)
	{
		if (a<b)
			MINUS(b,a,c), c.sign=b.sign;
		else
			MINUS(a,b,c), c.sign=a.sign;
		return;
	}
	c.sign=a.sign;
	c.n=max(a.n,b.n);
	memset(c.v,0,(c.n+5)*sizeof(int));
	for (register int i=1;i<=c.n;i++)
	{
		c.v[i]+=a.v[i]+b.v[i];
		c.v[i+1]=c.v[i]/mo;
		c.v[i]%=mo;
	}
	if (c.v[c.n+1]) c.n++;
}

inline void MUL(const BIG &a, int b, BIG &c)
{
	c.sign=a.sign; // b>0
	c.n=a.n;
	memset(c.v,0,(c.n+5)*sizeof(int));
	for (register int i=1;i<=a.n;i++)
	{
		register long long V=(long long)a.v[i]*b+c.v[i];
		c.v[i]=V%mo;
		c.v[i+1]=V/mo;
	}
	if (c.v[c.n+1]) c.n++;
}

bool Test(int x)
{
	BIG *now=&_big1, *tmp=&_big2;
	*now=A[N];
	for (int i=N-1;i>=0;i--)
	{
		MUL(*now,x,*tmp);
		PLUS(*tmp,A[i],*now);
	}
	return !now->n;
}

int main()
{
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	scanf("%d%d",&N,&M);
	for (int i=0;i<=N;i++) A[i].READ();
	for (int i=1;i<=M && ans<N;i++)
		if (Test(i))
			ANS[++ans]=i;
	printf("%d\n",ans);
	for (int i=1;i<=ans;i++)
		printf("%d\n",ANS[i]);
	return 0;
}

