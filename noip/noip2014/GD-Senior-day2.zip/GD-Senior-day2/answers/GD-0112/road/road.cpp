#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;

inline void READ(int &x)
{
	char c;
	x=0;
	do c=getchar(); while (c<'0' || c>'9');
	do x=x*10+c-48, c=getchar(); while (c>='0' && c<='9');
}

const int maxn=10005, maxm=200005;

int N, M, S, T, list[maxn], f[maxn];
bool flag[maxn], ok[maxn];

struct GRAPH
{
	int m, a[maxn], b[maxm], c[maxm];
	
	void add(int x, int y)
	{
		m++, b[m]=y, c[m]=a[x], a[x]=m;
	}
	
	void Bfs1();
	void Bfs2();
} ORI, REV;

void GRAPH::Bfs1()
{
	int st, en;
	list[st=en=1]=T;
	flag[T]=true;
	for (;st<=en;st++)
	{
		int x(list[st]);
		for (int i=a[x];i;i=c[i]) if (!flag[b[i]])
		{
			list[++en]=b[i];
			flag[b[i]]=true;
		}
	}
}

void GRAPH::Bfs2()
{
	memset(f,255,sizeof f);
	if (!ok[S]) return;
	int st, en;
	list[st=en=1]=S;
	f[S]=0;
	for (;st<=en;st++)
	{
		int x(list[st]);
		for (int i=a[x];i;i=c[i]) if (!~f[b[i]] && ok[b[i]])
		{
			f[b[i]]=f[x]+1;
			list[++en]=b[i];
		}
	}
}

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	READ(N), READ(M);
	for (int i=1;i<=M;i++)
	{
		int x, y;
		READ(x), READ(y);
		ORI.add(x,y);
		REV.add(y,x);
	}
	READ(S), READ(T);
	REV.Bfs1();
	for (int i=1;i<=N;i++)
	{
		ok[i]=true;
		for (int j=ORI.a[i];j&&ok[i];j=ORI.c[j])
			if (!flag[ORI.b[j]])
				ok[i]=false;
	}
	ORI.Bfs2();
	printf("%d\n",f[T]);
	return 0;
}

