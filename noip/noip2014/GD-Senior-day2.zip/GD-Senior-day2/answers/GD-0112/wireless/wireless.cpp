#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;

const int maxn=25;

int D, N, ans1, ans2, X[maxn], Y[maxn], K[maxn];

int main()
{
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	scanf("%d%d",&D,&N);
	for (int i=1;i<=N;i++)
		scanf("%d%d%d",&X[i],&Y[i],&K[i]);
	for (int i=0;i<=128;i++)
		for (int j=0;j<=128;j++)
		{
			int cur(0);
			for (int k=1;k<=N;k++)
				if (abs(X[k]-i)<=D && abs(Y[k]-j)<=D)
					cur+=K[k];
			if (cur>ans2)
				ans2=cur, ans1=0;
			if (cur==ans2)
				ans1++;
		}
	printf("%d %d\n",ans1,ans2);
	return 0;
}

