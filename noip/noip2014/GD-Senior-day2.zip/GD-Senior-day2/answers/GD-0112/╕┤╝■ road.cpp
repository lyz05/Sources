#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;

inline void READ(int &x)
{
	char c;
	x=0;
	do c=getchar(); while (c<'0' || c>'9');
	do x=x*10+c-48, c=getchar(); while (c>='0' && c<='9');
}

const int maxn=10005, maxm=200005;

struct GRAPH
{
	int n, m, a[maxn], b[maxm], c[maxm];
	
	void add(int x, int y)
	{
		m++, b[m]=y, c[m]=a[x], a[x]=m;
	}
};

struct OLD_t : GRAPH
{
	int belong[maxn];
	void Bfs();
} OLD;

struct NEW_t : GRAPH
{
	int dgr[maxn];
	void Bfs();
} NEW;

void Tarjan(int x)
{
	static int DFN, top, stack[maxn], dfn[maxn], low[maxn];
	static bool flag[maxn];
	dfn[x]=low[x]=++DFN;
	flag[x]=true;
	stack[++top]=x;
	for (int i=OLD.a[x];i;i=OLD.c[i])
		if (!flag[OLD.b[i]])
		{
			Tarjan(OLD.b[i]);
			low[x]=min(low[x],low[OLD.b[i]]);
		} else
		if (!OLD.belong[OLD.b[i]])
			low[x]=min(low[x],dfn[OLD.b[i]]);
	if (dfn[x]==low[x])
	{
		NEW.n++;
		static int color[maxn];
		color[NEW.n]=color[0]=NEW.n;
		do
		{
			int now(stack[top]);
			OLD.belong[now]=NEW.n;
			for (int i=OLD.a[now];i;i=OLD.c[i])
				if (color[OLD.belong[OLD.b[i]]]!=NEW.n)
				{
					color[OLD.belong[OLD.b[i]]]=NEW.n;
					NEW.add(OLD.belong[OLD.b[i]],NEW.n);
					NEW.dgr[NEW.n]++;
				}
		} while (stack[top--]!=x);
	}
}

int S, T, list[maxn], f[maxn];

void NEW_t::Bfs()
{
	int st, en;
	list[st=en=1]=OLD.belong[T];
	for (;st<=en;st++)
	{
		int x(list[st]);
		for (int i=a[x];i;i=c[i]) if (!--dgr[b[i]])
			list[++en]=b[i];
	}
}

void OLD_t::Bfs()
{
	int st, en;
	list[st=en=1]=S;
	memset(f,255,sizeof f);
	f[S]=0;
	for (;st<=en;st++)
	{
		int x(list[st]);
		for (int i=a[x];i;i=c[i]) if (!~f[b[i]] && !NEW.dgr[belong[b[i]]])
		{
			f[b[i]]=f[x]+1;
			list[++en]=b[i];
		}
	}
}

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int M;
	READ(OLD.n), READ(M);
	for (int i=1;i<=M;i++)
	{
		int x, y;
		READ(x), READ(y);
		OLD.add(x,y);
	}
	READ(S), READ(T);
	for (int i=1;i<=OLD.n;i++) if (!OLD.belong[i])
		Tarjan(i);
	NEW.Bfs();
	OLD.Bfs();
	printf("%d\n",f[T]);
	return 0;
}

