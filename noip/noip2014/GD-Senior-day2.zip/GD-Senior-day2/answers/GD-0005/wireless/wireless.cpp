#include <fstream>
using namespace std;

const int MAXN = 135;

long long ans[MAXN][MAXN];

int main()
{
	ifstream fin("wireless.in");
	ofstream fout("wireless.out");
	
	int d, n, x, y, k;
	
	fin >> d;
	fin >> n;
	while (n--) {
		fin >> x >> y >> k;
		for (int i = x - d, iend = x + d; i <= iend; ++i)
		for (int j = y - d, jend = y + d; j <= jend; ++j) {
		       if (i < 0 or i > 128 or j < 0 or j > 128) continue;	       
		       ans[i][j] += k;
		}
	}

	int cnt = 0;
	long long big = 0;
	for (int i = d, iend = 128 - d; i <= iend; ++i)
	for (int j = d, jend = 128 - d; j <= jend; ++j) {
		if (ans[i][j] > big) {
			big = ans[i][j];
			cnt = 1;
		} else if (ans[i][j] == big)
			++cnt;
	}
	
	fout << cnt << ' ' << big << endl;

	fin.close(); fout.close();
	return 0;
}
