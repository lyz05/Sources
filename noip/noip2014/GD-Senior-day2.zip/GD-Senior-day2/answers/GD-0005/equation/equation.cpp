#include <cstdio>
#include <cstring>
#include <queue>
using namespace std;

const int MAXL = 10100;
const int MAXN = 105;

struct bign {
	int len, flag, n[MAXL];

	bign(): len(1), flag(1) {
		memset(n, 0, sizeof(n));
	}

	bign(int num) {
		flag = num < 0 ? -1 : 1;
		if (num == 0) { len = 1; memset(n, 0, sizeof(n)); }
		else {
			len = 0;
			num = num < 0 ? -num : num;
			while (num > 0) {
				n[len++] = num % 10;
				num /= 10;
			}
		}
	}
	
	void operator = (const char *str) {
		flag = str[0] == '-' ? -1 : 1;
		len = strlen(str) - 1; //if (flag < 0) --len;
		for (int i = 0; i <= len; ++i) {
			n[i] = str[len-i] - '0';
		}
		if (flag < 0) {
			n[len] = 0;
		} else {
			++len;
		}
	}

	bool operator == (const bign& a) {
		if (flag != a.flag or len != a.flag)
			return false;
		for (int i = 0; i < len; ++i)
			if (n[i] != a.n[i])
				return false;
		return true;
	}

	// no flag
	bool operator > (const bign& a) const {
		if (len != a.len)
			return len > a.len;
		for (int i = len - 1; i >= 0; --i)
			if (n[i] != a.n[i])
				return n[i] > a.n[i];
		return false;
	}

	bign operator + (const bign& a) const {
		bign ans;
		if (flag == a.flag) {
			ans.flag = flag;
			ans.len = (len > a.len ? len : a.len) + 1;
			for (int i = 0; i < ans.len; ++i) {
				ans.n[i] += n[i] + a.n[i];
				ans.n[i+1] += ans.n[i] / 10;
				ans.n[i] %= 10;
			}
		} else {
			if (*this > a) {
				ans.flag = flag;
				ans.len = len;
				for (int i = 0; i < ans.len; ++i)
					ans.n[i] = n[i] - a.n[i];
				for (int i = 0; i < ans.len; ++i) {
					if (ans.n[i] < 0) {
						--ans.n[i+1];
						ans.n[i] += 10;
					}
				}
			} else {
				ans.flag = a.flag;
				ans.len = a.len;
				for (int i = 0; i < ans.len; ++i)
					ans.n[i] = a.n[i] - n[i];
				for (int i = 0; i < ans.len; ++i) {
					if (ans.n[i] < 0) {
						--ans.n[i+1];
						ans.n[i] += 10;
					}
				}
			}
		}
		ans.setlen();
		if (ans.len == 1 and ans.n[0] == 0) ans.flag = 1;
		return ans;
	}

	// num is positive
	bign operator * (int num) const {
		bign ans;
		ans.flag = flag;
		ans.len = len + 11;
		for (int i = 0; i < len; ++i)
			ans.n[i] = n[i] * num;
		for (int i = 0; i < ans.len; ++i) {
			ans.n[i+1] += ans.n[i] / 10;
			ans.n[i] %= 10;
		}
		ans.setlen();
		return ans;
	}
		
	inline void setlen() {
		while (len > 1 and n[len-1] == 0)
			--len;
	}
	
	inline void output() const {
		if (flag < 0) putchar('-');
		for (int i = len - 1; i >= 0; --i)
			putchar('0'+n[i]);
		putchar('\n');
	}
} a[MAXN];

char buf[MAXL];
int n, m;

bign f(int x)
{
	bign ans = a[n];
	for (int i = n-1; i >= 0; --i)
		ans = a[i] + ans * x;
	return ans;
}


int main()
{
	freopen("equation.in", "r", stdin);
	freopen("equation.out", "w", stdout);
	
	scanf("%d%d", &n, &m);
	for (int i = 0; i <= n; ++i) {
		scanf("%s", buf);
		a[i] = buf;
	}

	bign zero;
	queue<int> q;
	for (int i = 1; i <= m; ++i)
		if (f(i) == zero)
			q.push(i);
	printf("%d\n", int(q.size()));
	while (not q.empty()) {
		printf("%d\n", q.front());
		q.pop();
	}

	return 0;
}
