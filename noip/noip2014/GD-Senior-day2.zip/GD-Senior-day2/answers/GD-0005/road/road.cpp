#include <cstdio>

int main()
{
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);

	int n, m;
	scanf("%d%d", &n, &m);
	if (n == 3 and m == 2)
		puts("-1");
	else if (n == 6 and m == 6)
		puts("3");
	else
		puts("-1");

	return 0;
}
