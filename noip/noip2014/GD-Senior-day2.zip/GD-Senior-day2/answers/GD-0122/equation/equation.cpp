#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cmath>
#include<cstring>

using namespace std;
typedef long long ll;

int mo=10000;

struct bignum{
	int a[10011];
	int len;
};

char s[10011];
bignum ad[111],am[111];
int n,m,i,len,j,ta,tm,num,l;
int ans[1000011];
int da[111],mn[111];

bignum sum(bignum a,bignum b)
{
	bignum c;
	int i;
	memset(c.a,0,sizeof(c.a));
	c.len=0;
	if(a.len>b.len)c.len=a.len;
	else c.len=b.len;
	for(i=1;i<=c.len;i++){
		c.a[i]+=a.a[i]+b.a[i];
		if(c.a[i]>=mo){
			c.a[i+1]+=c.a[i]/mo;
			c.a[i]%=mo;
		}
	}
	c.len++;
	if(c.a[c.len]==0)c.len--;
	return c;
}

bignum mul(bignum a,int x)
{
	ll gx;
	int i;
	bignum c;
	memset(c.a,0,sizeof(c.a));
	c.len=0;
	for(i=1;i<=a.len;i++){
		gx=c.a[i]+(ll)a.a[i]*x;
		c.a[i+1]+=gx/mo;
		c.a[i]=gx%mo;
	}
	c.len=a.len;
	c.len++;
	if(c.a[c.len]==0)c.len--;
	while(c.a[c.len]>=mo){
		c.a[c.len+1]+=c.a[c.len]/mo;
		c.a[c.len]%=mo;
		c.len++;
	}
	return c;
}

bignum gjmul(bignum a,bignum b)
{
	bignum c;
	int i,j,w;
	ll x;
	memset(c.a,0,sizeof(c.a));
	c.len=0;
	for(i=1;i<=a.len;i++)
		for(j=1;j<=b.len;j++){
			w=i+j-1;
			x=c.a[w]+a.a[i]*b.a[j];
			c.a[w+1]+=x/mo;
			c.a[w]=x%mo;
		}
	c.len=a.len+b.len-1;
	while(c.a[c.len]==0)c.len--;
	return c;
}

int compare(bignum a,bignum b)
{
	int i;
	if(a.len>b.len)return 1;
	else if(a.len<b.len)return 2;
	for(i=a.len;i>=1;i--){
		if(a.a[i]>b.a[i])return 1;
		else if(a.a[i]<b.a[i])return 2;
	}
	return 0;
}

bool check(int x)
{
	bignum ag,dw,ag2;
	int i,j;
	memset(ag.a,0,sizeof(ag.a));
	memset(ag2.a,0,sizeof(ag2.a));
	memset(dw.a,0,sizeof(dw.a));
	dw.len=1;
	dw.a[1]=1;
	ag.len=0;
	ag2.len=0;
	for(i=1;i<=ta;i++){		
		for(j=1;j<=da[i]-da[i-1];j++)dw=mul(dw,x);
		ag=sum(ag,gjmul(dw,ad[i]));
	}
	memset(dw.a,0,sizeof(dw.a));
	dw.len=1;
	dw.a[1]=1;
	for(i=1;i<=tm;i++){
		for(j=1;j<=mn[i]-mn[i-1];j++)dw=mul(dw,x);
		ag2=sum(ag2,gjmul(dw,am[i]));
		if(compare(ag,ag2)==2)return false;
	}
	if(compare(ag,ag2)==0)return true;
}

int main()
{
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(i=0;i<=n;i++){
		scanf("%s",&s);
		len=strlen(s);
		if(s[0]=='-'){
			l=1;
			tm++;
			mn[tm]=i;
			am[tm].len=1;
			for(j=len-1;j>=1;j--){
				if(l==10000){
					l=1;
					am[tm].len++;
				}
				am[tm].a[am[tm].len]+=l*(s[j]-48);
				l*=10;
			}
		}
		else{
			ta++;
			da[ta]=i;
			ad[ta].len=1;
			l=1;
			for(j=len-1;j>=0;j--){
				if(l==10000){
					l=1;
					ad[ta].len++;
				}
				ad[ta].a[ad[ta].len]+=l*(s[j]-48);
				l*=10;
			}
		}
	}
	if(ta==0||tm==0)printf("0\n");
	else{
		for(i=1;i<=m;i++){
			if(check(i)){
				num++;
				ans[num]=i;
			}
		}
		printf("%d\n",num);
		for(i=1;i<=num;i++)printf("%d\n",ans[i]);
	}
}
