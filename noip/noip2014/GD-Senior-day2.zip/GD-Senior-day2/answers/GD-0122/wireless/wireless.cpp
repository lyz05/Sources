#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cmath>
#include<cstring>

using namespace std;
typedef long long ll;

int xzq,ple,mx;
int f[131][131],pre[131][131];
int i,j,n,d,x,z,q,lx,rx,ly,ry,k;

int main()
{
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	scanf("%d",&d);
	scanf("%d",&n);
	memset(f,0,sizeof(f));
	memset(pre,0,sizeof(pre));
	for(i=1;i<=n;i++){
		scanf("%d%d%d",&x,&z,&q);
		f[x][z]+=q;
	}
	for(i=0;i<=128;i++){
		pre[i][0]=f[i][0];
		for(j=1;j<=128;j++)pre[i][j]=pre[i][j-1]+f[i][j];
	}
	xzq=0;
	ple=0;
	for(i=0;i<=128;i++){
		for(j=0;j<=128;j++){
			mx=0;
			lx=max(0,i-d);
			rx=min(i+d,128);
			ly=max(0,j-d);
			ry=min(j+d,128);
			for(k=lx;k<=rx;k++){
				if(ly==0)mx+=pre[k][ry];
				else mx+=pre[k][ry]-pre[k][ly-1];
			}
			if(mx>xzq){
				xzq=mx;
				ple=1;
			}
			else if(mx==xzq)ple++;
		}
	}
	printf("%d %d\n",ple,xzq);
}
