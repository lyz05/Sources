#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cmath>
#include<cstring>

using namespace std;

int g[10111],next[200011],y[200011],d[10011];
int que[2000011];
int mo=2000011;
bool p[10111],pa[10111],pr[10111];
int n,m,s,t,i,j,tt,k;
struct data{
	int x,z;
}edge[200111];

void star(int i,int j)
{
	tt++;
	next[tt]=g[i];
	g[i]=tt;
	y[tt]=j;
}

void Bfs()
{
	int l,r,x,j,k;
	memset(p,false,sizeof(p));
	memset(pr,false,sizeof(pr));
	l=r=1;
	que[l]=t;
	p[t]=true;
	pr[t]=true;
	while(l<=r){
		x=que[l];
		j=g[x];
		while(j!=0){
			k=y[j];
			if(p[k]==false){
				r++;
				que[r]=k;
				p[k]=true;
				pr[k]|=pr[x];
			}
			j=next[j];
		}
		l++;
	}
}

void Spfa()
{
	int sl,sr,l,r,x,j,k;
	l=r=1;
	sl=sr=1;
	que[1]=s;
	memset(d,127,sizeof(d));
	d[s]=0;
	memset(p,true,sizeof(p));
	p[s]=false;
	while(sl<=sr){
		x=que[l];
		j=g[x];
		while(j!=0){
			k=y[j];
			if(pa[k]==true&&d[x]+1<d[k]){
				d[k]=d[x]+1;
				if(p[k]==true){
					r++;
					if(r>=mo)r=0;
					sr++;
					que[r]=k;
					p[k]=false;
				}
			}
			j=next[j];
		}
		l++;
		if(l>=mo)l=0;
		sl++;
		p[x]=true;
	}
}

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(i=1;i<=m;i++)scanf("%d%d",&edge[i].x,&edge[i].z);
	scanf("%d%d",&s,&t);
	tt=0;
	for(i=1;i<=m;i++)star(edge[i].z,edge[i].x);
	Bfs();
	memset(g,0,sizeof(g));
	tt=0;
	for(i=1;i<=m;i++)star(edge[i].x,edge[i].z);
	for(i=1;i<=n;i++){
		pa[i]=true;
		j=g[i];
		while(j!=0){
			k=y[j];
			pa[i]&=pr[k];
			j=next[j];
		}
	}
	Spfa();
	if(d[t]>200000000)d[t]=-1;
	printf("%d\n",d[t]);
}

