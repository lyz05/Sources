#include<cstdio>
#include<cstdlib>
#define MAXN 1001
#define MAXM 20001
using namespace std;

int n,m,val[MAXM],p[MAXM],sum,father[MAXM],fp[MAXM];
int dout[MAXN],s,t;
int dist[MAXN];
bool  mark[MAXN];

void init()
{
    scanf("%d%d",&n,&m);
    for (int i=1;i<=n;i++)  {
      p[i]=0;
      fp[i]=0;
      dout[i]=0;
    }
    int a,b,d=0;
    sum=n;
    for (int i=1;i<=m;i++)  {
	  scanf("%d%d",&a,&b);
	  if (a==b)  {d++;continue;}
	  sum++;
	  val[sum]=b;
	  p[sum]=p[a];
	  p[a]=sum;
	  
	  father[sum]=a;
	  fp[sum]=fp[b];
	  fp[b]=sum;
	  
	  dout[a]++; 
	}
	scanf("%d%d",&s,&t);
	for (int i=1;i<=n;i++)
	  mark[i]=false;
	return;
}

void check(int x)
{
    bool sign[MAXN];
    for (int i=1;i<=n;i++)
      sign[i]=0;
    x=p[x];
	while (x!=0)  {
	  if (sign[val[x]])  dout[x]--;//p[x]=p[p[x]];}
	  else sign[val[x]]=1;
	  x=p[x];
	}
	return;
}

void find_unvailable()
{
    for (int i=1;i<=n;i++)
	  check(i);
/*	for (int i=1;i<=n;i++)
	  printf("%d ",dout[i]);
	printf("\n");*/
	int que[MAXN],f,r;
	f=0; r=0;
	for (int i=1;i<=n;i++)  
	  if (i!=t && dout[i]==0)  {
	     r++;
	     que[r]=i;
	     mark[i]=true;
	  }
/*	for (int i=1;i<=n;i++)
	   if (mark[i])  printf("%d ",i);*/
	while (f<r)  {
	  f++;
	  int i;
	  i=fp[que[f]];
	  while (i!=0)  {
	    dout[father[i]]--;
	    if (dout[father[i]==0] || dout[que[f]]==0)  {
		   r++;
		   que[r]=father[i];
		   mark[father[i]]=true;
		} 
	    i=fp[i];
	  }
	}
/*	for (int i=1;i<=n;i++)
	   if (mark[i])  printf("%d ",i);*/
}
void minidist()
{
    int que[MAXN],f,r;
    for (int i=1;i<=n;i++)
      dist[i]=-1;
   f=0; r=1;
	que[r]=s;
	while (f<r)  {
	   int j,now;
	   f++;
	   now=que[f];
	   j=p[now];
	   while (j!=0)  {
	     if (!mark[val[j]] && (dist[now]+1<dist[val[j]] || dist[val[j]]==-1))  {
		    if (dist[val[j]]==-1)  {
			   r++;
			   que[r]=val[j];
			}
	        dist[val[j]]=dist[now]+1;
		 }
		 j=p[j];
	   }
    }   
    return;
}
int main()
{
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    init();
    find_unvailable();
    minidist();
	printf("%d",-1);
    return 0;
}
