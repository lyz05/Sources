#include<cstdio>
#include<cstdlib>
using namespace std;

int main()
{
   freopen("equation.in","r",stdin);
   freopen("equation.out","w",stdout);
   int g[100],n,m,s[100],ans=0;
   scanf("%d%d",&n,&m);
   int j=1;
   for (int i=0;i<=n;i++)
     scanf("%d",&g[i]);
   for (int i=0;i<=n;i++)
     s[i]=0;
   for (int i=1;i<=m;i++)  {
     int sum;
     sum=g[0]+i*g[1];
     j=1;
     for (int k=2;k<=n;k++)  {
	   j=j*i;
	   sum +=g[k]*j;
	 }
	 if (sum==0)  {ans++;s[i]=1;}
   }
   printf("%d\n",ans)
   for (int i=1;i<=n;i++)
     if (s[i]==1)  printf("%d\n",i);
   return 0;
}
