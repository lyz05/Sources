#include<cstdio>
#include<cstdlib>
#define MAXX 130
using namespace std;

int d,n,g[MAXX][MAXX];
long long s[MAXX][MAXX];
void init()
{
    int aa,bb;
	scanf("%d%d",&d,&n);
	d=d*2+1;
	for (int i=0;i<=128;i++)
	  for (int j=0;j<=128;j++)
	    s[i][j]=0;
    for (int i=1;i<=n;i++)  {
	  scanf("%d%d",&aa,&bb);
	  scanf("%d",&g[aa][bb]);
	}
	for (int i=0;i<=128;i++)  {
	  s[0][i]=g[0][i];
	  s[i][0]=g[i][0];
    }
    for (int i=1;i<=128;i++)
      for (int j=1;j<=128;j++)
        s[i][j]=s[i-1][j]+s[i][j-1]-s[i-1][j-1]+g[i][j];
    long long maxsum=0;
    int count=0;
    long long a,b,c;
	for (int i=0;i<=128;i++)
      for (int j=0;j<=128;j++)  {
        if (j-d>=0)  a=s[i][j-d];  else a=0;
        if (i-d>=0)  b=s[i-d][j];  else b=0;
        if (j-d>=0 && i-d>=0)  c=s[i-d][j-d];  else c=0;
        a=s[i][j]-a-b+c;
		if (a>maxsum) {maxsum=a; count=1;}
		else if (a==maxsum)  count++;
      }
    printf("%d %d",count,maxsum);
    return;
}
int main()
{
    freopen("wireless.in","r",stdin);
    freopen("wireless.out","w",stdout);
    init();
    return 0;
}
