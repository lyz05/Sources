#include<iostream>
#include<fstream>
#include<string.h>
using namespace std;
int a[110],ans=0,n,m;
int fun(int x)
{
	int i,q=1,sum=0;
	for(i=0;i<=n;i++)
	{
		sum=sum+a[i]*q;
		q=q*x;
	}
	return sum;
}
int main()
{
    int n,m,i,k[110];
	ifstream fin("equation.in");
	fin>>n>>m;
	for(i=0;i<=n;i++)fin>>a[i];
	fin.close();
	for(i=1;i<=m;i++)if(fun(i)==0){ans++;k[ans]=i;}
	ofstream fout("equation.out");
	fout<<ans<<endl;
	fout.close();
	return 0;
}
