#include<iostream>
#include<fstream>
#include<queue>
#include<string.h>
#define MAXN 10000+10
#define MAXM 200000+10
#define MAXINT 300000
using namespace std;

struct edge
{
	int v;
	int next;
};
edge w[MAXM],wf[MAXM];
int p[MAXN],n,m,s,r,pf[MAXN];
bool can_visit[MAXN],visit[MAXN],can_link[MAXN];

void input()
{
	int i,j,k=1,kf=1,from,to,flag=0;
	ifstream fin("road.in");
	fin>>n>>m;
	for(i=1;i<=n;i++)
	{
		p[i]=-1;
		pf[i]=-1;
	}
	for(i=1;i<=m;i++)
	{
		flag=0;
		fin>>from>>to;
		//���ر�
		for(j=p[from];j!=-1;j=w[j].next)
		{
			if(w[j].v==to)
			{
				flag=1;
				break;
			}
		}
		if(flag==1)continue;
		w[k].next=p[from];
		w[k].v=to;
		p[from]=k++;
		//���� 
		wf[kf].next=pf[to];
		wf[kf].v=from;
		pf[to]=kf++;
	}
	fin>>s>>r;
	fin.close();
	memset(can_visit,0,sizeof(can_visit));
	memset(can_link,1,sizeof(can_link));
	return;
}

void check_visit(int x)
{
	visit[x]=1;
	int i,t;
	for(i=pf[x];i!=-1;i=wf[i].next)
	{
		t=wf[i].v;
		if(visit[t]==1)break;
		can_visit[t]=1;
		check_visit(t);
	}
	return;
}

int in_queue[MAXN],d[MAXN];

void SPFA(int s)
{
	can_visit[r]=1;
	int i,t,u;
	for(i=1;i<=n;i++)
	{
		in_queue[i]=0;
		d[i]=MAXINT;
	}
	queue<int>q;
	while(!q.empty())q.pop();
	q.push(s);
	d[s]=0;
	in_queue[s]=1;
	while(!q.empty())
	{
		u=q.front(); 
		q.pop();
		in_queue[u]=0;
		for(i=p[u];i!=-1;i=w[i].next)
		{
			t=w[i].v;
			if(can_link[t]==0)continue;
			if(d[u]<MAXINT&&d[t]>d[u]+1)
			{
				d[t]=d[u]+1;
				if(in_queue[t]==0)
				{
					in_queue[t]=1;
					q.push(t);
				}
			}
		}
	}
}
void output(int x)
{
	ofstream fout("road.out");
    if(d[x]==MAXINT)fout<<"-1";
    else fout<<d[x];
	fout.close();
}
int main()
{
	int i,j;
	input();
	memset(visit,0,sizeof(visit));
	check_visit(r);
	can_visit[r]=1;
	for(i=1;i<=n;i++)
	{
		if(can_visit[i]==0)
		{
			for(j=pf[i];j!=-1;j=wf[j].next)can_link[wf[j].v]=0;;
		}
	}
	SPFA(s);
	output(r);
	return 0;
}
