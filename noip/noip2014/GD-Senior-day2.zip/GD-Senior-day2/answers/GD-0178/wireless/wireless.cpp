#include<iostream>
#include<fstream>
#include<string.h>
using namespace std;
int MIN(int x,int y)
{
	if(x<y)return x;
	else return y;
}
int MAX(int x,int y)
{
	if(x>y)return x;
	else return y;
}
int main()
{
	int d,n,x,y,k[130][130];
	memset(k,0,sizeof(k));
	ifstream fin("wireless.in");
	int i,j,minx=129,maxx=0,miny=129,maxy=0;
	fin>>d>>n;
	for(i=1;i<=n;i++)
	{
		fin>>x>>y;
		if(x>maxx)maxx=x;
		if(x<minx)minx=x;
		if(y>maxy)maxy=y;
		if(y<miny)miny=y;
		fin>>k[x][y];
	}
	fin.close();
	int line[130][130];
	memset(line,0,sizeof(line));
	for(i=minx;i<=maxx;i++)
	  for(j=miny;j<=maxy;j++)line[j][i]=line[j][i-1]+k[i][j];
	int max=0,ans=0,q,sum=0;
	int upx,upy,lowx,lowy;
	for(i=minx;i<=maxx;i++)
	  for(j=miny;j<=maxy;j++)
	  {
	  	  sum=0;
	  	  upx=MIN(i+d,maxx);
	  	  lowx=MAX(i-d,minx);
	  	  upy=MIN(j+d,maxy);
	  	  lowy=MAX(j-d,miny);
	  	  for(q=lowy;q<=upy;q++)sum+=line[q][upx]-line[q][lowx-1];
	  	  if(sum>max)
	  	  {
	  	      max=sum;
	  	      ans=1;
	  	  }
	  	  else if(sum==max)ans++;
	  }
	ofstream fout("wireless.out");
	fout<<ans<<" "<<max;
	fout.close();
	return 0;
}
