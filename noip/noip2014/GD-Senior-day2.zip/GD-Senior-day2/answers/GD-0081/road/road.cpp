#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <map>
using namespace std;

const int maxN = 10005, maxM = 200005;
const int oo = 10000000;
struct Tedge{int v, next;}Fedge[maxM], Bedge[maxM];
int Fdad[maxN], Bdad[maxN], Fedges, Bedges;
int s, t, n, m, open[maxN], dis[maxN];
bool vis[maxN], sav[maxN], flag[maxN];

void insertFedge(int u, int v){
	Fedges++;
	Fedge[Fedges].v=v;
	Fedge[Fedges].next = Fdad[u];
	Fdad[u] = Fedges;
}

void insertBedge(int u, int v){
	Bedges++;
	Bedge[Bedges].v=v;
	Bedge[Bedges].next = Bdad[u];
	Bdad[u] = Bedges;
}

void Readln(){
	scanf( "%d%d", &n, &m );
	for (int i=1; i<=m; i++){
		int u, v;
		scanf( "%d%d", &u, &v );
		insertFedge(u, v);
		insertBedge(v, u);
	}
	scanf( "%d%d", &s, &t );
}

void Bbfs(){
	int head = 1, tail = 1;
	for (int i=1; i<=n; i++) {
		vis[i] = false;
		flag[i] = false;
	}
	open[1] = t; vis[t] = true; flag[t] = true;
	while (head <= tail){
		int now = open[head];
		head++;
		for (int i=Bdad[now]; i!=0; i=Bedge[i].next){
			int v = Bedge[i].v;
			if (!vis[v]){
				vis[v] = true;
				flag[v] = true;
				tail++;
				open[tail] = v;
			}
		}
	}
}

void Fbfs(){
	if (!sav[s]) {printf( "-1\n" );return;}
	if (s == t) {printf( "0\n" ); return;}
	for (int i=1; i<=n; i++) vis[i] = false;
	for (int i=1; i<=n; i++) dis[i] = oo;
	int head = 1, tail = 1;
	open[1] = s; vis[s] = true; dis[s] = 0;
	while (head <= tail){
		int now = open[head];
		head++;
		for (int i=Fdad[now]; i!=0; i=Fedge[i].next){
			int v = Fedge[i].v;
			if (!vis[v] && sav[v]){
				vis[v] = true;
				dis[v] = dis[now]+1;
				if (v == t) {
					printf( "%d\n", dis[v] );
					return;
				}
				tail++;
				open[tail] = v;
			}
		}
	}
	printf( "-1\n" );
}

void Solve(){
	Bbfs();
	for (int i=1; i<=n; i++){
		sav[i] = true;
		for (int j=Fdad[i]; j!=0; j=Fedge[j].next)
		if (!flag[Fedge[j].v]){
			sav[i] = false;
			break;
		}
	}
	Fbfs();
}

int main(){
	freopen( "road.in", "r", stdin );
	freopen( "road.out", "w", stdout );
	Readln();
	Solve();
	return 0;
}
