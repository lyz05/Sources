#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <map>
using namespace std;

const int maxN = 105, L = 500, maxM = 1000005;
int n, m, s[maxN];
int anss, ans[maxM];
int num[maxN][L+10];
int tot[L+10];
char str[L+10];

void Solve1(){
	for (int i=0; i<=n; i++) scanf( "%d", &s[i] );
	for (int i=1; i<=m; i++){
		int tmp = 1, tot = 0;
		for (int j=0; j<=n; j++){
			tot += tmp*s[j];
			tmp *= i;
		}
		if (tot == 0){
			anss++;
			ans[anss] = i;
		}
	}
	printf( "%d\n", anss );
	for (int i=1; i<=anss; i++) printf( "%d\n", ans[i] );
}

void cheng(int *tot, int val){
	for (int i=1; i<=tot[0]; i++) tot[i] *= val;
	int len = tot[0] + 10;
	tot[0] = 0;
	for (int i=1; i<=len; i++){
		tot[i+1] += tot[i]/10;
		tot[i] %= 10;
		if (tot[i] != 0) tot[0] = i;
	}
}

void jia(int *tot, int *a){
	int len = max(tot[0], a[0]);
	for (int i=1; i<=len; i++) tot[i] += a[i];
	tot[0] = 0;
	for (int i=1; i<=len+1; i++){
		tot[i+1] += tot[i]/10;
		tot[i] %= 10;
		if (tot[i] != 0) tot[0] = i;
	} 
}

void Solve2(){
	for (int i=0; i<=n; i++){
		scanf( "%s", str );
		num[i][0] = strlen(str);
		int k = 1, tp = 0;
		if (str[0] == '-') {
			k = -1;
			tp = 1;
		}
		for (int j=num[i][0]-1; j>=tp; j--) num[i][num[i][0]-j] = (str[j]-48)*k;
		if (k==-1) num[i][0]--;
	}
	for (int i=1; i<=m; i++){
		for (int j=0; j<=L; j++) tot[j] = 0;
		for (int j=n; j>=0; j--){
			if (j < n) cheng(tot, i);
			jia(tot, num[j]);
		}
		if (tot[0] == 0){
			anss++;
			ans[anss] = i;
		}
	}
	printf( "%d\n", anss );
	for (int i=1; i<=anss; i++) printf( "%d\n", ans[i] );
}

int main(){
	freopen( "equation.in", "r", stdin );
	freopen( "equation.out", "w", stdout );
	scanf( "%d%d\n", &n, &m );
	if (n <= 2){
		Solve1();
	}else{
		if (m <= 100){
			Solve2();
		}else{printf( "0\n" );}
	}
	return 0;
}
