#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <map>
using namespace std;

const int L = 129;
int d, n, sum[L+10][L+10];

void Readln(){
	scanf( "%d", &d );
	scanf( "%d", &n );
	for (int i=1; i<=n; i++){
		int u, v, c;
		scanf( "%d%d%d", &u, &v, &c );
		u++; v++;
		sum[u][v] += c;
	}
}

int getarea(int a, int b, int c, int d){
	return sum[c][d]-sum[a-1][d]-sum[c][b-1]+sum[a-1][b-1];
}

void Solve(){
	for (int i=1; i<=L; i++)
		for (int j=1; j<=L; j++)
			sum[i][j] += sum[i-1][j]+sum[i][j-1]-sum[i-1][j-1];
	int ans = 0, cal = 0;
	for (int i=d+1; i+d<=L; i++)
		for (int j=d+1; j+d<=L; j++){
			int tmp = getarea(i-d, j-d, i+d, j+d);
			if (tmp == ans){
				cal++;
			}else{
				if (tmp > ans){
					ans = tmp;
					cal = 1;
				}
			}
		}
	printf( "%d %d\n", cal, ans );
}

int main(){
	freopen( "wireless.in", "r", stdin );
	freopen( "wireless.out", "w", stdout );
	Readln();
	Solve();
	return 0;
}
