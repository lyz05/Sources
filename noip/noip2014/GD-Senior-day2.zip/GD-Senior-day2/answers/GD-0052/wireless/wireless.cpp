#include<cstring>
#include<cstdio>
#include<cstdlib>
#include<fstream>
using namespace std;
ifstream cin("wireless.in");
ofstream cout("wireless.out");
int d,n,a[150][150];
int min(int x,int y) {if (x<y) return x;else return y;}
int max(int x ,int y) {if (x>y) return x;else return y;}
int main()
{
	int i,j,g,k,x,y;
	int ans1,ans2;
	cin>>d>>n;
	memset(a,0,sizeof(a));
	for (i=1;i<=n;i++) {
		cin>>x>>y>>k;
		a[x][y]+=k;
	}
	ans1=ans2=0;
	for (i=0;i<=128;i++)
		for (j=0;j<=128;j++) {
			x=0;
			for (g=max(i-d,0);g<=min(i+d,128);g++)
				for (k=max(j-d,0);k<=min(j+d,128);k++)
					x+=a[g][k];
			if (x>ans2) {
				ans2=x;ans1=1;
			}
			else if (x==ans2) ans1++;
		}
	cout<<ans1<<' '<<ans2;
	
	cin.close();
	cout.close();
	return 0;
}