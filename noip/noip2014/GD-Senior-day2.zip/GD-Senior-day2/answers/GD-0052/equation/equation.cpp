#include<cstring>
#include<cstdio>
#include<cstdlib>
#include<fstream>
using namespace std;
ifstream cin("equation.in");
ofstream cout("equation.out");
int n,m,a[110][10010],L[110];
int c[20010];
bool f[10010];
string w;
void init()
{
	int i,j,k,l;
	cin>>n>>m;
	memset(a,0,sizeof(a));
	for (i=0;i<=n;i++) {
		cin>>w;
		l=w.length();
		if (w[0]=='-') {a[i][0]=-1;k=1;} else {a[i][0]=1;k=0;}
		L[i]=l-k;
		for (j=k;j<l;j++)
			a[i][l-j]=w[j]-48;
	}
}
bool cmp(int x)
{
	int i,k;
	k=350;while (c[k]==0) k--;
	if (k>L[x]) return true;
		else if (k<L[x]) return false;
			else {
				for (i=k;i>0;i--)
					if (c[i]>a[x][i]) return true;
						else if (c[i]<a[x][i]) return false;
				return true;
			}
}
bool tr(int p)
{
	int i,j,y;
	for (i=0;i<=350;i++) c[i]=a[n][i];
	for (i=n-1;i>=0;i--) {
		y=0;
		for (j=1;j<=350;j++) {
			y=p*c[j]+y;
			c[j]=y%10;
			y=y/10;
		}
		if (c[0]==a[i][0]) {
			y=0;
			for (j=1;j<=110;j++) {
				y=c[j]+a[i][j]+y;
				c[j]=y%10;
				y=y/10;
			}
		}
		else {
			if (cmp(i)) {
				y=0;
				for (j=1;j<=350;j++) {
					y=c[j]-a[i][j]+y;
					if (y<0) {y+=10;c[j+1]--;}
					c[j]=y%10;
					y=y/10;
				}
			}
			else {
				y=0;
				for (j=1;j<=350;j++) {
					y=a[i][j]-c[j]+y;
					if (y<0) {y+=10;c[j+1]++;}
					c[j]=y%10;
					y=y/10;
				}
				c[0]=a[i][0];
			}
		}
	}
	y=350;while (c[y]==0) y--;
	if (y==0) return true; else return false;
}
void mainx()
{
	int i,ans=0;
	memset(f,false,sizeof(f));
	for (i=1;i<=m;i++) 
		if (tr(i)) {
			f[i]=true;
			ans++;
		}
	cout<<ans<<endl;
	for (i=1;i<=m;i++)
		if (f[i]) cout<<i<<endl;
}
int main()
{
	
	init();
	mainx();
	
	cin.close();
	cout.close();
	return 0;
}