#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<fstream>
using namespace std;
#define maxn 10010
#define maxm 200010
ifstream cin("road.in");
ofstream cout("road.out");
struct {
	int x,y,l;
} p1[maxm];
struct {
	int x,y,l;
} p2[maxm];
int n,m,S,T;
int sump1,sump2,b1[maxn],b2[maxn];
int q[maxn],d[maxn];
bool f[maxn],t[maxn],z[maxn];
void add1(int x,int y)
{
	sump1++;
	p1[sump1].x=x;
	p1[sump1].y=y;
	p1[sump1].l=b1[x];
	b1[x]=sump1;
}
void add2(int x,int y)
{
	sump2++;
	p2[sump2].x=x;
	p2[sump2].y=y;
	p2[sump2].l=b2[x];
	b2[x]=sump2;
}
void init()
{
	int i,j,x,y;
	int l,r;
	bool g;
	cin>>n>>m;
	memset(b1,0,sizeof(b1));
	memset(b2,0,sizeof(b2));
	sump1=sump2=0;
	for (i=1;i<=m;i++) {
		cin>>x>>y;
		add1(x,y);
		add2(y,x);
	}
	cin>>S>>T;
	
	memset(f,false,sizeof(f));
	l=0;r=1;q[1]=T;f[T]=true;
	while (l!=r) {
		l++;
		i=q[l];
		for (j=b2[i];j>0;j=p2[j].l)
			if (!f[p2[j].y]) {
				f[p2[j].y]=true;
				r++;q[r]=p2[j].y;
			}
	}
	for (i=1;i<=n;i++) {
		g=true;
		for (j=b1[i];j>0;j=p1[j].l)
			if (!f[p1[j].y]) {
				g=false;
				break;
			}
		t[i]=g;
	}
}
void mainx()
{
	int i,j,l,r;
	bool x;
	memset(z,false,sizeof(z));
	memset(d,-1,sizeof(d));
	l=0;r=1;q[r]=S;d[r]=0;z[S]=true;
	x=false;
	while (l!=r) {
		l++;
		i=q[l];
		for (j=b1[i];j>0;j=p1[j].l)
			if (t[p1[j].y] && !z[p1[j].y]) {
				z[p1[j].y]=true;
				r++;q[r]=p1[j].y;d[r]=d[l]+1;
				if (p1[j].y==T) {
					x=true;
					cout<<d[r];
					break;
				}
			}
		if (x) break;
	}
	if (!x) cout<<-1;
}
int main()
{
	
	init();
	if (!f[S] || !t[S]) cout<<-1;
		else mainx();
	
	cin.close();
	cout.close();
	return 0;
}