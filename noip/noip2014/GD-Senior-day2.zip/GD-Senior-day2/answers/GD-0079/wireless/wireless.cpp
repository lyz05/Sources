#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cmath>
#include <bitset>
#include <ctime>
#include <map>
#include <queue>
#include <set>
using namespace std;

const int maxn=128;
int d,n,a[maxn+15][maxn+15],x,y,k;
int ans1,ans2;
int main()
{
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	scanf("%d",&d);
	scanf("%d",&n);
	for (int i=1;i<=n;i++)
	{
		scanf("%d%d%d",&x,&y,&k);
		a[x][y]=k;
	}
	for (int i=0;i<=maxn;i++)
	 for (int j=0;j<=maxn;j++)
	 {
	 	int sum=0;
	 	for (int x=max(0,i-d),sx=min(maxn,i+d);x<=sx;x++)
	 	 for (int y=max(0,j-d),sy=min(maxn,j+d);y<=sy;y++)
	 	  sum+=a[x][y];
	 	if (sum>ans2)
	 	{
	 		ans2=sum;
	 		ans1=1;
	 	}
	 	else
	 	if (sum==ans2) ans1++;
	 }
	printf("%d %d\n",ans1,ans2);
	return 0;
}

