#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cmath>
#include <bitset>
#include <ctime>
#include <map>
#include <queue>
#include <set>
using namespace std;

const int maxn=10000+15;
const int maxm=200000+15;
int n,m,x,y,S,T;
int fr1,nod1[maxm],nex1[maxm],hea1[maxn];
int fr2,nod2[maxm],nex2[maxm],hea2[maxn];
bool boo[maxn],bog[maxn];
int h,t,line[maxn];
int f[maxn];
int ins1(int x,int y)
{
	nod1[++fr1]=y;
	nex1[fr1]=hea1[x];
	hea1[x]=fr1;
	return 0;
}
int ins2(int x,int y)
{
	nod2[++fr2]=y;
	nex2[fr2]=hea2[x];
	hea2[x]=fr2;
	return 0;
}
int bfs2(int now)
{
	line[h=t=1]=now;
	bog[now]=true;
	for (;h<=t;h++)
	 for (int u=hea2[line[h]];u;u=nex2[u])
	  if (!bog[nod2[u]])
	  {
	  	bog[nod2[u]]=true;
	  	line[++t]=nod2[u];
	  }
	for (int i=1;i<=n;i++)
	{
		bool bo=true;
		for (int u=hea1[i];u;u=nex1[u])
		 if (!bog[nod1[u]])
		 {
		 	bo=false;
		 	break;
		 }
		boo[i]=bo;
	}
	return 0;
}
int bfs(int now)
{
	memset(f,-1,sizeof(f));
	if (!boo[now])
	{
		printf("-1\n");
		return 0;
	}
	line[h=t=1]=now;
	f[now]=0;
	for (;h<=t;h++)
	 for (int u=hea1[line[h]];u;u=nex1[u])
	  if (f[nod1[u]]==-1 && boo[nod1[u]])
	  {
	  	f[nod1[u]]=f[line[h]]+1;
	  	line[++t]=nod1[u];
	  }
	printf("%d\n",f[T]);
	return 0;
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=m;i++)
	{
		scanf("%d%d",&x,&y);
		ins1(x,y);
		ins2(y,x);
	}
	scanf("%d%d",&S,&T);
	bfs2(T);
	bfs(S);
	return 0;
}

