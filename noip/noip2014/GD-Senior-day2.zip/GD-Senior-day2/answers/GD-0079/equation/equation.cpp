#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cmath>
#include <bitset>
#include <ctime>
#include <map>
#include <queue>
#include <set>
using namespace std;

const long long modd=2373498371ll;
int n,m;
long long a[105];
int f[1000005],su;
char s[10015];
int len;
int main()
{
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=0;i<=n;i++)
	{
		scanf("%s",s);
		len=strlen(s);
		if (s[0]=='-')
		{
			for (int j=1;j<len;j++)
			{
				a[i]=a[i]*10+(s[j]-'0');
				a[i]%=modd;
			}
			a[i]=modd-a[i];
		}
		else
		{
			for (int j=0;j<len;j++)
			{
				a[i]=a[i]*10+(s[j]-'0');
				a[i]%=modd;
			}
		}
	}
    su=0;
    if (n*m<=100*450000)
    {
	  for (int i=1;i<=m;i++)
	  {
		long long ans=a[n];
		for (int j=n-1;j>=0;j--) ans=(ans*i+a[j])%modd;
		if (ans==0ll) f[++su]=i;
		if (su>=n) break;
	  }
	  printf("%d\n",su);
	  for (int i=1;i<=su;i++) printf("%d\n",f[i]);
    }
    else
    {
      int g=100*450000/n;
      for (int i=1,ii;i*2<=g;i++)
	  {
		long long ans=a[n];
		for (int j=n-1;j>=0;j--) ans=(ans*i+a[j])%modd;
		if (ans==0ll) f[++su]=i;
		if (su>=n) break;
		ii=m-i;
		ans=a[n];
		for (int j=n-1;j>=0;j--) ans=(ans*ii+a[j])%modd;
		if (ans==0ll) f[++su]=ii;
		if (su>=n) break;
	  }
	  printf("%d\n",su);
	  sort(f+1,f+su+1);
	  for (int i=1;i<=su;i++) printf("%d\n",f[i]);
    }
	return 0;
}

