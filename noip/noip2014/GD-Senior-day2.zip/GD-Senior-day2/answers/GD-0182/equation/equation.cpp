#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <cctype>
#include <vector>
#include <map>
#include <string>
#include <algorithm>
using namespace std;

typedef long long int LL;

void setIO(string s,string ot){
	freopen((s+".in").c_str(),"r",stdin);
	freopen((s+"."+ot).c_str(),"w",stdout);
}

const int maxN=105;

int N,M;

void readInput1(){
	static char sss[100];
	gets(sss);
	sscanf(sss,"%d%d",&N,&M);
}

namespace solve2{
	const int Mod1=1000000007,Mod2=1000000009;
	LL a1[maxN],a2[maxN];
	int Time;
	
	bool Check(LL x){
		LL v1=0,v2=0;
		for (int i=N; i!=-1; i--){
			v1=(v1*x+a1[i])%Mod1;
			v2=(v2*x+a2[i])%Mod2;
		}
		Time+=N;
		return (v1==0LL && v2==0LL);
	}
	
	void Calc(){
		vector<int>ans;
		Time=0;
		int K=0;
		for (int i=1; i<=M; i++){
			if (Check(i)){
				ans.push_back(i);
				K++;
				if (K==N) break;
			}
			if (Time>=30000000) break;
		}
		cout<<K<<endl;
		for (int i=0; i!=K; i++) cout<<ans[i]<<endl;
	}
	
	void Work(){
		for (int i=0; i<=N; i++){
			bool mns=false;
			static char s[10010];
			gets(s);
			char *ed=s+strlen(s),*p=s;
			if (*p=='-'){
				mns=true;
				p++;
			}
			LL &v1=a1[i],&v2=a2[i];
			v1=v2=0;
			while (p!=ed){
				if (isdigit(*p)){
					v1=(v1*10+int(*p)-int('0'))%Mod1;
					v2=(v2*10+int(*p)-int('0'))%Mod2;
				}
				p++;
			}
			if (mns){
				v1=(Mod1-v1)%Mod1;
				v2=(Mod2-v2)%Mod2;
			}
		}
		Calc();
	}
}

int main(){
	setIO("equation","out");
	readInput1();
	solve2::Work();
	return 0;
}
