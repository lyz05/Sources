#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <cctype>
#include <vector>
#include <map>
#include <string>
#include <algorithm>
using namespace std;

typedef long long int LL;

void setIO(string s,string ot){
	freopen((s+".in").c_str(),"r",stdin);
	freopen((s+"."+ot).c_str(),"w",stdout);
}

const int L=129;

int s[L+10][L+10];
int N,D;

void readInput(){
	cin>>D>>N;
	for (int i=0; i!=N; i++){
		int x,y,v;
		cin>>x>>y>>v;
		x++,y++;
		s[x][y]+=v;
	}
}

void solve(){
	for (int i=1; i<=L; i++){
		for (int j=1; j<=L; j++){
			s[i][j]+=s[i-1][j]+s[i][j-1]-s[i-1][j-1];
		}
	}
	int ans=0,cnt=0;
	for (int i=1; i<=L; i++){
		for (int j=1; j<=L; j++){
			int X1=max(1,i-D)-1,Y1=max(1,j-D)-1,X2=min(L,i+D),Y2=min(L,j+D);
			int Sum=s[X2][Y2]-s[X2][Y1]-s[X1][Y2]+s[X1][Y1];
			if (Sum>ans){
				ans=Sum;
				cnt=1;
			}	else{
				if (ans==Sum) cnt++;
			}
		}
	}
	cout<<cnt<<' '<<ans<<endl;
}

int main(){
	setIO("wireless","out");
	readInput();
	solve();
	return 0;
}
