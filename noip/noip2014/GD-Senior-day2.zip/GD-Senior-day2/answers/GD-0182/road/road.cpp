#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <cctype>
#include <vector>
#include <map>
#include <string>
#include <algorithm>
using namespace std;

typedef long long int LL;

void setIO(string s,string ot){
	freopen((s+".in").c_str(),"r",stdin);
	freopen((s+"."+ot).c_str(),"w",stdout);
}

const int maxN=10010,maxM=200050;

struct pth{
	int nd;
	pth *nx;
}dat1[maxM],dat2[maxM];

int S,T,N,M;

bool Ban[maxN];

namespace Posi{
	pth *fir[maxN],*Pe;
	void add_edge(int x,int y){
		Pe->nd=y;
		Pe->nx=fir[x];
		fir[x]=Pe++;
	}
	
	int q[maxN];
	int flg[maxN];
	
	int Work(){
		if (Ban[S]) return -1;
		memset(flg,0,sizeof flg);
		flg[S]=1;
		q[0]=S;
		for (int head=0,tail=1; head!=tail; head++){
			int p=q[head];
			for (pth *u=fir[p]; u; u=u->nx){
				if (!flg[u->nd] && !Ban[u->nd]){
					if (u->nd==T) return flg[p];
					flg[u->nd]=flg[p]+1;
					q[tail++]=u->nd;
				}
			}
		}
		return -1;
	}
}

namespace Anti{
	pth *fir[maxN],*Pe;
	void add_edge(int x,int y){
		Pe->nd=y;
		Pe->nx=fir[x];
		fir[x]=Pe++;
	}
	
	int q[maxN];
	bool flg[maxN];
	
	void Work(){
		memset(flg,0,sizeof flg);
		flg[T]=true;
		q[0]=T;
		for (int head=0,tail=1; head!=tail; head++){
			int p=q[head];
			for (pth *u=fir[p]; u; u=u->nx){
				if (!flg[u->nd]){
					flg[u->nd]=true;
					q[tail++]=u->nd;
				}
			}
		}
		for (int i=0; i!=N; i++){
			if (!flg[i]){
				Ban[i]=true;
				for (pth *u=fir[i]; u; u=u->nx){
					Ban[u->nd]=true;
				}
			}
		}
	}
}

void solve(){
	Anti::Work();
	cout<<Posi::Work()<<endl;
}

void readInput(){
	scanf("%d%d",&N,&M);
	for (int i=0; i!=M; i++){
		int x,y;
		scanf("%d%d",&x,&y);
		x--,y--;
		if (x!=y){
			Posi::add_edge(x,y);
			Anti::add_edge(y,x);
		}
	}
	scanf("%d%d",&S,&T);
	S--,T--;
}

int main(){
	setIO("road","out");
	Posi::Pe=dat1;
	Anti::Pe=dat2;
	readInput();
	solve();
	return 0;
}
