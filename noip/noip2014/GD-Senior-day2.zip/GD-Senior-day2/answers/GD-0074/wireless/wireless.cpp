#include<fstream>
#include<iomanip>
using namespace std;
ifstream cin("wireless.in");
ofstream cout("wireless.out");
long map[130][130]={0},d,line[130]={0};
int main()
{
	long n,sa,s,sb,mmax=0,sum=0,i,temp;
	cin>>d>>n;
	d=2*d;
	for(s=1;s<=n;s++){
		cin>>sa>>sb>>map[sa+1][sb+1];
	}
	for(sa=1;sa<=129-d;sa++){
		memset(line,0,sizeof(line));
		for(sb=1;sb<=129;sb++){
			for(s=0;s<=d;s++){
				line[sb]+=map[sa+s][sb];
			}
		}
		for(s=1;s<=129-d;s++){
				temp=0;
				for(i=s;i<=s+d;i++){
					temp+=line[i];
				}
				if(temp>mmax){
					mmax=temp;
					sum=1;
				}
				else if(temp==mmax){
					sum++;
				}
			}
	}
	cout<<sum<<' '<<mmax;
	cin.close();
	cout.close();
}