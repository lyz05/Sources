#include<cstdio>
using namespace std;
bool map[10000][10000]={0},p[10000]={0},y[10000];
long n,m,start,goal;
bool yn(long x)
{
	if(y[x]){return false;}
	else{
		long s;
		for(s=0;s<n;s++){
			if(map[x][s]){
				if(!p[s]){y[x]=true;break;}
			}
		}
		return y[x];
	}
}
void pd(long x)
{
	struct{
		long last,now;
	}line[10001]={0};
	long rear=0,front=0,s;
	bool bo[10001]={0};
	line[rear].now=x;
	rear++;
	while(front!=rear)
	{
			for(s=0;s<n;s++){
				if(map[line[front].now][s]&&line[front].now!=s){
					if(p[s]){
						p[x]=true;
						break;
					}
					else if(!bo[s]){
						bo[s]=true;
						line[rear].now=s;
						line[rear].last=front;
						rear++;
					}
				}
			}
		front++;
	}
	if(p[x]){
		while(front>0){
			p[line[front].now]=true;
			front=line[front].last;
		}
	}
	else{
		for(s=0;s<n;s++){
			if(map[s][x]){
				y[s]=true;
			}
		}
	}
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	long s,sa,sb;
	scanf("%ld%ld",&n,&m);
	for(s=1;s<=m;s++){
		scanf("%ld%ld",&sa,&sb);
		map[sa-1][sb-1]=true;
	}
	scanf("%ld%ld",&start,&goal);
	start--;
	goal--;
	p[goal]=true;
	for(s=0;s<n;s++){pd(s);}
	long line[10001]={0},dis[10001]={0},front=0,rear=0;
	bool bo[10001]={0};
	line[rear]=start;
	bo[line[rear]]=true;
	rear++;
	while(front!=rear){
		for(s=0;s<n;s++){
			if(map[line[front]][s]&&!y[s]){
				if(dis[s]==0){
					dis[s]=dis[line[front]]+1;
					if(!bo[s]){
						bo[s]=true;
						line[rear]=s;
						rear++;
					}
				}
				else if(dis[s]>dis[line[front]]+1&&dis[s]>0){
					dis[s]=dis[line[front]]+1;
					if(!bo[s]){
						bo[s]=true;
						line[rear]=s;
						rear++;
					}
				}
			}
		}
		front++;
	}
	if(dis[goal]==0){printf("-1");}
	else {
		printf("%ld",dis[goal]);
	}
	return 0;
}