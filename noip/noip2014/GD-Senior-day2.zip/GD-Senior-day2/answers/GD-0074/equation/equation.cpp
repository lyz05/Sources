#include<fstream>
#include<cmath>
using namespace std;
ifstream cin("equation.in");
ofstream cout("equation.out");
int main()
{
	long n,m,a[10],s,x;
	cin>>n>>m;
	if(n==1){
		cin>>a[0]>>a[1];
		if(-a[0]%a[1]==0){
			if(-a[0]/a[1]>=1&&(-a[0]/a[1]<=m)){
				cout<<1<<endl<<-a[0]/a[1];
			}
			else cout<<0;
		}
		else {
			cout<<0;
		}
	}
	else if(n==2){
		cin>>a[0]>>a[1]>>a[2];
		long x1=-1,x2=-1,ans=2;
		if(sqrt(a[1]*a[1]-4*a[0]*a[2])*sqrt(a[1]*a[1]-4*a[0]*a[2])==(a[1]*a[1]-4*a[0]*a[2])){
			long temp;
			temp=sqrt(a[1]*a[1]-4*a[0]*a[2]);
			if((temp-a[1])%(2*a[2])==0){
				x1=(temp-a[1])/(2*a[2]);
				if(x1<1||x1>m){
					x1=-1;
					ans--;
				}
			}
			else {x1=-1;ans--;}
			if((-temp-a[1])%(2*a[2])==0){
				x2=(-temp-a[1])/(2*a[2]);
				if(x2<1||x2>m){
					x2=-1;
					ans--;
				}
			}
			else {x2=-1;ans--;}
			if(x1==x2&&x1!=-1&&x2!=-1){
				cout<<1<<endl<<x1;
			}
			else {
				cout<<ans<<endl;
				if(x1>x2){
					temp=x1;
					x1=x2;
					x2=temp;
				}
				if(x1>=1)cout<<x1<<endl;
				if(x2>=1)cout<<x2;
			}
		}
		else {cout<<0;}
	}
	else {
		cout<<0;
	}
	cin.close();
	cout.close();
}