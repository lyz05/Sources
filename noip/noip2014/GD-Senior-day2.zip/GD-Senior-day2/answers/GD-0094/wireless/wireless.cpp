#include <fstream>
using namespace std;
ifstream fin("wireless.in");
ofstream fout("wireless.out");

void init();
void work();

int a[200][200],d,n,maxx,ans;

int main()
{
   init();
   work();
   fout<<ans<<" "<<maxx<<endl;   	
   return 0;	
}

void init()
{
   fin>>d>>n;
   for (int i=1;i<=n;i++)
   {
   	  int x,y,k;
   	  fin>>x>>y>>k;
   	  a[x][y]=k;
   }
}

void work()
{
   for (int x=0;x<=128;x++)
    for (int y=0;y<=128;y++)
	{
		int tot=0;	
		for (int x1=x-d;x1<=x+d;x1++)
		 for (int y1=y-d;y1<=y+d;y1++)
		  if (x1>=0 && y1>=0) tot+=a[x1][y1];
		if (tot==maxx) ans++; 
		if (tot>maxx) {maxx=tot;ans=1;}
	}	   	
}
