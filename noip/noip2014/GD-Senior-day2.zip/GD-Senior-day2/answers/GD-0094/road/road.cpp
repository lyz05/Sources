#include <queue>
#include <fstream>
using namespace std;
ifstream fin("road.in");
ofstream fout("road.out");

bool pd(int x);
void init();
void work();

bool f[107][107];
int a[107][107];
int dis[107];
int pdd[107];
int n,m,start,en;
queue <int> q;

int main()
{
	init();
	if (n>100) {fout<<-1<<endl;return 0;}
	work();	
	if (dis[en]==10007) fout<<-1<<endl;
              else fout<<dis[en]<<endl;
              
	return 0;
}

void init()
{
	fin>>n>>m;
	if (n>100) return;
	for (int i=1;i<=m;i++)
	{
	    int x,y;
	    fin>>x>>y;
	    if (f[x][y]==1) continue;
	    f[x][y]=1;
	    a[x][0]++;
	    a[x][a[x][0]]=y;
	}	
	fin>>start>>en;
}

void work()
{
	q.push(start);
	for (int i=1;i<=n;i++) dis[i]=10007;
	dis[start]=0;
	
	while (!q.empty())
	{
		int now=q.front();
		q.pop();
		
		for (int i=1;i<=a[now][0];i++)
		{
			bool flag=1;
			int next=a[now][i];
			for (int j=1;j<=a[next][0];j++) 
			 if (pd(a[next][j])==false) {
			 	 flag=0;
			 	 break;
			 } 
			 
			if (flag && dis[next]>dis[now]+1){
				dis[next]=dis[now]+1;
				q.push(next);
			}  
 		}
	}
}


bool pd(int x)
{
	if (x==en) return 1;
	if (pdd[x]==1) return 1;
	if (pdd[x]==2) return 0;
		queue <int> q;
		while (!q.empty()) q.pop();
		bool vis[107];
		for (int i=1;i<=n;i++)vis[i]=0;
		q.push(x);
		while (!q.empty())
	{
		   int now=q.front();
		   vis[now]=1;
		   q.pop();
		   
		   for (int i=1;i<=a[now][0];i++)
		    if (vis[a[now][i]]!=1)
		    {
		       if (a[now][i]==en) {
		         pdd[x]=1;
		         return true;
			   }
		       q.push(a[now][i]);	
		    }
	}	
	pdd[x]=2;
	return false;
}


