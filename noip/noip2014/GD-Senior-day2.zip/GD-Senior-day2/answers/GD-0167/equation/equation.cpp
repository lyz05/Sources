#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <cstring>

using namespace std;

void open()
{
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
}

void close(){fclose(stdin);fclose(stdout);}

int n,m;
int cnt=0,ans[105];
long long a[105];

void init()
{
	scanf("%d%d",&n,&m);
	for(int i=0;i<=n;i++) cin>>a[i];
}

void work()
{
	if(n<=10)
	{
		int tmp=0;
		for(int i=1;i<=m;i++)
		{
			for(int j=0;j<=n;j++)
				tmp+=(a[j] * pow(i,j));
			if(!tmp) ans[++cnt]=i;
		}
	}
	else
	{
		cnt=0;
		return;
	}
}

int main()
{
	open();
	init();
	work();
	printf("%d\n",cnt);
	for(int i=1;i<=cnt;i++) printf("%d\n",ans[i]);
	close();
}
