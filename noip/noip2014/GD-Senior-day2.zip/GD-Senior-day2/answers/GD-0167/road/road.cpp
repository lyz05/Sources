#include <cstdio>
#include <cmath>
#include <algorithm>
#include <iostream>
#include <cstring>
#include <queue>
const int inf=0xfffffff;

using namespace std;

int e=0,ot[200005],ne[200005],g[10005];
int u=0,to[200005],next[200005],head[10005];
int dis[10005],cnt[10005];
bool vis[10005],ok[10005];
int n,m,s,t;

void open()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
}

void close(){fclose(stdin);fclose(stdout);}

void addedge(int x,int y)
{
	ot[++e]=y;ne[e]=g[x];g[x]=e;
	to[++u]=x;next[u]=head[y];head[y]=u;
}

void init()
{
	memset(g,255,sizeof g);
	memset(head,255,sizeof head);
	memset(ok,256,sizeof ok);
	memset(cnt,256,sizeof cnt);
 	int x,y;
	scanf("%d%d",&n,&m);
 	for(int i=1;i<=m;i++)
 	{
 		scanf("%d%d",&x,&y);
 		addedge(x,y);
 	}
	 scanf("%d%d",&s,&t);
}

void print(int x)
{
	ok[x]=1;
	for(int yy=head[x];yy+1;yy=next[yy])
		if(!ok[to[yy]])
			print(to[yy]);
	return;
}

void change(int x)
{
	ok[x]=0;
	for(int yy=head[x];yy+1;yy=next[yy])
		if(ok[to[yy]])
			change(to[yy]);
	return;
}

void judge()
{
	ok[t]=1;
	for(int yy=head[t];yy+1;yy=next[yy])
		print(to[yy]);
	for(int i=1;i<=n;i++)
		if(!ok[i])
			change(i);
}

void spfa()
{
	queue<int> q;
	memset(vis,256,sizeof vis);
	for(int i=1;i<=n;i++) dis[i]=inf;
	dis[s]=0;
	vis[s]=1;
	q.push(s);
	while(!q.empty())
	{
		int u=q.front();
		q.pop();
		for(int yy=g[u];yy+1;yy=ne[yy])
		{
			int v=ot[yy];
			if(dis[v]>dis[u]+1)
				dis[v]=dis[u]+1;
			if(!vis[v] && ok[v])
			{
				vis[v]=1;
				q.push(v);
			}
		}
	}
}

int main()
{
	open();
	init();
	judge();
	spfa();
	if(dis[t]==inf) printf("-1\n");
	else printf("%d\n",dis[t]);
	close();
}

/*
10 13
1 2
2 3
3 4
4 5
5 6
1 4
4 9
1 7
7 8
8 10
10 9
3 7
10 6
1 9
*/
