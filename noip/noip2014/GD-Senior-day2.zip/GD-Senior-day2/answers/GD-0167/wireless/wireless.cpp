#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>

using namespace std;

int d,n;
int xx[55],yy[55],w[55];
int cnt=0,ans=0;

void open()
{
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
}

void close(){fclose(stdin);fclose(stdout);}

void init()
{
	scanf("%d%d",&d,&n);
	for(int i=1;i<=n;i++) scanf("%d%d%d",&xx[i],&yy[i],&w[i]);
}

void work()
{
	int x1,y1,x2,y2,tot;
	for(int i=0;i<=128;i++)
		for(int j=0;j<=128;j++)
		{
			tot=0;
			x1=min(i+d,128);y1=min(j+d,128);
			x2=max(i-d,0);y2=max(j-d,0);
			//printf("%d %d %d %d\n",x1,y1,x2,y2);
			for(int t=1;t<=n;t++)
				if(xx[t]<=x1 && yy[t]<=y1 && xx[t]>=x2 && yy[t]>=y2)
					tot+=w[t];
			if(tot==ans) cnt++;
			if(tot>ans)
			{
				ans=tot;
				cnt=1;
			}
			
		}
}

int main()
{
	open();
	init();
	work();
	printf("%d %d\n",cnt,ans);
	close();
}
