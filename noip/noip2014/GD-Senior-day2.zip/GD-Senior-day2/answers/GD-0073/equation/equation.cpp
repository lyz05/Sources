#include<fstream>
#include<string>
using namespace std;
ifstream cin("equation.in");
ofstream cout("equation.out");
int main(){
	long n,m,i,j,k;
	cin>>n>>m;
	if (n<=2){
		long a[n+1],ans[m+1],num=0,sum,tot;
		for(i=0;i<=n;i++)cin>>a[i];
		for(i=1;i<=m;i++){
			sum=a[0];
			for(j=1;j<=n;j++){
				tot=1;
				for(k=1;k<=j;k++)
					tot=tot*i;
				sum=sum+a[j]*tot;
			}
			if (sum==0) {ans[num]=i; num++;}
		}
		cout<<num;
		for(i=0;i<num;i++)cout<<endl<<ans[i];
	}else{
		string a[101];
		for(i=0;i<=n;i++)cin>>a[i];
		cout<<0;
	}
	cin.close(); cout.close();
	return 0;
}

