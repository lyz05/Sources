#include<fstream>
using namespace std;
ifstream cin("wireless.in");
ofstream cout("wireless.out");
int main(){
	long d,n,tot,ans=0,big=0,i,j,k,h;
	cin>>d>>n;
	long map[130][130];
	for(i=0;i<=128;i++)
		for(j=0;j<=128;j++)
			map[i][j]=0;
	for(i=0;i<n;i++){
		cin>>j>>k>>h; map[j][k]=h;
	}
	for(i=d;i<=128-d;i++)
		for(j=d;j<=128-d;j++){
			tot=0;
			for(k=i-d;k<=i+d;k++)
				for(h=j-d;h<=j+d;h++)
					tot=tot+map[k][h];
			if (tot>big) {big=tot; ans=1;}
			else if (tot==big) {ans++;}
		}
	cout<<ans<<' '<<big; cin.close();cout.close();
	return 0;
}

