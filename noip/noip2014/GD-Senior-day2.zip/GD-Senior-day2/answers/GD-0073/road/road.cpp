#include<fstream>
using namespace std;
ifstream cin("road.in");
ofstream cout("road.out");
bool cango[10001];
long n,m,s,t,from[200001],to[200001],divide[10001],now[10001],cost[10001],tou=0,wei=0;
void way(long x){
	long i;
	for(i=divide[x];i<divide[x+1];i++){
		cango[from[i]]=true; way(from[i]);
	}
}
void sort(long l,long r){
	long i=l,j=r,h; bool e=true;
	do{
		if (from[i]>from[j] || from[i]==from[j] && to[i]>to[j]){
			h=from[i]; from[i]=from[j]; from[j]=h;
			h=to[i]; to[i]=to[j]; to[j]=h; e=!e;
		}
		if (e) j--; else i++;
	}while (i<j);
	i++; j--;
	if (l<j) sort(l,j);
	if (i<r) sort(i,r);
}
void push(long a,long b){
	now[tou]=a; cost[tou]=b; tou++;
}
void pop(long &a,long &b){
	a=now[wei]; b=cost[wei]; wei++;
}
void tosort(long l,long r){
	long i=l,j=r,h; bool e=true;
	do{
		if (to[i]>to[j] || to[i]==to[j] && from[i]>from[j]){
			h=from[i]; from[i]=from[j]; from[j]=h;
			h=to[i]; to[i]=to[j]; to[j]=h; e=!e;
		}
		if (e) j--; else i++;
	}while (i<j);
	i++; j--;
	if (l<j) tosort(l,j);
	if (i<r) tosort(i,r);
}
int main(){
	long i,j,now=0,cost;
	bool yes;
	cin>>n>>m;
	long save[n+1],lsave;
	bool v[n+1];
	for(i=1;i<=n;i++){
		cango[i]=false; v[i]=true;
	}
	for(i=1;i<=m;i++)
		cin>>from[i]>>to[i];
	cin>>s>>t;
	tosort(1,m);
	j=0; divide[n+1]=m+1;
	for(i=1;i<=m;i++)
		if (to[i]!=j) 
		while (j<to[i]){j++; divide[j]=i;}
	j++;
	for(i=j;i<=n;i++) divide[i]=m+1;
	cango[t]=true;
	way(t);
	sort(1,m);
	j=0;
	for(i=1;i<=m;i++)
		if (from[i]!=j)
		while (j<from[i]){j++; divide[j]=i;}
	j++;
	for(i=j;i<=n;i++) divide[i]=m+1;
	push(s,0); v[s]=false;
	if (cango[s])
	while (tou>wei){
		pop(now,cost);
		if (now==t) break;
		lsave=0; yes=true;
		for(i=divide[now];i<divide[now+1];i++)
			if (cango[to[i]]){
				save[lsave]=to[i]; lsave++;
			}else {yes=false; break;}
		if (yes)
		while (lsave>0){
			lsave--;
			if (v[save[lsave]]) push(save[lsave],cost+1);
		}
	}
	if (now==t) cout<<cost; else cout<<-1; cin.close(); cout.close();
	return 0;
}
