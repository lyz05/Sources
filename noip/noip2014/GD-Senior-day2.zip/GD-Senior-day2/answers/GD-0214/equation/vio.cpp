#include <cstdio>
#include <cstring>
#define  fr(i,x,y) for(i=x;i<=y;i++)
typedef long long LL;
const int maxn=110;
const int maxm=1000010;
int n,m;
int a[maxn],ans[maxm];
void Read(){
	int i;
	scanf("%d%d",&n,&m);
	fr(i,0,n)scanf("%d",&a[i]);
}
bool Check(int x){
	int i;
	LL t,v;
	t=0,v=1;
	fr(i,0,n)t+=v*a[i],v*=x;
	return !t;
}
void Solve(){
	int i;
	fr(i,1,m)
		if(Check(i))
			ans[++ans[0]]=i;
	printf("%d\n",ans[0]);
	fr(i,1,ans[0])printf("%d\n",ans[i]);
}
int main(){
	freopen("equation.in","r",stdin);
	freopen("vio.out","w",stdout);
	Read();
	Solve();
}
