#include <cstdio>
#include <cstring>
#include <ctime>
#include <cstdlib>
#define  fr(i,x,y) for(i=x;i<=y;i++)
int n=2;
int m=100;
int Random(int x){return rand()%x;}
int main(){
	int a0,a1,a2;
	freopen("equation.in","r",stdin);
	scanf("%d%d%d%d%d",&n,&m,&a0,&a1,&a2);
	fclose(stdin);
	freopen("equation.in","w",stdout);	
	printf("%d %d\n",n,m);
	if(++a2>100){
		a2=0;
		a1++;
	}
	if(a1>100){
		a1=0;
		a0++;
	}
	printf("%d\n%d\n%d\n",a0,a1,a2);
}
