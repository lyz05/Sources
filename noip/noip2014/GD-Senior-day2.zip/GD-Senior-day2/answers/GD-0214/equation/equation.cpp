#include <cstdio>
#include <cstring>
#define  fr(i,x,y) for(i=x;i<=y;i++)
#define  frd(i,x,y) for(i=x;i>=y;i--)
using namespace std;
const int maxn=110;
const int maxm=10010;
const int wei=(int)1e8;
struct Bignum{int a[maxm/8];}big[maxn],cun1,cun2;
Bignum *p1,*p2,*p3;
int n,m,len,x;
int ans[1000010];
char s[maxm];
bool fu[maxn];
void Read(){
	int i,j,t;
	scanf("%d%d",&n,&m);
	fr(i,0,n){
		scanf("%s",s+1);len=strlen(s+1);
		if(s[1]=='-'){
			fu[i]=true;
			fr(j,1,len-1)s[j]=s[j+1];
			len--;
		}
		t=1;
		big[i].a[0]=1;
		frd(j,len,1){
			big[i].a[big[i].a[0]]+=(s[j]-'0')*t;
			if((t*=10)>wei)t=1,big[i].a[0]++;
		}
		if(t==1&&len>1)big[i].a[0]--;
	}
}
bool Small(Bignum *x,Bignum *y){
	int i;
	if((*x).a[0]!=(*y).a[0])return (*x).a[0]<(*y).a[0];
	len=(*x).a[0];
	frd(i,len,1)
		if((*x).a[i]!=(*y).a[i])return (*x).a[i]<(*y).a[i];
	return false;
}
void Plus(Bignum *x,Bignum *y){
	int i,t;
	len=(*x).a[0];
	if((*y).a[0]>len)len=(*y).a[0];
	t=0;
	fr(i,1,len){
		(*p1).a[i]=(*x).a[i]+(*y).a[i]+t;
		if((*p1).a[i]>=wei)(*p1).a[i]-=wei,t=1;
		else t=0;
	}
	if(t)(*p1).a[++len]=1;
	(*p1).a[0]=len;
}
void Dec(Bignum *x,Bignum *y){
	int i;
	len=(*x).a[0];
	fr(i,1,len)(*p1).a[i]=(*x).a[i];
	fr(i,1,(*y).a[0])
		if(((*p1).a[i]-=(*y).a[i])<0){
			(*p1).a[i]+=wei;
			(*p1).a[i+1]--;
		}
	fr(i,(*y).a[0]+1,len)
		if((*p1).a[i]<0){
			(*p1).a[i]+=wei;
			(*p1).a[i+1]--;
		}
	while(len>1&&(*p1).a[len]==0)len--;
	(*p1).a[0]=len;
}
bool Chu(){
	int i,t;
	len=(*p1).a[0];
	t=0;
	frd(i,len,1){
		t=((*p1).a[i]+=t*wei)%x;
		(*p1).a[i]/=x;
	}
	if(t)return false;
	while(len>1&&!(*p1).a[len])len--;
	(*p1).a[0]=len;
	return true;
}
bool Check(){
	int i;
	bool fu1;
	cun1.a[0]=1,cun1.a[1]=0,fu1=false;
	p1=&cun1,p2=&cun2;
	fr(i,0,n){
		p3=p1,p1=p2,p2=p3;
		if((!fu1&&!fu[i])||(fu1&&fu[i]))Plus(p2,&big[i]);
		else if(fu1)
			if(Small(p2,&big[i]))Dec(&big[i],p2),fu1=false;
			else Dec(p2,&big[i]);
		else
			if(Small(p2,&big[i]))Dec(&big[i],p2),fu1=true;
			else Dec(p2,&big[i]);
		if(x>1&&!Chu())return false;
	}
	return (*p1).a[0]==1&&(*p1).a[1]==0;
}
void Solve(){
	int i;
	fr(i,1,m)
		if(x=i,Check())
			ans[++ans[0]]=i;
	printf("%d\n",ans[0]);
	fr(i,1,ans[0])printf("%d\n",ans[i]);
}
int main(){
	freopen("equation.in","r",stdin);
	freopen("equation.out","w",stdout);
	Read();
	Solve();
	return 0;
}
