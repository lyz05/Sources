#include <cstdio>
#include <cstring>
#define  fr(i,x,y) for(i=x;i<=y;i++)
const int maxn=10010;
const int maxm=200010;
struct Edge{
	int y,next;
	Edge(){}
	Edge(int _y,int _next){y=_y,next=_next;}
}edge[maxm],r_edge[maxm];
int n,m,E_cnt,r_E_cnt,st,ed;
int que[maxn],first[maxn],r_first[maxn],dep[maxn];
int cun[maxm][2];
bool vis[maxn],ok[maxn];
void Ins(int x,int y){edge[++E_cnt]=Edge(y,first[x]);first[x]=E_cnt;}
void Ins_r(int x,int y){r_edge[++r_E_cnt]=Edge(y,r_first[x]);r_first[x]=r_E_cnt;}
void Read(){
	int i;
	scanf("%d%d",&n,&m);
	fr(i,1,m){
		scanf("%d%d",&cun[i][0],&cun[i][1]);
		Ins_r(cun[i][1],cun[i][0]);
	}
	scanf("%d%d",&st,&ed);
}
void Pretreat(){
	int i,x,k,y;
	que[que[0]=1]=ed;
	vis[ed]=true;
	fr(i,1,que[0]){
		x=que[i];
		for(k=r_first[x];y=r_edge[k].y,k;k=r_edge[k].next)
			if(!vis[y]){
				vis[y]=true;
				que[++que[0]]=y;
			}
	}
	fr(i,1,n)ok[i]=true;
	fr(i,1,m)
		if(!vis[cun[i][1]])
			ok[cun[i][0]]=false;
	fr(i,1,m)
		if(ok[cun[i][0]]&&ok[cun[i][1]])
			Ins(cun[i][0],cun[i][1]);
}
void Solve(){
	int i,x,k,y;
	fr(i,1,n)dep[i]=-1;
	que[que[0]=1]=st;
	dep[st]=0;
	fr(i,1,que[0]){
		x=que[i];
		for(k=first[x];y=edge[k].y,k;k=edge[k].next)
			if(ok[y]&&dep[y]==-1){
				dep[y]=dep[x]+1;
				que[++que[0]]=y;
			}
	}
	printf("%d\n",dep[ed]);
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	Read();
	Pretreat();
	Solve();
	return 0;
}
