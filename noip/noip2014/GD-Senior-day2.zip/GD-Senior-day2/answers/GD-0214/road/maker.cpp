#include <cstdio>
#include <cstring>
#include <ctime>
#include <cstdlib>
#define  fr(i,x,y) for(i=x;i<=y;i++)
int n=100;
int m=120;
int st=1;
int ed=n;
int Random(int x){return rand()%x;}
int main(){
	freopen("road.in","w",stdout);
	int i,x,y;
	srand(time(0));
	printf("%d %d\n",n,m);
	fr(i,2,n)printf("%d %d\n",i-1,i);
	fr(i,n,m){
		do{x=Random(n)+1;}while(x==ed);
		y=Random(n)+1;
		printf("%d %d\n",x,y);
	}
	printf("%d %d\n",st,ed);
}
