#include <cstdio>
#include <cstring>
#define  fr(i,x,y) for(i=x;i<=y;i++)
const int maxn=1010;
const int maxm=200010;
struct Edge{
	int y,next;
	Edge(){}
	Edge(int _y,int _next){y=_y,next=_next;}
}edge[maxm];
int n,m,E_cnt,st,ed;
int first[maxn],dep[maxn],que[maxn];
bool ok[maxn],ok1[maxn],vis[maxn];
void Ins(int x,int y){edge[++E_cnt]=Edge(y,first[x]);first[x]=E_cnt;}
void Read(){
	int i,x,y;
	scanf("%d%d",&n,&m);
	fr(i,1,m){
		scanf("%d%d",&x,&y);
		Ins(x,y);
	}
	scanf("%d%d",&st,&ed);
}
bool Bfs(int st){
	if(st==ed)return true;
	int i,x,k,y;
	fr(i,1,n)vis[i]=false;
	vis[st]=true;
	que[que[0]=1]=st;
	fr(i,1,que[0]){
		x=que[i];
		for(k=first[x];y=edge[k].y,k;k=edge[k].next)
			if(!vis[y]){
				vis[y]=true;
				que[++que[0]]=y;
				if(y==ed)return true;
			}
	}
	return false;
}
void Pretreat(){
	int i,x,k,y;
	fr(i,1,n)
		ok1[i]=Bfs(i);
	fr(x,1,n){
		for(k=first[x];y=edge[k].y,k;k=edge[k].next)
			if(!ok1[y])
				break;
		ok[x]=!k;
	}
}
void Solve(){
	int i,x,k,y;
	fr(i,1,n)dep[i]=-1;
	que[que[0]=1]=st;
	dep[st]=0;
	fr(i,1,que[0]){
		x=que[i];
		for(k=first[x];y=edge[k].y,k;k=edge[k].next)
			if(ok[y]&&dep[y]==-1){
				dep[y]=dep[x]+1;
				que[++que[0]]=y;
			}
	}
	printf("%d\n",dep[ed]);
}
int main(){
	freopen("road.in","r",stdin);
	freopen("vio.out","w",stdout);
	Read();
	Pretreat();
	Solve();
}
