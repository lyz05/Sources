#include <cstdio>
#include <cstring>
#define  fr(i,x,y) for(i=x;i<=y;i++)
const int maxn=210;
const int N=200;
int m,n,ans1,ans2;
int a[maxn][maxn];
void Read(){
	int i,x,y;
	scanf("%d%d",&m,&n);
	fr(i,1,n){
		scanf("%d%d",&x,&y);
		scanf("%d",&a[x+1][y+1]);
	}
}
void Maxx(int &x,int y){if(y>x)x=y;}
void Solve(){
	int i,j,t;
	m=2*m+1;
	fr(i,1,N)
		fr(j,1,N)
			a[i][j]=a[i][j]+a[i-1][j]+a[i][j-1]-a[i-1][j-1];
	fr(i,m,N)
		fr(j,m,N){
			t=a[i][j]-a[i-m][j]-a[i][j-m]+a[i-m][j-m];
			if(t>ans2)ans2=t,ans1=1;
			else ans1+=(t==ans2);
		}
	printf("%d %d\n",ans1,ans2);
}
int main(){
	freopen("wireless.in","r",stdin);
	freopen("wireless.out","w",stdout);
	Read();
	Solve();
	return 0;
}
