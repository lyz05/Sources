#!/usr/bin/env python
# encoding=utf-8


def hello():
    print('hello')
 

def world():
    print('world')