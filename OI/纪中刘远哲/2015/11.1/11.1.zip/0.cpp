#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>
using namespace std;

int main()
{
	freopen(".in","r",stdin);
	//freopen(".out","w",stdout);

	return 0;
}
