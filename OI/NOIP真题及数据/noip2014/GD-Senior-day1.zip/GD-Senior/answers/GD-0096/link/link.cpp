#include <fstream>
#include <vector>
using namespace std;

ifstream fin("link.in");
ofstream fout("link.out");

#define maxn 200005
#define MM 10007

int n, W[maxn], Maxx, ans;
vector <int > E[maxn];

void solve() {
	Maxx = -1; ans = 0;
	for (int i=1; i<=n; i++)
		for (int j=0; j!=E[i].size(); ++j)
			for (int k=0; k!=E[ E[i][j] ].size(); ++k) {
				int u = E[ E[i][j] ][k];
				if (i == u) continue;
				Maxx = max(Maxx, W[i]*W[u]);
				ans = (ans + W[i]*W[u]) % MM;
			}
}

int main() {
	fin >> n;
	for (int i=0; i!=n-1; ++i) {
		int u, s;
		fin >> u >> s;
		E[u].push_back(s);
		E[s].push_back(u);
	}
	for (int i=1; i<=n; i++)
		fin >> W[i];
	for (int i=1; i<=n; i++) {
		for (int j=0; j!=E[i].size(); ++j)
			fout << E[i][j] << ' ';
		fout << endl;
	}
	
	
	solve();
	fout << Maxx << ' ' << ans  << endl;
	return 0;
}
