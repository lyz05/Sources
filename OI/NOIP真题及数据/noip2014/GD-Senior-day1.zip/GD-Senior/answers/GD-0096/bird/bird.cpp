#include <fstream>
#include <queue>
using namespace std;

ifstream fin("bird.in");
ofstream fout("bird.out");

#define maxn 10005
#define maxm 1005

struct Guan{
	bool is_;
	int P, L, H;
};
struct Point{
	int x, y, Gnum, Xnum;
};


int n, m, k, Gmax, Xmin, ID;
bool F1[maxn][maxm];
int F2[maxn][maxm];
int X[maxn], Y[maxn];
Guan G[maxn];
queue <Point > Q;

void init() {
	fin >> n >> m >> k;
	for (int i=0; i!=n; ++i)
		fin >> X[i] >> Y[i];
	for (int i=0; i!=k; ++i) {
		int P, L, H;
		fin >> P >> L >> H;
		G[P].is_ = true;
		G[P].L = L;
		G[P].H = H;
	}
}

void Print(Point Z) {
	fout << Z.x << ' '<< Z.y << ' ' << Z.Xnum << ' ' << Z.Gnum << endl;
}

void BFS() {
	Gmax = -100000005;
	Xmin = 100000005;
	
	for (int i=1; i<=m; ++i) {
		Point a;
		a.x = 0;
		a.y = i;
		a.Gnum = 0;
		a.Xnum = 0;
		if (F1[a.x][a.y] == false || (F1[a.x][a.y] == true && F2[a.x][a.y] >a.Xnum)) {
			F1[a.x][a.y] = true;
			F2[a.x][a.y] = a.Xnum;
			Q.push(a);
		}
	}
	
	for (; Q.empty()==0; ) {
		Point now = Q.front();
		Print(now);
		Q.pop();
		if (now.x == n && now.Xnum < Xmin)
			Xmin = now.Xnum;
		if (now.Gnum > Gmax)
			Gmax = now.Gnum;
		if (now.x >= n) continue;
		
		Point next = now;
		next.x ++;
		next.y -= Y[now.x];
		if (next.y >0) {
			if (G[next.x].is_ == false || 
				(G[next.x].is_ == true && 
					next.y>G[next.x].L && 
						next.y<G[next.x].H)) {
							if (G[next.x].is_ == true) next.Gnum++;
							if (F1[next.x][next.y] == false || 
								(F1[next.x][next.y] == true && F2[next.x][next.y] >next.Xnum)) {
									F1[next.x][next.y] = true;
									F2[next.x][next.y] = next.Xnum;
									Q.push(next);
							}
						}
		}
		
		next = now;
		next.x ++;
		if (next.y == m) continue;
		bool yes=false;
		for (; ; ) {
			next.y += X[now.x];
			next.Xnum ++;
			if (next.y >=m) {
				next.y = m;
				yes = true;
			}
			if (G[next.x].is_ == false || 
				(G[next.x].is_ == true && 
					next.y>G[next.x].L && 
						next.y<G[next.x].H)) {
							if (G[next.x].is_ == true) next.Gnum++;
							if (F1[next.x][next.y] == false || 
								(F1[next.x][next.y] == true && F2[next.x][next.y] >next.Xnum)) {
									F1[next.x][next.y] = true;
									F2[next.x][next.y] = next.Xnum;
									Q.push(next);
							//Print(Q.back());
							}
						}
			if (G[next.x].is_ == true && next.y>=G[next.x].H) yes = true;
			if (yes) break;
		}
	}
}

void outit() {
	if (Xmin != 100000005) {
		fout << '1' << endl;
		fout << Xmin << endl;
	}
	else {
		fout << '0' << endl;
		fout << Gmax << endl;
	}
}

int main() {
	init();
	BFS();
	outit();
	return 0;
}
