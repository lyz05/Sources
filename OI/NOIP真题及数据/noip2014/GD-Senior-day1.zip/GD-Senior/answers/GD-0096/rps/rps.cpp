#include <fstream>
using namespace std;

ifstream fin("rps.in");
ofstream fout("rps.out");

#define maxn 205

int N, NA, NB, As, Bs;
int A[maxn], B[maxn];
int res[5][5];

void init() {
	res[0][1]=-1; res[0][2]=1; res[0][3]=1; res[0][4]=-1;
	res[1][2]=-1; res[1][3]=1; res[1][4]=-1;
	res[2][3]=-1; res[2][4]=1;
	res[3][4]=1;
	for (int i=0; i!=5; ++i)
		for (int j=0; j!=5; ++j) {
			if (i == j) res[i][j] =0;
			if (i > j) res[i][j] = -res[j][i];
		}
	/*for (int i=0; i!=5; ++i) {
		for (int j=0; j!=5; ++j) 
			fout << res[i][j] << ' ';
		fout << endl;
	}*/
	
	
	fin >> N >> NA >> NB;
	for (int i=0; i!=NA; ++i)
		fin >> A[i];
	for (int i=0; i!=NB; ++i)
		fin >> B[i];
}

void work() {
	int Ap=0, Bp=0;
	for (int i=0; i!=N; ++i) {
		if (res[ A[Ap] ][ B[Bp] ] == 1) As++;
		if (res[ A[Ap] ][ B[Bp] ] == -1) Bs++;
		Ap++; Bp++;
		Ap %= NA; Bp %= NB;
	}
}

int main() {
	init();
	work();
	fout << As << ' ' << Bs << endl;
	return 0;
}
