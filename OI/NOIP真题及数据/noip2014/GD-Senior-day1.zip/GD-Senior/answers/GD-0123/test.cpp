#include<cstdio>

using namespace std ;

int main () {
	int q ;
	scanf ( "%d" , & q ) ; 
	printf ( "Hello Noip.");
}
