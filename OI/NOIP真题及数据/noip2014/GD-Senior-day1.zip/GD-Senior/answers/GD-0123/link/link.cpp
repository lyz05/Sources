#include<cstdio>
#include<iostream>
#define maxn 200200
#define MO 10007

using namespace std ;

int n ;
long long many [ maxn ] , rmq [ maxn ] , val [ maxn ] , ma , sum ;
struct data {
	int u , v ;
} edge [ maxn ] ;

void Init () {
	scanf ( "%d" , & n ) ;
	for ( int i = 1 ; i <= n - 1 ; i ++ ) scanf ( "%d%d" , & edge [ i ] . u , & edge [ i ] . v ) ;
	for ( int i = 1 ; i <= n ; i ++ ) scanf ( "%lld" , & val [ i ] ) ;
}

void Ins ( int u , int v ) {
	sum = ( sum +  ( many [ u ] * val [ v ] % MO ) ) % MO ;
	ma = max ( ma , rmq [ u ] * val [ v ] ) ;
	rmq [ u ] = max ( rmq [ u ] , val [ v ] ) ;
	many [ u ] = ( many [ u ] + val [ v ] ) % MO ;
}

void Work () {
	for ( int i = 1 ; i <= n - 1 ; i ++ ) {
		Ins ( edge [ i ] . u , edge [ i ] . v ) ;
		Ins ( edge [ i ] . v , edge [ i ] . u ) ;
	}
	sum = ( sum * 2 ) % MO ;
	cout << ma << ' ' << sum ;
}

int main () {
	freopen("link.in" , "r" , stdin ) ;
	freopen("link.out" , "w" , stdout ) ;
	Init () ;
	Work () ;	
}
