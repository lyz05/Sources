#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#define MO 10007
#define maxn 2200
using namespace std ;

long long f [ maxn ] [ maxn ] , a [ maxn ] , ma , sum ;
int n ;

void Init () {
	memset ( f , 60 , sizeof ( f ) ) ;
	scanf ( "%d" , & n ) ;
	int u , v ;
	for ( int i = 1 ; i <= n - 1 ; i ++ ) {
		scanf ( "%d%d" , & u , & v ) ;
		f [ u ] [ v ] = 1 ;
		f [ v ] [ u ] = 1 ;
	}
	for ( int i = 1 ; i <= n ; i ++ ) scanf ( "%lld" , & a [ i ] ) ;
}

void Work () {
	for ( int k = 1 ; k <= n ; k ++ ) 
	for ( int i = 1 ; i <= n ; i ++ )
	for ( int j = 1 ; j <= n ; j ++ ) {
		if ( i == j || j == k || i == k ) continue ;
		if ( f [ i ] [ k ] > 1000000 || f [ k ] [ j ] > 1000000 ) continue ;
		f [ i ] [ j ] = min ( f [ i ] [ j ] , f [ i ] [ k ] + f [ k ] [ j ] ) ;
	}
	for ( int i = 1 ; i <= n ; i ++ ) {
		for ( int j = 1 ; j <= n ; j ++ ) {
			if ( i == j ) continue ;
			if ( f [ i ] [ j ] != 2 ) continue ;
			ma = max ( ma , a [ i ] * a [ j ] ) ;
			sum = ( sum + a [ i ] * a [ j ] % MO ) % MO ;
		}
	}
	cout << ma << ' ' << sum ;
}

int main () {
	freopen("link.in" , "r" , stdin ) ;
	freopen("p.out" , "w" , stdout ) ;
	Init () ;
	Work () ;
}
