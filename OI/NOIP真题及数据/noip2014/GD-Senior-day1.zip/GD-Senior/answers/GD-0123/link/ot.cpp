#include<cstdio>
#include<iostream>
#define maxn 200200
#define MO 10007

using namespace std ;

int n ;
long long many [ maxn ] , rmq [ maxn ] , val [ maxn ] , ma , sum , tot ;
int y [ maxn ] , g [ maxn ] , next [ maxn ] ;
struct data {
	int u , v ;
} edge [ maxn ] ;

void Init () {
	scanf ( "%d" , & n ) ;
	for ( int i = 1 ; i <= n - 1 ; i ++ ) scanf ( "%d%d" , & edge [ i ] . u , & edge [ i ] . v ) ;
	for ( int i = 1 ; i <= n ; i ++ ) scanf ( "%lld" , & val [ i ] ) ;
}

void Ins ( int u , int v ) {
	y [ ++ tot ] = v ;
	next [ tot ] = g [ u ] ;
	g [ u ] = tot ;
}

void Dp ( int x , int fa ) {
	long long q = 0 ;
	for ( int t = g [ x ] ; t != 0 ; t = next [ t ] ) {
		int son = y [ t ] ;
		if ( son == fa ) continue ;
		sum = ( sum + q * val [ son ] * 2 ) % MO ;
		q += val [ son ] ;
		Dp ( son , x ) ;
	}
	sum = ( sum + val [ fa ] * q * 2 ) % MO ;
}

void Work () {
	for ( int i = 1 ; i <= n - 1 ; i ++ ) {
		Ins ( edge [ i ] . u , edge [ i ] . v ) ;
		Ins ( edge [ i ] . v , edge [ i ] . u ) ;
	}
	Dp ( 1 , 0 ) ;
	cout << sum ;
}

int main () {
	//freopen("link.in" , "r" , stdin ) ;
	freopen("ot.out" , "w" , stdout ) ;
	Init () ;
	Work () ;	
}
