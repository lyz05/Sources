#include<cstdio>
#define maxn 220

using namespace std ;

int n , len_A , len_B ;
int a [ maxn ] , b [ maxn ] , win [ 10 ] [ 10 ] ;

void Init () {
	scanf ( "%d%d%d" , & n , & len_A , & len_B ) ;
	for ( int i = 1 ; i <= len_A ; i ++ ) scanf ( "%d" , & a [ i ] ) ;
	for ( int i = 1 ; i <= len_B ; i ++ ) scanf ( "%d" , & b [ i ] ) ;
}

void Pre () {
	win [ 0 ] [ 0 ] = 3 ; win [ 0 ] [ 1 ] = 2 ; win [ 0 ] [ 2 ] = 1 ; win [ 0 ] [ 3 ] = 1 ; win [ 0 ] [ 4 ] = 2 ;
	win [ 1 ] [ 0 ] = 1 ; win [ 1 ] [ 1 ] = 3 ; win [ 1 ] [ 2 ] = 2 ; win [ 1 ] [ 3 ] = 1 ; win [ 1 ] [ 4 ] = 2 ;
	win [ 2 ] [ 0 ] = 2 ; win [ 2 ] [ 1 ] = 1 ; win [ 2 ] [ 2 ] = 3 ; win [ 2 ] [ 3 ] = 2 ; win [ 2 ] [ 4 ] = 1 ;
	win [ 3 ] [ 0 ] = 2 ; win [ 3 ] [ 1 ] = 2 ; win [ 3 ] [ 2 ] = 1 ; win [ 3 ] [ 3 ] = 3 ; win [ 3 ] [ 4 ] = 1 ;
	win [ 4 ] [ 0 ] = 1 ; win [ 4 ] [ 1 ] = 1 ; win [ 4 ] [ 2 ] = 2 ; win [ 4 ] [ 3 ] = 2 ; win [ 4 ] [ 4 ] = 3 ;
}

void Work () {
	int i = 0 , j = 0 , sa = 0 , sb = 0 ;
	while ( n -- ) {
		i ++ ;
		j ++ ;
		if ( i > len_A ) i = 1 ;
		if ( j > len_B ) j = 1 ;
		if ( win [ a [ i ] ] [ b [ j ] ] == 1 ) sa ++ ;
		if ( win [ a [ i ] ] [ b [ j ] ] == 2 ) sb ++ ;
	}
	printf ( "%d %d" , sa , sb ) ;
}

int main () {
	freopen ( "rps.in" , "r" , stdin ) ;
	freopen ( "rps.out" , "w" , stdout ) ;
	Init () ;
	Pre () ;
	Work () ;
}
