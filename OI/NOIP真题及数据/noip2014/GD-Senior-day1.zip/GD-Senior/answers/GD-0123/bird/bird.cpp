#include<cstdio>
#include<algorithm>
#include<cstring>
#include<climits>
#define maxn 1100
using namespace std ;

int n , m , t ;
int f [ maxn ] [ maxn ] , many [ maxn ] ;
struct data {
	bool flag ;
	int up , down ;
	data () {
		flag = false ;
	}
} a [ maxn ] , pie [ maxn ] ;

void Init () {
	scanf ( "%d%d%d" , & n , & m , & t ) ;
	int x , u , v ;
	for ( int i = 0 ; i <= n - 1 ; i ++ ) scanf ( "%d%d" , & a [ i ] . up , & a [ i ] . down ) ;
	for ( int i = 1 ; i <= t ; i ++ ) {
		scanf ( "%d%d%d" , & x , & u , & v ) ;
		pie [ x ] . flag = true ;
		pie [ x ] . down = u ;
		pie [ x ] . up = v ;
	}
	many [ 0 ] = pie [ 0 ] . flag ;
	for ( int i = 1 ; i <= n ; i ++ ) many [ i ] = many [ i - 1 ] + pie [ i ] . flag ;
}

void Work () {
	memset ( f , 60 , sizeof ( f ) ) ;
	int err = f [ 1 ] [ 1 ] - 10 , up , down ;
	if ( pie [ 0 ] . flag == false ) for ( int i = 0 ; i <= m ; i ++ ) f [ 0 ] [ i ] = 0 ; else 
	for ( int i = pie [ 0 ] . down + 1 ; i <= pie [ 0 ] . up - 1 ; i ++ ) f [ 0 ] [ i ] = 0 ;
	for ( int i = 0 ; i <= n - 1 ; i ++ ) {
		up = a [ i ] . up ;
		down = a [ i ] . down ;
		for ( int j = 0 ; j <= m ; j ++ ) {
			if ( f [ i ] [ j ] >= err ) continue ;
			if ( pie [ i + 1 ] . flag == false ) {
				if ( j - down > 0 )
					f [ i + 1 ] [ j - down ] = min ( f [ i + 1 ] [ j - down ] , f [ i ] [ j ] ) ;
			 	for ( int k = 1 ; j + ( k - 1 ) * up <= m ; k ++ ) 
					f [ i + 1 ] [ min ( m , j + k * up ) ] = min ( f [ i ] [ j ] + k , f [ i + 1 ] [ min ( m , j + k * up ) ] ) ;
			} else {
				if ( j - down > pie [ i + 1 ] . down && j - down < pie [ i + 1 ] . up ) 
					f [ i + 1 ] [ j - down ] = min ( f [ i + 1 ] [ j - down ] , f [ i ] [ j ] ) ;
				for ( int k = 1 ; ( j + ( k - 1 ) * up <= m ) && ( j + k * up > pie [ i + 1 ] . down ) && ( j + k * up < pie [ i + 1 ] . up ) ; k ++ ) {
					f [ i + 1 ] [ min ( m , j + k * up ) ] = min ( f [ i ] [ j ] + k , f [ i + 1 ] [ min ( m , j + k * up ) ] ) ;
				}
			}
		}
	}
	int ans = INT_MAX ;
	for ( int j = 0 ; j <= m ; j ++ ) 
		if ( f [ n ] [ j ] < err ) ans = min ( ans , f [ n ] [ j ] ) ;
	if ( ans == INT_MAX ) {
		printf ( "0\n" ) ;
		for ( int i = n - 1 ; i >= 0 ; i -- ) {
			for ( int j = 0 ; j <= m ; j ++ ) 
			if ( f [ i ] [ j ] < err ) {
				printf ( "%d" , many [ i ] ) ;
				
				return ;
			}
		}
	} else {
		printf ( "1\n" ) ;
		printf ( "%d" , ans ) ;
	}
}

int main () {
	freopen ( "bird.in" , "r" , stdin ) ;
	freopen ( "bird.out" , "w" , stdout ) ;
	Init () ;
	Work () ;
}
