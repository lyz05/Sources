#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <algorithm>

using namespace std;

const int oo=1<<30;

int N,M,K;
int X[10005],Y[10005];
int Low[10005],High[10005];
int s[10005];
int F[10005][1005][2];

int main()
{
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	scanf("%d%d%d",&N,&M,&K);
	for (int i=0; i<N; i++) scanf("%d%d",&X[i],&Y[i]);
	memset(Low,0,sizeof(Low));
	for (int i=0; i<=N; i++) High[i]=oo;
	memset(s,0,sizeof(s));
	for (int i=1; i<=K; i++)
	{
		int P,L,H;
		scanf("%d%d%d",&P,&L,&H);
		Low[P]=L;
		High[P]=H;
		s[P]++;
	}
	for (int i=1; i<=N; i++) s[i]+=s[i-1];
	for (int i=0; i<=N; i++)
		for (int j=0; j<=M; j++) F[i][j][0]=F[i][j][1]=oo;
	for (int i=1; i<=M; i++) F[0][i][0]=0;
	for (int i=0; i<N; i++)
		for (int j=1; j<=M; j++)
		{
			//F[i][j][0]
			if (F[i][j][0]!=oo)
			{
				//Down
				int nj=j-Y[i];
				if (nj>0)
					if ((nj>Low[i+1]) && (nj<High[i+1]))
						if (F[i][j][0]<F[i+1][nj][0]) F[i+1][nj][0]=F[i][j][0];
				//Up
				nj=j+X[i];
				if (nj>M) nj=M;
				if (F[i][j][0]+1<F[i][nj][1]) F[i][nj][1]=F[i][j][0]+1;
			}
			//F[i][j][1]
			if (F[i][j][1]!=oo)
			{
				//Up
				int nj=j+X[i];
				if (nj>=M) nj=M;
				if (F[i][j][1]+1<F[i][nj][1]) F[i][nj][1]=F[i][j][1]+1;
				//next
				if ((j>Low[i+1]) && (j<High[i+1]))
					if (F[i][j][1]<F[i+1][j][0]) F[i+1][j][0]=F[i][j][1];
			}
		}
	int Ans=oo;
	for (int i=1; i<=M; i++)
		if (F[N][i][0]<Ans) 
			Ans=F[N][i][0]; 
	if (Ans!=oo)
	{
		cout << 1 << endl;
		cout << Ans << endl;
		return 0;
	}
	cout << 0 << endl;
	for (int i=N-1; i>=0; i--)
	{
		bool flag=false;
		for (int j=1; j<=M; j++)
		{
			if (F[i][j][0]!=oo)
			{
				flag=true;
				break;
			}
			if (F[i][j][1]!=oo)
			{
				flag=true;
				break;
			}
		}
		if (flag)
		{
			cout << s[i] << endl;
			return 0;
		}
	}
	return 0;
}

