#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <algorithm>

using namespace std;

const int G[5][5]={
{0,2,1,1,2},
{1,0,2,1,2},
{2,1,0,2,1},
{2,2,1,0,1},
{1,1,2,2,0}
};

int N,NA,NB;
int a[205],b[205];

int main()
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	scanf("%d%d%d",&N,&NA,&NB);
	for (int i=1; i<=NA; i++) scanf("%d",&a[i]);
	for (int i=1; i<=NB; i++) scanf("%d",&b[i]);
	int p=0,q=0;
	int Ansa=0,Ansb=0;
	for (int i=1; i<=N; i++)
	{
		p++;
		if (p>NA) p=1;
		q++;
		if (q>NB) q=1;
		if (G[a[p]][b[q]]==1) Ansa++;
		else if (G[a[p]][b[q]]==2) Ansb++;
	}
	cout << Ansa << ' ' << Ansb << endl;
	return 0;
}

