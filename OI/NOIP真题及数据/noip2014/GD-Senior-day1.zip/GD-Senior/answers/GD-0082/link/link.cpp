#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <algorithm>

using namespace std;

const int oo=10007;

int N,Cou;
int w[200005];
int v[400005],next[400005],root[200005];
int c[200005],fa[200005],s[200005],sum[200005],F1[200005],F2[200005],G[200005],F[200005];
bool yes[200005];

void insert(int father,int son)
{
	Cou++;
	v[Cou]=son;
	next[Cou]=root[father];
	root[father]=Cou;
}

void BFS()
{
	memset(yes,true,sizeof(yes));
	memset(sum,0,sizeof(sum));
	memset(F1,0,sizeof(F1));
	memset(F2,0,sizeof(F2));
	memset(G,0,sizeof(G));
	int tail=1;
	c[1]=1;
	fa[1]=0;
	yes[1]=false;
	for (int head=1; head<=tail; head++)
		for (int x=root[c[head]]; x>0; x=next[x])
			if (yes[v[x]])
			{
				fa[v[x]]=c[head];
				sum[c[head]]=(sum[c[head]]+w[v[x]]) % oo;
				if (w[v[x]]>F1[c[head]])
				{
					F2[c[head]]=F1[c[head]];
					F1[c[head]]=w[v[x]];
					G[c[head]]=v[x];
				}
				else
				if (w[v[x]]>F2[c[head]]) F2[c[head]]=w[v[x]];
				yes[v[x]]=false;
				tail++;
				c[tail]=v[x];
			}
}

int main()
{
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	scanf("%d",&N);
	for (int i=1; i<N; i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		insert(u,v);
		insert(v,u);
	}
	for (int i=1; i<=N; i++) scanf("%d",&w[i]);
	BFS();
	for (int i=1; i<=N; i++)
		if ((fa[i]!=0) && (fa[fa[i]]!=0))
		{
			int Gr=fa[fa[i]];
			if (w[i]>F[Gr]) F[Gr]=w[i];
			s[Gr]=(s[Gr]+w[i]) % oo;
		}
	int Ans1=0, Ans2=0;
	for (int i=1; i<=N; i++)
	{
		if ((fa[i]!=0) && (fa[fa[i]]!=0))
		{
			if (w[fa[fa[i]]]*w[i]>Ans1) Ans1=w[fa[fa[i]]]*w[i];
			Ans2=(Ans2+w[fa[fa[i]]]*w[i]) % oo;
		}
		if (fa[i]!=0)
		{
			int Max=F1[fa[i]];
			if (G[fa[i]]==i) Max=F2[fa[i]];
			if (Max*w[i]>Ans1) Ans1=Max*w[i];
			Ans2=(Ans2+(sum[fa[i]]-w[i]+oo)*w[i]) % oo;
		}
		if (F[i]*w[i]>Ans1) Ans1=F[i]*w[i];
		Ans2=(Ans2+s[i]*w[i]) % oo;
	}
	cout << Ans1 << ' ' << Ans2 << endl;
	return 0;
}

