#include<cmath>
#include<iomanip>
#include<cstdio>
#include<cstdlib>
#include<fstream>
#include<cstring>
using namespace std;
ifstream cin("rps.in");
ofstream cout("rps.out");
long a[500],b[500],p[10][10],n,c,d,ansa,ansb;
int main()
{
	long i,j,k;
	ios::sync_with_stdio(false);
	memset(a,0,sizeof(a));
	memset(b,0,sizeof(b));
	p[0][0]=1;p[0][1]=0;p[0][2]=2;p[0][3]=2;p[0][4]=0;
	p[1][0]=2;p[1][1]=1;p[1][2]=0;p[1][3]=2;p[1][4]=0;
	p[2][0]=0;p[2][1]=2;p[2][2]=1;p[2][3]=0;p[2][4]=2;
	p[3][0]=0;p[3][1]=0;p[3][2]=2;p[3][3]=1;p[3][4]=2;
	p[4][0]=2;p[4][1]=2;p[4][2]=0;p[4][3]=0;p[4][4]=1;
	cin>>n>>c>>d;
	for (i=1;i<=c;i++)	cin>>a[i];
	for (i=1;i<=d;i++)	cin>>b[i];
	ansa=ansb=0;
	k=j=1;
	for (i=1;i<=n;i++)
	{
		if (p[a[k]][b[j]]==0)	ansb++;
		if (p[a[k]][b[j]]==2)	ansa++;
		if (k==c)	k=1;
		else k++;
		if (j==d)	j=1;
		else j++;
	}
	cout<<ansa<<' '<<ansb;
	cin.close();cout.close();
	return 0;
}