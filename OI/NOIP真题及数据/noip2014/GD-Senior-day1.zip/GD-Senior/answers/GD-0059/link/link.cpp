#include<cmath>
#include<iomanip>
#include<cstdio>
#include<cstdlib>
#include<fstream>
#include<cstring>
using namespace std;
ifstream cin("link.in");
ofstream cout("link.out");
struct yjw
{
	long num,next;
}a[400005];
long n,tot,h[200005];
long long maxx,ans,b[200005];
void add(long i,long j)
{
	tot++;
	a[tot].num=j;
	a[tot].next=h[i];
	h[i]=tot;
}
void doit(long i)
{
	long j,k;
	j=h[i];
	while (j>0)
	{
		k=a[j].next;
		while (k>0)
		{
			if (b[a[j].num]*b[a[k].num]>maxx)	maxx=b[a[j].num]*b[a[k].num];	
			ans=(ans+(2*b[a[j].num]*b[a[k].num])%10007)%10007;
			k=a[k].next;
		}
		j=a[j].next;
	}
}
int main()
{
	long i,j,k;
	ios::sync_with_stdio(false);
	memset(h,0,sizeof(h));
	memset(a,0,sizeof(a));
	memset(b,0,sizeof(b));
	tot=maxx=ans=0;
	cin>>n;
	for (i=1;i<=n-1;i++)
	{
		cin>>j>>k;
		add(j,k);add(k,j);
	}
	for (i=1;i<=n;i++)	cin>>b[i];
	for (i=1;i<=n;i++)	doit(i);
	cout<<maxx<<' '<<ans;
	cin.close();cout.close();
return 0;	
}