#include<cmath>
#include<iomanip>
#include<cstdio>
#include<cstdlib>
#include<fstream>
#include<cstring>
using namespace std;
long a[1005],b[1005],h[10005],f[10005],g[10005],k,n,m,xx[10005],yy[10005];
bool ok,o;
int main()
{
	long i,j,s,t;
	ifstream cin("bird.in");
	ofstream cout("bird.out");
	ios::sync_with_stdio(false);
	memset(a,0,sizeof(a));
	memset(h,0,sizeof(h));
	memset(f,-1,sizeof(f));
	memset(g,-1,sizeof(g));
	memset(xx,0,sizeof(xx));
	memset(yy,0,sizeof(yy));
	cin>>n>>m>>k;
	for (i=0;i<=n-1;i++)	cin>>xx[i]>>yy[i];
	for (i=1;i<=k;i++)	
	{
		cin>>j>>s>>t;
		f[j]=s;g[j]=t;
	}
	for (i=1;i<=n;i++)	{	h[i]=h[i-1];if (f[i]>=0)	h[i]++;	}
	for (i=0;i<=n-1;i++)
	{
		memset(b,-1,sizeof(b));
		ok=false;
		for (j=1;j<=m;j++)
			if (a[j]>=0)
			{
				for (s=1;s<=100000;s++)
				{
					t=j+s*xx[i];o=true;
					if (g[i+1]>=0)
					{
						if (t>=g[i+1])	break;
						if (t<=f[i+1])	o=false;
					}
					if (o)
					{
						if (t<=m)
						{
							if (b[t]==-1 || a[j]+s<b[t])	{	b[t]=a[j]+s;ok=true;	}
						}
						else
						{
							t=m;
							if (b[t]==-1 || a[j]+s<b[t])	{	b[t]=a[j]+s;ok=true;	}
							break;
						}
					}
				}
				if (	(g[i+1]>0 && (j-yy[i]>=g[i+1] || j-yy[i]<=f[i+1]))	||	(j-yy[i]<=0)	)	{}
				else 
					if (b[j-yy[i]]==-1 || a[j]<b[j-yy[i]])	{	b[j-yy[i]]=a[j];ok=true;	}
			}
		if (!ok)	{	cout<<'0'<<endl<<h[i]<<endl;break;	}
		memcpy(a,b,sizeof(b));
	}
	if (ok)
	{
		s=10000000;
		for (i=1;i<=m;i++)
			if (a[i]>=0	&&	a[i]<s)	s=a[i];
		cout<<'1'<<endl<<s<<endl;
	}
	cin.close();cout.close();
return 0;	
}



