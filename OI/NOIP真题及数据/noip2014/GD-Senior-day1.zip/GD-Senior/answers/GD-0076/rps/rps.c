#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>
#include <malloc.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
#define MAX 10000
int A[MAX];
int B[MAX];
int win(int a,int b)
{
	if(a==b)
		return 0;
	else if(a==0)
	{
		if(b==1)
			return 0;
		else if(b==2)
			return 1;
		else if(b==3)
			return 1;
		else if(b==4)
			return 0;
	}
	else if(a==1)
	{
		if(b==0)
			return 1;
		else if(b==2)
			return 0;
		else if(b==3)
			return 1;
		else if(b==4)
			return 0;
	}
	else if(a==2)
	{
		if(b==0)
			return 0;
		else if(b==1)
			return 1;
		else if(b==3)
			return 0;
		else if(b==4)
			return 1;
	}
	else if(a==3)
	{
		if(b==0)
			return 0;
		else if(b==1)
			return 0;
		else if(b==2)
			return 1;
		else if(b==4)
			return 1;
	}
	else if(a==4)
	{
		if(b==0)
			return 1;
		else if(b==1)
			return 1;
		else if(b==2)
			return 0;
		else if(b==3)
			return 0;
	}
}

int gcd(int a,int b)
{
	if(a%b==0)
		return b;
	return gcd(b,a%b);
}

int main(int argc, char *argv[]) {
	
	int i,n,na,nb,ca=0,cb=0,m;
	FILE *in,*out;
	srand(time(NULL));
	in=fopen("rps.in","a+");
	out=fopen("rps.out","w+");

	fscanf(in,"%d %d %d",&n,&na,&nb);
	for(i=0;i<na;i++)
		fscanf(in,"%d",&A[i]);
	for(i=0;i<nb;i++)
		fscanf(in,"%d",&B[i]);
	m=na*nb/gcd(na,nb);
	for(i=0;i<m;i++)
	{
		ca+=win(A[i%na],B[i%nb]);
		cb+=win(B[i%nb],A[i%na]);
	}
	ca*=n/m;
	cb*=n/m;
	for(i=0;i<n%m;i++)
	{
		ca+=win(A[i%na],B[i%nb]);
		cb+=win(B[i%nb],A[i%na]);	
	}
	fprintf(out,"%d %d",ca,cb);
	fclose(in);
	fclose(out);
	return 0;
}
