#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>
#include <malloc.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
#define MAX 200000
int n,m,k;
int X[MAX],Y[MAX];

int weigui(int x,int y)
{
	if(y==0||y>m)
		return 1;
}

int main(int argc, char *argv[]) {
	
	int i,x,y,ans=0;
	FILE *in,*out;
	srand(time(NULL));
	in=fopen("bird.in","a+");
	out=fopen("bird.out","w+");
	fscanf(in,"%d %d %d",&n,&m,&k);
	for(i=0;i<n-1;i++)
		fscanf(in,"%d %d",&X[i],&Y[i]);
	for(i=0;i<n-1;i++)
		Y[i]=-Y[i];
	x=10;
	y=1;
	if(k==0)
	{
		for(i=n-2;i>=0;i--)
		{
			x--;
			if(weigui(x,y-Y[i])==1)
			{
				if(weigui(x,y-X[i])==1)
				{
					i=n-1;
					x=10;
					y++;
					ans=0;
				}
				else
				{
					y-=X[i];
					ans+=1;
				}
			}
			else
			{
				y-=Y[i];
			}
		}
	}
	else
	{
		ans=3;
	}

	
	fprintf(out,"1\n%d",ans);
	
	fclose(in);
	fclose(out);
	return 0;
}
