#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>
#include <malloc.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
#define MAX 200000

typedef struct enode
{
	int v;
	struct enode *next;
}Enode;

typedef struct
{
	int v;
	int w;
	int d;
	int p;
	int colour;
	Enode *first;
}Vnode;

Vnode G[MAX];
int Wa=0,Wm=0,Q[MAX];
int head=1,tail=1,n;

void ENQUEUE(int u)
{
	if(tail>n+1)
		tail=1;
	Q[tail++]=u;
}

int DEQUEUE(void)
{
	int ans;
	ans=Q[head++];
	if(head>n+1)
		head=1;
	return ans;
}

int Empty(void)
{
	if(tail==head)
		return 1;
	else
		return 0;
}

void BFS(int s)
{
	int i,u;
	Enode *v;
	for(i=1;i<=n;i++)
	{
		G[i].p=-1;
		G[i].d=0;
		G[i].colour=0;
	}
	G[s].p=s;
	G[s].d=0;
	ENQUEUE(s);
	G[s].colour=1;
	while(Empty()==0)
	{
		u=DEQUEUE();
		v=G[u].first;
		while(v!=NULL)
		{
			if(G[v->v].colour==0)
			{
				G[v->v].colour=1;
				ENQUEUE(v->v);
				G[v->v].d=G[u].d+1;
				G[v->v].p=u;
			}
			v=v->next;
		}
		G[u].colour=2;
	}
	
	
}

void work(void)
{
	int i,j,k,w;
	int A[MAX];
	k=0;
	for(i=1;i<=n;i++)
	{
		if(G[i].d==1)
		{
			for(j=1;j<=n;j++)
			{
				if(G[j].d==1&&i!=j)
				{
					w=G[i].w*G[j].w;
					if(w>Wm)
					{
						Wm=w;
					}
					Wa+=w;
				}
			}
		}
	}
	
	for(i=1;i<=n;i++)
	{
		if(G[i].d==2)
		{
			w=G[i].w*G[1].w;
			if(w>Wm)
				Wm=w;
			Wa+=2*w;
		}
	}
	
	for(i=1;i<=n;i++)
	{
		if(G[i].d>2)
		{
			w=G[i].w*G[G[G[i].p].p].w;
			if(w>Wm)
				Wm=w;
			Wa+=2*w;
		}
	}

}

int main(int argc, char *argv[]) {
	
	int i,u,k;
	Enode *v,*tmp;
	FILE *in,*out;
	srand(time(NULL));
	in=fopen("link.in","a+");
	out=fopen("link.out","w+");
	fscanf(in,"%d",&n);
	for(i=1;i<=n;i++)
		G[i].v=i;
	for(i=1;i<=n-1;i++)
	{
		v=(Enode *)malloc(sizeof(Enode));
		v->next=NULL;
		fscanf(in,"%d %d",&u,&k);
		v->v=k;
		tmp=G[u].first;
		if(tmp==NULL)
			G[u].first=v;
		else
		{
			while(tmp->next!=NULL)
				tmp=tmp->next;
			tmp->next=v;
		}	
	}
	
	for(i=1;i<=n;i++)
		fscanf(in,"%d",&G[i].w);
	BFS(1);
	work();
	fprintf(out,"%d %d",Wm,Wa);
	fclose(in);
	fclose(out);
	return 0;
}
