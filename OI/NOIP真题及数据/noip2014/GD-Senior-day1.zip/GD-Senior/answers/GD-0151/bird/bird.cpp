#include <cstdio>
#include <cstdlib>
#include <cstring>
using namespace std;

int n, m, k;
int UpDown[10010][2];
int avail[10010][2];
int f[1010][110];
bool v[1010][110];
int zs[1010];

int main ()
{
	freopen ( "bird.in", "r", stdin );
	freopen ( "bird.out", "w", stdout );
	memset (zs, 0, sizeof(zs) );
	scanf ( "%d%d%d", &n, &m, &k );
	int i, j;
	for ( i = 1; i <= n; i ++ )
	 scanf ( "%d%d", &UpDown[i][0], &UpDown[i][1] );
	for ( i = 0; i <= n; i ++ ) avail[i][0] = 1, avail[i][1] = m;
	for ( i = 1; i <= k; i ++ )
	{
        int x; scanf ( "%d", &x ); zs[x] = 1;
	    scanf ( "%d%d", &avail[x][0], &avail[x][1] );
	    avail[x][0] ++; avail[x][1] --;
    }
    for ( i = 1; i <= n; i ++ ) zs[i] += zs[i-1];
    memset ( f, 63, sizeof(f) );
    memset ( v, 0, sizeof(v) );
    
    for ( i = 1; i <= m; i ++ ) v[0][i] = 1, f[0][i] = 0;
    for ( i = 1; i <= n; i ++ )
    {
    	for ( j = avail[i][0]; j <= avail[i][1]; j ++ )
    	{
    		int k = 1;
			while ( j - k*UpDown[i][0] > 0 )
			{
				int cha = j - k*UpDown[i][0];
			    if ( cha < avail[i-1][0] ) { k ++;continue; }
			    if ( cha > avail[i-1][1] ) { k ++;continue; }
			    if ( v[i-1][cha] ) 
			    {

			    	v[i][j] = 1;
			    	if ( f[i][j] > f[i-1][cha] + k )
			    	 f[i][j] = f[i-1][cha] + k;
			    }
				k ++;
			}
			int cha = j+UpDown[i][1];
			if ( cha <= m && v[i-1][cha] )
			{
			    v[i][j] = 1;
				if ( f[i][j] > f[i-1][cha] )
			     f[i][j] = f[i-1][cha]; 	
			}
			if ( j == m )
			{
				for ( cha = 1; cha <= m; cha ++ )
				if ( v[i-1][cha] )
				{
					v[i][j] = 1;
					int k = m-cha;
					if ( k == 0 ) k = 1;
					else k = (k%UpDown[i][0] == 0) ? k/UpDown[i][0] : (k/UpDown[i][0]+1);
				    if ( f[i][j] > f[i-1][cha] + k ) f[i][j] = f[i-1][cha] + k; 
				}
			}
    	}
    	/*printf ( "%d\n", i );
    	for ( j = 1; j <= m; j ++ )
    	if ( f[i][j] < 999999999 )
    	 printf ( "%d ", f[i][j] );
    	else
		 printf ( "%d ", -1 );
    	printf ( "\n");*/ 
    }
    
    int ok = 0;
    for ( i = 1; i <= m; i ++ )
     if ( v[n][i] ) { ok = 1; break; }
    printf ( "%d\n", ok );
    if ( ok == 1 ) 
    {
    	int Min = 999999999;
    	for ( i = 1; i <= m; i ++ )
    	 if ( v[n][i] && f[n][i] < Min ) Min = f[n][i];
    	printf ( "%d\n", Min ); 
    }
    else 
    {
    	for ( i = n-1; i >= 0; i -- )
    	{
    		int ok = 0;
    	    for ( j = 1; j <= m; j ++ )
    	     if ( v[i][j] ) { ok = 1; break; }
    	    if ( ok == 1 ) { printf ( "%d\n", zs[i] ); break; }
       }
    }
	return 0;
}
/*
10 10 6
3 9
9 9
1 2
1 3
1 2
1 1
2 1
2 1
1 6
2 2
1 2 7
5 1 5
6 3 5
7 5 8
8 7 9
9 1 3

6 4 3
1 1
1 1
1 2
1 1
1 1
1 1
1 1 3
3 0 2
5 1 3
*/
