#include <cstdio>
#include <cstdlib>
#include <cstring>
using namespace std;

int com[5][5] = {{0,0,1,1,0}, 
                 {1,0,0,1,0},
                 {0,1,0,0,1},
                 {0,0,1,0,1},
                 {1,1,0,0,0},};
int n;
int alen, blen;
int a[210], b[210];

int main ()
{	
	freopen ( "rps.in", "r", stdin );
	freopen ( "rps.out", "w", stdout );
	scanf ( "%d%d%d", &n, &alen, &blen );
	int i, j;
	for ( i = 1; i <= alen; i ++ )
	 scanf ( "%d", &a[i] );
	for ( i = 1; i <= blen; i ++ )
	 scanf ( "%d", &b[i] );
	int ans1 = 0, ans2 = 0, p1 = 1, p2 = 1;
	while( n -- )
	{
	    ans1 += com[a[p1]][b[p2]];
	    ans2 += com[b[p2]][a[p1]];
	    p1 ++; if ( p1 == alen+1 ) p1 = 1;
	    p2 ++; if ( p2 == blen+1 ) p2 = 1;
	}
	printf ( "%d %d\n", ans1, ans2 );
	return 0;
}
