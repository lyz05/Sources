#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#define Mod 10007
using namespace std;

int main ()
{
	freopen ( "link.in", "w", stdout );
	int i;
	srand(time(0));
	int n = rand()%9000+2000; printf ( "%d\n", n );
	for ( i = 1; i < n; i ++ )
	 printf ( "%d %d\n", rand()%i+1, i+1 );
	for ( i = 1; i <= n; i ++ )
	 printf ( "%d ", rand()%1000+1 );
	printf ( "\n" ); 
	return 0;
}
