#include <cstdio>
#include <cstdlib>
#include <cstring>
#define Mod 10007
using namespace std;

struct node
{
	int x, y, next, d;
}a[210000]; int fir[210000], len; 

int n, Sum = 0, Max = -999999999;
int w[210000];

void ins ( int x, int y, int d )
{
	len ++;
	a[len].x = x; a[len].y = y; a[len].d = d;
	a[len].next = fir[x]; fir[x] = len;
}

void dfs ( int x )
{
	int k;
	for ( k = fir[x]; k; k = a[k].next )
	{
		int y = a[k].y;
		for ( int kk = fir[y]; kk; kk = a[kk].next )
		{
			int yy = a[kk].y;
			if ( yy == x ) continue;
			int now = w[x] * w[yy];
			if ( now > Max ) Max = now;
			Sum = (Sum + now) % Mod;
		}
	}
	//printf ( "%d %d\n", Max, Sum );
}

int main ()
{
    freopen ( "link.in", "r", stdin );
	freopen ( "link_vio.out", "w", stdout );
	memset ( fir, 0, sizeof(fir) ); len = 0;
	scanf ( "%d", &n );
	int i, j;
	for ( i = 1; i < n; i ++ )
	{
	    int x, y;
	    scanf ( "%d%d", &x, &y );
	    ins ( x, y, 1 );
	    ins ( y, x, 1 );
	}
	
	for ( i = 1; i <= n; i ++ ) scanf ( "%d", &w[i] );
	for ( i = 1; i <= n; i ++ )
	 dfs(i);
	
    printf ( "%d %d\n", Max, Sum );	
	return 0;
}
/*
5
1 2
2 3
3 4
4 5
1 5 2 3 10
*/
