#include <cstdio>
#include <cstdlib>
#include <cstring>
#define Mod 10007
using namespace std;

struct enode
{
	int x, y;
}bian[210000]; int len = 0;
int n, w[210000], Sum, Max;

struct node
{
	int fa, dep;
}a[210000];

struct Ceng
{
	int Max, Sum;
	Ceng() { Max = -999999999, Sum = 0; }
}Floor[210000];

int cmp ( const void *p1, const void *p2 )
{
	enode n1 = *(enode*) p1;
	enode n2 = *(enode*) p2;
	if ( n1.x != n2.x ) return n1.x - n2.x;
	return n1.y - n2.y;
}

int main ()
{
	freopen ( "link.in", "r", stdin );
	freopen ( "link.out", "w", stdout );
	scanf ( "%d", &n );
	int i, j;
	for ( i = 1; i < n; i ++ )
	{
		int x, y;
		scanf ( "%d%d", &x, &y );
		if ( x > y ) { int t = x; x = y; y = t; }
		bian[i].x = x; bian[i].y = y;
	}
	qsort ( bian+1, n-1, sizeof(enode), cmp );
	
	for ( i = 1; i <= n; i ++ )
	 scanf ( "%d", &w[i] );
	
	a[1].fa = 0; a[1].dep = 1; Sum = 0, Max = -999999999;
	for ( i = 1; i < n; i ++ )
	{
		int x = bian[i].x, y = bian[i].y;
		a[y].dep = a[x].dep+1; a[y].fa = x;
		
		if ( Floor[x].Sum == 0 ) 
		{
		    Floor[x].Sum = w[y];
			Floor[x].Max = w[y];	
		}
		else 
		{
			int jb = ( w[y]*Floor[x].Sum ) %Mod;
			Sum = ( Sum + ( jb*2 ) %Mod ) %Mod;
			int now = w[y]*Floor[x].Max;
			if ( now > Max ) Max = now;
			
			if ( w[y] > Floor[x].Max ) Floor[x].Max = w[y];
			Floor[x].Sum = (Floor[x].Sum+w[y]) % Mod;
		}
		
		if ( a[x].fa != 0 )
		{
			int gf = a[x].fa, jb = (w[gf]*w[y]%Mod);
			Sum = (Sum + (jb*2)%Mod)%Mod;
			int now = w[gf]*w[y]; 
			if ( now > Max ) Max = now;
		}
		//printf ( "%d %d\n", Max, Sum );
	}
	
	printf ( "%d %d\n", Max, Sum );
	return 0;
}
