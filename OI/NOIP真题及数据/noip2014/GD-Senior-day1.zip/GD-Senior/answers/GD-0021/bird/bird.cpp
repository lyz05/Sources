#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <fstream>
#include <cmath>

#define rep(i, l, r) for(int i = l; i <= r; i++)
#define down(i, l, r) for(int i = l; i >= r; i--)
#define MS 12345
#define MAX 1073741823

using namespace std;

struct node
{
	int p, x, y;
	bool operator < (const node &k) const { return p < k.p; }	
} c[MS];

int n, m, o, x[MS], y[MS], k[MS][1009], a, pp;
bool b;

int main()
{
	freopen("bird.in", "r", stdin); freopen("bird.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &o);
	rep(i, 1, n) scanf("%d%d", &x[i], &y[i]);
	rep(i, 1, o) scanf("%d%d%d", &c[i].p, &c[i].x, &c[i].y); 
	sort(c+1, c+1+o); pp = 1; c[o+1].p = 0;
	rep(i, 1, m) k[0][i] = 0;
	rep(i, 1, n)
	{
		rep(j, 1, x[i]) k[i][j] = MAX;
		rep(j, 1, m-x[i]) if (k[i-1][j] < k[i][j]) k[i][j+x[i]] = k[i-1][j]+1; else k[i][j+x[i]] = k[i][j]+1;
		rep(j, m-x[i]+1, m-1) if (min(k[i-1][j],k[i][j])+1 < k[i][m]) k[i][m] = min(k[i-1][j],k[i][j])+1;
		if (k[i-1][m]+1 < k[i][m]) k[i][m] = k[i-1][m]+1; 
		rep(j, y[i]+1, m) if (k[i-1][j] < k[i][j-y[i]]) k[i][j-y[i]] = k[i-1][j];
		if (c[pp].p == i)
		{
			rep(j, 1, c[pp].x) k[i][j] = MAX;
			rep(j, c[pp].y, m) k[i][j] = MAX;
		}
		b = true; rep(j, 1, m) if (k[i][j] < MAX) b = false;
		if (b) break;
		if (c[pp].p == i) pp++;
	}
	if (b) printf("0 %d\n", pp-1); else
	{	
		a = MAX;
		rep(i, 1, m) if (a > k[n][i]) a = k[n][i];
		printf("1 %d\n", a);
	}
	fclose (stdin); fclose(stdout);
	return 0;	
}
