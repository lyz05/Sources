#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <fstream>
#include <cmath>

#define rep(i, l, r) for(int i = l; i <= r; i++)
#define down(i, l, r) for(int i = l; i >= r; i--)
#define MS 456789
#define MAX 1073741823

using namespace std;

int n, m, a, w[MS], k[MS], maxa, ans;

struct node
{
	int x, y;
	bool operator < (const node &k) const { return x < k.x || (x == k.x && w[y] > w[k.y]); }	
} c[MS];

int main()
{
	freopen("link.in", "r", stdin); freopen("link.out", "w", stdout);
	scanf("%d", &n);
	rep(i, 1, n-1) scanf("%d%d", &c[i].x, &c[i].y);
	rep(i, 1, n) scanf("%d", &w[i]); m = n-1;
	rep(i, 1, m) c[i+m].x = c[i].y, c[i+m].y = c[i].x; m *= 2;
	sort(c+1, c+m+1); c[m+1].x = MAX;
	k[1] = 1; rep(i, 2, n+1) { k[i] = k[i-1]; while (c[k[i]].x < i) k[i]++; }
	maxa = -MAX; ans = 0;
	rep(i, 1, n)
	{
		if (k[i+1] - k[i] < 2) continue;
		if (maxa < w[c[k[i]].y] * w[c[k[i]+1].y]) maxa = w[c[k[i]].y] * w[c[k[i]+1].y];
		a = 0;
		rep(j, k[i], k[i+1]-1)
		{
			ans = (ans + a * w[c[j].y]) % 10007; a += w[c[j].y];
		}
	}
	ans *= 2; ans %= 10007;
	printf("%d %d\n", maxa, ans);
	fclose(stdin); fclose(stdout);
	return 0;	
}
