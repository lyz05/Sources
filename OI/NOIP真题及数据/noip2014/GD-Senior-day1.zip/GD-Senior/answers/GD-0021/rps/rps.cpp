#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <fstream>
#include <cmath>

#define rep(i, l, r) for(int i = l; i <= r; i++)
#define down(i, l, r) for(int i = l; i >= r; i--)
#define MS 1234
#define MAX 1073741823

using namespace std;

int n, na, nb, a[MS], b[MS], ka, kb ,sa, sb; 

int main()
{
	freopen("rps.in", "r", stdin); freopen("rps.out", "w", stdout);
	scanf("%d%d%d", &n, &na, &nb);
	rep(i, 1, na) scanf("%d", &a[i]);
	rep(i, 1, nb) scanf("%d", &b[i]);
	ka = na; kb = nb; sa = sb = 0;
	rep(i, 1, n)
	{
		if (ka == na) ka = 1; else ka++;
		if (kb == nb) kb = 1; else kb++;
		if (a[ka] == b[kb]) continue;
		if ((a[ka] == 0 && (b[kb] == 2 || b[kb] == 3)) || 
		   (a[ka] == 1 && (b[kb] == 0 || b[kb] == 3)) ||
		   (a[ka] == 2 && (b[kb] == 1 || b[kb] == 4)) ||
		   (a[ka] == 3 && (b[kb] == 2 || b[kb] == 4)) ||
		   (a[ka] == 4 && (b[kb] == 0 || b[kb] == 1))) sa++;
		else sb++;
	}
	printf("%d %d\n", sa, sb);
	fclose (stdin); fclose(stdout);
	return 0;	
}
