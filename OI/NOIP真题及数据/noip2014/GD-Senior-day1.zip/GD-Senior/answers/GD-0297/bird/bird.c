#include<stdio.h>
#include<string.h>
#define MAXN 10000+1

FILE *fin,*fout;

struct
{
	int X,Y;
}jump[MAXN];

struct
{
	int P,L,H;
}pipe[MAXN];

int n,m,k;
int pic[MAXN][MAXN];
int ans,min,max,fai;

void Input()
{
	ans=0;
	min=10000;
	max=0;
	fai=0;
	fscanf(fin,"%d%d%d",&n,&m,&k);
	int i,j;
	for (i=1;i<=n;i++)
	  fscanf(fin,"%d%d",&jump[i].X,&jump[i].Y);
	for (i=1;i<=k;i++)
	{
		fscanf(fin,"%d%d%d",&pipe[i].P,&pipe[i].L,&pipe[i].H);
		for(j=0;j<=pipe[i].L;j++)
		  pic[pipe[i].P][j]=1;
		for(j=pipe[i].H;j<=m;j++)
		  pic[pipe[i].P][j]=1;
	}
	for (i=0;i<=n;i++)
	  pic[i][0]=1;
}

void Solve(int x,int y,int z)
{
	if (pic[x][y]==0){
	  int i,w;
	  if (x>max) max=x;
	  if (x==n)
	  {
		  ans=1;
		  if (z<min) min=z;
	  }
 	  else
	  {
		  w=((m-y)/jump[x+1].X)+1;
		  if (y-jump[x+1].Y>0)
		    Solve(x+1,y-jump[x+1].Y,z);
		  for (i=1;i<=w;i++)
		  {
			  if ((i*jump[x+1].X+y)>=m)
		  	  {
				  z=z+i;
				  Solve(x+1,m,z);
				  z=z-i;
			  }
			  else
			  {
				  z+=i;
				  Solve(x+1,y+i*jump[x+1].X,z);
				  z-=i;
			  }
		  }
      }
    }
}

int main()
{
	fin=fopen("bird.in","r");
	fout=fopen("bird.out","w");
	int i,j;
	memset(pic,0,sizeof(pic));
	Input();
	for (i=1;i<=m;i++)
	  Solve(0,i,0);
	if (ans) fprintf(fout,"%d\n%d\n",ans,min);
	  else
	  {
	  	for (i=1;i<=k;i++)
	  	  if (max>pipe[i].P) fai++;
	  	fprintf(fout,"0\n%d\n",fai);
	  }
	fclose(fin);
	fclose(fout);
	return 0;
}
