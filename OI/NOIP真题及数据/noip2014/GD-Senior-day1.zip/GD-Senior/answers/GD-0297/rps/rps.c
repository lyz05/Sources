#include<stdio.h>
#define MAXN 200+1

int N,NA,NB;
int A[MAXN],B[MAXN];
int Sa,Sb;
int ka,kb;

FILE *fin,*fout;

void Fight(int n)
{
	int i;
	for (i=1;i<=n;i++)
	{
		ka++;
		kb++;
		if (A[ka]!=B[kb]) 
		{
			if (A[ka]==0)
			{
				if(B[kb]==2 || B[kb]==3) Sa++;
				else Sb++;
			}
			if (A[ka]==1)
			{
				if(B[kb]==0 || B[kb]==3) Sa++;
				else Sb++;
			}
			if (A[ka]==2)
			{
				if(B[kb]==1 || B[kb]==4) Sa++;
				else Sb++;
			}
			if (A[ka]==3)
			{
				if(B[kb]==2 || B[kb]==4) Sa++;
				else Sb++;
			}
			if (A[ka]==4)
			{
				if(B[kb]==0 || B[kb]==1) Sa++;
				else Sb++;
			}
		}
		if (ka==NA) ka=0;
		if (kb==NB) kb=0;
		
	}
}

int main()
{
	fin=fopen("rps.in","r");
	fout=fopen("rps.out","w");
	Sa=0;
	Sb=0;
	fscanf(fin,"%d%d%d",&N,&NA,&NB);
	ka=0;
	kb=0;
	int i,j;
	for (i=1;i<=NA;i++)
	  fscanf(fin,"%d",&A[i]);
	for (j=1;j<=NB;j++)
	  fscanf(fin,"%d",&B[j]);
	Fight(N);
	fprintf(fout,"%d %d\n",Sa,Sb);
	fclose(fin);
	fclose(fout);
	return 0;
}
