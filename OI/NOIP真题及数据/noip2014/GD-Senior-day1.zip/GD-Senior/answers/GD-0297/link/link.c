#include<stdio.h>
#define MAXN 200000+1

FILE *fin,*fout;

struct
{
	int link[2000];
	int h;
	int k;
}m[MAXN];

int n,h;
int max,ans;

void Go(int x,int y,int z)
{
	int j,t;
	if (y==2) 
	{
		t=m[h].k*m[x].k;
		if (t>max) max=t;
		ans+=t;
	}
	else
	for (j=1;j<=m[x].h;j++)
	{
		if (m[x].link[j]!=z)
		{
			y++;
			Go(m[x].link[j],y,x);
			y--;
		}
	}
}

int main()
{
	fin=fopen("link.in","r");
	fout=fopen("link.out","w");
	fscanf(fin,"%d",&n);
	max=0;
	ans=0;
	int i,a,b,j;
	for (i=1;i<n;i++)
	{
		fscanf(fin,"%d%d",&a,&b);
		m[a].h++;
		m[a].link[m[a].h]=b;
		m[b].h++;
		m[b].link[m[b].h]=a;
	}
	for (i=1;i<=n;i++)
	  fscanf(fin,"%d",&m[i].k);
	for (h=1;h<=n;h++)
	  Go(h,0,0); 
	ans=ans % 10007;
	fprintf(fout,"%d %d\n",max,ans);
	fclose(fin);
	fclose(fout);
	return 0;
}
