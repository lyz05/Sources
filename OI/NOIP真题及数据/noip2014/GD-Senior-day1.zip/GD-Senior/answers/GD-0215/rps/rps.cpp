#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
using namespace std;
#define rep(i,u,v) for (int i=(u);i<=(v);i++)
int n,na,nb,ansa,ansb;
int a[210],b[210];
int calc(int x,int y){
	if (x==0){
		if (y==2||y==3)return 1;
		else return 0;
	}
	else if (x==1){
		if (y==0||y==3)return 1;
		else return 0;
	}
	else if (x==2){
		if (y==1||y==4)return 1;
		else return 0;
	}
	else if (x==3){
		if (y==4||y==2)return 1;
		else return 0;
	}
	else {
		if (y==0||y==1)return 1;
		else return 0;
	}
}
int main(){
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	scanf("%d%d%d",&n,&na,&nb);
	ansa=ansb=0;
    rep(i,1,na)scanf("%d",&a[i]);
    rep(i,1,nb)scanf("%d",&b[i]);
    rep(i,1,n){
    	int x=i%na,y=i%nb;
    	if (x==0)x=na;
    	if (y==0)y=nb;
    	ansa+=calc(a[x],b[y]);
    	ansb+=calc(b[y],a[x]);
    }
    printf("%d %d\n",ansa,ansb);
	return 0;
}
