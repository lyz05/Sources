#include<cstdio>
#include<cstring>
#include<iostream>
#include<cstdlib>
using namespace std;
#define rep(i,u,v) for (int i=(u);i<=(v);i++)
#define reph(k,x) for (int k=fir[x];k;k=e[k].next)
#define N 200010
#define md 10007
struct node{
	int y,next;
}e[N];
int fir[N],w[N],list[N],h[N],ff[N],c[N];
int anssum,n,maxans,len,st;
int mymax(int x,int y){
	return x>y?x:y;
}
void ins(int x,int y){
	e[++len].y=y;e[len].next=fir[x];fir[x]=len;
}
int bfs(int s){
	int x,l=1,r=1,maxx=0,ret=s;
	list[1]=s;
	memset(h,-1,sizeof(h));
	ff[s]=h[s]=0;
	while (l<=r){
		int x=list[l++];
		reph(k,x){
			int y=e[k].y;
			if (h[y]==-1){
				h[y]=h[x]+1;
				ff[y]=x;
				list[++r]=y;
				if (h[y]>maxx){
					maxx=h[y];
					ret=y;
				}
			}
		}
	}
	return ret;
}
int getst(int s){
	c[0]=0;
	int mm=(h[s]+2)/2;
	while (s){
		c[++c[0]]=s;
		s=ff[s];
	}
	return c[mm];
}
void dfs(int fa,int x,int sum,int maxx){
	int nowsum=w[fa];
	if (x!=st){
		anssum=(anssum+sum*w[x])%md;
		maxans=mymax(maxans,maxx*w[x]);
	}
	maxx=w[fa];
	reph(k,x){
		int y=e[k].y;
		if (y==fa)continue;
		dfs(x,y,nowsum,maxx); 
		nowsum=(w[y]+nowsum)%md;
		maxx=mymax(maxx,w[y]);
	}
}
int main(){
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	int x,y;
	scanf("%d",&n);
	anssum=0;maxans=0;len=0;
	w[0]=0;
	rep(i,1,n-1){
		scanf("%d%d",&x,&y);
		ins(x,y);ins(y,x);
	}
	rep(i,1,n)scanf("%d",&w[i]);
	int xx=bfs(1);
	int yy=bfs(xx);
	st=getst(yy);
	dfs(0,st,0,0);
	anssum=(anssum*2)%md;
	printf("%d %d\n",maxans,anssum);
	return 0;
}
