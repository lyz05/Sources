#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
using namespace std;
#define rep(i,u,v) for (int i=(u);i<=(v);i++)
int n,m,k,ans;
int up[10001],down[10001],w[10001];
int mymin(int x,int y){
	return x>y?y:x;
}
void dfs(int x,int y,int sum){
	if (y<=0)return;
	if (sum>=ans)return;
	if (x==n){
		ans=mymin(ans,sum);
		return;
	}
	dfs(x+1,y-down[x],sum);
	dfs(x+1,mymin(y+up[x],m),sum+1);
	dfs(x+1,mymin(y+2*up[x],m),sum+2);
	dfs(x+1,mymin(y+3*up[x],m),sum+3);
	
}
void solve(){
	rep(i,1,m)dfs(0,i,0);
}
int main(){
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	int p,l,h;
	scanf("%d%d%d",&n,&m,&k);
	rep(i,0,n-1){
		scanf("%d%d",&up[i],&down[i]);
 		w[i+1]=w[i]+down[i];
	 }
	rep(i,1,k)scanf("%d%d%d",&p,&l,&h);
	if (m>w[n])printf("1\n0\n");
	else {
		ans=100000000;
		solve();
		if (ans==100000000) printf("0\n0\n");
		else	printf("1\n%d\n",ans);
	}
	return 0;
}
