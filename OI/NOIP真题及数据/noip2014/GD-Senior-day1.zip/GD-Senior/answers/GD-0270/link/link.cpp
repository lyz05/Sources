#include <cstdio>
#include <vector>
#include <algorithm>
#define ele int
using namespace std;
#define ls vector<ele>
#define maxn 200010
#define MOD 10007
ele n,_max,sum,w[maxn];
bool vis[maxn];
ls g[maxn];
inline void init(){
	ele u,v;
	scanf("%d",&n);
	for (ele i=0; i<n-1; ++i){
		scanf("%d%d",&u,&v);
		--u,--v;
		g[u].push_back(v);
		g[v].push_back(u);
	}
	for (ele i=0; i<n; ++i) scanf("%d",w+i);
	for (ele i=0; i<n; ++i) vis[i]=false;
	_max=-1;
	sum=0;
}
void search(ele target,ele i,ele dep){
	ele len;
	if (dep==2){
		if (target*w[i]>_max) _max=target*w[i];
		sum+=(target*w[i])%MOD;
		sum%=MOD;
		return;
	}
	len=g[i].size();
	vis[i]=true;
	for (ele j=0; j<len; ++j)
		if (!vis[g[i][j]])
			search(target,g[i][j],dep+1);
	vis[i]=false;
}
inline void solve(){
	for (ele i=0; i<n; ++i) search(w[i],i,0);
	printf("%d %d\n",_max,sum);
}
int main(){
	freopen("link.in","r",stdin); freopen("link.out","w",stdout);
	init();
	solve();
	return 0;
}

