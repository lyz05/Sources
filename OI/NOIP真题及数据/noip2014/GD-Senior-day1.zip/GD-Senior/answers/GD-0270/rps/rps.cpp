#include <cstdio>
#define ele int
using namespace std;
#define maxn 210
const ele win[5][5]={{0,2,1,1,2},{1,0,2,1,2},{2,1,0,2,1},{2,2,1,0,1},{1,1,2,2,0}};
ele n,na,nb,a[maxn],b[maxn];
inline void init(){
	scanf("%d%d%d",&n,&na,&nb);
	for (ele i=0; i<na; ++i) scanf("%d",a+i);
	for (ele i=0; i<nb; ++i) scanf("%d",b+i);
}
inline void solve(){
	ele i=0,j=0,s1=0,s2=0;
	for (ele p=0; p<n; ++p){
		if (a[i]<b[j]){
			if (win[a[i]][b[j]]==1) ++s1; else 
				if (win[a[i]][b[j]]==2) ++s2;
		}
		else if (a[i]>b[j]){
			if (win[b[j]][a[i]]==1) ++s2; else
				if (win[b[j]][a[i]]==2) ++s1;
		}
		++i,++j;
		if (i==na) i=0;
		if (j==nb) j=0;
	}
	printf("%d %d\n",s1,s2);
}
int main(){
	freopen("rps.in","r",stdin); freopen("rps.out","w",stdout);
	init();
	solve();
	return 0;
}

