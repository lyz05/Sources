#include <cstdio>
#include <algorithm>
#define ele int
using namespace std;
#define maxn 10010
#define maxm 1010
class node{
	public:
		ele p,l,h;
		inline bool operator<(node b) const{ return p<b.p; }
};
ele n,m,k,f1[maxn][maxm],f2[maxn][maxn],block[maxn][maxm],x[maxn],y[maxn];
node a[maxn];
inline void init(){
	scanf("%d%d%d",&n,&m,&k);
	for (ele i=0; i<n; ++i) scanf("%d%d",x+i,y+i);
	for (ele i=0; i<k; ++i) scanf("%d%d%d",&a[i].p,&a[i].l,&a[i].h);
	sort(a,a+k);
	f1[0][0]=false; 
	for (ele j=1; j<=m; ++j) f1[0][j]=true;
	for (ele i=0; i<=n; ++i)
		for (ele j=0; j<=m; ++j) block[i][j]=false;
	for (ele i=0; i<k; ++i){
		for (ele j=0; j<=a[i].l; ++j) block[a[i].p][j]=true;
		for (ele j=a[i].h; j<=m; ++j) block[a[i].p][j]=true;
	}
	for (ele j=0; j<=m; ++j) f2[0][j]=0;
}
inline void solve(){
	ele t,c;
	bool flag=false,fl=false;
	for (ele i=1; i<=n; ++i)
		for (ele j=0; j<=m; ++j){
			f1[i][j]=false;
			f2[i][j]=100000000;
			if (j==0 || block[i][j]){ f1[i][j]=false; continue; }
			if (j+y[i-1]<=m && f1[i-1][j+y[i-1]]){ f1[i][j]=true; f2[i][j]=f2[i-1][j+y[i-1]]; }
			//if (j+y[i-1]>m && f1[i-1][m]){ f1[i][j]=true; f2[i][j]=f2[i-1][j+y[i-1]]; } 
			if (j==m){
				for (ele p=j-1; p>j-x[i-1] && p>=0; --p)
					if (f1[i-1][p]){ f1[i][j]=true; f2[i][j]=min(f2[i][j],f2[i-1][p]+1); }
				//if (f1[i][j]) continue;
			}
			t=j;
			c=0;
			while (1){
				t-=x[i-1]; ++c;
				if (t<=0) break;
				if (f1[i-1][t]){ f1[i][j]=true; f2[i][j]=min(f2[i][j],f2[i-1][t]+c); }
			}
		}
	for (ele j=0; j<=m; ++j)
		if (f1[n][j]){ flag=true; break; }
	if (flag) printf("1\n"); else printf("0\n");
	if (!flag)
		for (ele j=k-1; j>=-1; --j){
			if (j==-1){ printf("0\n"); break; }
			for (ele p=0; p<=m; ++p)
				if (f1[a[j].p][p]){ printf("%d\n",j+1); fl=true; break; }
			if (fl) break;
		}
	if (flag){
		t=100000000;
		for (ele j=0; j<=m; ++j)
			if (f2[n][j]<t) t=f2[n][j];
		printf("%d\n",t);
	}
}
int main(){
	freopen("bird.in","r",stdin); freopen("bird.out","w",stdout);
	init();
	solve();
	return 0;
}

