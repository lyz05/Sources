#include<cstring>
#include<cstdio>
#include<algorithm>
using namespace std;
const int maxn = 11000;

int x[maxn],y[maxn],f[maxn][110][2];
bool bz[maxn];
int n,m,k,ans,p,l,h;

struct Node
{
	int doo,upp;
}t[maxn];

int pd(int x , int y)
{
	if (x == -1) return y;
	if (x > y) return y;
	return x;
}

int main()
{
	freopen("bird.in" , "r" , stdin);
	freopen("bird.out" , "w" , stdout);
	
	scanf("%d%d%d" , &n , &m , &k);
	
	memset(f , 255 , sizeof f);
	memset(bz, 0 , sizeof bz);
	
	for (int i = 0 ; i < n ; i ++) scanf("%d%d" , &x[i] , &y[i]);
	
	for (int i = 1 ; i <= k ; i ++)
	{
		scanf("%d%d%d" , &p , &l , &h);
		if (p < 0) continue;
		bz[p] = 1;
		t[p].doo = l;
		t[p].upp = h;
	}
	
	for (int i = 1 ; i <= m ; i ++)
	{
		if (!bz[0]) f[0][i][0] = f[0][i][1] = 0 ; else
		{
			if (i < t[0].upp && i > t[0].doo) f[0][i][0] = f[0][i][1] = 0;
		}
	}
	
	if (!bz[0]) ans = 0 ; else ans = 1;
	int flag = 0;
	
	for (int i = 1 ; i <= n ; i ++)
	{
		for (int j = 1 ; j <= m ; j ++)
		{
			/*up*/
			int tmp = j - x[i - 1];
			if (tmp > 0)
			{
				if (f[i - 1][tmp][0] != -1) f[i][j][1] = pd(f[i][j][1] , f[i - 1][tmp][0] + 1);
				if (f[i - 1][tmp][1] != -1) f[i][j][1] = pd(f[i][j][1] , f[i - 1][tmp][1] + 1);
				if (f[i][tmp][1] != -1) f[i][j][1] = pd(f[i][j][1] , f[i][tmp][1] + 1);
			}
			
			tmp = j + y[i - 1];
			if (tmp <= m)
			{
				if (f[i - 1][tmp][0] != -1) f[i][j][0] = pd(f[i][j][0] , f[i - 1][tmp][0]);
				if (f[i - 1][tmp][1] != -1) f[i][j][0] = pd(f[i][j][0] , f[i - 1][tmp][1]);
			}
		}
		for (int j = m - x[i - 1] ; j <= m ; j ++)
		{
			if (f[i][j][1] != -1)
			{
				f[i][m][1] = pd(f[i][m][1] , f[i][j][1] + 1);
			}
			if (f[i - 1][j][0] != -1)
			{
				f[i][m][1] = pd(f[i][m][1] , f[i - 1][j][0] + 1);
			}
			if (f[i - 1][j][1] != -1)
			{
				f[i][m][1] = pd(f[i][m][1] , f[i - 1][j][1] + 1);
			}
		}
		if (bz[i])
		{
			for (int j = 1 ; j <= m ; j ++) 
				if (j <= t[i].doo || j >= t[i].upp) f[i][j][0] = f[i][j][1] = -1;
		}
		for (int j = 1 ; j <= m ; j ++) if (f[i][j][0] != -1 || f[i][j][1] != -1) {flag = 1 ; break;}
		if (flag && bz[i]) ans ++;
		if (!flag) break;
	}
	
	if (!flag) 
	{
		printf("0\n%d\n" , ans);
	} else
	{
		printf("1\n");
		ans = n;
		for (int i = 1 ; i <= m ; i ++)
		{
			if (f[n][i][1] != -1 && f[n][i][1]< ans) ans = f[n][i][1];
			if (f[n][i][0] != -1 && f[n][i][0]< ans) ans = f[n][i][0];
		}
		printf("%d\n" , ans);
	}
	
	return 0;
	
}
