#include<cstring>
#include<algorithm>
#include<cstdio>
using namespace std;
const long long mo = 10007;
const int maxn = 200100;

struct Node
{
	int ma,ma2,num;
}t[maxn];

int a[maxn],b[maxn];
long long v[maxn],sum[maxn];
long long ansma,ans1;
int n;

void Init()
{
	scanf("%d" , &n);
	for (int i = 1 ; i < n ; i ++) scanf("%d%d" , &a[i] , &b[i]);
	for (int i = 1 ; i <= n ; i ++) scanf("%lld" , &v[i]);
	memset(sum , 0 , sizeof sum);
	memset(t , 0 , sizeof t);
	for (int i = 1 ; i < n ; i ++)
	{
		sum[a[i]] += v[b[i]];
		if (v[b[i]] > t[a[i]].ma)
		{
			t[a[i]].ma2 = t[a[i]].ma;
			t[a[i]].ma = v[b[i]];
			t[a[i]].num = b[i];
		} else
		{
			if (v[b[i]] > t[a[i]].ma2) t[a[i]].ma2 = v[b[i]];
		}
		
		sum[b[i]] += v[a[i]];
		if (v[a[i]] > t[b[i]].ma)
		{
			t[b[i]].ma2 = t[b[i]].ma;
			t[b[i]].ma = v[a[i]];
			t[b[i]].num = a[i];
		} else
		{
			if (v[a[i]] > t[b[i]].ma2 ) t[b[i]].ma2 = v[a[i]];
		}
	}
	
}

void Work()
{
	ans1 = 0 , ansma = 0;
	for (int i = 1 ; i < n ; i ++)
	{
		ans1 += (sum[b[i]] - v[a[i]]) * v[a[i]];
		ans1 += (sum[a[i]] - v[b[i]]) * v[b[i]];
		ans1 %= mo;
		
		long long st = 0;
		if (t[a[i]].num != b[i]) st = v[b[i]] * t[a[i]].ma ; else st = v[b[i]] * t[a[i]].ma2;
		long long st2 = 0;
		if (t[b[i]].num != a[i]) st2 = v[a[i]] * t[b[i]].ma ; else st2 = v[a[i]] * t[b[i]].ma2;
		
		if (st < st2) st = st2;
		if (ansma < st) ansma = st;
	}
	printf("%lld %lld" , ansma , ans1);
}

int main()
{
	freopen("link.in" , "r" , stdin);
	freopen("link.out"  , "w" , stdout);
	
	Init();
	Work();
	
	return 0;
}
