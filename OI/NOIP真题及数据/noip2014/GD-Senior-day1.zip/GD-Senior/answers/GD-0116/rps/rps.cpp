#include<cstring>
#include<cstdio>
#include<algorithm>
using namespace std;
int n,na,nb,ans1,ans2;
int a[400],b[400],pd[10][10];

int main()
{
	freopen("rps.in" , "r" , stdin);
	freopen("rps.out" , "w" , stdout);
	
	scanf("%d%d%d" , &n , &na , &nb);
	for (int i = 1 ; i <= na ; i ++) scanf("%d" , &a[i]);
	for (int i = 1 ; i <= nb ; i ++) scanf("%d" , &b[i]);
	
	pd[0][0] = 0 , pd[0][1] = 0 , pd[0][2] = 1 , pd[0][3] = 1 , pd[0][4] = 0;
	pd[1][0] = 1 , pd[1][1] = 0 , pd[1][2] = 0 , pd[1][3] = 1 , pd[1][4] = 0;
	pd[2][0] = 0 , pd[2][1] = 1 , pd[2][2] = 0 , pd[2][3] = 0 , pd[2][4] = 1;
	pd[3][0] = 0 , pd[3][1] = 0 , pd[3][2] = 1 , pd[3][3] = 0 , pd[3][4] = 1;
	pd[4][0] = 1 , pd[4][1] = 1 , pd[4][2] = 0 , pd[4][3] = 0 , pd[4][4] = 0;
	
	int l = 0 , r = 0;
	ans1 = 0 , ans2 = 0;
	for (int i = 1 ; i <= n ; i ++)
	{
		l = l % na + 1;
		r = r % nb + 1;
		ans1 += pd[a[l]][b[r]];
		ans2 += pd[b[r]][a[l]];
	}
	printf("%d %d" , ans1 , ans2);
	return 0;
}
