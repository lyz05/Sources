#include <cstdio>
#include <cstring>
#include <algorithm>

const int N = 1000 + 10, M = 100 + 10, INF = 0x3f3f3f3f;

int n, m, k, inf[N], sup[N], x[N], y[N];
int dp[N][M];
bool pipe[M];

inline void cmin(int &a, int b) { if (b < a) a = b; }

void solve(int &flag, int &ans) {
	memset(dp, 0x3f, sizeof dp);
	for (int i = 1; i <= m; ++i) dp[0][i] = 0;
	for (int i = 0; i < n; ++i) {
		flag = 0;
		for (int j = inf[i]; j <= sup[i]; ++j) {
			if (dp[i][j] != INF) {
				flag = 1;
				int nj = j - y[i], cnt;
				if (inf[i + 1] <= nj && nj <= sup[i + 1]) cmin(dp[i + 1][nj], dp[i][j]);
				for (nj = j + x[i], cnt = 1;; nj += x[i], ++cnt) {
					if (nj > m) nj = m;
					if (inf[i + 1] <= nj && nj <= sup[i + 1]) cmin(dp[i + 1][nj], dp[i][j] + cnt);
					if (nj == m) break;
				}
			}
		}
		if (flag == 0) {
			ans = 0;
			for (int j = 0; j < i; ++j) ans += pipe[j];
			return;
		}
	}
	ans = INF;
	for (int j = inf[n]; j <= sup[n]; ++j) cmin(ans, dp[n][j]);
}

int main() {
	freopen("bird.in", "r", stdin);
	freopen("bird.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	for (int i = 0; i < n; ++i) scanf("%d%d", x + i, y + i);
	for (int i = 0; i <= n; ++i) inf[i] = 1, sup[i] = m;
	for (int i = 1, p; i <= k; ++i) {
		scanf("%d", &p);
		scanf("%d%d", inf + p, sup + p);
		inf[p]++, sup[p]--;
		pipe[p] = true;
	}
	int flag, ans;
	solve(flag, ans);
	printf("%d\n%d\n", flag, ans);
	return 0;
}
