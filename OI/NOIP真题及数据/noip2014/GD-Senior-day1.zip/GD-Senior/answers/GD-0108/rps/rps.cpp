#include <cstdio>

const int N = 200 + 10;

const int map[5][5] = {{0, -1, 1, 1, -1},
                       {1, 0, -1, 1, -1},
											 {-1, 1, 0, -1, 1},
											 {-1, -1, 1, 0, 1},
											 {1, 1, -1, -1, 0}};

int n, na, nb;
int a[N], b[N];

int main() {
	freopen("rps.in", "r", stdin);
	freopen("rps.out", "w", stdout);
	scanf("%d%d%d", &n, &na, &nb);
	for (int i = 0; i < na; ++i) scanf("%d", a + i);
	for (int i = 0; i < nb; ++i) scanf("%d", b + i);
	int cntx = 0, cnty = 0;
	for (int i = 0; i < n; ++i) {
		int x = a[i % na], y = b[i % nb];
		switch (map[x][y]) {
			case 1: cntx++; break;
			case -1: cnty++; break;
		}
	}
	printf("%d %d\n", cntx, cnty);
	return 0;
}
