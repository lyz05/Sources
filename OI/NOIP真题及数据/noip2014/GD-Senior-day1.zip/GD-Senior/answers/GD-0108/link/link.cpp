#include <cstdio>
#include <vector>
#include <algorithm>

const int N = 200000 + 10, E = N * 2, MOD = 10007;

int n, w[N];

int adj[N];
int to[E], next[E];

inline void link(int a, int b) {
	static int cnt = 0;
	to[++cnt] = b;
	next[cnt] = adj[a];
	adj[a] = cnt;
}

int ans = 0, mx = 0;

void bfs(int s) {
	static int q[N], *qf, *qr, fa[N];
	qf = qr = q;
	for (*qr++ = s; qf < qr;) {
		int a = *qf++, sum = 0;
		static std::vector<int> pre, suf;
		pre.clear(), suf.clear();
		for (int it = adj[a]; it; it = next[it]) {
			int b = to[it];
			if (b != fa[a]) fa[*qr++ = b] = a;
			pre.push_back(w[b]), suf.push_back(w[b]);
			(sum += w[b]) %= MOD;
		}
		for (int i = 1; i < pre.size(); ++i) pre[i] = std::max(pre[i - 1], pre[i]);
		for (int i = suf.size() - 2; i >= 0; --i) suf[i] = std::max(suf[i + 1], suf[i]);
		for (int it = adj[a], cur = 0; it; it = next[it], ++cur) {
			int b = to[it];
			(ans += ((sum - w[b] + MOD) % MOD) * w[b]) %= MOD;
			int tmp = 0;
			if (cur > 0) tmp = std::max(tmp, pre[cur - 1]);
			if (cur + 1 < suf.size()) tmp = std::max(tmp, suf[cur + 1]);
			mx = std::max(mx, w[b] * tmp);
		}
	}
}

int main() {
	freopen("link.in", "r", stdin);
	freopen("link.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1, u, v; i < n; ++i) {
		scanf("%d%d", &u, &v);
		link(u, v);
		link(v, u);
	}
	for (int i = 1; i <= n; ++i) scanf("%d", w + i);
	bfs(1);
	printf("%d %d\n", mx, ans);
	return 0;
}
