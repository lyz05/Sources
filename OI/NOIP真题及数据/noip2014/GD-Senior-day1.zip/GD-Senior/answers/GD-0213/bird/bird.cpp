#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<vector>
#include<set>
#include<map>
#include<ctime>
#include<queue>
#define rep(i,x,y) for(i=x;i<=y;i++)
#define reps(i,x,y) for(i=x;i>=y;i--)
#define INF 0x5fffffffffffll
#define MP make_pair
#define PB push_back
#define N 10010
#define M 1010
using namespace std;
typedef long long LL;
typedef double DB;
typedef vector<int> VI;
int n,m,K;
LL Mov[2][M],Po[2][M],f[2][M];
int X[N],Y[N];
bool mark[N];
int L[N],H[N];
void init(){
	int i,j,k;
	scanf("%d%d%d",&n,&m,&K);
	rep(i,0,n-1){
		scanf("%d%d",&X[i],&Y[i]);
	}
	rep(i,1,K){
		int p;
		scanf("%d",&p);
		mark[p]=1;
		scanf("%d%d",&L[p],&H[p]);
	}
}
bool peng(int p,int w){
	return w<=L[p]||w>=H[p];
}
void solve(){
	int i,j,k;
	int Cou=0;
//	rep(i,0,n)
	//	rep(j,0,m)f[i][j]=Po[i][j]=Mov[i][j]=INF;

	int nt=0,now=1;
	rep(j,1,m)Po[0][j]=0;
	rep(i,0,n-1){
		bool o=0;
		swap(nt,now);
		rep(j,1,m)f[nt][j]=Po[nt][j]=Mov[nt][j]=INF;
		
		rep(j,1,m){
			//if(Mov[i][j]||Po[i][j])f[i][j]=1;
			f[now][j]=min(Mov[now][j],Po[now][j]);
			if(i){
				int nxt=min(m,j+X[i-1]);
				Mov[now][nxt]=min(Mov[now][j]+1,Mov[now][nxt]);
			}
			if(mark[i]&&peng(i,j)){
				f[now][j]=INF;
				continue;
			}
			if(f[now][j]<INF){
				o=1;
				int nxt=min(m,j+X[i]);
				Mov[nt][nxt]=min(f[now][j]+1,Mov[nt][nxt]);
				if(j-Y[i])Po[nt][j-Y[i]]=min(f[now][j],Po[nt][j-Y[i]]);
			}
		}
		if(!o){
			puts("0");
			printf("%d\n",Cou);
			return;
		}
		if(mark[i])Cou++;
	}
	puts("1");

	LL ans=INF;
	rep(j,1,m){
		ans=min(ans,Mov[nt][j]);
		ans=min(ans,Po[nt][j]);
	}
	cout<<ans<<endl;
}
int main(){
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	init();
	solve();
	return 0;
} 
