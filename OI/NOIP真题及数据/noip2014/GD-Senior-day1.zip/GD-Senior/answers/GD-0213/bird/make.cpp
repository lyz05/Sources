#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<vector>
#include<set>
#include<map>
#include<ctime>
#include<queue>
#define rep(i,x,y) for(i=x;i<=y;i++)
#define reps(i,x,y) for(i=x;i>=y;i--)
#define INF 0x5fffffff
#define MP make_pair
#define PB push_back
using namespace std;
typedef long long LL;
typedef double DB;
typedef vector<int> VI;
int a[11000];
int main(){
	freopen("bird.in","w",stdout);
//	freopen(".out","w",stdout);
	int i,j,k;
	srand(time(0));
	int n=rand()%100+5,m=rand()%100+5,K=rand()%(n-1)+1;
	printf("%d %d %d\n",n,m,K);
	rep(i,0,n-1){
		printf("%d %d\n",rand()%(m-1)+1,rand()%(m-1)+1);
	}
	rep(i,1,n-1)a[i]=i;
	rep(i,1,n-1){
		swap(a[i],a[rand()%(n-1)+1]);
	}
	rep(i,1,10000){
		swap(a[rand()%(n-1)+1],a[rand()%(n-1)+1]);
	}
	rep(i,1,K){
		int L=rand()%(m-2);
		int H=rand()%(m-L-1)+L+2;
		printf("%d %d %d\n",a[i],L,H);
	}
	return 0;
} 
