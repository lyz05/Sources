#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<vector>
#include<set>
#include<map>
#include<ctime>
#include<queue>
#define rep(i,x,y) for(i=x;i<=y;i++)
#define reps(i,x,y) for(i=x;i>=y;i--)
#define INF 0x5fffffff
#define MP make_pair
#define PB push_back
using namespace std;
typedef long long LL;
typedef double DB;
typedef vector<int> VI;
const int c[5][5]={0,-1,1,1,-1,
                   1,0,-1,1,-1,
                  -1,1,0,-1,1,
                  -1,-1,1,0,1,
                   1,1,-1,-1,0
};
int n1,n2,n;
int a[210],b[210];
void solve(){
	 int i,j,k;
	 scanf("%d%d%d",&n,&n1,&n2);
	 rep(i,1,n1)scanf("%d",&a[i]);
	 rep(i,1,n2)scanf("%d",&b[i]);
	 i=1;j=1;
	 int ans1=0,ans2=0;
	 while(n--){
		int val=c[a[i]][b[j]];
		if(val==1)ans1++;
		if(val==-1)ans2++;
		i++;j++;
		if(i>n1)i=1;
		if(j>n2)j=1;
	 }
	 printf("%d %d\n",ans1,ans2);
}
int main(){
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	//init();
	solve();
	return 0;
} 
