#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<vector>
#include<set>
#include<map>
#include<ctime>
#include<queue>
#define rep(i,x,y) for(i=x;i<=y;i++)
#define reps(i,x,y) for(i=x;i>=y;i--)
#define INF 0x5fffffff
#define MP make_pair
#define PB push_back
#define Mod 10007
using namespace std;
typedef long long LL;
typedef double DB;
typedef vector<int> VI;
int n;
int m[300][300];
int w[300];
void solve(){
	int i,j,k;
	scanf("%d",&n);
	memset(m,63,sizeof(m));
	rep(i,1,n-1){
		scanf("%d%d",&j,&k);
		m[j][k]=m[k][j]=1;
	}
	rep(i,1,n)scanf("%d",&w[i]);
	rep(i,1,n)m[i][i]=0;
	rep(k,1,n){
		rep(i,1,n)
			rep(j,1,n)
				m[i][j]=min(m[i][k]+m[k][j],m[i][j]);
	}
	LL Max=0,ans=0;
	rep(i,1,n){
		rep(j,1,n){
			if(m[i][j]==2){
				Max=max(Max,LL(w[i])*w[j]);
				ans=(ans+w[i]*w[j]%Mod)%Mod;
			}
		}
	}
	cout<<Max<<' '<<ans<<endl;
}
int main(){
	freopen("link.in","r",stdin);
//	freopen(".out","w",stdout);
	//init();
	solve();
	return 0;
} 
