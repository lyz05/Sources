#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<vector>
#include<set>
#include<map>
#include<ctime>
#include<queue>
#define rep(i,x,y) for(i=x;i<=y;i++)
#define reps(i,x,y) for(i=x;i>=y;i--)
#define INF 0x5fffffff
#define MP make_pair
#define PB push_back
#define Mod 10007
#define N 210000
using namespace std;
typedef long long LL;
typedef double DB;
typedef vector<int> VI;
LL mson[N],sson[N];
VI G[N];
LL ans,Max;
int w[N];
int n;
vector<pair<int,int> >L;
LL M(LL val){
   while(val<0)val+=Mod;
   while(val>=Mod)val-=Mod;
   return val;
}
/*void dfs(int x,int fa){
	int i,j,k;
	for(k=0;k<G[x].size();k++){
		int y=G[x][k];
		if(y==fa)continue;
		dfs(y,x);
		Max=max(Max,mson[x]*w[y]);//1
 		mson[x]=max(mson[x],LL(w[y]));
 		ans=M(ans+sson[x]*w[y]%Mod);//1
 		sson[x]=M(sson[x]+w[y]);
 		
 		Max=max(Max,LL(w[x])*mson[y]);
 		ans=M(ans+LL(w[x])*sson[y]%Mod);
	}
	
}*/
void bfs(){
	int i,j,k;
	L.PB(MP(1,0));
	for(i=0;i<L.size();i++){
		int x=L[i].first,fa=L[i].second;
		for(k=0;k<G[x].size();k++){
			int y=G[x][k];
			if(y==fa)continue;
			L.PB(MP(y,x));
		}
	}
	for(i=L.size()-1;i>=0;i--){
		int x=L[i].first,fa=L[i].second;
		for(k=0;k<G[x].size();k++){
			int y=G[x][k];
			if(y==fa)continue;
			Max=max(Max,mson[x]*w[y]);//1
 			mson[x]=max(mson[x],LL(w[y]));
 			ans=M(ans+sson[x]*w[y]%Mod);//1
 			sson[x]=M(sson[x]+w[y]);
 		
 			Max=max(Max,LL(w[x])*mson[y]);
 			ans=M(ans+LL(w[x])*sson[y]%Mod);
		}
	}
}
void solve(){
	int i,j,k;
	scanf("%d",&n);
	rep(i,1,n-1){
		scanf("%d%d",&j,&k);
		G[j].PB(k);
		G[k].PB(j);
	}
	rep(i,1,n)scanf("%d",&w[i]);
	ans=Max=0;
	//dfs(1,0);
	bfs();
	cout<<Max<<' '<<M(ans+ans)<<endl;
}
int main(){
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	//init();
	solve();
	return 0;
} 
