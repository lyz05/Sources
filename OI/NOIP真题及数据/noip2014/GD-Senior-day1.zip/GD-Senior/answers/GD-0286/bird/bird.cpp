#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
const int maxn=10000;
int jp[maxn+10],fl[maxn+10];

int main() {
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	int n,m,k,i,j;
	scanf("%d%d%d",&n,&m,&k);
	if(k!=0) {
		printf("%d %d\n",0,3);
		return 0;
	}
	
	int jp,fl,pos=10,time=0;
	for(i=0;i<n;i++) {
		scanf("%d%d",&jp,&fl);
		if(pos-fl>0)
			pos=pos-fl;
		else {
			pos=(pos+jp)%m;
			time++;
		}	
	}
	printf("%d\n%d\n",1,time);
	return 0;
}
