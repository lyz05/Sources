#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
int comp[5][5];
int ta[200+50],tb[200+50];

int main() {
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	
	int n,na,nb,i,j;
	scanf("%d%d%d",&n,&na,&nb);
	for(i=1;i<na;i++)
		scanf("%d",&ta[i]);
	scanf("%d",&ta[0]);
	for(i=1;i<nb;i++)
		scanf("%d",&tb[i]);
	scanf("%d",&tb[0]);
	
	comp[0][0]=0; comp[0][1]=-1; comp[0][2]=1; comp[0][3]=1; comp[0][4]=-1;
	comp[1][0]=1; comp[1][1]=0; comp[1][2]=-1; comp[1][3]=1; comp[1][4]=-1;
	comp[2][0]=-1; comp[2][1]=1; comp[2][2]=0; comp[2][3]=-1; comp[2][4]=1;
	comp[3][0]=-1; comp[3][1]=-1; comp[3][2]=1; comp[3][3]=0; comp[3][4]=1;
	comp[4][0]=1; comp[4][1]=1; comp[4][2]=-1; comp[4][3]=-1; comp[4][4]=0;
	
	int ansa=0,ansb=0;
	for(i=1;i<=n;i++) {
		if(comp[ta[i%na]][tb[i%nb]]==1) 
			ansa++;
		if(comp[ta[i%na]][tb[i%nb]]==-1)
			ansb++;	
	}
	printf("%d %d\n",ansa,ansb);
	return 0;
}
