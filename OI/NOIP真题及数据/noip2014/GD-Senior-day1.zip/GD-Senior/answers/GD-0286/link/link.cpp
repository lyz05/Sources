#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>

const int maxn=5000;
bool link[maxn+10][maxn+10];
int dq[maxn+10][maxn+10],num[maxn+10],ans=0,tot=0,n;

void dfs(int pprev,int prev,int now,int dep) {
	if(dep==2) {
		int d=num[pprev]*num[now];
		if(d>ans) ans=d;
		tot=(tot+d+d)%10007;
		dq[pprev][now]=d;
		return;
	}
	int i;
	for(i=now+1;i<=n;i++) {
		if(link[now][i]&&i!=pprev&&i!=prev)
			dfs(pprev,now,i,2); 
	}
	return;
}

int main() {
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	int i,j,x,y;
	scanf("%d",&n);
	memset(link,0,sizeof(link));
	memset(dq,0,sizeof(dq));
	for(i=1;i<n;i++) {
		scanf("%d%d",&x,&y);
		link[x][y]=1;
		link[y][x]=1;
	}
	for(i=1;i<=n;i++) 
		scanf("%d",&num[i]);
	for(j=1;j<=n;j++)
		for(i=j+1;i<=n;i++) {
			if(link[j][i]==0) continue;
			dfs(j,j,i,1);
		}
	printf("%d %d\n",ans,tot);
	return 0;
}
