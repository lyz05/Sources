#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstring>
using namespace std;
const int N = 10005, M = 1005;

int LimT[N], LimB[N], U[N], D[N];
bool Limited[N];
int f[N][M];
int n, m, p, Inf;

void preprocessing()
{
	ios :: sync_with_stdio( 0 );
	cin >> n >> m >> p;
	for ( int i=1; i<=n; ++i ) cin >> U[i] >> D[i];
	fill( LimT, LimT + n + 1, m + 1 );
	for ( int i=0, x, B, T; i<p; ++i )
	{
		cin >> x >> B >> T;
		LimT[x] = min( LimT[x], T );
		LimB[x] = max( LimB[x], B );
		Limited[x] = 1;
	}
	memset( f, 60, sizeof( f ) ); Inf = f[0][0];
	for ( int i=1; i<=m; ++i ) f[0][i] = 0;
}

void work()
{	
	for ( int i=0; i<n; ++i )
	{
		for ( int j=LimB[i]+1; j<LimT[i]; ++j )
			for ( int k=1, p=min( j+U[i], m ); p<LimT[i]; p=min( p+U[i], m ), ++k )
				if ( f[i][p] < f[i][j] + k ) break;
				else f[i][p] = f[i][j] + k;
		/*for ( int j=LimT[i]-1; j>LimB[i]; --j )
			for ( int k=1, p=j-D[i]; p>LimB[i]; ++k, p-=D[i] )
				if ( f[i][p] < f[i][j] + k ) break;
				else f[i][p] = f[i][j] + k;*/
		for ( int j=LimB[i]+1; j<LimT[i]; ++j )
		{
			int p = min( j + U[ i+1 ], m );
			if ( LimB[ i+1 ] < p && p < LimT[ i+1 ] ) 
				f[ i+1 ][p] = min( f[ i+1 ][p], f[i][j] + 1 );
			if ( LimB[ i+1 ] < j - D[ i+1 ] && j - D[ i+1 ] < LimT[ i+1 ] )
				f[ i+1 ][ j - D[ i+1 ] ] = min( f[ i+1 ][ j - D[ i+1 ] ], f[i][j] );
		}
	}
	int Res = Inf;
	for ( int j=1; j<=m; ++j ) Res = min( Res, f[n][j] );
	if ( Res < Inf ) 
	{
		cout << 1 << endl << Res << endl;
		return;
	}
	int Lim = n, Cnt = 0;
	for ( int i=n-1; i>=0; --i )
	{
		Lim = i;
		bool Done = 0;
		for ( int j=1; j<=m; ++j )
			if ( f[i][j] < Inf )
			{
				Done = 1; break;
			}
		if ( Done ) break;
	}
	for ( int i=0; i<=Lim; ++i )
		if ( Limited[i] ) ++Cnt;
	cout << 0 << endl << Cnt << endl;
}

int main()
{
	freopen( "bird.in", "r", stdin );
	freopen( "bird.out", "w", stdout );
	preprocessing();
	work();
	fclose( stdin ); fclose( stdout );
	return 0;
}

