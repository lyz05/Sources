#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstring>
using namespace std;
const int map[5][5] = 
{
	{ 0, 0, 1, 1, 0 },
	{ 1, 0, 0, 1, 0 },
	{ 0, 1, 0, 0, 1 },
	{ 0, 0, 1, 0, 1 },
	{ 1, 1, 0, 0, 0 }
};
const int N = 205;

int a[N], b[N];
int Q, n, m;
int ResA, ResB;

int main()
{	
	freopen( "rps.in", "r", stdin );
	freopen( "rps.out", "w", stdout );
	cin >> Q >> n >> m;
	for ( int i=0; i<n; ++i ) cin >> a[i];
	for ( int i=0; i<m; ++i ) cin >> b[i];
	for ( int i=n; i<Q; ++i ) a[i] = a[ i-n ];
	for ( int i=m; i<Q; ++i ) b[i] = b[ i-m ];
	for ( int i=0; i<Q; ++i )
	{
		ResA += map[ a[i] ][ b[i] ];
		ResB += map[ b[i] ][ a[i] ];
	}
	cout << ResA << " " << ResB << endl;
	fclose( stdin ); fclose( stdout );
	return 0;
}

