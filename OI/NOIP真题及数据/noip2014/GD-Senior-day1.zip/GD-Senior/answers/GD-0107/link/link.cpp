#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <vector>
using namespace std;
const int N = 200005, Mo = 10007;

vector < int > e[N];
int a[N];
int n, ResSum, ResMax;

long long sqr( long long x ) { return x * x; }

int main()
{
	freopen( "link.in", "r", stdin );
	freopen( "link.out", "w", stdout );
	ios :: sync_with_stdio( 0 );
	cin >> n;
	int x, y;
	for ( int i=1; i<n; ++i )
	{
		cin >> x >> y; --x, --y;
		e[x].push_back( y );
		e[y].push_back( x );
	}
	for ( int i=0; i<n; ++i ) cin >> a[i];
	for ( int i=0; i<n; ++i )
	{
		long long Sum = 0, Dec = 0;
		int Maxi = 0, Maxii = 0;
		for ( int j=0; j<e[i].size(); ++j )
		{
			Sum = ( Sum + a[ e[i][j] ] ) % Mo; 
			Dec = ( Dec + sqr( a[ e[i][j] ] ) ) % Mo; 
			if ( a[ e[i][j] ] > Maxi ) Maxii = Maxi, Maxi = a[ e[i][j] ];
			else if ( a[ e[i][j] ] > Maxii ) Maxii = a[ e[i][j] ];
		}
		ResSum = ( ResSum + sqr( Sum ) - Dec + Mo ) % Mo;
		ResMax = max( ResMax, Maxi * Maxii );
	}
	cout << ResMax << " " << ResSum << endl;
	fclose( stdin ); fclose( stdout );
	return 0;
}

