#include<iostream>
#include<stdio.h>
#include<string.h>
using namespace std;
int f[10][10],a[210],b[210],na,nb,n,ansa,ansb,xa,xb;
int main()
{
    freopen("rps.in","r",stdin);
    freopen("rps.out","w",stdout);
    f[0][2]=f[0][3]=1;f[1][0]=f[1][3]=1;
    f[2][1]=f[2][4]=1;f[3][2]=f[3][4]=1;
    f[4][0]=f[4][1]=1;
    scanf("%d%d%d",&n,&na,&nb);
    for(int i=0;i<na;i++)scanf("%d",&a[i]);
    for(int i=0;i<nb;i++)scanf("%d",&b[i]);
    ansa=ansb=xa=xb=0;
    for(int i=1;i<=n;i++)
    {
	    ansa+=f[a[xa]][b[xb]];
	    ansb+=f[b[xb]][a[xa]];
	    xa=(xa+1)%na;
		xb=(xb+1)%nb;
	}
    printf("%d %d\n",ansa,ansb);
return 0;
}
