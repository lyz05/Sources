#include<iostream>
#include<stdio.h>
#include<string.h>
using namespace std;
int mini(int a,int b)
{
   if(a<b)return a;
   return b;
}
int f[110][110],w[200010],n,ans,maxa,x,y;
struct Link
{
   int num;
   Link *nextit;
};
Link a[200010];
void dfs(int father,int loc,int dep)
{
	if(dep==2)
    {
	    x=w[father]*w[loc];
	    if(x>maxa)maxa=x;
	    ans=(ans+x)%10007;
	    return;
	}
	Link *q;
	q=a[loc].nextit;
	while(q!=NULL)
	{
	    if(q->num!=father)dfs(father,q->num,dep+1);
	    q=q->nextit;
	}
}
int main()
{
    freopen("link.in","r",stdin);
    freopen("link.out","w",stdout);
    scanf("%d",&n);
    if(n<=100)
    {        
        for(int i=1;i<=n;i++)
           for(int j=1;j<=n;j++)
             f[i][j]=10000;
		for(int i=1;i<n;i++)
		{
		   scanf("%d%d",&x,&y);
		   f[x][y]=f[y][x]=1;
		}
		for(int k=1;k<=n;k++)
	       for(int i=1;i<=n;i++)
		      for(int j=1;j<=n;j++)	
		      {
			     if(i==j)continue;
				 f[i][j]=mini(f[i][k]+f[k][j],f[i][j]);			     
			  }
			  
	}
	else
	{
	     Link *p;
		 for(int i=1;i<n;i++)
	     {
		    scanf("%d%d",&x,&y);
		    p=new Link;
		    p->num=y;
		    p->nextit=a[x].nextit;
		    a[x].nextit=p;
		    p=new Link;
		    p->num=x;
		    p->nextit=a[y].nextit;
		    a[y].nextit=p;
		 }
	}
	for(int i=1;i<=n;i++)scanf("%d",&w[i]);
	ans=maxa=0;
	if(n<=100)
	{	
	    int x=0;
		for(int i=1;i<=n;i++)
		   for(int j=1;j<=n;j++)
		   {
			  if(f[i][j]==2)
			  {
			    x=w[i]*w[j];
		        if(x>maxa)maxa=x;
		        ans=(ans+x)%10007;
			  } 		   
		   }
		
	}
	else
	{
	    for(int i=1;i<=n;i++)
		   dfs(i,i,0);
	}    	
	printf("%d %d\n",maxa,ans);
return 0;
}
