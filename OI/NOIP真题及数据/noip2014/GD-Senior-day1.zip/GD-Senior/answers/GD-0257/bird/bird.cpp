#include<iostream>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
using namespace std;
int mini(int a,int b)
{
   if(a<b)return a;
   return b;
}
int maxi(int a,int b)
{
   if(a>b)return a;
   return b;
}
struct pipe
{
    int p,l,h;
};
pipe pi[10010];
int n,m,k,act[10010][2],ans1,ans0,vis[1010][10010],gg[1010][10010];//vis1�ɴvis2���ɴ� 
bool judge;
int cmp(const void *a,const void *b)
{
    pipe *pa,*pb;
    pa=(pipe *)a;pb=(pipe *)b;
    if(pa->p>pb->p)return 1;
    return -1;
}
void dfs30(int x,int h,int step)
{
  if(x==n)
  {
	 ans1=step;
     judge=true;
     return;
  }
  if(h>act[x][1])
  {
	 dfs30(x+1,h-act[x][1],step);
     if(judge)return;
  }
  int t=1,high;
  while(1)
  {
	  high=mini(h+t*act[x][0],m);
	  dfs30(x+1,high,step+t);
      if(judge)return;
      if(h+t*act[x][0]>=m);
      t++;
  }
}
void dfs(int x,int h,int pn)
{
   if(vis[h][x]!=0)return;
   int high=m,low=0;
   bool flag=false;
  if(x+1==pi[pn].p&&pn<=k)
  {
      high=pi[pn].h-1;
	  low=pi[pn].l;
	  pn++;
   
   if(h>act[x][1]+low&&h-act[x][1]<=high)
   {
      flag=true;
	  dfs(x+1,h-act[x][1],pn);
      if(vis[h-act[x][1]][x+1])
      {
		if(!gg[h][x])gg[h][x]=gg[h-act[x][1]][x+1];
		else gg[h][x]=mini(gg[h][x],gg[h-act[x][1]][x+1]);
		ans1=mini(ans1,gg[h][x]);
	  }
	  else
	  {
	       gg[h][x]=maxi(gg[h][x],gg[h-act[x][1]][x+1]);
	       ans0=maxi(ans0,gg[h][x]);
      } 
   }
   int t=1;
   while(h+t*act[x][0]<=high&&h+t*act[x][0]>low)
   {
      flag=true;
	  dfs(x+1,h+t*act[x][0],pn);
      if(vis[h+t*act[x][0]][x+1])
      {
		   if(!gg[h][x])gg[h][x]=gg[h+t*act[x][0]][x+1]+t;
		   gg[h][x]=mini(gg[h][x],gg[h+t*act[x][0]][x+1]+t);
		   ans1=mini(ans1,gg[h][x]);
	  }
	  else
	  {
	     gg[h][x]=maxi(gg[h][x],gg[h+t*act[x][0]][x+1]);  
		 ans0=maxi(ans0,gg[h][x]);    
      }
      t++;
   }
   if(!flag)
   {
      vis[h][x]=2;
      gg[h][x]=maxi(pn-1,gg[h][x]); 
      ans0=maxi(ans0,gg[h][x]);
   }  
  }
  else
  {
   if(h>act[x][1]+low)
   {
      flag=true;
	  dfs(x+1,h-act[x][1],pn);
      if(vis[h-act[x][1]][x+1])
      {
		if(!gg[h][x])gg[h][x]=gg[h-act[x][1]][x+1];
		else gg[h][x]=mini(gg[h][x],gg[h-act[x][1]][x+1]);
		ans1=mini(ans1,gg[h][x]);
	  }
	  else
	  {
	       gg[h][x]=maxi(gg[h][x],gg[h-act[x][1]][x+1]);
	       ans0=maxi(ans0,gg[h][x]);
      } 
   }
   int t=1;
   while(h+t*act[x][0]>low)
   {
      flag=true;
      high=mini(m,h+t*act[x][0]);
	  dfs(x+1,high,pn);
      if(vis[high][x+1])
      {
		   if(!gg[h][x])gg[h][x]=gg[high][x+1]+t;
		   gg[x][h]=mini(gg[h][x],gg[high][x+1]+t);
		   ans1=mini(ans1,gg[h][x]);
	  }
	  else
	  {
	     gg[h][x]=maxi(gg[h][x],gg[high][x+1]);  
		 ans0=maxi(ans0,gg[h][x]);    
      }
      if(high==m)break;
      t++;
   }
   if(!flag)
   {
      vis[h][x]=2;
      gg[h][x]=maxi(pn-1,gg[h][x]); 
      ans0=maxi(ans0,gg[h][x]);
   }  
  }
}
int main()
{
    freopen("bird.in","r",stdin);
    freopen("bird.out","w",stdout);
    scanf("%d%d%d",&n,&m,&k);
    for(int i=0;i<n;i++)
	    scanf("%d%d",&act[i][0],&act[i][1]);
	for(int i=1;i<=k;i++)
	scanf("%d%d%d",&pi[i].p,&pi[i].l,&pi[i].h);
	if(k==0)
	{
	   judge=false;
	   for(int i=m;i>act[0][i];i--)
	   {   
	      dfs30(0,i,0);
          if(judge)break;
	   }
	}  
	else
	{
	   judge=false;
	   qsort(pi+1,k,sizeof(pipe),cmp);
	   ans1=10000010;ans0=0;
	   judge=false;
	   for(int i=m;i>0;i--)
	   {
	      vis[i][n]=1;
	      gg[i][n]=0;
	   }
	   for(int i=m;i>act[0][1];i--)
	   {   
		  dfs(0,i,1);
	   }
	}
	if(judge)printf("1\n%d\n",ans1);
	else printf("0\n%d\n",ans0);
return 0;
}
