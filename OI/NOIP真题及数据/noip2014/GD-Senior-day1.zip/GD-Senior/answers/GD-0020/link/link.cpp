#include <cstdio>
#include <cstring>
#include <vector>
#define max(A,B) ((A)>(B)?(A):(B))
#define MAXN 210000
using namespace std;


vector<int> G[MAXN];
int n,w[MAXN]={0};
int maxw=0,ans=0;

void read_G(){
	int u,v;
	scanf ("%d",&n);
	for (int i=0; i<n-1; ++i ){
		scanf ("%d%d",&u,&v);
		G[u].push_back(v);
		G[v].push_back(u);
	}
	for (int i=1; i<=n; ++i ){
		scanf ("%d",w+i);
	}
}

void Work(){
	for (int i=1; i<=n; ++i){
		int m=G[i].size();
		for (int j=0;j<m-1;++j){
			for (int k=j+1;k<m;++k){
				maxw=max(maxw,w[G[i][j]]*w[G[i][k]]);
				ans += w[G[i][j]]*w[G[i][k]];
				ans %=10007;
			}
		}
	}
}

int main(){
	freopen( "link.in", "r", stdin );
	freopen( "link.out", "w", stdout );
	read_G();
	Work();
	ans=ans*2%10007;
	printf("%d %d\n",maxw,ans);
	return 0;
}
