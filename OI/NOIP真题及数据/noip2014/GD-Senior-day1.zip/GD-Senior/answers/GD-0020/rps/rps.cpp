#include <cstdio>
#include <cstring>
#define MAXN 210
using namespace std;

int n,na,nb;
int s1[MAXN],s2[MAXN];
int cnt1=0,cnt2=0;

int main(){
	freopen( "rps.in", "r", stdin );
	freopen( "rps.out", "w", stdout );
	memset(s1,0,sizeof(s1) );
	memset(s2,0,sizeof(s2) );
	scanf ("%d%d%d",&n,&na,&nb);
	for (int i=0; i<na; ++i )
		scanf ("%d",s1+i);
	for (int i=0; i<nb; ++i )
		scanf ("%d",s2+i);
	for (int i=0; i<n; ++i ){
		int p=s1[i%na];
		int q=s2[i%nb];
		if ( (p==0&&q==2) || (p==0&&q==3) || (p==1&&q==3) || (p==2&&q==4 )|| (p==3&&q==4) ){
			cnt1++;
		}
		else if ((q==0&&p==1) || (q==0&&p==4) || (q==1&&p==2) || (q==1&&p==4 )|| (q==2&&p==3) ){
			cnt1++;
		}
		else if (p==q);
		else cnt2++;
	}
	printf("%d %d\n",cnt1,cnt2);
	return 0;
}
