#include <cstdio>
#include <cstring>
#define max(A,B) ((A)>(B)?(A):(B))
#define MAXN 10010
#define MAXM 1010
using namespace std;

int n,m,k;
bool f[MAXN][MAXM];
int X[MAXN],Y[MAXN];
int ans[MAXN]={0};

int main(){
	int P,L,H;
	int cnt=0;
	bool ok;
	freopen( "bird.in", "r", stdin );
	freopen( "bird.out", "w", stdout );
	scanf ("%d%d%d",&n,&m,&k);
	memset(f,true,sizeof(f));
	memset(X,0,sizeof(X));
	memset(Y,0,sizeof(Y));
	for (int i=0; i<n; ++i )
		scanf ("%d%d",X+i,Y+i);
	for (int i=0; i<k; ++i ){
		scanf ("%d%d%d",&P,&L,&H);
		memset(f[P],false,sizeof(bool)*(L+1));
		memset(f[P]+H, false, sizeof(bool)*(m-H+1));
		ans[P]=1;
	}

	int x;
	for (x=1; x<=n; ++x){
		ok=false;
		for (int j=1; j<=m; ++j){
			if ( !f[x][j] ) continue;
			f[x][j]=false;
			if ( j+Y[x-1]<=m && f[x-1][j+Y[x-1]] ){
				f[x][j]=true;
				ok=true;
				continue;
			}
			for (int k=1; j-k*X[x-1]>0; ++k ){
				if (f[x-1][j-k*X[x-1]]){
					f[x][j]=true;
					ok=true;
					break;
				}
			}
			if (j==m) {
				f[x][j]=true;
				ok=true;
			}
		}
		if (!ok) break;
	}
	for (int i=0; i<x; ++i ){
		cnt+=ans[i];
	}
	if ( x>n && ok==true ){
		printf("1\n%d\n",cnt);
	}
	else {
		printf("0\n%d\n",cnt);
	}

	return 0;
}
