#include <iostream>
#include <cstdio>
#include <fstream>
#include <stdio.h>
#include <cstring>
#include <string>
#include <string.h>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cstdlib>
#include <vector>
using namespace std;

const int maxN=10005, maxM=1003, oo=10000*1000*2;
int n, m, k, upX[maxN], downY[maxN], pipe_L[maxN], pipe_H[maxN], f[2][maxM];
bool is_pipe[maxN];

void init()
{
	scanf ("%d%d%d", &n, &m, &k);
	for (int i=0; i<n; i++) scanf ("%d%d", &upX[i], &downY[i]);
	for (int i=0; i<=n; i++) is_pipe[i] = false;
	for (int i=1; i<=k; i++)
	{
		int P, L, H;
		scanf ("%d%d%d", &P, &L, &H);
		is_pipe[P] = true;
		pipe_L[P] = L;
		pipe_H[P] = H;
	}
}

int work_1_7()
{
	for (int i = 1; i <= m; i++) f[0][i] = 0;
	f[0][0] = oo;
	int cnt = 0;
	for (int i = 0; i < n; i++)
	{
		int nxt = i+1;
		int u = i%2; int v = 1-u;
		bool OK_flag = false;
		for (int j = 0; j <= m; j++) f[v][j] = oo;
		
		if (is_pipe[nxt])
		{
			for (int j = 0; j <= m; j++)
			  if (f[u][j] < oo)
			  {
			  	  OK_flag = true;
			  	  int newH = j;
			  	  for (int g = 1; g <= m; g++)
			  	  {
			  	  	  newH = newH + upX[i];
			  	  	  if (newH > pipe_L[nxt] && newH < pipe_H[nxt]) 
						  f[v][newH] = min(f[v][newH], f[u][j] + g);
			  	  }
				  newH = j - downY[i];
				  if (newH > pipe_L[nxt] && newH < pipe_H[nxt])
				     f[v][newH] = min(f[v][newH], f[u][j]);
			  }
	    }
	    else
	    {
	    	for (int j = 0; j <= m; j++)
	    	  if (f[u][j] < oo)
	    	  {
	    	  	  OK_flag = true;
	    	  	  int newH = j;
	    	  	  for (int g = 1; g <= m; g++)
	    	  	  {
	    	  	  	  newH = min (m, newH + upX[i]);
	    	  	  	  f[v][newH] = min(f[v][newH], f[u][j] + g);
	    	  	  	  if (newH == m) break ;
	    	  	  }
	    	  	  newH = j - downY[i];
	    	  	  if (newH > 0)
	    	  	      f[v][newH] = min(f[v][newH], f[u][j]);
	    	  }
	    }
	    if (!OK_flag) return cnt;
	    cnt += (int)is_pipe[i];
	}
	bool OK_flag = false;
	for (int j = 1; j <= m; j++)
	  if (f[n%2][j] < oo) 
	  { OK_flag = true; break; }
	if (!OK_flag) return cnt;
	else return -1;
}

int work()
{
	for (int j = 1; j <= m; j++) f[0][j] = 0;
	f[0][0] = oo;
	int cnt = 0;
	for (int i = 0; i < n; i++)
	{
		int u = i%2;
		int v = 1-u;
		int nxt = i+1;
		bool OK_flag = false;
		for (int j = 0; j <= m; j++) f[v][j] = oo;
		
		if (is_pipe[nxt])
		{
			for (int j = 0; j <= m; j++)
			  if (f[u][j] < oo)
			  {
			  	  OK_flag = true;
			  	  int newH = j+upX[i];
			  	  if (newH > pipe_L[nxt] && newH < pipe_H[nxt])
			  	      f[v][newH] = min (f[v][newH], f[u][j] + 1);
			  }  // up: 1 step
			for (int j = upX[i]; j <= m; j++)
			  if (j > pipe_L[nxt] && j < pipe_H[nxt])
			    f[v][j] = min (f[v][j], f[v][j-upX[i]] + 1);
			    // up: more steps
			for (int j = 0; j <= m; j++)
			  if (f[u][j] < oo)
			  {
			  	  int newH = j-downY[i];
			  	  if (newH > pipe_L[nxt] && newH < pipe_H[nxt])
			  	      f[v][newH] = min (f[v][newH], f[u][j]);
			  } //down
		}
		else
		{
			for (int j = 0; j <= m; j++)
			  if (f[u][j] < oo)
			  {
			  	  OK_flag = true;
			  	  int newH = min(m, j + upX[i]);
			  	  f[v][newH] = min (f[v][newH], f[u][j] + 1);
			  }  // up: 1 step
			for (int j = upX[i]; j <= m; j++)
			    f[v][j] = min (f[v][j], f[v][j-upX[i]] + 1);
			    // up: more steps
			for (int j = m-upX[i]; j < m; j++)
			    f[v][m] = min(f[v][m], f[v][j] + 1);
			    // up: to the top
			for (int j = 0; j <= m; j++)
			  if (f[u][j] < oo)
			  {
			  	  int newH = j - downY[i];
			  	  if (newH > 0)
			  	    f[v][newH] = min (f[v][newH], f[u][j]);
			  } // down
		}
		if (!OK_flag) return cnt;
		cnt += is_pipe[i];
	}
	bool OK_flag = false;
	for (int j = 1; j <= m; j++)
	  if (f[n%2][j] < oo)
	  { OK_flag = true; break; } 
	if (!OK_flag) return cnt;
	else return -1;
}

void print_res (int ans)
{
	if (ans >= 0) printf ("0\n%d\n", ans);
	else
	{
		ans = oo;
		for (int i = 1; i <= m; i++)
		  ans = min (ans, f[n%2][i]);
		printf ("1\n%d\n", ans);
	} 
}

int main()
{
	freopen("bird.in", "r", stdin);
	freopen("bird.out", "w", stdout);
	
	init();
	
	if (n<=1000 && m<=100) 
	{
	    int ans = work_1_7();
	    print_res (ans);
	    return 0;
	}	
	int ans = work();
	print_res (ans);
	return 0;
	
}

