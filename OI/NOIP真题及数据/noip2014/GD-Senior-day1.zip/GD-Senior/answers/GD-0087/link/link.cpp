#include <iostream>
#include <cstdio>
#include <fstream>
#include <stdio.h>
#include <cstring>
#include <string>
#include <string.h>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cstdlib>
#include <vector>
using namespace std;

const int maxN=200005;
const int mod = 10007;
int n, maxv, sumv, w[maxN], now, head[maxN], fa[maxN], sum[maxN], maxs1[maxN], maxs2[maxN], q[maxN];
struct Edge {
	int v, next;
} e[maxN*2];

void addEdge (int u, int v)
{
	now++; e[now].v=v; e[now].next=head[u]; head[u]=now;
}

void init()
{
	scanf ("%d", &n);
	now=0;
	for (int i=0; i<=n; i++) head[i]=0;
	for (int i=1; i<n; i++)
	{
		int u, v;
		scanf ("%d%d", &u, &v);
		addEdge (u,v); addEdge (v, u);
	}
	for (int i=1; i<=n; i++)
	    scanf ("%d", &w[i]);
}

void work()
{
	maxv = sumv = 0;
	q[1] = 1; 
	fa[1] = 0;
	for (int H=1, T=1; H<=T; H++)
	{
		int u=q[H];
		sum[u] = 0;
		maxs1[u] = maxs2[u] = -1;
		for (int i=head[u]; i; i=e[i].next)
		  if (e[i].v != fa[u])
		  {
		  	  int v = e[i].v;
		  	  fa[v] = u;
		  	  sum[u] = (sum[u] + w[v]) % mod;
		  	  sumv = (sumv - w[v] * w[v]) % mod;
		  	  if (w[v] > maxs1[u])
		  	  { maxs2[u]=maxs1[u]; maxs1[u]=w[v]; }
		  	  else
		  	      if (w[v] > maxs2[u]) maxs2[u] = w[v];
		  	  T++; q[T] = v;
		  }
		if (u != 1)
		{
			if (maxs1[u] >= 0)
			    maxv = max (maxv, w[fa[u]] * maxs1[u]);
			sumv = (sumv + (w[fa[u]] * sum[u] * 2) % mod) % mod;
		}
		if (maxs2[u] >= 0)
		{
			maxv = max (maxv, maxs1[u] * maxs2[u]);
		}
		sumv = (sumv + (sum[u] * sum[u]) % mod) % mod;
	}
	sumv = ((sumv % mod) + mod) % mod;
	
	printf ("%d %d\n", maxv, sumv);
}

void bfs (int stP)
{
	q[1] = stP; 
	fa[stP] = 0;
	sum[stP] = 0;
	for (int H=1, T=1; H<=T; H++)
	{
		int u=q[H];
		for (int i=head[u]; i; i=e[i].next)
		  if (e[i].v != fa[u])
		  {
		  	  int v=e[i].v;
		  	  fa[v] = u;
		  	  sum[v] = sum[u]+1;
		  	  T++; q[T] = v;
		  }
	}
}

void work_1_6()
{
	maxv = sumv = 0;
	for (int i=1; i<=n; i++)
	{
		bfs (i);
		for (int j=1; j<=n; j++)
		  if (sum[j] == 2)
		  {
		  	  int nw = w[i] * w[j];
		  	  maxv = max (maxv, nw);
		  	  sumv = (sumv + (nw%mod)) % mod;
		  }
	}
	printf ("%d %d\n", maxv, sumv);
}

int main()
{
	freopen("link.in", "r", stdin);
	freopen("link.out", "w", stdout);
	
	init();
	if (n<=2000) { work_1_6(); return 0; }
	work();
	
	return 0;
}

