#include <iostream>
#include <cstdio>
#include <fstream>
#include <stdio.h>
#include <cstring>
#include <string>
#include <string.h>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cstdlib>
#include <vector>
using namespace std;
ifstream fin("rps.in");
ofstream fout("rps.out");

const int maxN=205;
const int r[5][5] = { {0, 0, 1, 1, 0},
                      {1, 0, 0, 1, 0},
                      {0, 1, 0, 0, 1},
                      {0, 0, 1, 0, 1},
                      {1, 1, 0, 0, 0} };
int N, NA, NB, cnta, cntb, A[maxN], B[maxN], qa[maxN], qb[maxN];

void init()
{
	fin >> N >> NA >> NB;
	for (int i=0; i<NA; i++) fin >> A[i];
	for (int i=0; i<NB; i++) fin >> B[i];
}

void work()
{
	cnta = cntb = 0;
	for (int i=0; i<N; i++)
	{
		qa[i] = A[i%NA];
		qb[i] = B[i%NB];
		cnta += r[qa[i]][qb[i]];
		cntb += r[qb[i]][qa[i]];
	}
	fout << cnta << " " << cntb << endl;
}

int main()
{
	init();
	work();
	
	return 0;
}

