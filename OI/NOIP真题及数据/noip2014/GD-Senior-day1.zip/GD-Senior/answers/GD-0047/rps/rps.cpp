#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;


int pd[6][6];
void  ycl()
{
    pd[0][0]=0;
pd[0][1]=0;
pd[0][2]=1;
pd[0][3]=1;
pd[0][4]=0;
pd[1][0]=1;
pd[1][1]=0;
pd[1][2]=0;
pd[1][3]=1;
pd[1][4]=0;
pd[2][0]=0;
pd[2][1]=1;
pd[2][2]=0;
pd[2][3]=0;
pd[2][4]=1;
pd[3][0]=0;
pd[3][1]=0;
pd[3][2]=1;
pd[3][3]=0;
pd[3][4]=1;
pd[4][0]=1;
pd[4][1]=1;
pd[4][2]=0;
pd[4][3]=0;
pd[4][4]=0;
}
int a[220],b[220];
int main()
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	int n,na,nb,len,i;
	scanf("%d %d %d",&n,&na,&nb);
	for(i=1;i<=na;i++)
	scanf("%d",&a[i]);
	for(i=1;i<=nb;i++)
	scanf("%d",&b[i]);
	len=1;
	ycl();
	for(i=na+1;i<=n;i++)
	{
	    a[i]=a[len];
	    len++;
	    if(len>na)len=1;
	}
	len=1;
	for(i=nb+1;i<=n;i++)
	{
	    b[i]=b[len];
	    len++;
	    if(len>nb)len=1;
    } 
	int x1=0,x2=0;
	for(i=1;i<=n;i++)
	{
		if(pd[a[i]][b[i]]==1)x1++;
	    
	    else if(a[i]!=b[i])x2++;
	}
	printf("%d %d\n",x1,x2);
    //system("pause");
    return 0;
}

