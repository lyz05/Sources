#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;
int maxn=-1;
int MOD=10007;
struct node
{
    int a[70],len,d;
    node()
    {
	   len=0;
	}
}t[200000];
int ans=0;
int find(int now)
{
	 int res=0,i,j,tt,son,x;
     for(i=1;i<=t[now].len;i++)
     {
     	 x=t[now].a[i];
	     for(j=1;j<=t[x].len;j++)
	     {
		       son=t[x].a[j];
		       tt=t[son].d*t[now].d;
		       if(tt>maxn)maxn=tt;
		       res=(res+tt)%MOD;
		 }
     }
     return res;
}

void work(int now)
{
	int i;
	if(t[now].len==0)return ;
	ans=(ans+find(now)*2)%MOD;
	for(i=1;i<=t[now].len;i++)
	work(t[now].a[i]);
}

int v[200001];
int main()
{
	 freopen("link.in","r",stdin);
    freopen("link.out","w",stdout);
	int i,n,x,y;
	scanf("%d",&n);
	memset(v,0,sizeof(v));
	for(i=1;i<n;i++)
    {
	     scanf("%d",&x);
	     t[x].len++;
	     scanf("%d",&t[x].a[t[x].len]);
	     v[t[x].a[t[x].len]]=1;
	}
	int root;
	for(i=1;i<=n;i++)
	      if(!v[i])
		  {root=i;break;}
	for(i=1;i<=n;i++)
	    scanf("%d",&t[i].d);
    work(root);
    printf("%d %d\n",maxn,ans);
    //system("pause");
    return 0;
}

