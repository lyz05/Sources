#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;

int minn=99999999,maxn=-1;
int n,m;
int map[500][500];
int x[500],y[500];
int xx[500];
bool bk=0;
void ss(int now,int cnt,int cs)
{
	int i;
    if(!map[cnt][now])return;
	if(now<=0)return ;	
	if(cnt==m){bk=1;if(cs<minn)minn=cs;return;}
	if(cnt>=maxn)maxn=cnt;
    for(i=1;i<=3;i++)
    {
    	if(now+i*x[cnt]>=n)
		{ss(n,cnt+1,cs+i);break;}
	    else ss(now+i*x[cnt],cnt+1,cs+i);
	}
	ss(now-y[cnt],cnt+1,cs);
	
}

int main()
{
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	int l,i,j,y1,x1,k;
    scanf("%d %d %d",&n,&m,&k);
    for(i=0;i<n;i++)
    scanf("%d %d",&x[i],&y[i]);
    for(i=0;i<=n;i++)
   	   for(j=0;j<=m;j++)
	  map[i][j]=1;
    for(i=1;i<=k;i++)
	{
	    scanf("%d %d %d",&xx[i],&x1,&y1);
        for(j=0;j<=x1;j++)map[xx[i]][j]=0;
        for(j=y1;j<=n;j++)map[xx[i]][j]=0;
	}
	for(i=0;i<=n;i++)
	    ss(i,0,0);
	if(bk)
	printf("1\n%d\n",minn);
	else 
	{
		int ans=0;
	    for(i=1;i<=k;i++)
	    if(xx[i]<maxn)ans++;
	    printf("0\n%d\n",ans);
	}
    //system("pause");
    return 0;
}

