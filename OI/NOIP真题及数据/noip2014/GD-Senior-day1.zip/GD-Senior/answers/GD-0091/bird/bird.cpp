#include<cstdio>
#include<cstdlib>
#include<fstream>
#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<string>
#include<map>
#include<utility>
#include<queue>
#include<stack>
#include<set>
#include<bitset>
#include<vector>

using namespace std;

typedef long long LL;
typedef double DB;
typedef pair<int,int> PII;

#define re(i,a,b) for(i=a;i<=b;i++)
#define red(i,a,b) for(i=a;i>=b;i--)
#define fi first
#define se second

const DB EPS=1e-9;
inline int dblcmp(DB x){if(abs(x)<EPS) return 0; return (x>0)?1:-1;}

template<class T> T sqr(T x){return x*x;}
template<class T> void upmin(T &t,T tmp){if(t>tmp)t=tmp;}
template<class T> void upmax(T &t,T tmp){if(t<tmp)t=tmp;}

inline void SetOpen(string s)
  {
  	freopen((s+".in").c_str(),"r",stdin);
  	freopen((s+".out").c_str(),"w",stdout);
  }

const int maxN=10000;
const int maxM=1000;
const int maxK=10000;
const int INF=2147483647;

int N,M,K;
int T,A,B;
int F[maxN+100][maxM+100];
int G[maxM+100];
int X[maxN+10],Y[maxN+10];
struct Td{int P,L,H;}d[maxK+10];
int ans1,ans2;

inline int cmpd(Td a,Td b){return a.P<b.P;}

int main()
  {
  	int i,j;
  	SetOpen("bird");
  	scanf("%d%d%d\n",&N,&M,&K);
  	re(i,0,N-1)scanf("%d%d\n",&X[i],&Y[i]);
  	re(i,1,K)scanf("%d%d%d\n",&d[i].P,&d[i].L,&d[i].H);
  	sort(d+1,d+K+1,cmpd);
  	re(i,0,maxN+10-1)re(j,0,maxM+10-1)F[i][j]=INF;
  	ans1=1;
  	T=0;
    re(j,1,M)F[0][j]=0;
    re(i,1,N)
      {
      	A=1;B=M;
      	if(T+1<=K && d[T+1].P==i){T++;A=d[T].L+1;B=d[T].H-1;}
      	re(j,0,M)G[j]=INF;
      	re(j,0,M)
      	  if(j-X[i-1]>=0)
						{
						  if(F[i-1][j-X[i-1]]!=INF)upmin(G[j],F[i-1][j-X[i-1]]+1);
						  if(G[j-X[i-1]]!=INF)upmin(G[j],G[j-X[i-1]]+1);
						}
      	re(j,1,X[i-1]-1)
				  if(M-j>=0) 
					  {
					  	if(F[i-1][M-j]!=INF)upmin(G[M],F[i-1][M-j]+1);
					  	if(G[M-j]!=INF)upmin(G[M],G[M-j]+1);
					  }
      	re(j,0,M)
      	  if(A<=j && j<=B)
      	    {
      	    	upmin(F[i][j],G[j]);
						  if(j+Y[i-1]<=M)upmin(F[i][j],F[i-1][j+Y[i-1]]);
						}
      	bool o=0;
      	re(j,0,M)if(F[i][j]!=INF){o=1;break;}
      	if(!o){ans1=0;break;}
      }
    if(ans1==0)
      {
      	ans2=max(0,T-1);
      }
    else
      {
      	ans2=INF;
      	re(j,0,M)upmin(ans2,F[N][j]);
      }
    printf("%d\n%d\n",ans1,ans2);
  	return 0;
  }
