#include<cstdio>
#include<cstdlib>
#include<fstream>
#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<string>
#include<map>
#include<utility>
#include<queue>
#include<stack>
#include<set>
#include<bitset>
#include<vector>

using namespace std;

typedef long long LL;
typedef double DB;
typedef pair<int,int> PII;

#define re(i,a,b) for(i=a;i<=b;i++)
#define red(i,a,b) for(i=a;i>=b;i--)
#define fi first
#define se second
#define mmst(a,v) memset(a,v,sizeof(v))
#define mmcy(a,b) memcpy(a,b,sizeof(b))

const DB EPS=1e-9;
inline int dblcmp(DB x){if(abs(x)<EPS) return 0; return (x>0)?1:-1;}

template<class T> T sqr(T x){return x*x;}
template<class T> T upmin(T &t,T tmp){if(t>tmp)t=tmp;}
template<class T> T upmax(T &t,T tmp){if(t<tmp)t=tmp;}

inline void SetOpen(string s)
  {
  	freopen((s+".in").c_str(),"r",stdin);
  	freopen((s+".out").c_str(),"w",stdout);
  }

const int maxN=200;
const PII F[5][5]=
{
{PII(0,0),PII(0,1),PII(1,0),PII(1,0),PII(0,1)},
{PII(1,0),PII(0,0),PII(0,1),PII(1,0),PII(0,1)},
{PII(0,1),PII(1,0),PII(0,0),PII(0,1),PII(1,0)},
{PII(0,1),PII(0,1),PII(1,0),PII(0,0),PII(1,0)},
{PII(1,0),PII(1,0),PII(0,1),PII(0,1),PII(0,0)},
};

int N,NA,NB;
int a[maxN+10],b[maxN+10],t1,t2;
int va,vb;

int main()
  {
  	int i;
  	SetOpen("rps");
  	scanf("%d%d%d\n",&N,&NA,&NB);
  	re(i,0,NA-1)scanf("%d",&a[i]);scanf("\n");
		re(i,0,NB-1)scanf("%d",&b[i]);scanf("\n");
		t1=t2=0;
		va=vb=0;
		re(i,1,N)
		  {
		  	va+=F[a[t1]][b[t2]].fi;
		  	vb+=F[a[t1]][b[t2]].se;
		  	t1=(t1+1)%NA;
		  	t2=(t2+1)%NB;
		  }
		printf("%d %d\n",va,vb);
		return 0;
	}
