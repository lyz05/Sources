#include<cstdio>
#include<cstdlib>
#include<fstream>
#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<string>
#include<map>
#include<utility>
#include<queue>
#include<stack>
#include<set>
#include<bitset>
#include<vector>

using namespace std;

typedef long long LL;
typedef double DB;
typedef pair<int,int> PII;

#define re(i,a,b) for(i=a;i<=b;i++)
#define red(i,a,b) for(i=a;i>=b;i--)
#define fi first
#define se second

const DB EPS=1e-9;
inline int dblcmp(DB x){if(abs(x)<EPS) return 0; return (x>0)?1:-1;}

template<class T> T sqr(T x){return x*x;}
template<class T> void upmin(T &t,T tmp){if(t>tmp)t=tmp;}
template<class T> void upmax(T &t,T tmp){if(t<tmp)t=tmp;}

const int maxN=200000;
const int Mod=10007;

int N;
int W[maxN+10];
int first[maxN+10],now;
struct Tedge{int v,next;}edge[2*maxN+100];
int fa[maxN+100];
int ans1,ans2;

inline void addedge(int u,int v)
  {
  	now++;
  	edge[now].v=v;
  	edge[now].next=first[u];
  	first[u]=now;
  }

int head,tail,que[maxN+100];
inline void BFS(int S)
  {
  	int i,u,v;
  	re(i,1,N)fa[i]=0;
  	fa[que[head=tail=0]=S]=-1;
  	while(head<=tail)
  	  {
  	  	u=que[head++],i,v;
  	  	for(i=first[u],v=edge[i].v;i!=-1;i=edge[i].next,v=edge[i].v)if(fa[v]==0)
				  {
				  	que[++tail]=v;
				  	fa[v]=u;
				  }
  	  }
  }

int main()
  {
  	int i,j;
  	freopen("link.in","r",stdin);
  	freopen("link.out","w",stdout);
  	scanf("%d\n",&N);
  	re(i,1,N)first[i]=-1;now=-1;
  	re(i,1,N-1)
  	  {
  	  	int u,v;
  	  	scanf("%d%d\n",&u,&v);
  	  	addedge(u,v);
  	  	addedge(v,u);
  	  }
  	re(i,1,N)scanf("%d",&W[i]);scanf("\n");
  	W[0]=0;
  	BFS(1);
  	ans1=ans2=0;
  	re(j,0,tail)
  	  {
  	  	int u=que[j],v;
  	  	if(fa[u]!=-1 && fa[fa[u]]!=-1)
  	  	  {
  	  	  	v=fa[fa[u]];
  	  	  	upmax(ans1,W[u]*W[v]);
  	  	  	ans2=(ans2+2*W[u]*W[v])%Mod;
  	  	  }
  	  	int sum=0,t1=0,t2=0;
  	  	for(i=first[u],v=edge[i].v;i!=-1;i=edge[i].next,v=edge[i].v)if(v!=fa[u])
  	  	  {
  	  	  	sum=(sum+W[v])%Mod;
  	  	  	if(W[t1]<W[v])
  	  	  	  {
  	  	  	  	t2=t1;
  	  	  	  	t1=v;
  	  	  	  }
  	  	  	else
  	  	  	  {
  	  	  	  	if(W[t2]<W[v]) t2=v;
  	  	  	  }
  	  	  }
  	  	upmax(ans1,W[t1]*W[t2]);
  	  	for(i=first[u],v=edge[i].v;i!=-1;i=edge[i].next,v=edge[i].v)if(v!=fa[u])
  	  	  ans2=(ans2+W[v]*(sum-W[v]))%Mod;
  	  }
  	ans2=(ans2%Mod+Mod)%Mod;
  	printf("%d %d\n",ans1,ans2);
  	return 0;
  }
