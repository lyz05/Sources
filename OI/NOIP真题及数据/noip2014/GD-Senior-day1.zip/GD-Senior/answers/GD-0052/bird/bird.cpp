#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<fstream>
using namespace std;
#define maxn 10010
#define maxm 1010
ifstream cin("bird.in");
ofstream cout("bird.out");
struct {
	int x,y;
} a[maxn];
struct xx{
	int p,l,h;
} t[maxn];
int n,m,sumk,inf=2000000000;
int f[2][maxm];
int maxl;
int min(int x,int y) {if (x<y) return x;else return y;}
void sort(int l,int r)
{
	int i,j,y;
	xx x;
	i=l;j=r;y=(i+j)/2;
	x=t[y];t[y]=t[i];
	while (i!=j) {
		while (i<j && x.p<t[j].p) j--;
		if (i<j) {t[i]=t[j];i++;}
		while (i<j && x.p>t[i].p) i++;
		if (i<j) {t[j]=t[i];j--;}
	}
	t[i]=x;
	if (l<i-1) sort(l,i-1);
	if (i+1<r) sort(i+1,r);
}
void init()
{
	int i;
	cin>>n>>m>>sumk;
	for (i=0;i<n;i++) cin>>a[i].x>>a[i].y;
	for (i=1;i<=sumk;i++) cin>>t[i].p>>t[i].l>>t[i].h;
	if (sumk>1) sort(1,sumk);
}
void mainx()
{
	int i,j,k,g,minx,lk;
	int l,r;
	bool z;
	l=0;r=1;
	f[l][0]=-1;
	for (i=1;i<=m;i++) f[l][i]=0;
	lk=1;maxl=0;
	for (i=1;i<=n;i++) {
		for (j=0;j<=m;j++) f[r][j]=-1;
		if (lk<=sumk && t[lk].p==i) {
			for (j=0;j<a[i-1].x;j++)  {
				minx=-inf;
				for (k=j;k<=m;k+=a[i-1].x) {
					if (f[l][k]!=-1) {
						if (minx<0 || f[l][k]<minx) minx=f[l][k];
						if (k-a[i-1].y>0 && t[lk].l<k-a[i-1].y && k-a[i-1].y<t[lk].h)
							if (f[r][k-a[i-1].y]==-1 || f[l][k]<f[r][k-a[i-1].y]) {
								f[r][k-a[i-1].y]=f[l][k];
							}
					}
					minx+=1;
					if (minx>=0) {
						g=min(k+a[i-1].x,m);
						if (t[lk].l<g && g<t[lk].h) 
							if (f[r][g]==-1 || minx<f[r][g]) f[r][g]=minx;
					}
				}
			}
			for (j=1;j<=m;j++) 
				if (f[r][j]!=-1) {
					maxl=lk;
					break;
				}
			lk++;
		}
		else {
			for (j=0;j<a[i-1].x;j++) {
				minx=-inf;
				for (k=j;k<=m;k+=a[i-1].x) {
					if (f[l][k]!=-1) {
						if (minx<0 || f[l][k]<minx) minx=f[l][k];
						if (k-a[i-1].y>0) 
							if (f[r][k-a[i-1].y]==-1 || f[l][k]<f[r][k-a[i-1].y]) f[r][k-a[i-1].y]=f[l][k];
					}
					minx+=1;
					if (minx>=0) {
						g=min(k+a[i-1].x,m);
						if (f[r][g]==-1 || minx<f[r][g]) f[r][g]=minx;
					}
				}
			}
		}
		l=(l+1)%2;r=(r+1)%2;
	}
	z=false;j=inf;
	for (i=1;i<=m;i++)
		if (f[l][i]!=-1) {
			z=true;
			if (f[l][i]<j) j=f[l][i];
		}
	if (!z) cout<<0<<'\n'<<maxl;
	else cout<<1<<'\n'<<j;
}
int main()
{
	
	init();
	mainx();
	
	cin.close();
	cout.close();
	return 0;
}