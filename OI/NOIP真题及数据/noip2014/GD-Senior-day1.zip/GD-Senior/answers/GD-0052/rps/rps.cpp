#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<fstream>
using namespace std;
#define maxn 20010
ifstream cin("rps.in");
ofstream cout("rps.out");
int n,na,nb,a[maxn],b[maxn];
int map[5][5]={{0,0,1,1,0},
						{1,0,0,1,0},
						{0,1,0,0,1},
						{0,0,1,0,1},
						{1,1,0,0,0}};
void init()
{
	int i,j;
	cin>>n>>na>>nb;
	for (i=0;i<na;i++) cin>>a[i];
	for (i=0;i<nb;i++) cin>>b[i];
}
void mainx()
{
	int i,ans1=0,ans2=0;
	for (i=0;i<n;i++) {
		ans1+=map[a[i%na]][b[i%nb]];
		ans2+=map[b[i%nb]][a[i%na]];
	}
	cout<<ans1<<' '<<ans2<<'\n';
}
int main()
{
	
	init();
	mainx();
	
	cin.close();
	cout.close();
	return 0;
}