#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<fstream>
using namespace std;
#define maxn 200010
ifstream cin("link.in");
ofstream cout("link.out");
struct {
	int y,l;
} p[2*maxn];
int n,sump,b[maxn],v[maxn];
int q[maxn],d[maxn],t1[maxn][3],t2[maxn][3],mp=10007;
int ans_max,ans_sum;
int f[maxn];
void add(int x,int y)
{
	sump++;
	p[sump].y=y;
	p[sump].l=b[x];
	b[x]=sump;
}
void init()
{
	int i,x,y;
	cin>>n;
	sump=0;
	memset(d,0,sizeof(d));
	memset(b,0,sizeof(b));
	for (i=1;i<n;i++) {
		cin>>x>>y;
		add(x,y);add(y,x);
		d[x]++;d[y]++;
	}
	memset(t1,0,sizeof(t1));
	memset(t2,0,sizeof(t2));
	for (i=1;i<=n;i++) {
		cin>>v[i];
		t1[i][0]=t2[i][0]=v[i];
	}
}
void mainx()
{
	int i,j,k,s;
	int l,r;
	memset(f,0,sizeof(f));
	l=r=0;
	for (i=1;i<=n;i++)
		if (d[i]==1) {
			r++;q[r]=i;f[i]=1;
		}
	ans_max=ans_sum=0;
	while (l!=r) {
		l++;
		i=q[l];
		ans_sum=(ans_sum+(2*v[i]*t2[i][2])%mp)%mp;
		s=0;
		if (v[i]*t1[i][2]>ans_max) ans_max=v[i]*t1[i][2];
		for (j=b[i];j>0;j=p[j].l) 
		if (f[p[j].y]<2) {
			if (v[i]*t1[p[j].y][1]>ans_max) ans_max=v[i]*t1[p[j].y][1];
			if (t1[i][0]>t1[p[j].y][1]) t1[p[j].y][1]=t1[i][0];
			if (t1[i][1]>t1[p[j].y][2]) t1[p[j].y][2]=t1[i][1];
			s=(s+v[i]*t2[p[j].y][1])%mp;
			t2[p[j].y][1]=(t2[p[j].y][1]+t2[i][0])%mp;
			t2[p[j].y][2]=(t2[p[j].y][2]+t2[i][1])%mp;
			d[p[j].y]--;
			if (d[p[j].y]==1 && f[p[j].y]==0) {
				f[p[j].y]=1;
				r++;
				q[r]=p[j].y;
			}
		}
		f[i]=2;
		ans_sum=(ans_sum+s*2)%mp;
	}
	cout<<ans_max<<' '<<ans_sum;
}
int main()
{
	
	init();
	mainx();
	
	cin.close();
	cout.close();
	return 0;
}
