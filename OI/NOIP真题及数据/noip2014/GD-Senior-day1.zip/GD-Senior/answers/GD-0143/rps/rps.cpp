#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <iostream>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <stack>
#include <vector>
#include <bitset>
using namespace std;

typedef pair<int,int> pii;
#define ll long long
#define double 
#define mp make_pair
#define mpii make_pair
#define st first
#define nd second
#define For(_i,a,b) for (int _i=(a),_n=(b); _i<=_n; _i++)
#define Rof(_i,a,b) for (int _i=(a),_n=(b); _i>=_n; _i--)
#define Mem(a,b) memset(a,b,sizeof(a))
#define Cpy(a,b) memcpy(a,b,sizeof(b))

const int maxn=1000+10;
int N,M,Q,A[maxn],B[maxn];
bool boo[10][10];

void work()
{
	For(i,1,N) scanf("%d",&A[i]);
	For(i,1,M) scanf("%d",&B[i]);
	int i=1,j=1;
	int aa=0,bb=0;
	while(Q--)
	{
		if (boo[A[i]][B[j]]) aa++;
		if (boo[B[j]][A[i]]) bb++;
		i++,j++;
		if (i>N) i=1;
		if (j>M) j=1;
	}
	printf("%d %d\n",aa,bb);
}
int main()
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	
	Mem(boo,0);
	boo[0][2]=boo[0][3]=true;
	boo[1][0]=boo[1][3]=true;
	boo[2][1]=boo[2][4]=true;
	boo[3][2]=boo[3][4]=true;
	boo[4][0]=boo[4][1]=true;
	scanf("%d%d%d",&Q,&N,&M); 
	work();
	
	return 0;
}

