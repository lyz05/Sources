#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <iostream>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <stack>
#include <vector>
#include <bitset>
using namespace std;

typedef pair<int,int> pii;
#define ll long long
#define double 
#define mp make_pair
#define mpii make_pair
#define st first
#define nd second
#define For(_i,a,b) for (int _i=(a),_n=(b); _i<=_n; _i++)
#define Rof(_i,a,b) for (int _i=(a),_n=(b); _i>=_n; _i--)
#define Mem(a,b) memset(a,b,sizeof(a))
#define Cpy(a,b) memcpy(a,b,sizeof(b))

const int maxn=200000+100,modd=10007;
struct Edge
{
	int node,next;
	Edge() { node=next=0; }
	Edge(int a,int b) { node=a,next=b; }
}E[maxn*2];
int fre,N,fa[maxn],o[maxn],A[maxn],head[maxn];
int Maxf,Sum;

void add_Edge(int x,int y)
{
	E[fre]=Edge(y,head[x]);
	head[x]=fre++;
}
void Done()
{
	Mem(fa,255);
	fa[1]=0; A[0]=0; fa[0]=0;
	int h=1,t=1; o[1]=1;
	for (; h<=t; h++)
	{
		int x=o[h];
		for (int i=head[x]; i!=-1; i=E[i].next)
		{
			int y=E[i].node;
			if (fa[y]!=-1) continue;
			fa[y]=x; o[++t]=y;
		}
	}
	For(i,1,t)
	{
		int x=o[i],tt=fa[x];
		int s=A[tt],m=A[tt];
		for (int i=head[x]; i!=-1; i=E[i].next)
		{
			int y=E[i].node;
			if (fa[y]!=x) continue;
			Maxf=max(Maxf,m*A[y]);
			Sum=(Sum+A[y]*s %modd) %modd;
			s=(s+A[y]) %modd;
			m=max(m,A[y]);
		}
	}
	Sum=(Sum*2)%modd;
}
void work()
{
	Mem(head,255); fre=0;
	For(i,1,N-1)
	{
		int x,y; scanf("%d%d",&x,&y);
		add_Edge(x,y);
		add_Edge(y,x);
	}
	For(i,1,N) scanf("%d",&A[i]);
	Maxf=0,Sum=0;
	Done();
	printf("%d %d\n",Maxf,Sum);
}
int main()
{
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	
	scanf("%d",&N);
	work();
	
	return 0;
}

