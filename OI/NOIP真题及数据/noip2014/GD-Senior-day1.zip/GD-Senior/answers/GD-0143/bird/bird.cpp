#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <iostream>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <stack>
#include <vector>
#include <bitset>
using namespace std;

typedef pair<int,int> pii;
#define ll long long
#define double 
#define mp make_pair
#define mpii make_pair
#define st first
#define nd second
#define For(_i,a,b) for (int _i=(a),_n=(b); _i<=_n; _i++)
#define Rof(_i,a,b) for (int _i=(a),_n=(b); _i>=_n; _i--)
#define Mem(a,b) memset(a,b,sizeof(a))
#define Cpy(a,b) memcpy(a,b,sizeof(b))

const int maxn=10000+10,maxm=1000+10,oo=10000*10000;
int N,M,K,U[maxn],D[maxn],L[maxn],H[maxn];
bool boo[maxn];
int f[maxn][maxm];

void Init()
{
	For(i,0,N-1) scanf("%d%d",&U[i],&D[i]);
	Mem(boo,0);
	For(i,1,K)
	{
		int p,l,h; scanf("%d%d%d",&p,&l,&h);
		boo[p]=true;
		L[p]=l,H[p]=h;
	}
}
void Done1()
{
	For(i,0,N) For(j,0,M) f[i][j]=oo;
	For(j,0,M) f[0][j]=0;
	For(i,0,N-1)
	{
		Rof(j,M,0) if (f[i][j]!=oo)
		{
			int x=i+1,y=j+U[i],c=1;
			for (; y<M; y+=U[i],c++)
			{
				if (boo[x] && y>=H[x]) break;
				if (boo[x] && y<=L[x]) continue;
				if (f[i][j]+c<f[x][y]) f[x][y]=f[i][j]+c;
				 else break;
			}
			if (y>M) y=M;
			if ((boo[x]) && (y>=H[x] || y<=L[x])) continue;
			if (f[i][j]+c<f[x][y]) f[x][y]=f[i][j]+c;
		}
		For(j,D[i]+1,M) if (f[i][j]!=oo)
		{
			int x=i+1,y=j-D[i];
			if (boo[x] && y<=L[x]) continue;
			if (boo[x] && y>=H[x]) break;
			if (f[i][j]<f[x][y]) f[x][y]=f[i][j];
		}
	}
	int ans=oo;
	For(j,0,M) ans=min(ans,f[N][j]);
	if (ans!=oo) { printf("1\n%d\n",ans); return ;}
	Rof(i,N-1,0)
	{
		For(j,1,M) if (f[i][j]!=oo) { ans=i; break; }
		if (ans!=oo) break;
	}
	int ret=0;
	For(i,0,ans) if (boo[i]) ret++;
	printf("0\n%d\n",ret);
}
void work()
{
	Init();
	Done1();
}
int main()
{
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	
	scanf("%d%d%d",&N,&M,&K); 
	work();
	
	return 0;
}

