#include <iostream>
#include <fstream>
using namespace std;

// There may be something wrong if set to 0x7FFFFFFF
const long INF = 0x3FFFFFFFL; 

/* Master Shiang Dzurr plays silver power */

typedef struct _Winner_of_Life_XWH_Loves_YeZi{
	long P;
	long L;
	long H;
}
Pipe;

long width, height, pipeCount;
long &n = width, &m = height, &k = pipeCount;

long up[10000], down[10000];
long (&X)[10000] = up, (&Y)[10000] = down;

Pipe pipe[10000];
Pipe (&p)[10000] = pipe;
void PipeSort(long,long);

long minTap[10000][1000];
long (&map)[10000][1000] = minTap;
// Stores minimun tap times

long completion = 1, completeValue;

ifstream fin;
ofstream fout;

template <typename T>
inline void Swap(T& a,T& b){T t = a;a = b;b = t;}
template <typename T>
inline T Max(const T& a,const T& b){return a>b?a:b;}
template <typename T>
inline T Min(const T& a,const T& b){return a<b?a:b;}



int main(){
	fin.open("bird.in");
	fout.open("bird.out");
	
	fin >> n >> m >> k;
	int i,j,z,pi,flag;
	for(i = 0;i < n;i++){
		fin >> X[i] >> Y[i];
	}
	for(i = 0;i < k;i++){
		fin >> pipe[i].P >> pipe[i].L >> pipe[i].H;
	}
	PipeSort(0,k);
	
	pi = 0;
	for(i = 0;i < height;i++)
		map[0][i] = 1;
	for(i = 1;i < width;i++){
		flag = 1;
		// If a whole column is unreachable then you can terminate the case
		
		for(j = 1;j < height;j++){
			// Roll over the whole field
			long minTapThis = INF;
			if(map[i-1][j-down[i]] > 0)/* Drop from prev */{
				minTapThis = Min(minTapThis, map[i-1][j-down[i]]);
			}
			else{
				z = j;
				while(z > 0)/* Rise from prev */{
					if(map[i-1][z] <= 0)continue;
					minTapThis = Min(minTapThis, map[i-1][z]);
					z -= up[i];
				}
			}
			if(minTapThis < INF)flag = 0;
			
			if(i == pipe[pi].P){
				for(j = 0;j <= pipe[pi].L;j++)
					map[i][j] = 0; // Definitely pipe is unreachable
				for(j = pipe[pi].H;j < height;j++)
					map[i][j] = 0;
			}
		}
		
		if(flag == 1){
			completion = 0;
			for(j = 0;j < pipeCount;j++){
				if(pipe[j].P > i){
					completeValue = j - 1;
					i = width; // Terminate the outer FOR loop
					break;
				}
			}
		}
	}
	
	fout << completion << " " << completeValue << endl;
	fin.close();
	fout.close();
	return 0;
}

void PipeSort(long a,long b){
	if(a+1 >= b)return;
	int i = a,j = b-1,f = 0;
	
	while(i<j){
		if(p[i].P > p[j].P){
			Swap(p[i],p[j]);
			f = f ^ 1;
		}
		
		(f==0) ? (j--) : (i++);
	}
	
	PipeSort(a,i);
	PipeSort(i+1,b);
}


