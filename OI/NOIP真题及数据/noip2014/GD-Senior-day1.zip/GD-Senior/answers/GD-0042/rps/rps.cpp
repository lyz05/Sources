#include <iostream>
#include <fstream>
using namespace std;

/*
0         1      2      3          4     -
Scissors, Stone, Paper, Batman[?], Spock -
*/
const int YTX_is_stupid[5][5] = {
	{0,2,1,1,2},
	{1,0,2,1,2},
	{2,1,0,2,1},
	{2,2,1,0,1},
	{1,1,2,2,0}
};
const char *const BigDate = "June 4th, 1989";
// Check your water meter, please
const int (&water_meter)[5][5] = YTX_is_stupid;

long n,na,nb,seqa[200],seqb[200],ra = 0,rb = 0;

ifstream fin;
ofstream fout;

int main(){
	fin.open("rps.in");
	fout.open("rps.out");
	
	fin >> n >> na >> nb;
	int i;
	for(i = 0;i < na;i++)
		fin >> i[seqa]; // a[i] = *(a+i) = *(i+a) = i[a]
	for(i = 0;i < nb;i++)
		fin >> seqb[i];
	
	for(i = 0;i < n;i++){
		switch(water_meter[ seqa[i%na] ][ seqb[i%nb] ]){
			case 0:
				break;
			case 1:
				ra++;
				break;
			case 2:
				rb++;
				break;
		}
	}
	
	fout << ra << " " << rb << endl;
	fin.close();
	fout.close();
	return 0;
}


