#include <iostream>
#include <fstream>
using namespace std;

typedef
struct I_am_tired_of_YTX{
	long a;
	long b;
}
I_Love_Forty_Zoe;
/*
I think I'd better add some descriptions
Because it is said that this year
All codes will be published
This is Structure "Edge"
*/

/*
But since I don't think I can complete Program 3
Why not do something funny?
*/

I_Love_Forty_Zoe e[400000];
long w[200000];

long n,sm = 0,sma,smb,st = 0;

ifstream fin;
ofstream fout;

void Harsh_YTX(long,long);

template <typename T>
inline void Swap(T& a,T& b){
	T t = a;
	a = b;
	b = t;
}

int main(){
	fin.open("link.in");
	fout.open("link.out");
	
	fin >> n;
	int i,j,ja,jb;
	for(i = 0;i < n-1;i++){
		fin >> ja >> jb;
		ja--;
		jb--;
		e[2*i].a = ja;
		e[2*i].b = jb;
		e[2*i+1].a = jb;
		e[2*i+1].b = ja;
	}
	e[2*n-2].a = e[2*n-2].b = -1;
	for(i = 0;i < n;i++){
		fin >> w[i];
	}
	Harsh_YTX(0,2*n-2);
	/*
	for(i = 0;i < 2*n-1;i++){
		cout << e[i].a << " " << e[i].b << endl;
	}
	*/
	
	int xb, sp = 0, cr = e[0].a,ltl,sqtl;
	for(xb = 0;xb < 2*n-1;xb++){
		if(e[xb].a != cr){
			if(xb-sp < 2)goto xwhxhyz;
			sma = smb = ltl = sqtl = 0;
			for(i = sp;i < xb;i++){
				sqtl = (sqtl + w[e[i].b]*w[e[i].b])  %10007;
				ltl = (ltl + w[e[i].b])  %10007;
				if(w[e[i].b] > sma){
					smb = sma;
					sma = w[e[i].b];
				}else if(w[e[i].b] > smb){
					smb = w[e[i].b];
				}
			}
			if(sma*smb > sm)sm = sma * smb;
			// cout << cr << " " << sma << " " << smb << endl;
			
			ltl = (ltl*ltl)%10007;
			sma = (20014+ltl-sqtl)%10007;
			st = (st+sma)%10007;
			
			xwhxhyz:
			
			cr = e[xb].a;
			sp = xb;
		}
	}
	
	fout << sm << " " << st << endl;
	fin.close();
	fout.close();
	return 0;
}

void Harsh_YTX(long a,long b){
	if(a+1 >= b)return;
	int i = a,j = b-1,f = 0;
	
	while(i<j){
		if((e[i].a > e[j].a)/* || ((e[i].a == e[j].a) && (e[i].b > e[j].b))*/){
			Swap(e[i],e[j]);
			f = f ^ 1;
		}
		
		(f==0) ? (j--) : (i++);
	}
	
	Harsh_YTX(a,i);
	Harsh_YTX(i+1,b);
}




