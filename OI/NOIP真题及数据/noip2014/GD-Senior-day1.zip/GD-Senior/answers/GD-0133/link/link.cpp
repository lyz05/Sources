#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;

#define N 200000+10
const int M=10007;
struct Nodetype
{
	int node;
	Nodetype *next;
}*a[N],*p;

bool bz[N];
int d[2*N];
int f[N],w[N],t[N],MW1[N],MW2[N],SUM[N];
int n,Mans=-0x7FFFFFFF,ans=0;

void link(int x,int y)
{
	p=new Nodetype;
	p->node=y;
	p->next=a[x];
	a[x]=p;
}

void Swap(int *a,int *b) {int t=*a; *a=*b; *b=t;}

void BFS(int S)
{
	int i=0,j=1;
	d[1]=S;
	bz[S]=1;
	while(i<j)
	{
		i++;
		int now=d[i];
		p=a[now];
		while(p)
		{
			if(!bz[p->node]&&p->node!=f[now])
			{
				bz[p->node]=1;
				d[++j]=p->node;
				f[p->node]=now;
				SUM[now]+=w[p->node];
				if(w[p->node]>MW1[now])
				{
					Swap(&MW1[now],&MW2[now]);
					MW1[now]=w[p->node];
				}
				else if(w[p->node]>MW2[now]) MW2[now]=w[p->node];
			}
			p=p->next;
		}
	}
}

int main()
{
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	scanf("%d",&n);
	memset(a,0,sizeof(a));
	memset(f,0,sizeof(f));
	memset(w,0,sizeof(w));
	memset(t,0,sizeof(t));
	memset(bz,0,sizeof(bz));
	memset(MW1,0,sizeof(MW1));
	memset(MW2,0,sizeof(MW2));
	memset(SUM,0,sizeof(SUM));
	for(int i=1;i<n;i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		t[u]++; t[v]++;
		link(u,v);
		link(v,u);
	}
	for(int i=1;i<=n;i++) scanf("%d",&w[i]);
	int F=1;
	for(;t[F]>1;F++);
	BFS(F);
	for(int i=1;i<=n;i++)
	{
		int s=w[i]*w[f[f[i]]];
		int T=(w[i]==MW1[f[i]] ? MW2[f[i]] : MW1[f[i]]);
		if(s>Mans) Mans=s;
		if(w[i]*T>Mans) Mans=w[i]*T;
		ans=(ans%M+(s*2)%M)%M;
		if(f[i]) ans=(ans%M+(w[i]%M*(SUM[f[i]]-w[i])%M)%M)%M;
	}
	printf("%d %d\n",Mans,ans%M);
	return 0;
}
