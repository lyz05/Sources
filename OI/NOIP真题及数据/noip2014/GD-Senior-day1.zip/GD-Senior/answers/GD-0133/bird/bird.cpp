#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;

#define N 10000+10
struct Stype1
{
	int x,y;
}s[N];
struct Stype2
{
	bool is;
	int l,h;
}p[N];

bool ok=0;
int n,m,k,Minans=0x7FFFFFFF,Maxans=-0x7FFFFFFF;

int Min(int x,int y) { return x < y ? x : y ; }

bool pd(int H,int l,int r) { return (H>l&&H<r&&H!=0) ; }

void dfs(int w,int hight,int tot,int times)
{
	if(times>Minans) return;
	if(tot>Maxans) Maxans=tot;
	if(w==n)
	{
		ok=1;
		Minans=times;
		return;
	}
	if(p[w+1].is)
	{
		if(pd(hight-s[w].y,p[w+1].l,p[w+1].h)) dfs(w+1,hight-s[w].y,tot+1,times);
		for(int k=1;k<=3;k++)
		{
			int delta=s[w].x*k;
			int now=Min(hight+delta,m);
			if(pd(now,p[w+1].l,p[w+1].h)) dfs(w+1,now,tot+1,times+k);
		}
	}
	else
	{
		if(pd(hight-s[w].y,0,m+1)) dfs(w+1,hight-s[w].y,tot,times);
		for(int k=1;k<=3;k++)
		{
			int delta=s[w].x*k;
			int now=Min(hight+delta,m);
			if(pd(now,0,m+1)) dfs(w+1,now,tot,times+k);
		}
	}
}

int main()
{
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	memset(s,0,sizeof(s));
	memset(p,0,sizeof(p));
	for(int i=0;i<n;i++) scanf("%d%d",&s[i].x,&s[i].y);
	for(int i=1;i<=k;i++)
	{
		int x;
		scanf("%d",&x);
		scanf("%d%d",&p[x].l,&p[x].h);
		p[x].is=1;
	}
	for(int i=1;i<=m;i++) dfs(0,i,0,0);
	if(ok) printf("1\n%d\n",Minans);
	else printf("0\n%d\n",Maxans);
	return 0;
}
