#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;

int t[10][10];
int a[210],b[210];
int N,Na,Nb,ans1=0,ans2=0;

void pre()
{
	t[0][2]=1; t[0][3]=1; t[2][0]=-1; t[3][0]=-1;
	t[1][0]=1; t[1][3]=1; t[0][1]=-1; t[3][1]=-1;
	t[2][1]=1; t[2][4]=1; t[1][2]=-1; t[4][2]=-1;
	t[3][2]=1; t[3][4]=1; t[2][3]=-1; t[4][3]=-1;
	t[4][0]=1; t[4][1]=1; t[0][4]=-1; t[1][4]=-1;
}

int main()
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	scanf("%d%d%d",&N,&Na,&Nb);
	memset(t,0,sizeof(t));
	pre();
	for(int i=1;i<=Na;i++) scanf("%d",&a[i]);
	for(int i=1;i<=Nb;i++) scanf("%d",&b[i]);
	int i=1;
	while(i<=N)
	{
		int pa=i%Na,pb=i%Nb;
		if(!pa) pa=Na;
		if(!pb) pb=Nb;
		if(t[a[pa]][b[pb]]>0) ans1++;
		if(t[a[pa]][b[pb]]<0) ans2++;
		i++;
	}
	printf("%d %d\n",ans1,ans2);
	return 0;
}
