#include<cstdio>
#include<cstring>
#include<algorithm>
#define fo(i,a,b) for (int i = a;i <= b;i ++)

using namespace std;

const int maxn = 205;
const int st[5][5] = {{0,-1,1,1,-1},
                      {0,0,-1,1,-1},
                      {0,0,0,-1,1},
                      {0,0,0,0,1},
                      {0,0,0,0,0}};

int N,NA,NB,A[maxn],B[maxn],SA=0,SB=0;

int main()
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	scanf("%d%d%d",&N,&NA,&NB);
	fo(i,0,NA-1) scanf("%d",&A[i]);
	fo(i,0,NB-1) scanf("%d",&B[i]);
	for (int k = 1,i = 0,j = 0;k <= N;k ++,i ++,j ++)
	{
		i %= NA, j %= NB;
		if (A[i] < B[j])
		{
			if (st[A[i]][B[j]] == -1) SB ++;
			else if (st[A[i]][B[j]] == 1) SA ++;
		} 
		else
		if (A[i] > B[j])
		{
			if (st[B[j]][A[i]] == -1) SA ++;
			else if (st[B[j]][A[i]] == 1) SB ++;
		}
	}
	printf("%d %d\n",SA,SB);
	return 0;
}
