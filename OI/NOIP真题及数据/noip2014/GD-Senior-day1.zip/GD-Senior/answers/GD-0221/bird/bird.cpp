#include<cstdio>
#include<cstring>
#include<algorithm>
#define fo(i,a,b) for (int i = a;i <= b;i ++)

using namespace std;

const int maxn = 10005;
const int maxm = 1005;
const int INF = (int)1e9;

int N,M,K,X[maxn],Y[maxn];
int f[maxn][maxm];
bool flag[maxn][maxm];

struct Barrier
{
	 int P,L,H;
}B[maxn];

inline bool cmp(const Barrier &a,const Barrier &b)
{
	if (a.P < b.P) return 1; else return 0;
}

void Initialize()
{
	scanf("%d%d%d",&N,&M,&K);
	fo(i,0,N-1) scanf("%d%d",&X[i],&Y[i]);
	fo(i,1,K) scanf("%d%d%d",&B[i].P,&B[i].L,&B[i].H);
	sort(B+1,B+1+K,cmp);
	fo(i,1,K)
	{
		fo(j,0,B[i].L) flag[B[i].P][j] = 1;
		fo(j,B[i].H,M) flag[B[i].P][j] = 1;
	}
}

void Work()
{
	memset(f,60,sizeof f);
	fo(i,1,M) f[0][i] = 0;
	fo(i,0,N-1)
	{
		fo(j,1,M)
		{
			if (f[i][j] > INF || flag[i][j]) continue;
			fo(k,1,M)
			{
				int _j = j + k * X[i];
				if (_j > M) _j = M;
				if (!flag[i+1][_j])
					if (f[i][j]+k < f[i+1][_j]) f[i+1][_j] = f[i][j]+k;
				if (_j >= M)
					break;
			}
			if (j > Y[i])
				if (f[i][j] < f[i+1][j-Y[i]]) f[i+1][j-Y[i]] = f[i][j];
		}
	}
}

void Print()
{
	int Ans = INF;
	fo(i,1,M) Ans = min(Ans,f[N][i]);
	if (Ans < INF) printf("1\n%d\n",Ans);
	else
	{
		bool done = 0;
		for (int i = K;i >= 1;i --)
		{
			fo(j,B[i].L+1,B[i].H-1)
				if (f[B[i].P][j] < INF)
				{
					done = 1;
					break;
				}
			if (done)
			{
				Ans = i;
				break;
			}
		}
		if (!done) Ans = 0;
		printf("0\n%d\n",Ans);
	}
}

int main()
{
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	Initialize();
	Work();
	Print();
	return 0;
}
