#include<cstdio>
#include<cstring>
#include<algorithm>
#define fo(i,a,b) for (int i = a;i <= b;i ++)

using namespace std;

const int maxn = 200005;
const int maxm = 400005;
const int P = 10007;

int N,W[maxn],father[maxn],q[maxn];;
int tot,a[maxn],b[maxm],c[maxm];
int S[maxn],M[maxn],Sum,Max;

void Insert(int x,int y)
{
	tot ++;
	b[tot] = y;
	c[tot] = a[x];
	a[x] = tot;
}

void Prebfs()
{
	q[1] = 1;
	for	(int l = 0,r = 1;l < r;)
	{
		int x = q[++l];
		for (int i = a[x];i;i = c[i])
			if (b[i] != father[x])
			{
				father[b[i]] = x;
				q[++r] = b[i];
			}
	}
}

void Initialize()
{
	scanf("%d",&N);
	fo(i,1,N-1)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		Insert(x,y), Insert(y,x);
	}
	fo(i,1,N) scanf("%d",&W[i]);
	Prebfs();
}

void Work()
{
	for (int j = N;j >= 1;j --)
	{
		int x = q[j];
		for (int i = a[x];i;i = c[i])
		{
			if (b[i] == father[x]) continue;
			
			Max = max(Max,M[b[i]]*W[x]);
			Sum = (Sum + S[b[i]]*W[x]%P) % P;
			Max = max(Max,M[x]*W[b[i]]);
			Sum = (Sum + S[x]*W[b[i]]%P) % P;

			M[x] = max(M[x],W[b[i]]);
			S[x] = (S[x] + W[b[i]]) % P;
		}
	}
	printf("%d %d\n",Max,Sum*2%P);
}

int main()
{
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	Initialize();
	Work();
	return 0;
}
