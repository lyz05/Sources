#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <fstream>
#include <string>
using namespace std;

const int maxn = 505;
int n,na,nb,a[maxn],b[maxn],ans[3];
int g[5][5] = { {0,1,2,2,1} , {2,0,1,2,1} , {1,2,0,1,2} , {1,1,2,0,2} , {2,2,1,1,0}} ;

void Init() {
	scanf("%d%d%d",&n,&na,&nb);
	for (int i = 1; i <= na; i++) scanf("%d",&a[i]);
	for (int i = na + 1; i <= n; i++) a[i] = a[i-na];
	
	for (int i = 1; i <= nb; i++) scanf("%d",&b[i]);
	for (int i = nb + 1; i <= n; i++) b[i] = b[i-nb];
}

void Solve() {
	for (int i = 1; i <= n; i++)
		ans[ g[ b[i] ][ a[i] ] ]++;
	printf("%d %d\n",ans[1],ans[2]);
}

int main() {
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	
	Init();
	Solve();
	
	return 0;
}

