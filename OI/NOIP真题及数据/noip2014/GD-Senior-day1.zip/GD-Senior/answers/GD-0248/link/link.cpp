#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <fstream>
#include <string>
using namespace std;

const int maxn = 200500;
const int mo = 10007;

struct Tedge { 
	int node,next;
	Tedge() {}
	Tedge(int ta,int tb) { node = ta, next = tb; }
}e[2*maxn];

int n,fre,maxl,ans;
int w[maxn],q[maxn],fa[maxn],sum[maxn],maxe[maxn],head[maxn];
bool boo[maxn];

void Addedge(int a,int b) {
	e[ ++fre ] = Tedge(b,head[a]);
	head[a] = fre;
}

void Init() {
	int a,b;
	scanf("%d",&n);
	fre = -1;
	memset(head,255,sizeof(head));
	for (int i = 1; i < n; i++) {
		scanf("%d%d",&a,&b);
		Addedge(a,b);
		Addedge(b,a);
	}
	for (int i = 1; i <= n; i++) scanf("%d",&w[i]);
}

void Bfs() {
	int h,t,tmp;
	q[1] = 1; boo[1] = true; fa[1] = 0;
	h = 1; t = 1;
	for (; h <= t; h++) {
		tmp = q[h];
		for (int now = head[tmp]; now != -1; now = e[now].next) 
			if (! boo[ e[now].node ] ) {
				boo[ e[now].node ] = true;
				q[ ++t ] = e[now].node;
				fa[ e[now].node ] = tmp;
			}
	}
}

void Solve() {
	int ele;
	ans = 0; maxl = 0;
	for (int i = n; i > 0; i--) {
		ele = q[i];
		sum[ fa[ ele ] ] = ( sum[ fa[ ele ] ] + w[ele] ) % mo ;
		if (w[ele] > w[ maxe[ fa[ele] ] ]) maxe[ fa[ele] ] = ele;
		ans = ( ans + ( w[ fa[ele] ] * sum[ele] ) % mo ) % mo; // i : ����i�ĸ��׺Ͷ��ӵ�����Ȩ 
		maxl = max(maxl,w[ fa[ fa[ele] ] ] * w[ele]);
	}
	for (int i = n; i > 0; i--) {
		ele = q[i];
		sum[ fa[ele] ] = ( ( sum[ fa[ele] ] - w[ele] ) % mo + mo ) % mo;
		ans = ( ans + ( w[ele] * sum[ fa[ele] ]) % mo ) % mo ;
		if (maxe[ fa[ele] ] != ele) maxl = max(maxl,w[ele] * w[ maxe[ fa[ele] ] ]);
	}
}

int main() {
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	
	Init();
	Bfs();
	Solve();
	printf("%d %d\n",maxl,(ans*2) % mo);
	
	return 0;
}

