#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <fstream>
#include <string>
using namespace std;

const int maxn = 2050;
const int maxm = 250;

struct Tbound {
	int lo,hi;
	Tbound() {}
	Tbound(int tlo,int thi) { lo = tlo , hi = thi; }
}blo[maxn];

int n,m,k,ans,tot;
int dx[maxn],dy[maxn],f[maxn][maxm];
bool boo[maxn];

void Init() {
	int p,l,h;
	scanf("%d%d%d",&n,&m,&k);
	for (int i = 0; i < n; i++) scanf("%d%d",&dx[i],&dy[i]);
	for (int i = 0; i <= n; i++) blo[i] = Tbound(1,m);
	for (int i = 1; i <= k; i++) {
		scanf("%d%d%d",&p,&l,&h);
		blo[p] = Tbound(l+1,h-1);
		boo[p] = true; 
	}
}

void Solve() {
	int now,st,en;
	memset(f,255,sizeof(f));
	for (int i = 1; i <= m; i++) f[0][i] = 0;
	
	for (int i = 0; i < n; i++)
	for (int j = blo[i].lo; j <= blo[i].hi; j++)
		if (f[i][j] != -1) {
			if (boo[i]) {
				tot++; 
				boo[i] = false; 
			}
			
			if ( (j + dx[i] <= blo[i+1].hi) || ((j + dx[i] > m) && (!boo[i]))) {
				if (blo[i+1].lo - j <= 0) st = 1; else st = (blo[i+1].lo - j) / dx[i];
				if (j + st * dx[i] < blo[i+1].lo) st++;
				now = j + st * dx[i];
				if (now > m) now = m;
				/*st = (blo[i+1].lo - j) / dx[i];
				if (st < 1) st = 1;*/
				for (int t = st; now <= blo[i+1].hi; t++) {
//					if ((now >= blo[i+1].lo) && (now <= blo[i+1].hi)) {
						if (f[i+1][now] == -1) 
							f[i+1][now] = f[i][j] + t;
						else
							f[i+1][now] = min(f[i+1][now],f[i][j] + t);
						if ((now != m) && (now + dx[i] > m)) now = m; else now += dx[i];
//					}
				}
			}
			
			now = j - dy[i];
			if ((now >= blo[i+1].lo) & (now <= blo[i+1].hi)) {
				if (f[i+1][now] == -1) 
					f[i+1][now] = f[i][j];
				else
					f[i+1][now] = min(f[i+1][now],f[i][j]);
			}
		}
		
	if (boo[n])
	for (int j = blo[n].lo; j <= blo[n].hi; j++)
		if (f[n][j] != -1) {
			tot++; 
			boo[n] = false;
			break;
		}	
}

void Print() {
	bool flag = false;
	ans = n * m * 5;
	for (int j = blo[n].lo; j <= blo[n].hi; j++)
		if (f[n][j] != -1) {
			flag = true; 
			ans = min(ans,f[n][j]);
		}
	if (flag) 
		printf("1\n%d\n",ans);
	else 
		printf("0\n%d\n",tot);
		
/*	printf("\n");
	for (int i = m; i >= 0; i--) {
		for (int j = 0; j <= n; j++)
			printf("%d ",f[j][i]);
		printf("%d\n");
	}*/
}

int main() {
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	
	Init();
	Solve();
	Print();
	
	return 0;
}

