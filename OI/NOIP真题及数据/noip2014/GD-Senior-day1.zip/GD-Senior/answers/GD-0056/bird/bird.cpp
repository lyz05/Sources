#include <cstdio>
#include <iostream>
#include <cstdio>
using namespace std;

const long N=10010, M=1010, L=999999999;
long n, m, p, S, pass;
long lu[N], ld[N];
long a[N][M], X[N], Y[N];

int main()
{
	long i, j, k, dx, dy, dz;
	bool cp;
	freopen("bird.in", "r", stdin);
	freopen("bird.out", "w", stdout);
	scanf("%ld%ld%ld", &n, &m, &p);
	/*X, Y*/
	for (i=0; i<n; i++)
		scanf("%ld%ld", &X[i], &Y[i]);
	/*lu, ld*/
	for (i=0; i<=n; i++)
		ld[i]=0, lu[i]=m+1;
	for (i=1; i<=p; i++)
	{
		scanf("%ld%ld%ld", &dx, &dy, &dz);
		ld[dx]=dy;
		lu[dx]=dz;
	}
	/*a*/
	for (i=1; i<=n; i++)
		for (j=0; j<=m; j++)
			a[i][j]=L;
	for (i=0; i<=n; i++)
	{
		for (j=0; j<=m; j++)
			if (!(ld[i] < j && j < lu[i]))
				a[i][j]=L;
		cp=0;
		for (j=0; j<=m; j++)
			if (a[i][j] < L)
				cp=1;
		if (cp && lu[i] < m+1) pass++;
		if (i == n || !cp) break;
		for (j=m; j>=0; j--)
		{
			if (a[i][j] == L) continue;
			for (k=1; j+k*X[i]<=m; k++)
				if (a[i+1][j+k*X[i]] <= a[i][j]+k) break;
					a[i+1][j+k*X[i]]=a[i][j]+k;
			if (j+k*X[i] > m && a[i+1][m] > a[i][j]+k)
				a[i+1][m]=a[i][j]+k;
		}
		for (j=0; j<=m; j++)
		{
			if (a[i][j] == L) continue;
			if (j-Y[i] >= 0 && a[i+1][j-Y[i]] > a[i][j])
				a[i+1][j-Y[i]]=a[i][j];
		}
	}
	S=L;
	for (i=0; i<=m; i++)
		S=min(S, a[n][i]);
	if (S < L)
		printf("1\n%ld\n", S);
	else
		printf("0\n%ld\n", pass);
	fclose(stdin); fclose(stdout);
}
