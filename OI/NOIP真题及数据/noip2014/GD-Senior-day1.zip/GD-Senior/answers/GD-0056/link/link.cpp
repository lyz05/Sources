#include <cstdio>
#include <iostream>
#define Long long long
using namespace std;

struct edge
{ Long x; edge *next; };
const Long N=200010;
Long n, s, S;
Long w[N], c[N], x[N], y[N];
edge e[N];

int main()
{
	Long i, dx, dy, v1, v2, v;
	edge *p;
	freopen("link.in", "r", stdin);
	freopen("link.out", "w", stdout);
	scanf("%lld", &n);
	/*x, y, e*/
	for (i=1; i<n; i++)
	{
		scanf("%lld%lld", &dx, &dy);
		p=new edge;
		p->x=dy; p->next=e[dx].next;
		e[dx].next=p;
		p=new edge;
		p->x=dx; p->next=e[dy].next;
		e[dy].next=p;
		x[i]=dx; y[i]=dy;
	}
	/*w*/
	for (i=1; i<=n; i++)
		scanf("%lld", &w[i]);
	/*c*/
	for (i=1; i<n; i++)
	{
		c[x[i]]=c[x[i]]+w[y[i]];
		c[y[i]]=c[y[i]]+w[x[i]];
	}
	/*s, S*/
	for (i=1; i<=n; i++)
	{
		v1=v2=0;
		for (p=e[i].next; p!=NULL; p=p->next)
		{
			v=p->x;
			S=S+w[v]*(c[i]-w[v]);
			if (w[v] > v1)
			{ v2=v1; v1=w[v]; continue; }
			if (w[v] > v2)
				v2=w[v];
		}
		if (v1*v2 > s)
			s=v1*v2;
	}
	S%=10007;
	cout << s << ' ' << S << '\n';
	fclose(stdin); fclose(stdout);
}
