#include <cstdio>
using namespace std;

const long s[5][5]={
{0, 0, 1, 1, 0},
{1, 0, 0, 1, 0},
{0, 1, 0, 0, 1},
{0, 0, 1, 0, 1},
{1, 1, 0, 0, 0}};
const long N=210;
long n, na, nb, sa, sb;
long a[N], b[N];

int main()
{
	long i, pa, pb;
	freopen("rps.in", "r", stdin);
	freopen("rps.out", "w", stdout);
	scanf("%ld%ld%ld", &n, &na, &nb);
	for (i=0; i<na; i++)
		scanf("%ld", &a[i]);
	for (i=0; i<nb; i++)
		scanf("%ld", &b[i]);
	pa=pb=0;
	for (i=1; i<=n; i++)
	{
		sa+=s[a[pa]][b[pb]];
		sb+=s[b[pb]][a[pa]];
		pa=(pa+1)%na;
		pb=(pb+1)%nb;
	}
	printf("%ld %ld\n", sa, sb);
	fclose(stdin); fclose(stdout);
}
