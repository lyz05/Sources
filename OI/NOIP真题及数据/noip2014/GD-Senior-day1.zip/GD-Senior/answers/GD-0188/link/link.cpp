#include <cstdio>
#include <iostream>
#include <cmath>
#include <cstring>
#include <vector>

using namespace std;

const int MAXN = 300001;
const int mod_num = 10007;

struct Node
{
	int f;
	long long f_max,s_max;
	long long sum;
};

int n;
int w[MAXN];
long long ans_max;
long long ans_sum;
Node Tree[MAXN];
vector <int> G[MAXN];
vector <int> child[MAXN];

void build(int u,int fa)
{
	Tree[u].f = fa;
	for (int i=0;i<G[u].size();i++) if (G[u][i] != fa) 
	{
		child[u].push_back(G[u][i]);
		build(G[u][i],u);		
	}
	for (int i=0;i<child[u].size();i++) 
	{
		int e = w[child[u][i]];
		if (e > Tree[u].f_max) Tree[u].s_max = Tree[u].f_max, Tree[u].f_max = e;
		else if (e > Tree[u].s_max) Tree[u].s_max = e;
		Tree[u].sum += e;
	}
}

void solve(int u)
{
	ans_max = max(ans_max,Tree[u].f_max*Tree[u].s_max);
	for (int i=0;i<child[u].size();i++) ans_sum = (ans_sum+(Tree[u].sum-w[child[u][i]])*w[child[u][i]])%mod_num;
	for (int i=0;i<child[u].size();i++)
	{
		int e = child[u][i];
		ans_sum = (ans_sum+w[u]*Tree[e].sum*2)%mod_num;
		ans_max = max(ans_max,w[u]*Tree[e].f_max);
	}
	for (int i=0;i<child[u].size();i++) solve(child[u][i]);

}

int main()
{
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
    scanf("%d",&n);
    for (int i=1;i<=n-1;i++)
    {
    	int u,v;
    	scanf("%d%d",&u,&v);
    	G[u].push_back(v);
    	G[v].push_back(u);
    }
    for (int i=1;i<=n;i++) scanf("%d",&w[i]);
    build(1,0);
    solve(1);
    printf("%lld ",ans_max);
    printf("%lld\n",ans_sum);
    return 0;
}
