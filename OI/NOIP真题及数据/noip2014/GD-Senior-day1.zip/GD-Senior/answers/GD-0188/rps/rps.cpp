#include <cstdio>

using namespace std;

const int MAXN = 301;
const int SIZE = 10;

int n,na,nb;
int SA[MAXN],SB[MAXN];
int a[SIZE][SIZE];

void make_table()
{
	a[0][0] = 0;a[0][1] = 0;a[0][2] = 1;a[0][3] = 1;a[0][4] = 0;
	a[1][1] = 0;a[1][2] = 0;a[1][3] = 1;a[1][4] = 0;
	a[2][2] = 0;a[2][3] = 0;a[2][4] = 1;
	a[3][3] = 0;a[3][4] = 1;
	a[4][4] = 0;
	for (int i=0;i<5;i++)
	    for (int j=i-1;j>=0;j--) a[i][j] = 1-a[j][i];	
}

int main()
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	make_table();
	scanf("%d%d%d",&n,&na,&nb);
	for (int i=1;i<=na;i++) scanf("%d",&SA[i]);
	for (int i=1;i<=nb;i++) scanf("%d",&SB[i]);
	int point_A = 0, point_B = 0;
	int ansA = 0, ansB = 0;
	for (int i=1;i<=n;i++)
	{
		point_A = point_A%na+1;
		point_B = point_B%nb+1;
		ansA += a[SA[point_A]][SB[point_B]];
		ansB += a[SB[point_B]][SA[point_A]];
	}
	printf("%d %d\n",ansA,ansB);
	return 0;
}
