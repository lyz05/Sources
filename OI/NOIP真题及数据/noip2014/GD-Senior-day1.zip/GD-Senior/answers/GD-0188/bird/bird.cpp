#include <cstdio>
#include <iostream>
#include <algorithm>
#include <vector>
#include <cstring>
#include <queue>

using namespace std;

const int MAXN = 1001;
const int MAXM = 101;
const int INF = 1000001;

struct Node
{
	int local,h,l;
	bool operator < (const Node &rhs) const
	{
		return local < rhs.local;
	}
};

struct Nd
{
	int v,dis;
};

int n,m,k,s = 0;
int x[MAXN],y[MAXN];
int dist[MAXN],pre[MAXN];
bool inq[MAXN];
Node Pipe[MAXN];
vector <Nd> G[8000001];

inline int get_point(int a,int b)
{
	return (a-1)*m+b;
}

bool spfa(int s,int maxnum,int x,int local)
{
	for (int i=0;i<=maxnum;i++) dist[i] = INF;
	memset(inq,false,sizeof(inq));
	queue <int> Q;
	Q.push(s);inq[s] = true;dist[s] = 0;
	while (!Q.empty())
	{
		int u = Q.front();Q.pop();
		inq[u] = false;
		for (int i=0;i<G[u].size();i++) if (dist[G[u][i].v] > dist[u]+G[u][i].dis)
		{
			Nd xx = G[u][i];
			dist[G[u][i].v] = dist[u]+G[u][i].dis;
			if (!inq[G[u][i].v])
			{
				Q.push(G[u][i].v);
				inq[G[u][i].v] = true;
			}
		}
    }
    bool flag = false;
    for (int i=1;i<=n;i++) pre[i] = INF;
    for (int i=Pipe[local].l+1;i<Pipe[local].h;i++) 
	{
		pre[i] = dist[get_point(x,i)];
		if (dist[get_point(x,i)] != INF) flag = true;
	}
	return flag;
}

void make_graph(int num)
{
	int local = Pipe[num].local-1;
	for (int i=Pipe[num].local;i<=Pipe[num+1].local;i++)
	{
		for (int j=1;j<=m;j++) G[get_point(i-local,j)].push_back((Nd){get_point(i-local+1,min(m,j+x[i])),1});
		for (int j=1;j<=m;j++) G[get_point(i-local,j)].push_back((Nd){get_point(i-local,min(m,j+x[i])),1});
		for (int j=y[i]+1;j<=m;j++) G[get_point(i-local,j)].push_back((Nd){get_point(i-local+1,j-y[i]),0});
	}
	for (int i=Pipe[num].l+1;i<Pipe[num].h;i++) G[0].push_back((Nd){get_point(1,i),pre[i]});
}

int main()
{
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	k += 2;
	for (int i=0;i<=n-1;i++) scanf("%d%d",&x[i],&y[i]);
	for (int i=2;i<=k-1;i++) scanf("%d%d%d",&Pipe[i].local,&Pipe[i].l,&Pipe[i].h);
	Pipe[1].local = 0, Pipe[1].l = 1, Pipe[1].h = m;
	Pipe[k].local = n, Pipe[k].l = 1, Pipe[k].h = m;
	sort(Pipe+1,Pipe+k+1);
	for (int i=1;i<=k-1;i++)
	{
		make_graph(i);
		bool flag = spfa(0,m*(Pipe[i+1].local-Pipe[i].local+1),Pipe[i+1].local-Pipe[i].local+1,i+1);
		if (!flag) 
		{
			printf("0\n%d\n",i-1);
			return 0;
		}
		int size = Pipe[i+1].local-Pipe[i].local+5;
		for (int i=0;i<=size*m;i++) G[i].clear();
	}	
	int ans = INF;
	for (int i=1;i<=m;i++) ans = min(ans,pre[i]);
	printf("1\n%d\n",ans);
	return 0;
}
