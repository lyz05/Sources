#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cstring>
using namespace std;

int n;
const int MAXN = 205;
int na[MAXN], nb[MAXN];
int scorea, scoreb;
int map[5][5] = {{0, -1, 1, 1, -1}, {1, 0, -1, 1, -1}, {-1, 1, 0, -1, 1}, {-1, -1, 1, 0, 1}, {1, 1, -1, -1, 0}}; // 0=ƽ 1=Ӯ -1=��

int main()
{
	freopen("rps.in", "r", stdin);
	freopen("rps.out", "w", stdout);
	
	cin >> n >> na[0] >> nb[0];
	for(int i=1; i<=na[0]; i++)
	{
		cin >> na[i];
	}
	for (int i=1; i<=nb[0]; i++)
	{
		cin >> nb[i];
	}
	
	scorea = scoreb = 0;
	int pa = 1, pb = 1;
	for (int i=1; i<=n; i++)
	{
		if (map[na[pa]][nb[pb]] == 1)
		{
			scorea++;
		}
		else if (map[na[pa]][nb[pb]] == -1)
		{
			scoreb++;
		}

		pa++;
		pb++;

		if (pa > na[0])
		{
			pa = 1;
		}
		if (pb > nb[0])
		{
			pb = 1;
		}
	}
	
	cout << scorea << ' ' << scoreb << endl;
	
	return 0;
}
