#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <algorithm>
using namespace std;

int n, m, k;
const int MAXN = 10005, MAXM = 1005;
int x[MAXN], y[MAXN];
struct pipetype
{
	int p, l, h;
	pipetype()
	{
		p = l = h = 0;
	}
	bool operator < (const pipetype &next) const
	{
		return p < next.p;
	}
};
pipetype pipe[MAXN];
int f[MAXN][MAXM];  // f[i][j] ��ʾ�ڵ�i�е�j�е������С����
bool achieve[MAXN][MAXM];

int main()
{
	freopen("bird.in", "r", stdin);
	freopen("bird.out", "w", stdout);
	
	cin >> n >> m >> k;
	for (int i=0; i<n; i++)
	{
		cin >> x[i] >> y[i];
	}
	for (int i=1; i<=k; i++)
	{
		cin >> pipe[i].p >> pipe[i].l >> pipe[i].h;
	}
	
	sort(pipe+1, pipe+1+k);
	
//	for (int i=1; i<=k; i++)
//	{
//		cout << pipe[i].p << ' ' << pipe[i].l << ' ' << pipe[i].h << endl;
//	}

//	freopen("CON", "r", stdin);
//	freopen("CON", "w", stdout);
	
	int nowpipe = 1;
	
	for (int j=1; j<=m; j++)
	{
		achieve[0][j] = true;
	}
	
//	if (n<=1000)
//	{
//		for (int i=0; i<n; i++)
//		{
//	//		if (i%100 == 0)
//	//			cout << i << endl;
//
//			int num_true = 0;
//			for (int j=m; j>=1; j--)
//			{
//				if (!achieve[i][j])
//				{
//					continue;
//				}
//
//				if ((j-y[i] > 0) && (f[i+1][j-y[i]]>f[i][j] || f[i+1][j-y[i]]==0))
//				{
//					f[i+1][j-y[i]] = f[i][j];
//					if (!achieve[i+1][j-y[i]])
//					{
//						num_true++;
//					}
//					achieve[i+1][j-y[i]] = true;
//				}
//
//				for (int add = x[i]; ; add+=x[i])
//				{
//					if ((j+add <= m) && ((f[i+1][j+add] > f[i][j]+add/x[i]) || (f[i+1][j+add] == 0)))
//					{
//						f[i+1][j+add] = f[i][j]+add/x[i];
//						if (!achieve[i+1][j+add])
//						{
//							num_true++;
//						}
//						achieve[i+1][j+add] = true;
//					}
//					else if (j+add > m)
//					{
//						if ((f[i+1][m] > f[i][j]+add/x[i]) || (f[i+1][m] == 0))
//						{
//							f[i+1][m] = f[i][j]+add/x[i];
//							if (!achieve[i+1][m])
//							{
//								num_true++;
//							}
//							achieve[i+1][m] = true;
//						}
//						break;
//					}
//				}
//			}
//
//			if (pipe[nowpipe].p == i+1)
//			{
//				for (int j=0; j<=pipe[nowpipe].l; j++)
//				{
//					if (achieve[i+1][j])
//					{
//						num_true--;
//					}
//					achieve[i+1][j] = false;
//				}
//				for (int j=pipe[nowpipe].h; j<=m; j++)
//				{
//					if (achieve[i+1][j])
//					{
//						num_true--;
//					}
//					achieve[i+1][j] = false;
//				}
//				nowpipe++;
//			}
//
//	//		for (int j=m; j>=0; j--)
//	//		{
//	//			cout << j << ' ' << f[i+1][j] << ' ';
//	//			if (achieve[i+1][j])
//	//			{
//	//				cout << "true\n";
//	//			}
//	//			else
//	//			{
//	//				cout << "false\n";
//	//			}
//	//		}
//	//		cout << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl;
//	//		getchar();
//
//			if (num_true == 0)
//			{
//				cout << 0 << endl;
//				cout << nowpipe-2 << endl;
//				return 0;
//			}
//		}
//
//		cout << 1 << endl;
//		int min_touch = 2147483640;
//		for (int j=1; j<=m; j++)
//		{
//			if (achieve[n][j] && f[n][j]<min_touch)
//			{
//				min_touch = f[n][j];
//			}
//		}
//		cout << min_touch << endl;
//	}
//	else
//	{
		for (int i=0; i<n; i++)
		{
//			if (i%100 == 0)
//				cout << i << endl;

			int num_true = 0;
			for (int j=m; j>=1; j--)
			{
				if (!achieve[i][j])
				{
					continue;
				}

				if ((j-y[i] > 0) && (f[i+1][j-y[i]]>f[i][j] || f[i+1][j-y[i]]==0))
				{
					f[i+1][j-y[i]] = f[i][j];
					if (!achieve[i+1][j-y[i]])
					{
						num_true++;
					}
					achieve[i+1][j-y[i]] = true;
				}

				for (int add = x[i]; ; add+=x[i])
				{
					if ((j+add <= m) && ((f[i+1][j+add] > f[i][j]+add/x[i]) || (f[i+1][j+add] == 0)))
					{
						f[i+1][j+add] = f[i][j]+add/x[i];
						if (!achieve[i+1][j+add])
						{
							num_true++;
							achieve[i+1][j+add] = true;
						}
						else
						{
							break;
						}
					}
					else if (j+add > m)
					{
						if ((f[i+1][m] > f[i][j]+add/x[i]) || (f[i+1][m] == 0))
						{
							f[i+1][m] = f[i][j]+add/x[i];
							if (!achieve[i+1][m])
							{
								num_true++;
								achieve[i+1][m] = true;
							}
							else
							{
								break;
							}
						}
						break;
					}
					else
					{
						break;
					}
				}
			}

			if (pipe[nowpipe].p == i+1)
			{
				for (int j=0; j<=pipe[nowpipe].l; j++)
				{
					if (achieve[i+1][j])
					{
						num_true--;
					}
					achieve[i+1][j] = false;
				}
				for (int j=pipe[nowpipe].h; j<=m; j++)
				{
					if (achieve[i+1][j])
					{
						num_true--;
					}
					achieve[i+1][j] = false;
				}
				nowpipe++;
			}

	//		for (int j=m; j>=0; j--)
	//		{
	//			cout << j << ' ' << f[i+1][j] << ' ';
	//			if (achieve[i+1][j])
	//			{
	//				cout << "true\n";
	//			}
	//			else
	//			{
	//				cout << "false\n";
	//			}
	//		}
	//		cout << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl;
	//		getchar();

			if (num_true == 0)
			{
				cout << 0 << endl;
				cout << nowpipe-2 << endl;
				return 0;
			}
		}

		cout << 1 << endl;
		int min_touch = 2147483640;
		for (int j=1; j<=m; j++)
		{
			if (achieve[n][j] && f[n][j]<min_touch)
			{
				min_touch = f[n][j];
			}
		}
		cout << min_touch << endl;
//	}
	
	return 0;
}
