#include <iostream>
#include <cstdlib>
#include <cstdio>
using namespace std;

int n;
const int MAXN = 200005;
struct nodetype
{
	nodetype *next;
	int to;
	nodetype()
	{
		to = 0;
	}
};
nodetype node[MAXN], link[MAXN];
int w[MAXN];

void add_node(int u, int v);
void add_link(int u, int v);

int main()
{
	freopen("link.in", "r", stdin);
	freopen("link.out", "w", stdout);
	
	cin >> n;
	for (int i=1; i<n; i++)
	{
		int u, v;
		cin >> u >> v;
		add_node(u, v);
	}
	for (int i=1; i<=n; i++)
	{
		cin >> w[i];
	}
	
//	for (int i=1; i<=n; i++)
//	{
//		nodetype *p = &node[i];
//		while (p->to != 0)
//		{
//			cout << p->to << ' ';
//			p = p->next;
//		}
//		cout << endl;
//	}

	for (int i=1; i<=n; i++)
	{
		nodetype *p = &node[i];
		while (p->to != 0)
		{
			nodetype *q = &node[p->to];
			while (q->to != 0)
			{
				add_link(i, q->to);
				q = q->next;
			}
			p = p->next;
		}
	}
	
//	for (int i=1; i<=n; i++)
//	{
//		nodetype *p = &link[i];
//		while (p->to != 0)
//		{
//			cout << p->to << ' ';
//			p = p->next;
//		}
//		cout << endl;
//	}

	int maxw = 0, sumw = 0;
	for (int i=1; i<=n; i++)
	{
		nodetype *p = &link[i];
		while (p->to != 0)
		{
			int temp = w[i] * w[p->to];
			if (maxw < temp)
			{
				maxw = temp;
			}
			sumw = (sumw + temp) % 10007;
			p = p->next;
		}
	}
	
	cout << maxw << ' ' << (sumw*2) % 10007 << endl;
	
	return 0;
}

void add_node(int u, int v)
{
	nodetype *p = new nodetype;
	p->to = node[u].to;
	p->next = node[u].next;
	node[u].to = v;
	node[u].next = p;
	return;
}

void add_link(int u, int v)
{
	nodetype *p = new nodetype;
	p->to = link[u].to;
	p->next = link[u].next;
	link[u].to = v;
	link[u].next = p;
	return;
}
