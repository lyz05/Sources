#include <cstdio>
#include <cstdlib>
#include <cstring>

#define N 255

using namespace std;

const int yes[5][5] = {
	{+0, -1, +1, +1, -1},
	{+1, +0, -1, +1, -1},
	{-1, +1, +0, -1, +1},
	{-1, -1, +1, +0, +1},
	{+1, +1, -1, -1, +0}
};

int n, na, nb, a[N], b[N], reta, retb;

int main() {
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	scanf("%d%d%d", &n, &na, &nb);
	for (int i=0;i<na;i++) scanf("%d", &a[i]);
	for (int i=0;i<nb;i++) scanf("%d", &b[i]);
	reta = retb = 0;
	for (int i=0;i<n;i++) {
		int ret = yes[a[i%na]][b[i%nb]];
		if (ret > 0) reta ++;
		if (ret < 0) retb ++;
	}
	printf("%d %d\n", reta, retb);
	return 0;
}
