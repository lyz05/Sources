#include <cstdio>
#include <cstdlib>
#include <cstring>

#define N 10020
#define M 1020
#define min(x,y) ((x)<(y)?(x):(y))

using namespace std;

int n, m, k, f[2][M], lm1[N], lm2[N], X[N], Y[N], gd[N], g[M], ans;

//int min(int x, int y) { return x < y ? x : y; }

int main() {
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	scanf("%d%d%d", &n, &m, &k);
	for (int i=0;i<n;i++) scanf("%d%d", &X[i], &Y[i]);
	for (int i=0;i<=n;i++) lm1[i] = 1, lm2[i] = m;
	memset(gd, 0, sizeof(gd));
	for (int i=0;i<k;i++) {
		int p, l, h;
		scanf("%d%d%d", &p, &l, &h);
		lm1[p] = l+1;
		lm2[p] = h-1;
		gd[p] = 1;
	}
	int s = 0; ans = 0;
	memset(f[s], 0, sizeof(f[s]));
	bool flag;
	for (int i=1;i<=n;i++) {
		s ^= 1;
		flag = false;
		for (int j=0;j<=m+1;j++) f[s][j] = 0x7f7f7f7f;
		for (int j=0;j<=m+1;j++) g[j] = 0x7f7f7f7f;
		for (int j=X[i-1]+1;j<=m;j++)
			g[j] = min(g[j-X[i-1]]+1, f[s^1][j-X[i-1]]+1);
		for (int j=lm1[i];j<=lm2[i];j++) {
			f[s][j] = min(g[j], f[s][j]);
			/*
			for (int a=1;a<=m;a++)
				if (j-a*X[i-1] > 0)
					f[s][j] = min(f[s][j], f[s^1][j-a*X[i-1]] + a);
			*/
			if (j+Y[i-1]<=m)
				f[s][j] = min(f[s][j], f[s^1][j+Y[i-1]]);
		}
		if (m <= lm2[i])
			for (int a=0;a<X[i-1] && m-a>0;a++)
				f[s][m] = min(f[s][m], f[s^1][m-a] + 1);
		for (int j=1;j<=m;j++)
			if (f[s][j] < 0x7f7f7f7f) flag = true;
		//for (int j=1;j<=m;j++) printf("%d ", f[s][j]); printf("\n");
		if (flag) ans += gd[i];
		else break;
	}
	if (!flag) printf("0\n%d\n", ans);
	else{
		int ans2 = 0x7f7f7f7f;
		for (int i=1;i<=m;i++)
			if (f[s][i] < ans2) ans2 = f[s][i];
		printf("1\n%d\n", ans2);
	}
	return 0;
}
