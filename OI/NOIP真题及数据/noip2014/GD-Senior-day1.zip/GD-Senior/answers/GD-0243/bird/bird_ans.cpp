#include <cstdio>
#include <cstdlib>
#include <cstring>

#define N 10020
#define M 1020

using namespace std;

int n, m, k, f[2][M], lm1[N], lm2[N], X[N], Y[N], gd[N], ans;

int min(int x, int y) { return x < y ? x : y; }

int main() {
	freopen("bird.in","r",stdin);
	freopen("bird.ans","w",stdout);
	scanf("%d%d%d", &n, &m, &k);
	for (int i=0;i<n;i++) scanf("%d%d", &X[i], &Y[i]);
	for (int i=0;i<=n;i++) lm1[i] = 1, lm2[i] = m;
	memset(gd, 0, sizeof(gd));
	for (int i=0;i<k;i++) {
		int p, l, h;
		scanf("%d%d%d", &p, &l, &h);
		lm1[p] = l+1;
		lm2[p] = h-1;
		gd[p] = 1;
	}
	int s = 0; ans = 0;
	memset(f[s], 0, sizeof(f[s]));
	bool flag;
	for (int i=0;i<n;i++) {
		for (int j=0;j<=m+1;j++) f[s^1][j] = 0x7f7f7f7f;
		flag = false;
		for (int j=lm1[i];j<=lm2[i];j++)
			if (f[s][j] < 0x7f7f7f7f) {
				flag = true;
				for (int a=1;a<=m;a++) 
					if (j+a*X[i] >= lm1[i+1] && min(j+a*X[i], m) <= lm2[i+1]) {
						f[s^1][min(j+a*X[i], m)] = min(f[s][j] + a, f[s^1][min(j+a*X[i], m)]);
						if (j+a*X[i]>m) break;
					}
				if (j-Y[i] >= lm1[i+1] && j-Y[i] <= lm2[i+1])
					f[s^1][j-Y[i]] = min(f[s][j], f[s^1][j-Y[i]]);
			}
		if (flag) ans += gd[i];
		else break;
		s ^= 1;
	}
	if (!flag) printf("0\n%d\n", ans);
	else{
		int ans2 = 0x7f7f7f7f;
		for (int i=1;i<=m;i++)
			if (f[s][i] < ans2) ans2 = f[s][i];
		printf("1\n%d\n", ans2);
	}
	return 0;
}
