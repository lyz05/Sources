#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <algorithm>

using namespace std;

int main() {
	freopen("bird.in","w",stdout);
	srand(time(0));
	int n = 10000, m = 1000, k = 50;
	printf("%d %d %d\n", n, m, k);
	for (int i=1;i<=n;i++)
		printf("%d %d\n", rand() % 50 + 1, rand() % 50 + 1);
	for (int i=1;i<=k;i++) {
		int x, y;
		x = rand() % m + 1, y = rand() % m + 1;
		while (x + 2 > y) {
			x = rand() % m + 1, y = rand() % m + 1;
		}
		printf("%d %d %d\n", rand() % n + 1, x, y);
	}
	return 0;
}
