#include <cstdio>
#include <cstdlib>
#include <cstring>

#define N 400020
#define Module 10007

using namespace std;

struct EDGE {
	int adj, next;
} edge[N];
int n, top, gh[N], father[N], W[N], q[N], ans, ansmax;

void addedge(int x, int y) {
	edge[++top].adj = y;
	edge[top].next = gh[x];
	gh[x] = top;
}

void bfs() {
	int head = 0, tail = 1;
	q[1] = 1;
	while (head < tail) {
		int x = q[++head];
		int sz = 0, mx = 0;
		for (int p=gh[x]; p; p=edge[p].next)
			if (edge[p].adj != father[x]) {
				father[edge[p].adj] = x;
				q[++tail] = edge[p].adj;
				if (father[x]) {
					(ans += W[father[x]] * W[edge[p].adj]) %= Module;
					if (W[father[x]] * W[edge[p].adj] > ansmax)
						ansmax = W[father[x]] * W[edge[p].adj];
				}
				(ans += sz * W[edge[p].adj]) %= Module;
				(sz += W[edge[p].adj]) %= Module;
				if (mx * W[edge[p].adj] > ansmax)
					ansmax = mx * W[edge[p].adj];
				if (W[edge[p].adj] > mx)
					mx = W[edge[p].adj];
			}
	}
}

int main() {
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	scanf("%d", &n);
	ansmax = 0;
	ans = 0;
	top = 0;
	memset(gh, 0, sizeof(gh));
	memset(father, 0, sizeof(father));
	for (int i=1;i<n;i++) {
		int x, y;
		scanf("%d%d", &x, &y);
		addedge(x, y);
		addedge(y, x);
	}
	for (int i=1;i<=n;i++) scanf("%d", &W[i]);
	bfs();
	(ans *= 2) %= Module;
	printf("%d %d\n", ansmax, ans);
	return 0;
}
