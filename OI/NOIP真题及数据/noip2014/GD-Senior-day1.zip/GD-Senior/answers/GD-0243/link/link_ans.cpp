#include <cstdio>
#include <cstdlib>
#include <cstring>

#define N 200020
#define Module 10007

using namespace std;

struct EDGE {
	int adj, next;
} edge[N*2];
int n, top, gh[N], ans, ansmax, W[N];

void addedge(int x, int y) {
	edge[++top].adj = y;
	edge[top].next = gh[x];
	gh[x] = top;
}

void dfs(int x, int rt, int rtt, int deep) {
	if (deep == 2) {
		(ans += W[x] * W[rtt]) %= Module;
		if (W[x] * W[rtt] > ansmax)
			ansmax = W[x] * W[rtt];
		return;
	}
	for (int p=gh[x]; p; p=edge[p].next)
		if (rt != edge[p].adj) {
			dfs(edge[p].adj, x, rt, deep+1);
		}
}

int main() {
	freopen("link.in","r",stdin);
	freopen("link.ans","w",stdout);
	scanf("%d", &n);
	for (int i=1;i<n;i++) {
		int x, y;
		scanf("%d%d", &x, &y);
		addedge(x, y);
		addedge(y, x);
	}
	for (int i=1;i<=n;i++) scanf("%d", &W[i]);
	ans = 0;
	ansmax = 0;
	for (int i=1;i<=n;i++) dfs(i, 0, 0, 0);
	printf("%d %d\n", ansmax, ans);
	return 0;
}
