#include<cstdio>
#include<cstring>
#include<algorithm>

using namespace std;

const int MAXN = 10005,MAXM = 1005; //Define j First

int F[MAXN][MAXM],Q[MAXM],L[MAXN],Sum[MAXN],R[MAXN],X[MAXN],Y[MAXN],N,M,K,tot,Inf, *a, *b, *Cur;

inline void Push(int Cur,long long x)
{
	if (*(b + Cur) == Inf) return;
	while (tot && (x * (*(b + Cur) - *(b + Q[tot])) <= Cur - Q[tot])) tot --;
	Q[++ tot] = Cur;
}

void read(int &x)
{
	char c;
	while (c = getchar(),c < '0' || c > '9');
	x = c - 48;
	while (c = getchar(),c >= '0' && c <= '9') x = x * 10 + c - 48;
}

int main()
{
	freopen("bird.in","r",stdin),freopen("bird.out","w",stdout);
	read(N),read(M),read(K);
	for(int i = 0;i < N;i ++) read(X[i]),read(Y[i]);
	for(int i = 0;i <= N;i ++) L[i] = 0,R[i] = M + 1;
	for(int i = 1;i <= K;i ++)
	{
		int P,l,H;read(P),read(l),read(H);
		Sum[P] ++,L[P] = l,R[P] = H;
	}
	for(int i = 1;i <= N;i ++) Sum[i] += Sum[i - 1];
	memset(F,60,sizeof F);
	Inf = F[0][0];
	for(int i = 1;i <= M;i ++) F[0][i] = 0;
	for(int i = 1;i <= N;i ++)
	{	
		int x = X[i - 1],y = Y[i - 1],Min = Inf;
		a = F[i],b = F[i - 1];
		for(int Mo = 0;Mo < X[i - 1];Mo ++)
		{
			tot = 0;
			for(int j = Mo;j <= M;j += x)
			if (!j) continue; else
			{
				if (j >= R[i]) break;
				if (j > x) Push(j - x,x);
				if (j <= L[i] || j >= R[i]) {*(a + j) = Inf;continue;}
				if (j + y <= M) *(a + j) = *(b + j + y);
				if (j > x)
				{
					if (tot) *(a + j) = min(*(a + j),*(b + Q[1]) + (j - Q[1]) / x);
				}
				if (*(a + j) < Min) Min = *(a + j);
			}
		}
		if (M >= R[i]) 
		{
			if (Min == Inf) break;
			continue;
		}
		*(a + M) = min(*(a + M),*(b + M) + 1);
		for(int k = 1;k <= M - 1;k ++) *(a + M) = min(*(a + M),*(b + k) + (M - k) / x + 1);
		if (*(a + M) < Min) Min = *(a + M);
		if (Min == Inf) break;
	}
	int Ans = Inf;
	for(int j = 1;j <= M;j ++) if (F[N][j] < Ans) 
			Ans = F[N][j];
	if (Ans != Inf) printf("1\n%d\n", Ans); else
	{
		printf("0\n");
		for(int i = N;i >= 0;i --)
		{
			a = F[i];
			bool ok = 0;
			for(int j = 1;j <= M;j ++) if (*(a + j) != Inf) {ok = 1;break;}
			if (ok) {printf("%d\n", Sum[i]);break;}
		}
	}
	return 0;
}

