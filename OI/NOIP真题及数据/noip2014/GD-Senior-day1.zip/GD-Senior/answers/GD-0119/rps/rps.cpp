#include<cstdio>
#include<cstring>

using namespace std;

const int MAXN = 205;

bool a[10][10];
int A[MAXN],B[MAXN],N,Na,Nb;

void Pre_Treat()
{
	a[0][2] = a[0][3] = 1;
	a[1][0] = a[1][3] = 1;
	a[2][1] = a[2][4] = 1;
	a[3][2] = a[3][4] = 1;
	a[4][0] = a[4][1] = 1;
}

int main()
{
	freopen("rps.in","r",stdin),freopen("rps.out","w",stdout);
	Pre_Treat();
	scanf("%d%d%d", &N, &Na, &Nb);
	int ca = 0,cb = 0;
	for(int i = 1;i <= Na;i ++) scanf("%d", &A[i]);
	for(int i = 1;i <= Nb;i ++) scanf("%d", &B[i]);
	for(int i = 1;i <= N;i ++)
	{
		int ac = A[(i - 1) % Na + 1],bc = B[(i - 1) % Nb + 1];
		ca += a[ac][bc],cb += a[bc][ac];
	}
	printf("%d %d\n",ca, cb);
	return 0;
}

