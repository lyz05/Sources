#include<cstdio>
#include<cstring>
#include<algorithm>

using namespace std;

const int MAXN = 300005,Mo = 10007;

bool bz[MAXN];
int Sum[MAXN],Fa[MAXN],W[MAXN],Max[MAXN],To[MAXN * 2],Next[MAXN * 2],Final[MAXN],N;
int Q[MAXN],tot,AnsMax,Count;

void link(int u,int v)
{
	To[++ tot] = v,Next[tot] = Final[u],Final[u] = tot;
}

void Bfs()
{
	int fi = 0,en = 1;Q[1] = 1;
	while (fi < en)
	{
		int u = Q[++ fi],PreMax = 0;bz[u] = 1;
		for(int i = Final[u];i;i = Next[i])
		if (!bz[To[i]]) 
		{
			Fa[To[i]] = u;
			Count = (Count + Sum[u] * W[To[i]] * 2 % Mo) % Mo;
			Sum[u] = (Sum[u] + W[To[i]]) % Mo;
			AnsMax = max(W[To[i]] * PreMax,AnsMax);
			PreMax = max(PreMax,W[To[i]]);
			Q[++ en] = To[i];
		}
		Max[u] = PreMax;
	}
	for(int i = en;i;i --)
	{
		int u = Q[i];
		for(int j = Final[u];j;j = Next[j])
		if (To[j] != Fa[u])
		{
			AnsMax = max(W[u] * Max[To[j]],AnsMax);
			Count = (Count + W[u] * Sum[To[j]] * 2 % Mo) % Mo;
		}
	}
}

int main()
{
	freopen("link.in","r",stdin),freopen("link.out","w",stdout);
	scanf("%d", &N);
	for(int i = 1;i < N;i ++)
	{
		int u,v;scanf("%d%d", &u, &v);
		link(u,v),link(v,u);
	}
	for(int i = 1;i <= N;i ++) scanf("%d", &W[i]);
	Bfs();
	printf("%d %d\n", AnsMax,Count);
	return 0;
}

