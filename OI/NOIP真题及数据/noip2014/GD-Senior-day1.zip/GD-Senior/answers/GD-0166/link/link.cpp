#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#define ll long long
using namespace std;
int p[2001][4];
ll w[2001];
int d[20001];
int v[2001][2001];
bool v1[2001][2001];
bool v2[2001];
int n,tmp=-1;ll ans,maxn;
void dfs(int n)
{
	tmp++;d[tmp]=n;
	for(int i=1;i<=3;i++)
	 {
	 	if(p[n][i]&&v[n][p[n][i]]<1)
	 	  {
	 	  	v[n][p[n][i]]++;
	 	  	v[p[n][i]][n]++;
	 	  	dfs(p[n][i]);
	 	  }
	 	
	 	  
	 }
	 for(int i=1;i<=3;i++)
	 {
	 	if(p[n][i]&&v[n][p[n][i]]<2)
	 	  {
	 	  	v[n][p[n][i]]++;
	 	  	v[p[n][i]][n]++;
	 	  	dfs(p[n][i]);
	 	  }
	 	
	 	  
	 }
	 
}
void bfs(int n,int step)
{
	d[step]=n;v2[n]=1;
	for(int i=1;i<=3;i++)
	 {
	 	if(p[n][i]&&!v2[p[n][i]])
	 	  {
	 	  	bfs(p[n][i],step+1);
	 	  }
	 }
}
int main()
{
freopen("link.in","r",stdin);
freopen("link.out","w",stdout);
ll i,a,b,m,j;
    cin>>n;
    for(i=1;i<n;i++)
      {
      	scanf("%d%d",&a,&b);
      	if(p[a][1]==0)
      	  {
      	  	p[a][1]=b;
      	  	if(p[b][1]==0)      	  	       	  	
      	  	   p[b][1]=a;
      	  	else if(p[b][2]==0)      	  	       	  	
      	  	   p[b][2]=a;
			else p[b][3]=a;	      
      	  }
      	else if(p[a][2]==0) {
      		p[a][2]=b;
      	  	if(p[b][1]==0)      	  	       	  	
      	  	   p[b][1]=a;
      	  	else if(p[b][2]==0)      	  	       	  	
      	  	   p[b][2]=a;
			else p[b][3]=a;
      	}  
      	else  {
      		p[a][3]=b;
      	  	if(p[b][1]==0)      	  	       	  	
      	  	   p[b][1]=a;
      	  	else if(p[b][2]==0)      	  	       	  	
      	  	   p[b][2]=a;
			else p[b][3]=a;
      }}
    for(i=1;i<=n;i++)
	   scanf("%d",&w[i]); 
	 dfs(1); 
	// for(i=0;i<=tmp;i++)
//	  cout<<i<<": "<<d[i]<<endl; 
	 for(i=0;i<=tmp;i++)
	   {
	   	for(j=i+2;j>=0&&j>=i-2;j-=4)
	   	  {
	   	  	if(d[i]!=d[j]&&!v1[d[i]][d[j]])
	   	  	 {
	   	  	  m=w[d[i]]*w[d[j]];//cout<<d[i]<<"--"<<d[j]<<endl;
	   	  	  maxn=max(maxn,m);
	   	  	  ans+=m;
	   	  	 v1[d[i]][d[j]]=v1[d[j]][d[i]]=1; 
			 }
	   	  }
	   } 
	 for(i=1;i<=tmp;i++)
	 d[i]=0;
	 bfs(1,0);
     for(i=0;i<=n;i++)
	   {
	   	for(j=i+2;j>=0&&j>=i-2;j-=4)
	   	  {
	   	  	if(d[i]!=d[j]&&!v1[d[i]][d[j]])
	   	  	 {
	   	  	  m=w[d[i]]*w[d[j]];
	   	  	  maxn=max(maxn,m);
	   	  	  ans+=m;while(ans>10007)ans-=10007;  	  	 
	   	  	 v1[d[i]][d[j]]=v1[d[j]][d[i]]=1; 
			 }
	   	  }
	   }  
	 ans*=2;while(ans>10007)ans-=10007;
	  cout<<maxn<<" "<<ans<<endl; 
fclose(stdin);fclose(stdout);
}
