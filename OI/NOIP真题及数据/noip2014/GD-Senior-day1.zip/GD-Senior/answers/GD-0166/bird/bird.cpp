#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>

using namespace std;
int n,m,k,maxn=99999999;
struct pipe
{
	int xi,l,h;
}p[10001];
int x[1001],y[1001];
int v[1001];
int loc[1001];
int f[1001][101];
int main()
{
	cin>>n>>m>>k;
	int i,j,t;
	for(i=0;i<=n-1;i++)
	   cin>>x[i]>>y[i];
	for(i=1;i<=k;i++)
	   {
	   cin>>p[i].xi>>p[i].l>>p[i].h;
	   v[p[i].xi]=1;loc[p[i].xi]=i;
       }
     for(i=1;i<=n;i++)
	    for(j=0;j<=m;j++)
		   f[i][j]=maxn;  
	for(i=1;i<=n;i++)		   	 	    
		{
			for(j=0;j<=m;j++)
	     	{
	     	if(f[i-1][j+y[i-1]]<maxn&&j+y[i-1]<=m) 
			   f[i][j]=f[i-1][j+y[i-1]];
			 t=3;
			 for(;t!=0;t--)
			    if(f[i-1][j-t*x[i-1]]<maxn&&j-t*x[i-1]>=0)
			    {
			  //  if(f[i][j]==-1)f[i][j]=maxn;  
			    f[i][j]=min(f[i][j],f[i-1][j-t*x[i-1]]+t);    
			    }
			  if(j==m)
			    for(t=m-x[i-1];t<=m;t++)
			    if(f[i-1][t]<maxn)
				  f[i][j]=min(f[i][j],f[i-1][t]+1);
				  
	        }
		}  
    
    int ans=maxn;
    for(i=0;i<=m;i++)
       ans=min(ans,f[n][i]);
     cout<<"1"<<endl<<ans<<endl;  
}


