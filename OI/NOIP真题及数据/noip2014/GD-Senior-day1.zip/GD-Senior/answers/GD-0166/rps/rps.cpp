#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
int n,na,nb;
int a[201],b[201];
int as[50000],bs[50000];
int ats,bts,ans;
int main()
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
    int i,j=0,k=0;
	cin>>n>>na>>nb;
	int tot=na*nb;
for(i=1;i<=na;i++)
	   cin>>a[i];
for(i=1;i<=nb;i++)
	   cin>>b[i];
	for(i=1;i<=tot;i++)
	  {
	  	j++;if(j>na)j=1;
	  	k++;if(k>nb)k=1;
	  	bs[i]=bts,as[i]=ats;
	  	if(a[j]==0)
	  	  {
	  	  	if(b[k]==2||b[k]==3)	  	  	  
	  	  	  {
	  	  	  ats++;
	  	  	  as[i]=ats;
	  	      }
	  	    if(b[k]==1||b[k]==4)
			   {
			   	bts++;
			   	bs[i]=bts;
			   }  
	  	  }
	  	  if(a[j]==1)
	  	  {
	  	  	if(b[k]==0||b[k]==3)	  	  	  
	  	  	  {
	  	  	  ats++;
	  	  	  as[i]=ats;
	  	      }
	  	    if(b[k]==2||b[k]==4)
			   {
			   	bts++;
			   	bs[i]=bts;
			   }  
	  	  }
	  	  if(a[j]==2)
	  	  {
	  	  	if(b[k]==1||b[k]==4)	  	  	  
	  	  	  {
	  	  	  ats++;
	  	  	  as[i]=ats;
	  	      }
	  	    if(b[k]==0||b[k]==3)
			   {
			   	bts++;
			   	bs[i]=bts;
			   }  
	  	  }
	  	  if(a[j]==3)
	  	  {
	  	  	if(b[k]==2||b[k]==4)	  	  	  
	  	  	  {
	  	  	  ats++;
	  	  	  as[i]=ats;
	  	      }
	  	    if(b[k]==0||b[k]==1)
			   {
			   	bts++;
			   	bs[i]=bts;
			   }  
	  	  }
	  	  if(a[j]==4)
	  	  {
	  	  	if(b[k]==0||b[k]==1)	  	  	  
	  	  	  {
	  	  	  ats++;
	  	  	  as[i]=ats;
	  	      }
	  	    if(b[k]==2||b[k]==3)
			   {
			   	bts++;
			   	bs[i]=bts;
			   }  
	  	  }
	  	  
	  }   
	 j=n/tot,k=n%tot;
	 ans=j*ats+as[k];cout<<ans<<" ";
	 ans=j*bts+bs[k];cout<<ans<<endl;  
	fclose(stdin);fclose(stdout);
}
