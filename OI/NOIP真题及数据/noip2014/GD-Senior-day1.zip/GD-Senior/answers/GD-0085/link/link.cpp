#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <ctime>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <map>
#include <vector>
#include <queue>
#include <set>

#define MAXN (400000 + 100)
#define MOD 10007

#define mmst(a , b) memset(a , b , sizeof(a));

int n , w[MAXN];

int now , H[MAXN];

struct edge
{
	int v , nxt;
}e[2 * MAXN];

void Ins(int u , int v)
{
	++ now;
	e[now] . v = v;
	e[now] . nxt = H[u];
	H[u] = now;
}

void Init()
{
	int i;
	scanf("%d" , &n);
	now = -1;
	for (i = 0 ; i < n ; i ++) H[i] = -1;
	for (i = 1 ; i < n ; i ++)
	{
		int u , v;
		scanf("%d%d",&u,&v);
		u --; v --;
		Ins(u , v);
		Ins(v , u);
	}
	for (i = 0 ; i < n ; i ++) scanf("%d" , &w[i]);
}

void Solve()
{
	int i , j;
	int ans1 = 0 , ans2 = 0;
	int v;
	for (i = 0 ; i < n ; i ++)
	{
		int Sum = 0 , sqsum = 0 , max1 = 0 , max2 = 0;
		for (j = H[i] ; j != -1 ; j = e[j] . nxt)
		{
			v = e[j] . v;
			Sum = (Sum + w[v]) % MOD;
			sqsum = (sqsum + w[v] * w[v] % MOD) % MOD;
			if (w[v] > max1)
			{
				max2 = max1;
				max1 = w[v];
			}
			else if (w[v] > max2) max2 = w[v];
		}
		if (max1 * max2 > ans1) ans1 = max1 * max2;
		ans2 = (ans2 + Sum * Sum % MOD) % MOD;
		ans2 = ((ans2 - sqsum) % MOD + MOD) % MOD;
	}
	printf("%d %d\n" , ans1 , ans2);
}

int main()
{
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	Init();
	Solve();
	return (0);
}

