#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <ctime>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <map>
#include <vector>
#include <queue>
#include <set>

#define MAXN (2000 + 10)

const bool win[5][5] ={{0,0,1,1,0},
					  {1,0,0,1,0},
					  {0,1,0,0,1},
					  {0,0,1,0,1},
					  {1,1,0,0,0}};

int n , na , nb;

int A[MAXN] , B[MAXN];

void Init()
{
	int i;
	scanf("%d%d%d",&n,&na,&nb);
	for (i = 0 ; i < na ; i ++) scanf("%d" , &A[i]);
	for (i = 0 ; i < nb ; i ++)	scanf("%d" , &B[i]);
}

void Solve()
{
	int i;
	int ansa = 0 , ansb = 0;
	for (i = 0 ; i < n ; i ++)
	{
		ansa += win[A[i % na]][B[i % nb]];
		ansb += win[B[i % nb]][A[i % na]];
	}
	printf("%d %d\n" , ansa , ansb);
}

int main()
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	Init();
	Solve();
	return (0);
}

