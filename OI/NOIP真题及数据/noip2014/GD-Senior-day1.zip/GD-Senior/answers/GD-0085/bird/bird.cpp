#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <ctime>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <map>
#include <vector>
#include <queue>
#include <set>

#define MAXN (10000 + 100)
#define MAXM (1000 + 10)

int n , m , K;

int X[MAXN] , Y[MAXN];

int L[MAXN] , H[MAXN];

int f[2][MAXM];

void Init()
{
	int i;
	scanf("%d%d%d",&n,&m,&K);
	for (i = 0 ; i < n ; i ++) scanf("%d%d",&X[i],&Y[i]);
	for (i = 0 ; i <= n ; i ++)
	{
		L[i] = 0;
		H[i] = m + 1;
	}
	for (i = 0 ; i < K ; i ++)
	{
		int tmp;
		scanf("%d" , &tmp);
		scanf("%d%d",&L[tmp],&H[tmp]);
	}
}

void Solve()
{
	int i , j;
	int lst , ths;
	int tmp;
	for (i = 1 ; i <= m ; i ++) f[0][i] = 0;
	int num = 0;
	bool no;
	for (i = 1 ; i <= n ; i ++)
	{
		no = 1;
		lst = ((i + 1) & 1);
		ths = (i & 1);
		f[ths][m] = -1;
		if (H[i] > m)
		{
			if (f[lst][m] != -1) f[ths][m] = f[lst][m] + 1;
			for (j = 1 ; j < m ; j ++)
			{
				if (f[lst][j] == -1) continue;
				tmp = f[lst][j] + (m - j - 1) / X[i - 1] + 1;
				if (f[ths][m] == -1) f[ths][m] = tmp;
				else if (tmp < f[ths][m]) f[ths][m] = tmp;
			}
		}
		if (f[ths][m] != -1)
		{
			no = 0 ;
//			printf("%d %d\n" , i , m);
		}
		for (j = 1 ; j < m ; j ++)
		{
			f[ths][j] = -1;
			if (j - X[i - 1] > 0)
			{
				if (f[lst][j - X[i - 1]] != -1)
					if (f[ths][j] == -1 || f[lst][j - X[i - 1]] + 1 < f[ths][j])
						f[ths][j] = f[lst][j - X[i - 1]] + 1;
				if (f[ths][j - X[i - 1]] != -1)
					if (f[ths][j] == -1 || f[ths][j - X[i - 1]] + 1 < f[ths][j])
						f[ths][j] = f[ths][j - X[i - 1]] + 1;
			}
		}
		for (j = H[i] ; j < m ; j ++) f[ths][j] = -1;
		for (j = 1 ; j <= L[i] ; j ++) f[ths][j] = -1;
		for (j = 1 ; j < m ; j ++)
		{
			if (j >= H[i] || j <= L[i]) continue;
			if (j + Y[i - 1] <= m)
				if (f[lst][j + Y[i - 1]] != -1)
					if (f[ths][j] == -1 || f[lst][j + Y[i - 1]] < f[ths][j])
						f[ths][j] = f[lst][j + Y[i - 1]];
			if (f[ths][j] != -1) 
			{
				no = 0 ;
//				printf("%d %d\n" , i , j);
			}
		}
		if (no) break;
		if (H[i] <= m) num ++;
	}
	if (no)
	{
		printf("0\n%d\n" , num);
		return;
	}
	num = -1;
	for (i = 1 ; i <= m ; i ++)
		if (f[n & 1][i] != -1 && (num == -1 || f[n & 1][i] < num))
			num = f[n & 1][i];
	printf("1\n%d\n" , num);
}

int main()
{
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	Init();
	Solve();
	return (0);
}

