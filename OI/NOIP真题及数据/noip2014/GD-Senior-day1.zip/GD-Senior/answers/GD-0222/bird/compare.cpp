#include <cstdio>
#include <cstring>

FILE *fpr,*fpw;

long int n,m,k,ans;
long int up[10009],down[10009],from[10009],to[10009];
long int f[2][1024],now,old;
bool tube[100009];

int main()
{
	fpr=fopen("bird.in","r");
	freopen("compare.out","w",stdout);
	long int i,j,a,b,p;
	fscanf(fpr,"%ld%ld%ld",&n,&m,&k);
	for (i=0;i<n;i++)
	{
		fscanf(fpr,"%ld%ld",&up[i],&down[i]);
		from[i]=1;to[i]=m;
	}from[n]=1;to[n]=m;
	for (i=1;i<=k;i++)
	{
		fscanf(fpr,"%ld%ld%ld",&j,&a,&b);
		from[j]=a+1;to[j]=b-1;tube[j]=true;
	}
	now=1;old=0;
	memset(f,63,sizeof(f));
	for (j=1;j<=m;j++)
		f[now][j]=0;
	long int through=0;
	for (i=1;i<=n;i++)
	{
		now=1-now;old=1-old;
		memset(f[now],63,sizeof(f)/2);
		#define relax(a,b) a=a<(b)?a:(b)
		for (j=from[i];j<=to[i];j++)
		{
			if (j+down[i-1]<=m)
				relax(f[now][j],f[old][j+down[i-1]]);
			for (p=1;j-up[i-1]*p>0;p++)
				relax(f[now][j],f[old][j-up[i-1]*p]+p);
		}
		if (!tube[i])
			for (j=m-up[i-1];j<=m;j++)
				relax(f[now][m],f[old][j]+1);
		for (j=from[i];j<=to[i];j++)
		{
			if (f[now][j]>=f[now][0])
				printf("%ld:-1 ",j);	
			else printf("%ld:%ld ",j,f[now][j]);
		}printf("\n");
		for (j=from[i];j<=to[i];j++)
			if (f[now][j]<f[now][0])
			{
				if (tube[i]) through++;
				break;
			}
		if (j==to[i]+1) return 0;
	}
	memset(&ans,63,sizeof(long int));
	for (j=1;j<=m;j++)
		if (ans>f[now][j])
			ans=f[now][j];
	return 0;
}
