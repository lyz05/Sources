#include <cstdio>

int main()
{
	FILE *fpr1=fopen("ans.out","r");
	FILE *fpr2=fopen("compare.out","r");
	long int a,aa,b,bb;
	while (fscanf(fpr1,"%ld:%ld",&a,&b)!=EOF)
	{
		fscanf(fpr2,"%ld:%ld",&aa,&bb);
		//printf("%ld %ld\n",a,b);
		if (a==aa&&b==bb) continue;
		//printf("%ld %ld\n",aa,bb);
		printf("wrong!");
		return 0;
	}printf("right!");
	return 0;
}
