#include <cstdio>
#include <cstdlib>
#include <ctime>

bool tube[10009];

int main()
{
	srand(time(0));
	long int n=10000,m=1000,k=3;
	freopen("bird.in","w",stdout);
	printf("%ld %ld %ld\n",n,m,k);
	long int i,j,a,b;
	for (i=1;i<=n;i++)
	{
		a=rand()%100;
		a++;
		b=rand()%100;
		b++;
		printf("%ld %ld\n",a,b);
	}
	for (i=1;i<=k;i++)
	{
		a=rand()%n;
		a++;
		while (tube[a])
		{
			a=rand()%n;
			a++;
		}
		printf("%ld",a);
		b=rand()%m;
		b++;
		a=rand()%b;
		printf(" %ld %ld\n",a,b);
	}
	return 0;
}
