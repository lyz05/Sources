#include <cstdio>
#define size 200009
#define mod 10007

FILE *fpr,*fpw;

long int n,w[size],bigest,ans;
long int head[size],end;
struct MAP
{long int here,pre;
}map[400009];

void build(long int from,long int to)
{
	map[++end].here=to;
	map[end].pre=head[from];
	head[from]=end;
}

long int dfs[size][3],top;
//now,fatehr,grandfather

int main()
{
	fpr=fopen("link.in","r");
	fpw=fopen("link.out","w");
	long int i,j,a,b;
	fscanf(fpr,"%ld",&n);
	for (i=1;i<n;i++)
	{
		fscanf(fpr,"%ld%ld",&a,&b);
		build(a,b);
		build(b,a);
	}
	for (i=1;i<=n;i++)
		fscanf(fpr,"%ld",&w[i]);
	dfs[++top][0]=1;
	long int now,father,grandfather,tot,tmp1,tmp2;
	while (top)
	{
		now=dfs[top][0];
		father=dfs[top][1];
		grandfather=dfs[top][2];
		top--;
		tot=0;tmp1=0;tmp2=0;
		ans=(ans+w[now]*w[grandfather]*2)%mod;
		if (bigest<w[now]*w[grandfather])
			bigest=w[now]*w[grandfather];
		for (i=head[now];i;i=map[i].pre)
			if (map[i].here!=father)
			{
				top++;
				dfs[top][0]=map[i].here;
				dfs[top][1]=now;
				dfs[top][2]=father;
				tot+=w[map[i].here];
				if (w[map[i].here]>tmp1)
				{tmp2=tmp1;tmp1=w[map[i].here];}
				else if (w[map[i].here]>tmp2)
					tmp2=w[map[i].here];
			}
		if (bigest<tmp1*tmp2) bigest=tmp1*tmp2;
		for (i=head[now];i;i=map[i].pre)
			if (map[i].here!=father)
				ans=(ans+((tot-w[map[i].here])%mod)*w[map[i].here])%mod;
		//printf("%ld:%ld\n",now,debug);
		tmp1=0;;
	}
	fprintf(fpw,"%ld %ld",bigest,ans);
	return 0;
}
