#include <cstdio>
#include <cstdlib>
#include <ctime>

int main()
{
	srand(time(0));
	long int n=200000;
	long int i,j,a,b;
	freopen("link.in","w",stdout);
	printf("%ld\n",n);
	for (i=2;i<=n;i++)
	{
		a=rand()%i;
		if (a==0) a=1;
		printf("%ld %ld\n",i,a);
	}
	for (i=1;i<n;i++)
	{
		a=rand()%10000;
		a++;
		printf("%ld ",a);
	}
	return 0;
}
