#include <cstdio>
#define size 200009
#define mod 10007

FILE *fpr,*fpw;

long int n,w[size],bigest,ans;
long int head[size],end;
struct MAP
{long int here,pre;
}map[400009];

void build(long int from,long int to)
{
	map[++end].here=to;
	map[end].pre=head[from];
	head[from]=end;
}

void dfs(long int now,long int depth,long int from)
{
	long int i;
	if (depth==2)
	{
		ans=(ans+w[from]*w[now])%mod;
		if (bigest<w[from]*w[now])
			bigest=w[from]*w[now];
		return;
	}
	for (i=head[now];i;i=map[i].pre)
		if (map[i].here!=from)
			dfs(map[i].here,depth+1,from);
}

int main()
{
	fpr=fopen("link.in","r");
	long int i,j,a,b;
	fscanf(fpr,"%ld",&n);
	for (i=1;i<n;i++)
	{
		fscanf(fpr,"%ld%ld",&a,&b);
		build(a,b);
		build(b,a);
	}
	for (i=1;i<=n;i++)
		fscanf(fpr,"%ld",&w[i]);
	for (i=1;i<=n;i++)
		dfs(i,0,i);
	printf("%ld %ld",bigest,ans);
	return 0;
}
