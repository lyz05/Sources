#include <cstdio>

FILE *fpr,*fpw;

long int n,a,b,ans_a,ans_b;

long int sa[256],sb[256];

long int book[5][5]={{ 0,-1, 1, 1,-1},\
					 { 1, 0,-1, 1,-1},\
					 {-1, 1, 0,-1, 1},\
					 {-1,-1, 1, 0, 1},\
					 { 1, 1,-1,-1, 0}};

int main()
{
	fpr=fopen("rps.in","r");
	fpw=fopen("rps.out","w");
	fscanf(fpr,"%ld%ld%ld",&n,&a,&b);
	long int i,j;
	for (i=1;i<=a;i++)
		fscanf(fpr,"%ld",&sa[i]);
	for (j=1;j<=b;j++)
		fscanf(fpr,"%ld",&sb[j]);
	for (i=1,j=1;n;n--)
	{
		//printf("%ld %ld %ld\n",sa[i],sb[j],book[sa[i]][sb[j]]);
		if (book[sa[i]][sb[j]]==1)
			ans_a++;
		else if (book[sa[i]][sb[j]]==-1)
			ans_b++;
		i++;if (i==a+1) i=1;
		j++;if (j==b+1) j=1;
	}
	fprintf(fpw,"%ld %ld",ans_a,ans_b);
	return 0;
}
