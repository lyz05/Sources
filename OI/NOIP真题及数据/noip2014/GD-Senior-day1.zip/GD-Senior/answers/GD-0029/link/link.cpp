#include<iostream>
#include<fstream>
#include<cstdlib>
#include<string>
using namespace std;
ifstream fin("link.in");
ofstream fout("link.out");


int n,ans=0,maxer=0;

struct jd {
	int id,num;
};

struct bian {
	int id1,id2;
};

jd a[200000];
bian b[200000];



void lianhe(int i,int j) {
	int temp;
	if(b[i].id2==b[j].id1) {
		temp=a[b[i].id1].num*a[b[j].id2].num;
		if(maxer<temp) {
			maxer=temp;
		}
		ans+=temp*2;
	}
	if(b[i].id1==b[j].id2) {
		temp=a[b[i].id2].num*a[b[j].id1].num;
		if(maxer<temp) {
			maxer=temp;
		}
		ans+=temp*2;
	}
	
	if(b[i].id1==b[j].id1) {
		temp=a[b[i].id2].num*a[b[j].id2].num;
		if(maxer<temp) {
			maxer=temp;
		}
		ans+=temp*2;
	}
	if(b[i].id2==b[j].id2) {
		temp=a[b[i].id1].num*a[b[j].id1].num;
		if(maxer<temp) {
			maxer=temp;
		}
		ans+=temp*2;
	}
	return;
}





int main() {
	int temp1,temp2;
	fin>>n;
	for(int i=0;i<n-1;++i) {
		fin>>temp1>>temp2;
		if(temp1>temp2) {
			b[i].id1=temp2;
			b[i].id2=temp1;
		}
		else {
			b[i].id1=temp1;
			b[i].id2=temp2;
	    }
	}
	for(int i=1;i<=n;++i) {
		a[i].id=i;
		fin>>a[i].num;
	}
	for(int i=0;i<n-1;++i) {
		for(int j=i+1;j<n-1;++j) {
			 
			lianhe(i,j);
			
		}
	}
	fout<<maxer<<" "<<ans;
	fin.close();
	fout.close();
	return 0;
}
