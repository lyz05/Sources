#include<iostream>
#include<fstream>
#include<cstdlib>
#include<string>
using namespace std;
ifstream fin("bird.in");
ofstream fout("bird.out");


int n,m,k;
int uod[10000][2];
int map[10001][2];
int dd;


bool ok(int x,int y) {
	if(y<=0) return false;
	if(map[x][0]!=-1) {
		if(y>map[x][0] && y<map[x][1]) {
			return true;
		}
		return false;
	}
	return true;
}


int minest(int x1,int x2,int x3,int x4) {
	int miner1,miner2,id1,id2;
	if(x1>x2) {
		miner1=x2;
		id1=1;
	}
	else {
		miner1=x1;
		id1=0;
	}
	
	if(x3>x4) {
		miner2=x4;
		id2=3;
	}
	else {
		miner2=x3;
		id2=2;
	}
	
	if(miner1>miner2) {
		return id2;
	}
	else {
		return id1;
	}
}


int minest2(int x1,int x2,int x3,int x4) {
	int miner1,miner2,id1,id2;
	if(x1>x2) {
		miner1=x2;
	}
	else {
		miner1=x1;
	}
	
	if(x3>x4) {
		miner2=x4;
	}
	else {
		miner2=x3;
	}
	
	if(miner1>miner2) {
		return miner2;
	}
	else {
		return miner1;
	}
}





int qj(int x,int yy) {
	if(x==n) {
		return 0;
	}
	int y[4];
	y[0]=yy-uod[x][1];
	y[1]=yy+uod[x][0];
	y[2]=y[1]+uod[x][0];
	y[3]=y[2]+uod[x][0];
	int yy1=10000,yy2=10000,yy3=10000,yy4=10000;
	
	if(y[1]>m) {
		y[1]=m;
	}
	if(y[2]>m) {
		y[2]=m;
	}
	if(y[3]>m) {
		y[3]=m;
	}
	
	if(ok(x+1,y[0])) {
		yy1=qj(x+1,y[0]);
	}
	if(ok(x+1,y[1])) {
		yy2=qj(x+1,y[1]);
	}
	if(ok(x+1,y[2])) {
		yy3=qj(x+1,y[2]);
	}
	if(ok(x+1,y[3])) {
		yy4=qj(x+1,y[3]);
	}
	return minest(yy1,yy2,yy3,yy4)+minest2(yy1,yy2,yy3,yy4);
}



int main() {
	int i,j;
	int ans=0;
	
	//input
	fin>>n>>m>>k;
	for(i=0;i<n;++i) {
		fin>>uod[i][0]>>uod[i][1]; //up or down
		map[i+1][0]=-1;map[i+1][1]=-1;
	}
	map[0][0]=-1;map[0][1]=-1;
	for(i=0;i<k;++i) {
		fin>>j;
		fin>>map[j][0]>>map[j][1]; //pipe
	}
	//input
	int temp=10000;
	int tmp;
	for(i=0;i<m;++i) {
		tmp=qj(0,i);
		if(temp>tmp) {
			temp=tmp;
		}
	}
	fout<<1<<endl<<temp;
	fin.close();
	fout.close();
	return 0;
}
