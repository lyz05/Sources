#include<iostream>
#include<fstream>
#include<cstdlib>
#include<string>
using namespace std;
ifstream fin("rps.in");
ofstream fout("rps.out");

int n,na,nb;
int aa[200],bb[200];


int pd(int a,int b) {
	if(a==b) {
		return 0;
	}
	
	else if(a==0) {
		if(b==1 || b==4) {
			return -1;
		}
		return 1;
	}
	
	else if(a==1) {
		if(b==0 || b==3) {
			return 1;
		}
		return -1;
	}
	
	else if(a==2) {
		if(b==1 || b==4) {
			return 1;
		}
		return -1;
	}
	
	else if(a==3) {
		if(b==0 || b==1) {
			return -1;
		}
		return 1;
	}
	
	else { //a==4
		if(b==0 || b==1) {
			return 1;
		}
		return -1;
	}
}


int main() {
	fin>>n>>na>>nb;
	for(int i=0;i<na;++i) {
		fin>>aa[i];
	}
	for(int j=0;j<nb;++j) {
		fin>>bb[j];
	}
	int ii=0,jj=0;
	int score1=0,score2=0;
	for(int i=0;i<n;++i) {
		cout<<aa[ii]<<" "<<bb[jj]<<endl;
		if(pd(aa[ii],bb[jj])==1) {
			score1++;
		}
		else if(pd(aa[ii],bb[jj])==-1) {
			score2++;
		}
		ii++;
		jj++;
		if(ii==na) {
			ii=0;
		}
		if(jj==nb) {
			jj=0;
		}
	}
	fout<<score1<<" "<<score2;
	fin.close();
	fout.close();
	return 0;
}
