#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
#define INF 0x7fffffff-10000000;
int n,m,k,xs[10010],xx[10010],bo[10010],f[10010][1010],sum[10010];
struct gdgd{
	int l,r;
}gd[10010];
int main(){
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	memset(sum,0,sizeof(sum));
	memset(xx,0,sizeof(xx));
	memset(xs,0,sizeof(xs));
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;i++) scanf("%d%d",&xs[i],&xx[i]);
	for(int i=1;i<=n;i++) {
		gd[i].l=0;
		gd[i].r=m;
	}
	memset(bo,0,sizeof(bo));
	int y=0;
	sum[0]=0;
	for(int i=1;i<=k;i++) {
	  int x;
	  scanf("%d",&x);
	  bo[x]=1;
	  scanf("%d%d",&gd[x].l,&gd[x].r);
	}
	for(int i=1;i<=n;i++)
	  if(bo[i]){	
     	  for(int j=y+1;j<i;j++) sum[j]=sum[y];
     	  sum[i]=sum[y]+1;
    	  y=i;
	  }
	for(int i=y+1;i<=n;i++) sum[i]=sum[y];
	for(int i=1;i<=n;i++) 
	  for(int j=0;j<=m;j++) f[i][j]=INF;
	for(int i=0;i<=m;i++) f[0][i]=0;
	for(int i=1;i<=n;i++)
	  for(int j=gd[i].l+1;j<gd[i].r;j++){
	   if(gd[i].l+xx[i]<=m )
	  	     if (j+xx[i]<=m) {
	  		     f[i][j]=f[i-1][j+xx[i]];
	  	     }
	  	       else {
	  	  	     f[i][j]=f[i-1][m];
	  	       }
	  	if (j-xs[i] <0)  for(int q=0;q<=m;q++) f[i][m]=min(f[i][m],f[i-1][q]+1);
	  	    else for(int q=1;q<=j/xs[i];q++)
		            if(j-q*xs[i]>=0){
	  	               f[i][j]=min(f[i][j],f[i-1][j-q*xs[i]]+q);

	  	}
	  }
	int ans=INF;
	int good=0;
	for(int i=0;i<=m;i++) ans=min(ans,f[n][i]);
	if(ans!= 0x7fffffff-10000000) {
		printf("1\n%d\n",ans);
		return 0;
	}
	  else {
	  	for(int i=n;i>=0;i--)
	  	  for(int j=0;j<=m;j++)
	  	    if(f[i][j]!= 0x7fffffff-10000000) {
	  	        printf("0\n%d\n",sum[i]);
	  	        return 0;
	  	    }
	  }
	return 0;
}
