#include<cstdio>
#include<vector>
#include<cstring>
#include<algorithm>
using namespace std;
vector<int> ee[400100];
int addedge(int x,int y){
	ee[x].push_back(y);
	return 0;
}
int n,w[200100],vis[200100],ans,maxn;
int dfs(int x,int y,int z){
	if(y==2){ 
	  maxn=max(maxn,z*w[x]);
	  ans+=z*w[x];
	  ans%=10007;
	  return 0;
    }
    for(int i=0;i<ee[x].size();i++)
      if(!vis[ee[x][i]]){
      	vis[ee[x][i]]=1;
      	dfs(ee[x][i],y+1,z);
      }
    return 0;
}
int main(){
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	memset(w,0,sizeof(w));
	scanf("%d",&n);
	for(int i=1;i<n;i++){
		int a,b;
		scanf("%d%d",&a,&b);
		addedge(a,b);
		addedge(b,a);
	}
	for(int i=1;i<=n;i++) scanf("%d",&w[i]);
	ans=0;maxn=0;
	for(int i=1;i<=n;i++){
		memset(vis,0,sizeof(vis));
		vis[i]=1;
		dfs(i,0,w[i]);
	}
	ans%=10007;
	printf("%d %d\n",maxn,ans);
	return 0;
}
