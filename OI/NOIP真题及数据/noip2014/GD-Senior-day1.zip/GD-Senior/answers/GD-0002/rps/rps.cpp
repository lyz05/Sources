#include<cstdio>
#include<cstring>
using namespace std;
int n,na,nb,a[300],b[300];
int ansa,ansb;
int pd(int x,int y){
	if(x==0 && y==2) return 1;
	if(x==0 && y==3) return 1;
	if(x==1 && y==3) return 1;
	if(x==2 && y==4) return 1;
	if(x==3 && y==4) return 1;	
	if(x==0 && y==1) return 2;
	if(x==0 && y==4) return 2;
	if(x==1 && y==2) return 2;
	if(x==1 && y==4) return 2;
	if(x==2 && y==3) return 2;
	
	if(y==0 && x==2) return 2;
	if(y==0 && x==3) return 2;
	if(y==1 && x==3) return 2;
	if(y==2 && x==4) return 2;
	if(y==3 && x==4) return 2;	
	if(y==0 && x==1) return 1;
	if(y==0 && x==4) return 1;
	if(y==1 && x==2) return 1;
	if(y==1 && x==4) return 1;
	if(y==2 && x==3) return 1;
	return 0;
}
int main(){
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	memset(a,0,sizeof(a));
	memset(b,0,sizeof(b));
	scanf("%d%d%d",&n,&na,&nb);
	for(int i=0;i<na;i++) scanf("%d",&a[i]);
	for(int i=0;i<nb;i++) scanf("%d",&b[i]);
	ansa=ansb=0;
	for(int i=0;i<n;i++){
		if(pd(a[i%na],b[i%nb])==1) ansa++;
           else	if(pd(a[i%na],b[i%nb])==2) ansb++;
	}
	printf("%d %d\n",ansa,ansb);
	return 0;
}
