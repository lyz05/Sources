#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;
const int maxn=10010;
struct node
{
	int p,l,h;
}a[maxn];
int n,m,k;
int up[maxn],down[maxn];

int ql[maxn],qh[maxn],qq[maxn];
bool ok;
bool bigok=0;
int anspo=maxn,ansg=0;

int cmp(const void *x,const void *y)
{
	node n1=*(node *)x;
	node n2=*(node *)y;
	return n1.p-n2.p;
}

int qmin(int x,int y){return x>y?y:x;}
int qmax(int x,int y){return x>y?x:y;}

void dfs(int x,int y,int po)
{
	if (x==n+1)
	{
		if (y>0)
		{
			ok=1;
			anspo=qmin(anspo,po);
			return;
		}
	}
	//system("pause");
	if (y>m)y=m;
	if (y<=0 || y<=ql[x] || y>=qh[x])
	{
		ansg=qmax(ansg,qq[x]-1);return;
	}
	int i,j;
	dfs(x+1,y-down[x],po);
	for (i=1;i<=3;i++)
	{
		dfs(x+1,y+up[x]*i,po+i);
		if (y+up[x]*i>=m)break;
	}
}

void dfs_0 (int x,int y,int po)
{
	
	int i,j;
	if (bigok)return;
	if (x==n+1)
	{
		if (y>0 && y<=m)
		{
			ok=1;
			anspo=qmin(anspo,po);
			if (anspo==1)bigok=1;
			return;
		}
	}

	if (y<=0){ok=0;return;}
	if (y>m)y=m;
	dfs_0(x+1,y-down[x],po);
	for (i=1;i<=3;i++)
	{
		dfs_0(x+1,y+up[x]*i,po+i);
		if (y+up[x]*i>=m)break;
	}
}

int main()
{
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	int i,j;
	int sumdown=0;
	cin>>n>>m>>k;
	for (i=0;i<n;i++)
	{
		scanf("%d%d",&up[i],&down[i]);
		sumdown+=down[i];
	}
	
	memset(ql,0,sizeof(ql));
	memset(qh,63,sizeof(qh));
	
	for (i=1;i<=k;i++)
	{
		scanf("%d%d%d",&a[i].p,&a[i].l,&a[i].h);
		ql[a[i].p]=a[i].l;
		qh[a[i].p]=a[i].h;
		qq[a[i].p]=i;
	}
	if (k==0)
	{
		if (sumdown<m){printf("1\n0\n");return 0;}
		
		if (down[0]>=m) dfs_0(1,m,1);
		else 			dfs_0(1,m-down[0],0);
		printf("1\n%d\n",anspo);
	}
	else
	{
		//qsort(a+1,k,sizeof(node),cmp);
		ok=0;
		for (i=1;i<=m;i++)
		dfs(0,i,0);
		if (ok)printf("1\n%d\n",anspo);
		else printf("0\n%d\n",ansg);
		
	}
	return 0;  
}

