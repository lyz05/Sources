#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;
const int maxn=200010;
const int MOD=10007;
struct node
{
	int x,y,next;
}a[maxn];
int first[maxn],len;

bool bo[maxn]; 
long long d[maxn];

int n;
long long amax,sum;

long long qmax(long long x,long long y){return x>y?x:y;}

void ins(int x,int y)
{
	len++;
	a[len].x=x;
	a[len].y=y;
	a[len].next=first[x];
	first[x]=len;
}

void dfs(int x,int fa,int dep)
{
	//printf("%d ---> %d  the %d step\n",fa,x,dep);
	if (dep==2)
	{
		long long tt;
		tt=d[x]*d[fa];
		
		amax=qmax(tt,amax);
		sum=(sum+tt)%MOD;
		
		return ;
	}
	int i,j,k;
	int y;
	for (k=first[x];k;k=a[k].next)
	{
		//printf("%d %d\n",a[k].x,a[k].y);
		y=a[k].y;
		if (dep==0 || dep==1 && bo[y])
		{
			dfs(y,fa,dep+1);
		}
	}
	
}

int main()
{
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	int i;
	int u,v;
	scanf("%d",&n);
	memset(first,0,sizeof(first));len=0;
	for (i=1;i<n;i++)
	{
		scanf("%d%d",&u,&v);
		ins(u,v);
		ins(v,u);
	}
	for (i=1;i<=n;i++)
	{
		scanf("%lld",&d[i]);
	}
	amax=0;sum=0;
	memset(bo,1,sizeof(bo));
	for (i=1;i<=n;i++)
	{
		bo[i]=0;
		dfs(i,i,0);
	}
	printf("%lld %lld\n",amax,(sum*2)%MOD);
	return 0;
}

