#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;
const int maxn=210;
int n,na,nb;
int a[maxn],b[maxn];
int gx[5][5];
int main()
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	int i,j;
	scanf("%d%d%d",&n,&na,&nb);
	for (i=1;i<=na;i++)
	{
		scanf("%d",&a[i]);
	}
	for (i=1;i<=nb;i++)
	{
		scanf("%d",&b[i]);
	}
	memset(gx,0,sizeof(gx));
	gx[0][2]=1;gx[0][3]=1;
	gx[1][0]=1;gx[1][3]=1;
	gx[2][1]=1;gx[2][4]=1;
	gx[3][2]=1;gx[3][4]=1;
	gx[4][0]=1;gx[4][1]=1;
	
	for (i=0;i<=4;i++)
	{
		for (j=0;j<=4;j++)
		{
			if (i==j)continue;
			if (gx[i][j]!=1)
			{
				gx[i][j]=-1;
			}
		}
	}
	
	int depa,depb;
	int ansa,ansb;
	depa=depb=1;
	ansa=ansb=0;
	while (n)
	{
		if (depa==na+1)depa=1;
		if (depb==nb+1)depb=1;
		if( gx[ a[depa] ][ b[depb] ] == 1)ansa++;
		else if( gx[ a[depa] ][ b[depb] ] == -1)ansb++;
		depa++;
		depb++;
		n--;
	}
	printf("%d %d\n",ansa,ansb);
	return 0;
}
