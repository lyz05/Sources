#include <cstdio>
using namespace std;
bool map[5][5] = {{0,0,1,1,0},
				  {1,0,0,1,0},
				  {0,1,0,0,1},
				  {0,0,1,0,1},
				  {1,1,0,0,0}};
int n,na,nb,tota,totb,a[201],b[201];
int main ()
{
	freopen ("rps.in","r",stdin);
	freopen ("rps.out","w",stdout);
	scanf ("%d%d%d",&n,&na,&nb);
	for (int i = 0;i < na;i++) scanf ("%d",&a[i]);
	for (int i = 0;i < nb;i++) scanf ("%d",&b[i]);
	for (int i = 0;i < n;i++)
	{
		int at = a[i%na], bt = b[i%nb];
		if (map[at][bt]) tota++;
			else if (map[bt][at]) totb++;
	}
	printf ("%d %d\n",tota,totb);
	return 0;
}
