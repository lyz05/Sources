#include <cstdio>
using namespace std;
int n,m,k,low[1001],high[1001],rise[1001],fall[1001],far,achievement[1001],step,Minstep;
void DFS (int x,int now)
{
	if (x > far) far = x;
	if (x == n)
	{
		if (step < Minstep) Minstep = step;
		return;
	}
	now -= fall[x];
	if (now < high[x+1] && now > low[x+1]) DFS (x+1,now);
	now += fall[x];
	for (int i = 1;i <= 3;i++)
	{
		now += rise[x];
		if (now > m) now = m;
		if (now < high[x+1] && now > low[x+1])
		{
			step += i;
			DFS (x+1,now);
			step -= i;
		}
		if (now == m) return;
	}
}
int main ()
{
	freopen ("bird.in","r",stdin);
	freopen ("bird.out","w",stdout);
	scanf ("%d%d%d",&n,&m,&k);
	for (int i = 0;i < n;i++) scanf ("%d%d",&rise[i],&fall[i]);
	for (int i = 0;i <= n;i++) low[i] = 0, high[i] = m+1;
	int loc;
	for (int i = 1;i <= k;i++)
	{
		scanf ("%d",&loc);
		scanf ("%d%d",&low[loc],&high[loc]);
		for (int j = loc;j <= n;j++) achievement[j]++;
	}
	far = 0, Minstep = 0x7fffffff;
	for (int i = 0;i <= m;i++)
	{
		step = 0;
		DFS (0,i);
	}
	if (far == n) printf ("1\n%d\n",Minstep);
		else printf ("0\n%d\n",achievement[far]);
	return 0;
}
