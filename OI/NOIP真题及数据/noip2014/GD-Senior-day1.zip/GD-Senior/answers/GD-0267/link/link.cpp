#include <cstdio>
using namespace std;
int n,w[200001],fa[200001],map[200001][125];
int Max,tot;
void findfa (int node)
{
	int sec[map[node][0]+1];
	for (int i = 0;i <= map[node][0];i++) sec[i] = map[node][i];
	map[node][0] = 0;
	for (int i = 1;i <= sec[0];i++)
		if (fa[sec[i]] == -1)
		{
			fa[sec[i]] = node;
			map[node][++map[node][0]] = sec[i];
			findfa (sec[i]);
		}
}
int main ()
{
	freopen ("link.in","r",stdin);
	freopen ("link.out","w",stdout);
	scanf ("%d",&n);
	for (int i = 1;i <= n;i++) fa[i] = -1;
	int u,v;
	scanf ("%d%d",&u,&v);
	fa[u] = 0;
	fa[v] = u;
	map[u][++map[u][0]] = v;
	for (int i = 2;i < n;i++)
	{
		scanf ("%d%d",&u,&v);
		if (fa[u] >= 0)
		{
			fa[v] = u;
			map[u][++map[u][0]] = v;
			findfa (v);
			continue;
		}
		if (fa[v] >= 0)
		{
			fa[u] = v;
			map[v][++map[v][0]] = u;
			findfa (u);
			continue;
		}
		map[u][++map[u][0]] = v;
		map[v][++map[v][0]] = u;
	}
	for (int i = 1;i <= n;i++) scanf ("%d",&w[i]);
	for (int i = 1;i <= n;i++)
	{
		for (int j = 1;j <= map[fa[i]][0];j++)
			if (i != map[fa[i]][j])
			{
				v = w[map[fa[i]][j]]*w[i];
				if (v > Max) Max = v;
				tot = (tot+v)%10007;
			}
		v = w[fa[fa[i]]]*w[i];
		if (v > Max) Max = v;
		tot = (tot+2*v)%10007;
	}
	printf ("%d %d\n",Max,tot);
	return 0;
}
