#include <cstdio>
#include <cstring>
#define  fr(i,x,y) for(i=x;i<=y;i++)
const int maxn=210;
int n,n1,n2,ans1,ans2;
int a[maxn],b[maxn];
void Read(){
	int i;
	scanf("%d%d%d",&n,&n1,&n2);
	fr(i,0,n1-1)scanf("%d",&a[i]);
	fr(i,0,n2-1)scanf("%d",&b[i]);
}
bool Win(int x,int y){
	if(x==0)return y==2||y==3;
	if(x==1)return y==0||y==3;
	if(x==2)return y==1||y==4;
	if(x==3)return y==2||y==4;
	return y==0||y==1;
}
void Solve(){
	int id1,id2;
	id1=id2=0;
	while(n--){
		if(a[id1]!=b[id2]){
			if(Win(a[id1],b[id2]))ans1++;
			else ans2++;
		}
		if(++id1==n1)id1=0;
		if(++id2==n2)id2=0;
	}
	printf("%d %d\n",ans1,ans2);
}
int main(){
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	Read();
	Solve();
	return 0;
}
