#include <cstdio>
#include <cstring>
#include <algorithm>
#define  fr(i,x,y) for(i=x;i<=y;i++)
using namespace std;
const int maxn=10010;
const int maxm=1010;
struct Barrier{int x,l,h;}bar[maxn];
int n,m,K,idK,ans;
int a[maxn][2],b[maxm];
int f[2][maxm];
bool cur,pas;
bool Cmp(const Barrier &x,const Barrier &y){return x.x<y.x;}
void Read(){
	int i;
	scanf("%d%d%d",&n,&m,&K);
	fr(i,1,n)scanf("%d%d",&a[i][0],&a[i][1]);
	fr(i,1,K)scanf("%d%d%d",&bar[i].x,&bar[i].l,&bar[i].h);
	sort(bar+1,bar+K+1,Cmp);
}
void Solve(){
	int i,row,t,l,h;
	idK=1;
	cur=false,pas=true;
	
	fr(i,1,m)
		if(i+a[1][1]<=m)f[cur][i]=0;
		else if(i>a[1][0])f[cur][i]=1;
		else f[cur][i]=-1;
	
	if(K&&bar[1].x==1){
		fr(i,1,bar[1].l)f[cur][i]=-1;
		fr(i,bar[1].h,m)f[cur][i]=-1;
		idK++;
		fr(i,1,m)
			if(f[cur][i]!=-1)break;
		if(i>m){
			printf("0\n0\n");
			return;
		}
	}
	fr(row,2,n){
		cur^=true,pas^=true;
		if(idK<=K&&bar[idK].x==row)l=bar[idK].l,h=bar[idK].h,idK++;
		else l=0,h=m+1;
		ans=n*m+1;
		fr(i,1,m){		
			b[i]=f[pas][i];
			if(b[i]!=-1&&i+a[row][0]>m)
				if(b[m-a[row][0]]==-1||b[m-a[row][0]]>b[i])b[m-a[row][0]]=b[i];
			if(i>a[row][0]&&(t=b[i-a[row][0]])!=-1){
				t++;
				if(b[i]==-1||b[i]>t)b[i]=t;
			}
		
			f[cur][i]=-1;
			
			if(i>a[row][0]&&(t=b[i-a[row][0]])!=-1)f[cur][i]=t+1;
			
			if(i+a[row][1]<=m&&(t=f[pas][i+a[row][1]])!=-1)
				if(f[cur][i]==-1||f[cur][i]>t)f[cur][i]=t;
			
			if(i<=l||i>=h)f[cur][i]=-1;
			if(f[cur][i]!=-1&&f[cur][i]<ans)ans=f[cur][i];
			
		}
		if(ans==n*m+1)break;
	}
	if(row<=n)printf("0\n%d\n",idK-2);
	else printf("1\n%d\n",ans);
}
int main(){
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	Read();
	Solve();
	return 0;
}
