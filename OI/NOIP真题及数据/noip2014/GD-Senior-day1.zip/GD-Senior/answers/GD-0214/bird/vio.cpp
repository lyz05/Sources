#include <cstdio>
#include <cstring>
#include <algorithm>
#define  fr(i,x,y) for(i=x;i<=y;i++)
using namespace std;
const int maxn=10010;
const int maxm=1010;
const int maxint=1<<30;
struct Barrier{int x,l,h;}bar[maxn];
int n,m,K;
int a[maxn][2];
int f[maxn][maxm];
bool Cmp(const Barrier &x,const Barrier &y){return x.x<y.x;}
void Read(){
	int i;
	scanf("%d%d%d",&n,&m,&K);
	fr(i,1,n)scanf("%d%d",&a[i][0],&a[i][1]);
	fr(i,1,K)scanf("%d%d%d",&bar[i].x,&bar[i].l,&bar[i].h);
	sort(bar+1,bar+K+1,Cmp);
}
void Minn(int &x,int y){if(y<x)x=y;}
void Solve(){
	int i,j,x,idK,l,h,t;
	fr(i,1,n)
		fr(j,1,m)
			f[i][j]=maxint;
	fr(i,1,m)f[0][i]=0;
	idK=1;
	fr(i,1,n){
		if(idK<=K&&bar[idK].x==i)l=bar[idK].l,h=bar[idK].h,idK++;
		else l=0,h=m+1;
		fr(j,1,m)
			if(f[i-1][j]!=maxint){
				if(j>a[i][1])Minn(f[i][j-a[i][1]],f[i-1][j]);
				for(t=f[i-1][j]+1,x=j+a[i][0];x<m;x+=a[i][0],t++)
					Minn(f[i][x],t);
				Minn(f[i][m],t);
			}
		t=maxint;
		fr(j,1,m){
			if(j<=l||j>=h)f[i][j]=maxint;
			Minn(t,f[i][j]);
		}
		if(t==maxint){
			printf("0\n%d\n",idK-2);
			return;
		}
	}
	printf("1\n%d\n",t);
}
int main(){
	freopen("bird.in","r",stdin);
	freopen("vio.out","w",stdout);
	Read();
	Solve();
	return 0;
}
