#include <cstdio>
#include <cstring>
#include <ctime>
#include <cstdlib>
#define  fr(i,x,y) for(i=x;i<=y;i++)
using namespace std;
const int maxn=1010;
int n=10000;
int m=100;
int K;
bool vis[maxn];
int Abs(int x){return x<0?-x:x;}
int Random(int x){return rand()%x;}
int main(){
	freopen("bird.in","w",stdout);
	int i,x,y;
	srand(time(0));
/*	printf("%d %d %d\n",n,m,K=n-1);
	fr(i,1,n)printf("1 %d\n",Random(m-1)+1);
	fr(i,1,K)printf("%d %d %d\n",i,i-1,i+1);*/
	
	printf("%d %d %d\n",n,m,K=Random(21));
	fr(i,1,n)printf("%d %d\n",Random(5)+1,Random(m-1)+1);
	fr(i,1,K){
		do{x=Random(n-1)+1;}while(vis[x]);
		vis[x]=true;
		printf("%d ",x);
		do{
			x=Random(m+1);
			y=Random(m+1);
		}while(Abs(x-y)<=1);
		if(x>y)x^=y^=x^=y;
		printf("%d %d\n",x,y);
	}
}
