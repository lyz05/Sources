#include <cstdio>
#include <cstring>
#define  fr(i,x,y) for(i=x;i<=y;i++)
#define  frk(k,x,_y) for(k=first[x];_y=edge[k].y,k;k=edge[k].next)
const int maxn=200010;
const int o=10007;
struct Edge{
	int y,next;
	Edge(){}
	Edge(int _y,int _next){y=_y,next=_next;}
}edge[maxn<<1];
int n,E_cnt,ans,ans1;
int a[maxn],first[maxn],que[maxn];
bool vis[maxn];
void Ins(int x,int y){edge[++E_cnt]=Edge(y,first[x]);first[x]=E_cnt;}
void Read(){
	int i,x,y;
	scanf("%d",&n);
	fr(i,2,n){
		scanf("%d%d",&x,&y);
		Ins(x,y),Ins(y,x);
	}
	fr(i,1,n)scanf("%d",&a[i]);
}
void Solve(){
	int i,x,k,y,k1,y1;
	que[que[0]=1]=1;
	fr(i,1,que[0]){
		x=que[i];vis[x]=true;
		frk(k,x,y){
			if(!vis[y])que[++que[0]]=y;
			frk(k1,y,y1)
				if(y1!=x){
					ans=(ans+a[x]*a[y1])%o;
					if(a[x]*a[y1]>ans1)ans1=a[x]*a[y1];
				}
		}
	}
	printf("%d %d\n",ans1,ans);
}
int main(){
	freopen("link.in","r",stdin);
	freopen("vio.out","w",stdout);
	Read();
	Solve();
}
