#include <cstdio>
#include <cstring>
#define  fr(i,x,y) for(i=x;i<=y;i++)
#define  frk(k,x,y) for(k=first[x];y=edge[k].y,k;k=edge[k].next)
const int maxn=200010;
const int o=10007;
struct Edge{
	int y,next;
	Edge(){}
	Edge(int _y,int _next){y=_y,next=_next;}
}edge[maxn<<1];
int n,E_cnt,ans,ans1;
int a[maxn],first[maxn],f[maxn],f1[maxn],f2[maxn],fa[maxn],que[maxn];
void Ins(int x,int y){edge[++E_cnt]=Edge(y,first[x]);first[x]=E_cnt;}
void Read(){
	int i,x,y;
	scanf("%d",&n);
	fr(i,2,n){
		scanf("%d%d",&x,&y);
		Ins(x,y),Ins(y,x);
	}
	fr(i,1,n)scanf("%d",&a[i]);
}
void Inc(int &x,int y){if((x+=y)>=o)x-=o;}
void Pretreat(){
	int x,y,k,i;
	fr(x,1,n)
		frk(k,x,y){
			Inc(f[x],a[y]);
			if(a[y]>f1[x])f2[x]=f1[x],f1[x]=a[y];
			else if(a[y]>f2[x])f2[x]=a[y];
		}
	que[que[0]=1]=1;
	fr(i,1,que[0]){
		x=que[i];
		frk(k,x,y)
			if(y!=fa[x]){
				fa[y]=x;
				que[++que[0]]=y;
			}
	}
}
int Cal(int x){return x>=0?x:x+o;}
void Maxx(int &x,int y){if(y>x)x=y;}
void Solve(){
	int i;
	fr(i,2,n)
		ans=(ans+a[i]*Cal(f[fa[i]]-a[i])+a[i]*a[fa[fa[i]]])%o;
	fr(i,1,n)Maxx(ans1,f1[i]*f2[i]);
	printf("%d %d\n",ans1,ans);
}
int main(){
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	Read();
	Pretreat();
	Solve();
	return 0;
}
