#include <cstdio>
#include <cstring>
#include <ctime>
#include <cstdlib>
#define  fr(i,x,y) for(i=x;i<=y;i++)
const int maxn=2010;
int n=10000;
int m=10000;
int a[maxn];
int Random(int x){return rand()%x;}
int main(){
	freopen("link.in","w",stdout);
	int i;
	srand(time(0));
	printf("%d\n",n);
	fr(i,2,n)printf("%d %d\n",Random(i-1)+1,i);
	fr(i,1,n)printf("%d%c",Random(m)+1,i==n?'\n':' ');
}
