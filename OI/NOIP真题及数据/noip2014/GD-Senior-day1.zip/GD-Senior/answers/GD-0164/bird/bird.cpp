#include<cstring>
#include<cstdio>
#include<iostream>
#include<algorithm>
#include<vector>
#include<queue>

#define FOR(i,j,k) for(i=j;i<=k;++i)
#define FORD(i,j,k) for(i=j;i>=k;--i)
#define IOS ios_base::sync_with_stdio(0)

using namespace std;
typedef long long int LL;
const int N=10100,M=1100;
int n,m,k,ans=0x3fffffff;
int f[2][M*2];
int x[N*2],y[N*2],L[N*2],h[N*2];


int main()
{
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	IOS;
	cin >> n >> m >> k;
	int i,p,j;
	FOR(i,0,n-1) cin >> x[i] >> y[i];
	memset(L,0,sizeof(L));
	memset(h,0,sizeof(h));
	FOR(i,1,k)
	{
		cin >> p;
		cin >> L[p] >> h[p];
	}
	
	memset(f,-1,sizeof(f));
	
	FOR(i,1,m) f[0][i]=0;
	int now=0,nex=1,LL,hh;
	int z=0;
	bool bb;
	FOR(i,0,n-1)
	{
		if(L[i+1]==0)LL=1;
		else LL=L[i+1]+1;
		if(h[i+1]==0)hh=m;
		else hh=h[i+1]-1;
		
		bb=0;
		FOR(j,LL,hh)
		{
			if(j+y[i]<=m)
			if((f[now][j+y[i]]!=-1)&&((f[now][j+y[i]]<f[nex][j])||(f[nex][j]==-1)))
			{
				f[nex][j]=f[now][j+y[i]];
				if((i==n-1)&&(f[nex][j]<ans)) ans=f[nex][j];
				bb=1;
			}
			if(j-x[i]>0)
			{
				if((f[now][j-x[i]]!=-1)&&((f[now][j-x[i]]+1<f[nex][j])||(f[nex][j]==-1)))
				{
					f[nex][j]=f[now][j-x[i]]+1;
					if((i==n-1)&&(f[nex][j]<ans)) ans=f[nex][j];
					bb=1;
				}
				if((f[nex][j-x[i]]!=-1)&&((f[nex][j-x[i]]+1<f[nex][j])||(f[nex][j]==-1)))
				{
					f[nex][j]=f[nex][j-x[i]]+1;
					if((i==n-1)&&(f[nex][j]<ans)) ans=f[nex][j];
					bb=1;
				}
			}
			if(j==m)
			{
				FOR(p,max(j-x[i]+1,1),m)
				{
					if((f[now][p]!=-1)&&((f[now][p]+1<f[nex][j])||(f[nex][j]==-1)))
					{		
						f[nex][j]=f[now][p]+1;
						if((i==n-1)&&(f[nex][j]<ans)) ans=f[nex][j];
						bb=1;
					}
					if((f[nex][p]!=-1)&&((f[nex][p]+1<f[nex][j])||(f[nex][j]==-1)))
					{		
						f[nex][j]=f[nex][p]+1;
						bb=1;
						if((i==n-1)&&(f[nex][j]<ans)) ans=f[nex][j];
					}
				}
			}
		}
		if(!bb)
		{
			cout << 0 << endl;
			cout << z << endl;
			return (0);
		}
		now=1-now;
		nex=1-nex;
		memset(f[nex],-1,sizeof(f[nex]));
		if((L[i+1]!=0)||(h[i+1]!=0))++z;
	}
	cout << 1 << endl;
	cout << ans << endl;
	return (0);
}

