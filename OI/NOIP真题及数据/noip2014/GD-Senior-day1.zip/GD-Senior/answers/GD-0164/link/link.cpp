#include<cstring>
#include<cstdio>
#include<iostream>
#include<algorithm>
#include<vector>

#define FOR(i,j,k) for(i=j;i<=k;++i)
#define FORD(i,j,k) for(i=j;i>=k;--i)
#define IOS ios_base::sync_with_stdio(0)
#define PB push_back
using namespace std;
typedef long long int LL;

const int N=200100;
const LL MO=10007;

vector<int> a[N];
LL n,w[N*2],ans=0,am=0;
int fa[N*2];

void dfs(int u)
{
	int i;
	LL s=0,m=0;
	
	FOR(i,0,int(a[u].size()-1))
	{
		if((a[u][i])!=fa[u])
		{
			s=(s+w[a[u][i]])%MO;
			fa[a[u][i]]=u;
			dfs(a[u][i]);
			ans-=(w[a[u][i]]*w[a[u][i]])%MO;
			if(m*w[a[u][i]]>am) am=w[a[u][i]]*m;
			if(w[a[u][i]]>m)m=w[a[u][i]];
		}
	}
	ans=(ans+(s*s)%MO)%MO;
	if(fa[u]!=0)
	{
		ans=(ans+(w[fa[u]]*s*2)%MO)%MO;
		if(m*w[fa[u]]>am) am=m*w[fa[u]];
	}
}


int main()
{
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	IOS;
	int i,x,y;
	cin >> n;
	FOR(i,1,n-1)
	{
		cin >> x >> y;
		a[x].PB(y);
		a[y].PB(x);
	}
	FOR(i,1,n) cin >> w[i];
	memset(fa,0,sizeof(fa));
	dfs(1);
	cout << am << " " << ans << endl;
	return (0);
}

