#include<cstring>
#include<cstdio>
#include<iostream>
#include<algorithm>
#include<vector>
#include<queue>

#define FOR(i,j,k) for(i=j;i<=k;++i)
#define FORD(i,j,k) for(i=j;i>=k;--i)
#define IOS ios_base::sync_with_stdio(0)

using namespace std;
typedef long long int LL;
const int dx[5][5]={{0,0,1,1,0},{1,0,0,1,0},{0,1,0,0,1},{0,0,1,0,1},{1,1,0,0,0}};
const int dy[5][5]={{0,1,0,0,1},{0,0,1,0,1},{1,0,0,1,0},{1,1,0,0,0},{0,0,1,1,0}};

int gcd(int a,int b)
{
	if(b==0) return (a);
	return gcd(b,a%b);
}

int n,na,nb,g,sa,sb;
int a[500],b[500];

int main()
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	IOS;
	cin >> n >> na >> nb;
	int i,j,k;
	FOR(i,0,(na-1)) cin >> a[i];
	FOR(i,0,(nb-1)) cin >> b[i];
	g=gcd(na,nb);
	g=min((na*nb/g),n);
	i=-1;j=-1;
	sa=0;sb=0;
	FOR(k,0,(g-1))
	{
		i=(i+1)%na;
		j=(j+1)%nb;
		sa+=dx[a[i]][b[j]];
		sb+=dy[a[i]][b[j]];
	}
	if(n>g)
	{
		sa*=n/g;
		sb*=n/g;
		g=n%g;
		i=-1;j=-1;
		FOR(k,0,(g-1))
		{
			i=(i+1)%na;
			j=(j+1)%nb;
			sa+=dx[a[i]][b[j]];
			sb+=dy[a[i]][b[j]];
		}
	}
	cout << sa << " " << sb << endl;
	return (0);
}

