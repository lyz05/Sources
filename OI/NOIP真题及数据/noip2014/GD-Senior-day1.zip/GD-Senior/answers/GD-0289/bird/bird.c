#include <stdio.h>
#include <string.h>
int n,m,k; //n: width, m: height, k: the number of tubes
typedef struct _tube{
	int x; //�ܵ�x���� 
	int up; //�϶����� 
	int down; //�¶����� 
} Tube;
typedef struct _ope{
	int up; //����������ĸ߶� 
	int down; //δ����½��ĸ߶� 
} Oper;
Tube tube[10001]; //120k RAM
Oper operation[10001]; //80k RAM
void SwapTube(Tube *a,Tube *b)
{
	Tube temp;
	temp=*a;*a=*b;*b=temp;
}
void TubeQsort(int l,int r)
{//����ܵ� 
	int ii,jj,mid;
	ii=l;jj=r;mid=(l+r)/2;
	while(ii<=jj)
	{
		while(tube[ii].x<tube[mid].x) ii++;
		while(tube[jj].x>tube[mid].x) jj--;
		if(ii<=jj) SwapTube(&tube[ii++],&tube[jj--]);
	}
	if(l<jj) TubeQsort(l,jj);
	if(ii<r) TubeQsort(ii,r);
}
int click; //����� 
int curtube; //��ǰ�ܵ��±�
int minclick;
int maxtube;
Tube NULLTUBE={-1,1001,0};
Tube *getcurtube(int x)
{ //��ȡ��ǰ�ܵ� ����˳�� x:0 -> n 
	if(x==tube[curtube].x)
		return &tube[curtube++];
	return &NULLTUBE;
}
int dfs(int h,int x,int end)
{
	int nh;// next height  ��һ������ĸ߶� 
	Tube *nt;//next tube  ��һ���ܵ� 
	int _curtube;
	int temp;
	if(x==end){curtube++; return 1;} //�ݹ���� 
	//δ������ 
	nh=h-operation[x].down;
	nt=getcurtube(x+1);
	_curtube=curtube;
	if(nh>nt->down&&nh<nt->up)
	{
		if(click<minclick||!minclick)minclick=click;
		if(curtube>maxtube)maxtube=curtube;
		temp=dfs(nh,x+1,end);
		if(temp==1) return 1;
	}
	//������ 
	curtube=_curtube;
	nh=h+operation[x].up;
	if(nh>n)nh=n;
	click++;
	if(nh>nt->down&&nh<nt->up)
	{
		if(click>minclick)minclick=click;
		if(curtube>maxtube)maxtube=curtube;
		temp=dfs(nh,x+1,end);
		if(temp==1) return 1;
	}
		
	click--;
	return 0;
}
int main()
{
	int i,j;
	int result;
	freopen("bird2.in","r",stdin);
	freopen("bird.out","w",stdout);
	minclick=maxtube=0;
	scanf("%d%d%d",&n,&m,&k);
	for(i=0;i<n;i++)
		scanf("%d%d",&operation[i].up,&operation[i].down);
	for(i=0;i<k;i++)
		scanf("%d%d%d",&tube[i].x,&tube[i].down,&tube[i].up);
	
	TubeQsort(0,k-1);
	
	for(i=1;i<=m;i++)
	{
		curtube=0;
		click=0;
		result=dfs(i,0,m);
		if(result==1) {
			printf("%d\n%d",1,minclick);
			return 0;
		}
		//printf("%d %d %d\n",result,maxclick,maxtube);
	}
	printf("%d\n%d",0,maxtube);
	return 0;
}
