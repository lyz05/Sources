#include <stdio.h>
#include <string.h>
typedef struct _stu {
	int w;
	struct _stu *next;
	struct _stu *prev;
} Line;
int n;
Line ll[200002]; //��������ͼ����  n-1
int max;
long sum;
void line(int a,int b)
{
	//����������
	if(ll[a].next==NULL&&ll[b].prev==NULL)
	{
		//������ָ������
		ll[a].next=&ll[b];
		ll[b].prev=&ll[a];
	}
	else
	{
		ll[a].prev=&ll[b];
		ll[b].next=&ll[a];
	}
}
int main()
{
	int i;
	int a,b;
	int val;
	Line *p,*q;
	
	max=0;
	sum=0;
	
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	
	scanf("%d",&n);
	memset(ll,0,sizeof(ll));
	for(i=1;i<=n-1;i++)
	{
		scanf("%d%d",&a,&b);
		line(a,b);
	}
	for(i=1;i<=n;i++)
		scanf("%d",&ll[i].w);
	
	for(i=1;i<=n;i++)
	{
		p=&ll[i];
		//ǰ 
		q=p->prev;
		if(q!=NULL)
		{
			q=q->prev;
			if(q!=NULL)
			{
				//ǰ������Ϊ�ǿ� 
				 val=q->w*p->w;
				 if(val>max) max=val;
				 sum+=val;
			}
		}
		//��
		q=p->next;
		if(q!=NULL)
		{
			q=q->next;
			if(q!=NULL)
			{
				//��������Ϊ�ǿ� 
				 val=q->w*p->w;
				 if(val>max) max=val;
				 sum+=val;
			}
		} 
	}
	printf("%d %d",max,sum);
	return 0;
}
