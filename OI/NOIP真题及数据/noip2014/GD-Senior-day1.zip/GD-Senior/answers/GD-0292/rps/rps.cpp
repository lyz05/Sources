#include <stdio.h>
#include <iostream>
using namespace std;

int n,n1,n2,len1[1001],len2[1001],g1=0,g2=0;
int tf[5][5]={0,2,1,1,2,1,0,2,1,2,2,1,0,2,1,2,2,1,0,1,1,1,2,2,0};
// 0==peace 1==1win 2==2win;

int main(){
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	cin>>n>>n1>>n2;
	int i,j,k;
	for(i=1;i<=n1;++i) cin>> len1[i];
	for(i=1;i<=n2;++i) cin>>len2[i];
	for(i=1;i<=n;++i){
		if(tf[len1[i%n1]][len2[i%n2]]==1){
			g1++;
		}
		else if(tf[len1[i%n1]][len2[i%n2]]==2){
			g2++;
		}
	}
	printf("%d %d",g1,g2);
	return 0;
}
