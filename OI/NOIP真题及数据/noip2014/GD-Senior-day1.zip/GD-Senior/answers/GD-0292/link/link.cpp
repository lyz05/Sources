#include <stdio.h>
#include <iostream>
using namespace std;

int w[200001],n;

struct node{
	int u;
	int v;
}road[200000];

int main(){
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	int i,j,k;
	cin>>n;
	for(i=1;i<=n-1;++i){
		cin>>road[i].u>>road[i].v;
	}
	int sum=0,da=0;
	for(i=1;i<=n;++i)cin>>w[i];
	for(i=1;i<=n;++i){
		for(j=i+1;j<=n;++j){
			if(road[i].u==road[j].u){
				int x=road[i].v;
				int y=road[j].v;
				sum=(sum+2*(w[x]*w[y])%10007)%10007;
				if(da<w[x]*w[y]) da=w[x]*w[y];
				cout<<sum<<" "<<i<<" "<<j<<endl;
			}
			if(road[i].u==road[j].v){
				int x=road[i].v;
				int y=road[j].u;
				sum=(sum+2*(w[x]*w[y])%10007)%10007;
				if(da<w[x]*w[y]) da=w[x]*w[y];
				cout<<sum<<" "<<i<<" "<<j<<endl;
			}
			if(road[i].v==road[j].u){
				int x=road[i].u;
				int y=road[j].v;
				sum=(sum+2*(w[x]*w[y])%10007)%10007;
				if(da<w[x]*w[y]) da=w[x]*w[y];
				cout<<sum<<" "<<i<<" "<<j<<endl;
			}if(road[i].v==road[j].v){
				int x=road[i].u;
				int y=road[j].u;
				sum=(sum+2*(w[x]*w[y])%10007)%10007;
				if(da<w[x]*w[y]) da=w[x]*w[y];
				cout<<sum<<" "<<i<<" "<<j<<endl;
			}
		}
	}
	cout<<da<<" "<<sum;
	return 0;
}
