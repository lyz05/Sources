#include <stdio.h>
#include <iostream>
using namespace std;

int n,m,p;
int f[10001][1001],has[10001]={0};

struct node1{
	int h;
	int l;
}pipe[10001];

struct node2{
	int u;
	int d;
}bird[10001];

int main(){
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	cin>>n>>m>>p;
	int i,j,k;
	for(i=1;i<=n;++i)
	    cin>>bird[i].u>>bird[i].d;
	for(i=0;i<=n;++i){
		pipe[i].h=m+1;
		pipe[i].l=0;
	}
	for(i=1;i<=p;++i){
		int x;
		cin>>x;
		cin>>pipe[x].l>>pipe[x].h;
		has[x]=1;
	}
	for(j=1;j<=m;++j) f[0][j]=0;
	for(i=1;i<=n;++i)
	    for(j=1;j<=m;++j)
	        f[i][j]=10000000;
	int flag;
	for(i=1;i<=n;++i){
		for(j=pipe[i].l+1;j<=pipe[i].h-1;++j){
			if(j+bird[i].d<pipe[i-1].h && f[i][j]>f[i-1][j+bird[i].d]+1) 
			    f[i][j]=f[i-1][j+bird[i].d];
			k=1;
			while(j-k*bird[i].u>pipe[i-1].l){
				if(f[i][j]>f[i-1][j-k*bird[i].u]+k)
				    f[i][j]=f[i-1][j-k*bird[i].u]+k;
				++k;
			}
			if(j==10){
				for(k=pipe[i-1].h-1;k>=pipe[i-1].l+1;--k){
					if(f[i][j]>f[i-1][k]+((j-k)/bird[i].u)+1)
					    f[i][j]=f[i-1][k]+((j-k)/bird[i].u)+1;
				}
			}
		}
		flag=1;
		for(j=pipe[i].l+1;j<=pipe[i].h-1;++j){
			if(f[i][j]!=10000000){
				flag=0;
				break;
			}
		}
		if(flag==1){
			flag=i;
			break;
		}
	}
	if(flag!=0){
		int num=0;
		for(i=1;i<flag;++i){
			if(has[i]==1) num++;
		}
		cout<<"0"<<endl<<num;
	}
	else{
		int xiao=10000000;
		for(i=1;i<=m;++i){
			if(xiao>f[n][i]) xiao=f[n][i];
		}
		cout<<"1"<<endl<<xiao;
	}
	return 0;
}











