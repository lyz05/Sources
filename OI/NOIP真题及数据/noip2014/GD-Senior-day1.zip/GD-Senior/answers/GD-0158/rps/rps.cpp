#include <cstdio>
#include <cstdlib>
#include <cstring>
#define FILENAME "rps"
using namespace std;
#define rep(i,j,k) for(i=j;i<k;i++)
#define FOR(i,j,k) for(i=j;i<=k;i++)
#define FORD(i,j,k) for(i=j;i>=k;i--)

#define MAXR 205

const int W_EQUAL = 0, W_A = 1, W_B = 2;

int win(int a, int b) {
	if(a==b) return W_EQUAL;
	if(a==0) {
		if(b==1||b==4) return W_B;
		if(b==2||b==3) return W_A;
	} else if(a==1) {
		if(b==2||b==4) return W_B;
		if(b==3) return W_A;
	} else if(a==2) {
		if(b==3) return W_B;
		if(b==4) return W_A;
	} else if(a==3) {
		if(b==4) return W_A;
	}
	int i=win(b,a);
	if(i==W_B) return W_A;
	if(i==W_A) return W_B;
	return i;
}

int na[MAXR], nb[MAXR];

int main() {
	freopen(FILENAME".in","r",stdin);
	freopen(FILENAME".out","w",stdout);
	
	int N, NA, NB;
	scanf("%d%d%d", &N, &NA, &NB);
	int i;
	rep(i,0,NA) scanf("%d", &na[i]);
	rep(i,0,NB) scanf("%d", &nb[i]);
	
	int c[3]={0};
	
	rep(i,0,N) {
		c[win(na[i%NA],nb[i%NB])]++;
	}
	printf("%d %d", c[1], c[2]);
	
	return 0;
}

