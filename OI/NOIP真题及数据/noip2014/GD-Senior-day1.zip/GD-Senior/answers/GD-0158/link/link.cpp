#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#define FILENAME "link"
using namespace std;
#define rep(i,j,k) for(i=j;i<k;i++)
#define FOR(i,j,k) for(i=j;i<=k;i++)
#define FORD(i,j,k) for(i=j;i>=k;i--)

#define max(i,j) ((i)>(j)?(i):(j))
typedef long long ll;

const int MAXN = 200005, MAXM = MAXN*2;

int h[MAXM], t[MAXM], p[MAXM], cnt=0;
int f[MAXN], computed[MAXN];
ll w[MAXN];
ll ans=0, maxans=0;

void add(int u, int v) {
	p[cnt]=h[u];
	t[cnt]=v;
	h[u]=cnt++;
}

void readin() {
	int n;
	scanf("%d", &n);
	int i, u, v;
	rep(i,1,n) {
		scanf("%d%d", &u, &v);
		add(u,v);add(v,u);
	}
	FOR(i,1,n) scanf("%d", &w[i]);
}

void add(ll &a, ll b) {
	a=(a+b)%10007;
}
/*
void dfs(int now, int par) {
	f[now] = par;
	if(par != -1) {
		if(f[par]!=-1) {
			maxans = max(maxans, w[now]*w[f[par]]);
			add(ans, w[now]*w[f[par]]*2);
		}
		
		for(int i=h[par];i!=-1;i=p[i]) {
			if(t[i]!=f[par]&&t[i]!=now&&!computed[t[i]]) {
				maxans = max(maxans, w[now]*w[t[i]]);
				add(ans, w[now]*w[t[i]]*2);
			}
		}
		computed[now]=1;
	}
	for(int i=h[now];i!=-1;i=p[i])
		if(t[i]!=par)
			dfs(t[i], now);
}*/

void bfs() {
	int q[MAXN*2];
	int l=0,r=0;
	q[r++]=1;
	f[1]=-1;
	while(l<r) {
		int u=q[l++];
		if(f[u]!=-1) {
			if(f[f[u]]!=-1) {
				maxans = max(maxans, w[u]*w[f[f[u]]]);
				add(ans, w[u]*w[f[f[u]]]*2);
			}
			
			for(int i=h[f[u]];i!=-1;i=p[i]) {
				if(t[i]!=f[f[u]]&&t[i]!=u&&!computed[t[i]]) {
					maxans = max(maxans, w[u]*w[t[i]]);
					add(ans, w[u]*w[t[i]]*2);
				}
			}
			computed[u]=1;
		}
		for(int i=h[u];i!=-1;i=p[i])
			if(t[i]!=f[u]) {
				f[t[i]]=u;
				q[r++]=t[i];
			}
	}
}

int main() {
	freopen(FILENAME".in","r",stdin);
	freopen(FILENAME".out","w",stdout);
	
	memset(f,-1,sizeof(f));
	memset(h,-1,sizeof(h));
	memset(computed,0,sizeof(computed));
	
	readin();
	//dfs(1, -1);
	bfs();
	
	cout<<maxans<<' '<<ans;
	
	return 0;
}

