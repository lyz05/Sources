#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>
#define FILENAME "bird"
using namespace std;
#define rep(i,j,k) for(i=j;i<k;i++)
#define FOR(i,j,k) for(i=j;i<=k;i++)
#define FORD(i,j,k) for(i=j;i>=k;i--)
#define inf 0x7ffffff

#define MAXN 10005
#define MAXM 1005
#define max(i,j) ((i)>(j)?(i):(j))
#define min(i,j) ((i)<(j)?(i):(j))

struct Pipe {
	int top, bottom, has;
} pipe[MAXN];

int up[MAXN], down[MAXN], n, m, k;
int passed_pipe[MAXN];
int ans, noans;

void readin() {
	int i,j;
	scanf("%d%d%d", &n, &m, &k);
	FOR(i,1,n) {
		scanf("%d%d", &up[i], &down[i]);
		pipe[i].top=m-1;
		pipe[i].bottom=1;
		pipe[i].has = 0;
	}
	rep(i,0,k) {
		scanf("%d",&j);
		scanf("%d%d", &pipe[j].bottom, &pipe[j].top);
		pipe[j].bottom++;
		pipe[j].top--;
		pipe[j].has = 1;
	}
	passed_pipe[0]=0;
	rep(i,1,n) {
		passed_pipe[i]=passed_pipe[i-1];
		if(pipe[i].has)
			passed_pipe[i]++;
	}
}

int bird[MAXN];
int maxgo=0,minclick=inf;

int f[MAXN][MAXM];

int work() {
	int i,j,k,maxgo=0;
	FOR(i,0,m) f[0][i]=0;
	FOR(i,1,n) {
		int go=0;
		FOR(j,pipe[i].bottom,pipe[i].top) {
			for(k=1;j-k*up[i]>0;k++) {
				go |= f[i][j] != noans;
				f[i][j]=min(f[i][j], f[i-1][j-k*up[i]]+k);
			}
			if(j+down[i]<=m) {
				f[i][j]=min(f[i][j],f[i-1][j+down[i]]);
				go |= f[i][j] != noans;
			}
		}
		if(!pipe[i].has)
		FOR(j,1,m) {
			int a=(int)ceil((1.0*m-1.0*j)/up[i]);
			if(a==0) a=1;
			f[i][m]=min(f[i][m],f[i-1][j]+a);
			go |= f[i][m] != noans;
		}
		if(go) maxgo = max(maxgo, passed_pipe[i]);
	}
	return maxgo;
}

int main() {
	freopen(FILENAME".in","r",stdin);
	freopen(FILENAME".out","w",stdout);
	
	readin();
	
	memset(f,127,sizeof(f));
	ans = noans = f[0][0];
	int maxgo = work(), i;
	FOR(i,1,m) {
		if(f[n][i]!=noans) ans=min(ans,f[n][i]);
	}
	if(ans==noans)
		printf("0\n%d", maxgo);
	else
		printf("1\n%d", ans);
	return 0;
}

