#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <cstring>

using namespace std;

int n,na,nb;
int a[205],b[205];
int ansa=0,ansb=0;

void init()
{
	scanf("%d%d%d",&n,&na,&nb);
	for(int i=1;i<=na;i++) 
	{	
		scanf("%d",&a[i]);
		int k=i+na;
		while(k<=n)
		{
			a[k]=a[i];
			k+=na;
		}
	}
	for(int i=1;i<=nb;i++) 
	{
		scanf("%d",&b[i]);
		int k=i+nb;
		while(k<=n)
		{
			b[k]=b[i];
			k+=nb;
		}
	}
}

void work()
{
	for(int i=1;i<=n;i++)
	{
		if(a[i]==0)
		{
			if(b[i]==1) {ansb++;continue;}
			if(b[i]==2) {ansa++;continue;}
			if(b[i]==3) {ansa++;continue;}
			if(b[i]==4) {ansb++;continue;}
		}
		if(a[i]==1)
		{
			if(b[i]==0) {ansa++;continue;}
			if(b[i]==2) {ansb++;continue;}
			if(b[i]==3) {ansa++;continue;}
			if(b[i]==4) {ansb++;continue;}
		}
		if(a[i]==2)
		{
			if(b[i]==0) {ansb++;continue;}
			if(b[i]==1) {ansa++;continue;}
			if(b[i]==3) {ansb++;continue;}
			if(b[i]==4) {ansa++;continue;}
		}
		if(a[i]==3)
		{
			if(b[i]==1) {ansb++;continue;}
			if(b[i]==2) {ansa++;continue;}
			if(b[i]==0) {ansb++;continue;}
			if(b[i]==4) {ansa++;continue;}
		}
		if(a[i]==4)
		{
			if(b[i]==1) {ansa++;continue;}
			if(b[i]==2) {ansb++;continue;}
			if(b[i]==3) {ansb++;continue;}
			if(b[i]==0) {ansa++;continue;}
		}
	}
}

int main()
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	init();
	work();
	printf("%d %d\n",ansa,ansb);
	fclose(stdin);fclose(stdout);
}
