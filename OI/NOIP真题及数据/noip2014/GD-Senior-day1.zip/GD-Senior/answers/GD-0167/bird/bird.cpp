#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>

using namespace std;

int n,m,k;
int x[105],y[105];
int ok=0;
int ans=0xfffffff;

void init()
{
	scanf("%d%d%d",&n,&m,&k);
	for(int i=0;i<n;i++) scanf("%d%d",&x[i],&y[i]);
}

void dfs(int t,int xx,int h,int sum)
{
	
	if(h<=0) return;//printf("%d %d %d %d\n",t,xx,h,sum);
	if(xx==n)
	{
		ok=1;
		ans=min(ans,sum);
		//printf("%d %d\n",h,sum);
		return;
	}
	
		for(int i=0;i<=3;i++)
		{
			if(!i) 
				dfs(i,xx+1,h-y[xx],sum+i);
			else
				dfs(i,xx+1,min(m,h+x[xx]*i),sum+i);	
		}
		
	
}

int main()
{
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	init();
	if(!k)
	{
	for(int i=0;i<=3;i++)
	{
		if(!i)
			dfs(i,1,m-y[0],i);
		else
			dfs(i,1,m,i);
	}
		
	if(ok)
		printf("%d\n%d\n",ok,ans);
	else
		printf("0\n0\n");
	return 0;
	}
	else
	{
		printf("0\n0\n");
	}
}
