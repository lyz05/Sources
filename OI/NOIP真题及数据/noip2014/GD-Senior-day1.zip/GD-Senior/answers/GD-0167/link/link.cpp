#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>

using namespace std;

const int M=10007;

int g[200005],ot[200005],ne[200005],w[200005];
int n;
int e=0;
int ans=0,max1=0;

void addedge(int x,int y)
{
	ot[++e]=y;ne[e]=g[x];g[x]=e;
	ot[++e]=x;ne[e]=g[y];g[y]=e;
}

void init()
{
	scanf("%d",&n);
	memset(g,255,sizeof g);
	int x,y;
	for(int i=1;i<n;i++)
	{
		scanf("%d%d",&x,&y);
		addedge(x,y);
	}
	for(int i=1;i<=n;i++) scanf("%d",&w[i]);
}

int work()
{
	int tmp;
	for(int i=1;i<=n;i++)
	{
		for(int yy=g[i];yy+1;yy=ne[yy])
		{
			int v=ot[yy];
			for(int j=g[i];j+1;j=ne[j])
			{
				if(v!=ot[j])
				{
					tmp=w[v]*w[ot[j]];
					//printf("a %d %d %d\n",v,ot[j],tmp);
					ans+=tmp%M;
					max1=max(max1,tmp);
				}
			}
			
		}
	}
}

int main()
{
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	init();
	work();
	printf("%d %d\n",max1,ans);
	fclose(stdin);fclose(stdout);
}
