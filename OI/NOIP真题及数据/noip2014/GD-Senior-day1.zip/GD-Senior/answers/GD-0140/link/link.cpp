#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<stack>
#include<queue>
#include<vector>
#include<algorithm>
#include<functional>
using namespace std;
typedef long long ll;
const int M=200010;
const int mod=10007;
int n;
int f[M];
int t[M];
ll s[M];

int get_f(int x)
{
	if (x==f[x]) return x;
	f[x]=get_f(f[x]);
	return f[x];
}
void merge(int x, int y)
{
	int x1=get_f(x);
	int y1=get_f(y);
	f[x1]=y1;
}
void solve()
{
	int tot=0;
	for(int i=1; i<=n; i++)
	{
		for(int j=1; j<=n; j++)
		{
			if (i!=j)
			{
				int x1=get_f(i);
				int x2=get_f(j);
				if (x1==x2 && abs(i-j)==2)
				{
					s[++tot]=(t[i]*t[j])%mod;
				}
			}
		}
	}
	int ans=0;
	ll sum=0;
	for(int i=1; i<=tot; i++)
	{
		if (s[i]>ans) ans=s[i];
		sum=(sum+s[i])%mod;
	}
	printf("%d %d\n", ans, sum);
}
void init()
{
	scanf("%d", &n);
	for(int i=1; i<=n; i++) f[i]=i;
	for(int i=1; i<=n-1; i++)
	{
		int x, y;
		scanf("%d %d", &x, &y);
		merge(x, y);
	}
	for(int i=1; i<=n; i++) scanf("%d", &t[i]);
}
int main()
{
	freopen("link.in", "r", stdin);
	freopen("link.out", "w", stdout);
	init();
	solve();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
