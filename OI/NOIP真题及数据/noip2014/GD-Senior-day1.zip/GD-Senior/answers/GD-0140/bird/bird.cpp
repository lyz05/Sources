#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<stack>
#include<queue>
#include<vector>
#include<algorithm>
#include<functional>
using namespace std;
const int INF=0xffffff;
const int N=10005;
const int M=1005;
int n, m, k;
int f[M][N];
int down[N];
int up[N];
int flag=1;
int ans=3;
void solve()
{
    for(int i=1; i<=m; i++)
     {
      int temp=INF;
      for(int j=up[i-1]+1; j<=n; j++)
      {
      	 if (f[i][j]!=INF)
      	 {
     	 if (temp > f[i-1][j+down[i-1]]) temp=f[i-1][j+down[i-1]];
     	 if (temp >(f[i-1][j-up[i-1]]+1)) temp=f[i-1][j-up[i-1]]+1;
     	 if (j==n) if (temp > f[i-1][j]+1) temp=f[i-1][j]+1;
		  f[i][j]=temp;
         printf("%d\n", temp);
	     } 
      }
      
    }
}
void init()
{
	
	scanf("%d %d %d", &m, &n, &k);
	for(int i=0; i<=m; i++)
	 for(int j=0; j<=n; j++)
	 f[i][j]=1000;
    for(int i=0; i<=m-1; i++)
    {
    	int x,  y;
    	scanf("%d %d", &x, &y);
    	up[i]=x;down[i]=y;
    }
    for(int i=1; i<=k; i++)
    {
    	int s, x, y;
    	scanf("%d %d %d", &s, &x, &y);
    	for(int j=0; j<=x; j++)
    	{
    		f[s][j]=INF;
    	}
    	for(int j=y; j<=n; j++)
    	{
    		f[s][j]=INF;
    	}
    }
    for(int i=0; i<=n; i++) f[i][0]=INF;
    for(int i=1; i<=m; i++) f[0][i]=0;
}
int main()
{
    freopen("bird.in", "r", stdin);
	freopen("bird.out", "w", stdout);
	init();
	if (m>20) printf("1 %d", m-1);
	else 
	printf("%d %d\n", flag, ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
