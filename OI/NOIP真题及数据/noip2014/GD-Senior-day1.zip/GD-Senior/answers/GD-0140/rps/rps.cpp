#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<stack>
#include<queue>
#include<vector>
#include<algorithm>
#include<functional>
using namespace std;
const int M=305;
int n, na,nb;
int a[M];
int b[M];
int map[6][6];
void init()
{
	scanf("%d %d %d", &n, &na, &nb);
	memset(map, 0, sizeof(map));
	for(int i=0; i<na; i++) scanf("%d", &a[i]);
	for(int i=0; i<nb; i++) scanf("%d", &b[i]); 
	map[0][0]=0;map[0][1]=0;map[0][2]=1;map[0][3]=1;map[0][4]=0;
	map[1][1]=0;map[1][2]=0;map[1][3]=1;map[1][4]=0;
	map[2][2]=0;map[2][3]=0;map[2][4]=1;
	map[3][3]=0;map[3][4]=1;map[4][4]=0;
	for(int i=0; i<=4; i++)
	 for(int j=0; j<=4; j++)
	 {
	 	if (map[i][j]==0 && i!=j)
	 	{
	 		map[j][i]=1;
	 	}
	 	else if (map[i][j]==1)
	 	{
	 		map[j][i]=0;
	 	}
	 }
}
void solve()
{
	int ta=-1;
	int tb=-1;
	int ansa=0;
	int ansb=0;
	for(int i=0; i<n; i++)
	{
		if (ta+1>na-1) ta=-1;
		if (tb+1>nb-1) tb=-1;
		ansa+=map[a[++ta]][b[++tb]];
		ansb+=map[b[tb]][a[ta]];
	}
	printf("%d %d\n", ansa, ansb);
}
int main()
{
	freopen("rps.in", "r", stdin);
	freopen("rps.out", "w", stdout);
	init();
	solve();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
