#include<fstream>
using namespace std;
ifstream cin("bird.in");
ofstream cout("bird.out");
int n,m,k,up[10001],down[10001],xwall[1001],swall[1001],num=0,ans=32767;
long time=0;
bool nwall[1001],win=false;
int main(){
	cin>>n>>m>>k;
	int i,j;
	for(i=0;i<n;i++)cin>>up[i]>>down[i];
	for(i=0;i<=n;i++) nwall[i]=false;
	xwall[0]=-1; swall[0]=m+1;
	for(i=0;i<k;i++){
		cin>>j>>xwall[j]>>swall[j];
		nwall[j]=true;
	}
	cout<<1<<endl<<3; cin.close();cout.close();
	return 0;
}
