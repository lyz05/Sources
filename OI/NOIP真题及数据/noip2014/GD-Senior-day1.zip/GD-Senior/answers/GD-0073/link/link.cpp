#include<fstream>
using namespace std;
ifstream cin("link.in");
ofstream cout("link.out");
long a[2001],b[2001],map[2001][2001],val[2001],n;
int main(){
	long i,j,k,ans=0,big=0;
	cin>>n;
	for(i=1;i<=n;i++)
	for(j=1;j<=n;j++)
	map[i][j]=0;
	for(i=1;i<n;i++){
		cin>>a[i]>>b[i];
		map[a[i]][b[i]]=1;
		map[b[i]][a[i]]=1;
	}
	for(i=1;i<=n;i++) cin>>val[i];
	for(i=1;i<=n;i++)
	for(j=1;j<=n;j++)
	for(k=1;k<=n;k++)
	if (map[i][k]*map[k][j]>0)
		if (map[i][k]+map[k][j]<map[i][j] || map[i][j]==0)
			map[i][j]=map[i][k]+map[k][j];
	map[1][1]=0;
	for(i=1;i<=n;i++)
	for(j=i+1;j<=n;j++)
	if (map[i][j]==2){
		ans=(ans+(val[i]*val[j]*2%10007))%10007;
		if (val[i]*val[j]>big) big=val[i]*val[j];
	}
	cout<<big<<' '<<ans;
	cin.close(); cout.close();
	return 0;
}
