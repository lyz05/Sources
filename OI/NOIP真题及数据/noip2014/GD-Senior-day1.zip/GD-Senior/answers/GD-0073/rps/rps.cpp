#include<fstream>
using namespace std;
ifstream cin("rps.in");
ofstream cout("rps.out");
int main(){
	int n,na,nb;
	cin>>n>>na>>nb;
	int a[na],b[nb],i,j,k,sa=0,sb=0;
	for(i=0;i<na;i++)cin>>a[i];
	for(i=0;i<nb;i++)cin>>b[i];
	j=0; k=0;
	for(i=1;i<=n;i++){
		if (a[j]==0){
			if (b[k]==1 || b[k]==4) sb++;
			if (b[k]==2 || b[k]==3) sa++;
		}
		else if (a[j]==1){
			if (b[k]==2 || b[k]==4) sb++;
			if (b[k]==0 || b[k]==3) sa++;
		}
		else if (a[j]==2){
			if (b[k]==0 || b[k]==3) sb++;
			if (b[k]==1 || b[k]==4) sa++;
		}
		else if (a[j]==3){
			if (b[k]==0 || b[k]==1) sb++;
			if (b[k]==2 || b[k]==4) sa++;
		}
		else if (a[j]==4){
			if (b[k]==2 || b[k]==3) sb++;
			if (b[k]==0 || b[k]==1) sa++;
		}
		j++; if (j>=na) j=0;
		k++; if (k>=nb) k=0;
	}
	cout<<sa<<' '<<sb;
	cin.close(); cout.close(); return 0;
}
