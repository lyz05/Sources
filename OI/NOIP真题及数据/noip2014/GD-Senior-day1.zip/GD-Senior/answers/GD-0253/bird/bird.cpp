#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <cstring>
#include <cmath>
#include <queue>
#include <algorithm>
#include <stack>
#include <map>
#include <set>

using namespace std;

FILE *fin,*fout;

int n,m,k,ans;
int up[10010],down[10010];
int h[10010],l[10010],p[10010],s[10010];
int f[10010][1010];
bool flag;

int main()
{
fin=fopen("bird.in","r");
fout=fopen("bird.out","w");

memset(f,-1,sizeof(f));

fscanf(fin,"%d%d%d",&n,&m,&k);
for(int i=0;i<n;i++) fscanf(fin,"%d%d",&up[i],&down[i]);
for(int i=1;i<=k;i++) 
{
fscanf(fin,"%d%d%d",&p[i],&l[i],&h[i]);
s[p[i]]=i;
}
for(int i=1;i<=m;i++) f[0][i]=0;
for(int i=0;i<n;i++)
{
bool have=false;
if(s[i]!=0) ans++;
for(int j=1;j<=m;j++)
 {
 if(f[i][j]==-1) continue;
 if(s[i]!=0&&( j<=l[s[i]] || j>=h[s[i]] ) ) { f[i][j]=-1; continue; } 
 have=true;
 if(j-down[i]>0) 
  {
  if(f[i+1][j-down[i]]==-1) f[i+1][j-down[i]]=f[i][j];
  else f[i+1][j-down[i]]=min(f[i+1][j-down[i]],f[i][j]);
  }
 int q; 
 for(q=1;j+up[i]*q<m;q++) 
  {
  if(f[i+1][j+up[i]*q]==-1) f[i+1][j+up[i]*q]=f[i][j]+q;
  else f[i+1][j+up[i]*q]=min(f[i+1][j+up[i]*q],f[i][j]+q);
  } 
 if(f[i+1][m]==-1) f[i+1][m]=f[i][j]+q;
 else f[i+1][m]=min(f[i+1][m],f[i][j]+q);
 } 
if(have==false) { ans--; flag=true; break; }
}
if(flag) fprintf(fout,"0\n%d\n",ans);	
else 
 {
 int sum=0,first=true;
 for(int i=1;i<=m;i++)
  {
  if(f[n][i]==-1) continue;
  if(first)  { sum=f[n][i]; first=false; } 
  else sum=min(sum,f[n][i]);
  }
 fprintf(fout,"1\n%d\n",sum);  
 }/*
for(int i=1;i<=n;i++)
{

 for(int j=1;j<=m;j++) cout <<f[i][j]<<' '; 
 cout <<endl;
 }*/
 fclose(fin);
fclose(fout);
return 0;
}

