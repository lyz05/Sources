#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <cstring>
#include <cmath>
#include <queue>
#include <algorithm>
#include <stack>
#include <map>
#include <set>

using namespace std;

FILE *fin,*fout;

int comp(int a,int b)
{
bool change=false,res=false;
if(a>b) 
 {
 int t=a; a=b; b=t;
 change=true;
 }	
if(a==b) return 0;
if(a==0&&b==1) res=false;
else if(a==1&&b==2) res=false;
else if(a==2&&b==3) res=false;
else if(a==0&&b==4) res=false;
else if(a==1&&b==4) res=false;
else res=true;
if(change) res=!res;
if(res) return 1;    
else return 2;
}

int n,na,nb;
int an[210],bn[210];

int main()
{
fin=fopen("rps.in","r");
fout=fopen("rps.out","w");

fscanf(fin,"%d%d%d",&n,&na,&nb);
for(int i=0;i<na;i++) fscanf(fin,"%d",&an[i]);
for(int i=0;i<nb;i++) fscanf(fin,"%d",&bn[i]);
int ka=0,kb=0,sa=0,sb=0;
for(int i=0;i<n;i++)
 {
 int res=comp(an[ka++],bn[kb++]);
 if(res==1) sa++;
 else if(res==2) sb++;
 ka%=na; kb%=nb;
 }
fprintf(fout,"%d %d\n",sa,sb); 
fclose(fin);
fclose(fout);
return 0;
}

