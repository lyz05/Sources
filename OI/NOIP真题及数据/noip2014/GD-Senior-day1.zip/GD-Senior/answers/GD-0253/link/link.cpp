#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <cstring>
#include <cmath>
#include <queue>
#include <algorithm>
#include <stack>
#include <map>
#include <set>

using namespace std;

FILE *fin,*fout;

int n;
int first[200100],next[500100],w[200100];
int u[500100],v[500100];
long long ans[200100];
int maxn,sum;

struct node
{
int x,y;
}ms[200100][4];

int f(int o,int fa,int ga)
{
int lin;	
 if(fa!=-1&&ga!=-1)
  {
  lin=w[o]*w[ga];
  sum=(sum+ (lin%10007) )%10007;
  sum=(sum+ (lin%10007) )%10007;
  maxn=max(maxn,lin);
  }
 for(int i=first[o];i!=-1;i=next[i]) 
  if(v[i]!=fa&&v[i]!=ga) 
  {	
  f(v[i],o,fa);
  }
 if(fa!=-1) ans[o]-=w[fa]; 
 for(int i=first[o];i!=-1;i=next[i])
  {
  if(v[i]==fa) continue;	
  ans[o]-=w[v[i]];
  //if(o==2) cout <<ans[o]<<' '<<v[i]<<endl;
  sum=(sum+ ( w[v[i]] * (ans[o]%10007) ) %10007 ) %10007;
  sum=(sum+ ( w[v[i]] * (ans[o]%10007) ) %10007 ) %10007;
  int x=0,y=1;
  if(ms[o][x].y==fa) x=2;
  if(ms[o][y].y==fa) y=2;
  lin=ms[o][x].x*ms[o][y].x;
  maxn=max(maxn,lin);
  }
}

bool cmp(node a,node b)
{
return a.x>b.x;
}

int main()
{
fin=fopen("link.in","r");
fout=fopen("link.out","w");

memset(first,-1,sizeof(first));
memset(next,-1,sizeof(next));
maxn=-1;

fscanf(fin,"%d",&n);
for(int i=0;i<n-1;i++)
 {
 fscanf(fin,"%d %d",&u[2*i],&v[2*i]);
 u[2*i+1]=v[2*i]; v[2*i+1]=u[2*i];
 next[2*i]=first[u[2*i]];
 first[u[2*i]]=2*i;
 
 next[2*i+1]=first[u[2*i+1]];
 first[u[2*i+1]]=2*i+1;
 }
for(int i=1;i<=n;i++) fscanf(fin,"%d",&w[i]);
for(int i=1;i<=n;i++)
{

 for(int j=first[i];j!=-1;j=next[j]) 
 {
 
 ans[i]+=w[v[j]];
 ms[i][3].x=w[v[j]];
 ms[i][3].y=v[j];
 sort(ms[i],ms[i]+4,cmp);
 }
 }
f(1,-1,-1);
fprintf(fout,"%d %d\n",maxn,sum%10007);
fclose(fin);
fclose(fout);
return 0;
}

