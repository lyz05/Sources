#include<iostream>
#include<fstream>
#include<algorithm>
#include<memory.h>
#include<vector>
using namespace std;
const int MAXN = 200005;
const int MOD = 10007;
int p[MAXN];
int length[MAXN];
int first[MAXN],next[MAXN];
bool checked[MAXN];
int next_point(int a,int j);
class cline
{
public:
	int u;int v;
	cline(int a=0,int b=0){u=a,v=b;}
};
cline line[MAXN];
vector<int> pl[MAXN];
int main()
{
	memset(length,0,sizeof(length));
	memset(checked,0,sizeof(checked));
	fstream file("link.in",ios::in);
	int n=0;
	long long sum=0;
	int max=0;
	file>>n;
	int a,b,l1,l2;
	for(int i=1;i<=n-1;i++)
	{
		file>>a>>b;
		line[i].u=a;line[i].v=b;
		pl[a].push_back(i);
		length[a]++;
		pl[b].push_back(i);
		length[b]++;
	}
	for(int i=1;i<=n;i++)
	{
		file>>p[i];
	}
	file.close();
	file.clear();
	file.open("link.out",ios::out);
	for(int i=1;i<=n;i++)//遍历dian
	{
		checked[i]=true;
		l1= length[i];
		for(int j=1;j<=l1;j++)
		{
			int next = next_point(i,j);
			l2 = length[next];
			for(int k= 1;k<=l2;k++)
			{
				int final = next_point(next,k);
				if(final==i) continue;
				int w=p[i]*p[final];
				//if(checked[final]) continue;
				
				
				if(w>max) max=w;
				if(w>=MOD||sum+w>=MOD)  
				{
					sum = sum%MOD;
					w = w%MOD;
					sum = (sum+w)%MOD;
				}
				else	sum += w;
				
			}
		}
		checked[i]=false;
	}
	file<<max<<" "<<sum;
	file.close();
	return 0;
}

int next_point(int a,int j)
{
	int l=pl[a][j-1];
	if(line[l].u==a)
		return line[l].v;
	else
		return line[l].u;
}