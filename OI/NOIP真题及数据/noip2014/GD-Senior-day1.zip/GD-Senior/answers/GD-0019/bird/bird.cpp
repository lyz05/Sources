#include<iostream>
#include<fstream>
#include<algorithm>
#include<memory.h>
using namespace std;
const int MAXK = 10005;
void gcd(int,int,int&,int&);
class pile
{
public:
	int P;int L;int H;
	pile(int a=0,int b=0,int c=0)
	{
		P=a,L=b,H=c;
	}
};
int n=0,m=0,k=0;
pile p[MAXK];
int main()
{
	fstream file("bird.in",ios::in);
	
	
	file.close();
	file.clear();
	file.open("bird.out",ios::out);
	file<<"0";
	file.close();
	return 0;
}


