#include<iostream>
#include<fstream>
#include<algorithm>
#include<memory.h>
using namespace std;
const int MAXN = 205;
int A[MAXN],B[MAXN];
void judge(int ai,int bi,int&n1,int&n2);
int main()
{
	int N=0,n1=0,n2=0,g1=0,g2=0;
	fstream file("rps.in",ios::in);
	file>>N>>n1>>n2;
	for(int i=0;i<n1;i++)
	{
		file>>A[i];
	}
	for(int i=0;i<n2;i++)
	{
		file>>B[i];
	}
	
	for(int i=0;i<N;i++)
	{
		judge(A[i%n1],B[i%n2],g1,g2);
	}
	file.close();
	file.clear();
	file.open("rps.out",ios::out);
	file<<g1<<" "<<g2;
	file.close();
	return 0;
}

void judge(int ai,int bi,int&n1,int&n2)
{
	if(ai==bi) return;
		if(ai==0)
		{
			if(bi==2||bi==3)
				n1++;
			else n2++;
		}
		if(ai==1)
		{
			if(bi==3||bi==0)
				n1++;
			else n2++;
		}
		if(ai==2)
		{
			if(bi==4||bi==1)
				n1++;
			else n2++;
		}
		if(ai==3)
		{
			if(bi==4||bi==2)
				n1++;
			else n2++;
		}
		if(ai==4)
		{
			if(bi==0||bi==1)
				n1++;
			else
				n2++;
		}
}
