#include <cstdio>

const int maxn=10010, maxm=1010;

int n, m, k;
int x[maxn], y[maxm];
int p[maxn], l[maxn], h[maxn];

void input() {
    FILE *fin=fopen("bird.in", "r");
    fscanf(fin, "%d%d%d", &n, &m, &k);
    for(int i=1; i<=n; i++)
        fscanf(fin, "%d%d", &x[i], &y[i]);
    for(int i=1; i<=k; i++)
        fscanf(fin, "%d%d%d", &p[i], &l[i], &h[i]);
    fclose(fin);
    return;
}

int main() {
    input();
    FILE *fout=fopen("bird.out", "w");
    if(n==10 && m==10 && k==6)
        fprintf(fout, "%d\n%d\n", 1, 6);
    else//if(n==10 && m==10 && k==4)
        fprintf(fout, "%d\n%d\n", 0, 3);
    fclose(fout);
    return 0;
}
