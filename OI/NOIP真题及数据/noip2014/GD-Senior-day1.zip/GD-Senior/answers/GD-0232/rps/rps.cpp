#include <cstdio>

const int maxn=210;

int n, nA, nB;
int tA[maxn], tB[maxn];
int sA=0, sB=0;
int judge[5][5]={
     0, -1,  1,  1, -1,
     1,  0, -1,  1, -1,
    -1,  1,  0, -1,  1,
    -1, -1,  1,  0,  1,
     1,  1, -1, -1,  0
};

void input() {
    FILE *fin=fopen("rps.in", "r");
    fscanf(fin, "%d%d%d", &n, &nA, &nB);
    for(int i=0; i<nA; i++)
        fscanf(fin, "%d", &tA[i]);
    for(int i=0; i<nB; i++)
        fscanf(fin, "%d", &tB[i]);
    fclose(fin);
}

void output() {
    FILE *fout=fopen("rps.out", "w");
    fprintf(fout, "%d %d\n", sA, sB);
    fclose(fout);
    return;
}

void p() {
    int A, B;
    for(int i=1; i<=n; i++) {
        A=i%nA-1;
        B=i%nB-1;
        if(judge[tA[A]][tB[B]]==1)
            sA++;
        else if(judge[tA[A]][tB[B]]==-1)
            sB++;
    }
    return;
}

int main() {
    input();
    p();
    output();
    return 0;
}
