#include <cstdio>
#include <cstring>
#include <vector>
#include <stack>

using namespace std;

const int maxn=200010;

int n;
//int u[maxn], v[maxn];
int w[maxn], c[maxn];
vector<int> g[maxn];//, ans;
bool vis[maxn];
long long sum=0, maxa=0;

int max(const int x, const int y) {
    return x>y?x:y;
}

void input() {
    int i, j=0;
    int u, v;
    FILE *fin=fopen("link.in", "r");
    fscanf(fin, "%d", &n);
    memset(c, 0, sizeof(c));
    for(i=1; i<=n-1; i++) {
        //fscanf(fin, "%d%d", &u[i], &v[i]);
        fscanf(fin, "%d%d", &u, &v);
        c[u]++;
        c[v]++;
        g[u].push_back(v);
        g[v].push_back(u);
        //c[u[i]]++;
        //c[v[i]]++;
        //g[u[i]].push_back(v[i]);
        //g[v[i]].push_back(u[i]);
    }
    for(i=1; i<=n; i++)
        fscanf(fin, "%d", &w[i]);
    fclose(fin);
    return;
}

void output() {
    FILE *fout=fopen("link.out", "w");
    fprintf(fout, "%d %d\n", (int)maxa, (int)sum);
    fclose(fout);
    return;
}

/*
void dfs(int parent, int node) {
    for(int i=0; i<g[node].size(); i++)
        for(int j=0; j<g[node].size(); j++)
            ans.push_back(w[i]*w[j]);
    if(parent==-1) {
        for(int i=0; i<g[node].size(); i++)
            dfs(node, g[node][i]);
        return;
    }
    for(int i=0; i<g[node].size(); i++)
        if(g[node][i]!=parent) {
            ans.push_back(w[g[node][i]]*w[parent]);
            dfs(node, g[node][i]);
        }
    return;
}
*/
void dfs(int parent, int node) {
    stack<int> sp, sn, si;
    sp.push(parent);
    sn.push(node);
    si.push(0);
    while(!sp.empty()) {
        int ip=sp.top(); sp.pop();
        int in=sn.top(); sn.pop();
        int ii=si.top(); si.pop();

        if(ii==0) {
            for(int i=0; i<g[in].size(); i++)
                for(int j=i+1; j<g[in].size(); j++)
                    if(g[in][i]!=ip && g[in][j]!=ip) {
                        maxa=max(w[g[in][i]]*w[g[in][j]], maxa);
                        sum=(sum+w[g[in][i]]*w[g[in][j]])%10007;//ans.push_back(w[g[in][i]]*w[g[in][j]]);
                    }
        }

        if(ip==-1) {
            for(int i=ii; i<g[in].size(); i++) {
                sp.push(ip);
                sn.push(in);
                si.push(i+1);

                sp.push(in);
                sn.push(g[in][i]);
                si.push(0);
                break;
            }
        } else {
            for(int i=ii; i<g[in].size(); i++) {
                if(g[in][i]!=ip) {
                    maxa=max(w[g[in][i]]*w[ip], maxa);
                    sum=(sum+w[g[in][i]]*w[ip])%10007;
                    //ans.push_back(w[g[in][i]]*w[ip]);
                    sp.push(ip);
                    sn.push(in);
                    si.push(i+1);

                    sp.push(in);
                    sn.push(g[in][i]);
                    si.push(0);
                    break;
                }
            }
        }
    }
    return;
}

int main() {
    input();
    for(int i=1; i<=n; i++)
        if(c[i]==1) {
            dfs(-1, i);
            break;
        }
    /*for(int i=0; i<ans.size(); i++) {
        maxa=max(maxa, ans[i]);
        sum=(sum+ans[i])%10007;
    }*/
    sum=(sum<<1)%10007;
    output();
    return 0;
}
