#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <utility>

const int sc[5][5]=	{{0,0,1,1,0}
					,{1,0,0,1,0}
					,{0,1,0,0,1}
					,{0,0,1,0,1}
					,{1,1,0,0,0}};

int n,na,nb;
int i,ansa,ansb;
int ga[222],gb[222];

using namespace std;
int main()
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	
	scanf("%d%d%d",&n,&na,&nb);
	for (i=0;i<na;i++)
		scanf("%d",ga+i);
	for (i=0;i<nb;i++)
		scanf("%d",gb+i);
	
	for (i=na;i<n;i++)
		ga[i]=ga[i-na];
	for (i=nb;i<n;i++)
		gb[i]=gb[i-nb];
		
	ansa=0;
	ansb=0;
	for (i=0;i<n;i++)
	{
		ansa+=sc[ga[i]][gb[i]];
		ansb+=sc[gb[i]][ga[i]];
	}
	
	printf("%d %d\n",ansa,ansb);
	
	return 0;
}

