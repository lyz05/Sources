#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <utility>
#define oo 16843009

using namespace std;

int L[11111];
int H[11111];
int metube;

int n,m,k;

int X0[1111],*f;
int X1[1111],*g;
int X[11111];
int Y[11111];

void FaIl(int a)
{
	printf("0\n%d\n",a);
	exit(0);
}

int main()
{
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	
	int i;
	
	scanf("%d%d%d",&n,&m,&k);
	for (i=0;i<n;i++)
		scanf("%d%d",X+i,Y+i);
	
	int aa,bb,cc;
	for (i=0;i<=n;i++)
		L[i]=0,H[i]=m+1;
	for (i=0;i<k;i++)
	{
		scanf("%d%d%d",&aa,&bb,&cc);
		L[aa]=bb; H[aa]=cc;
	}
	
	metube=0;
	f=X0; g=X1;
	memset(f,0,sizeof(f));
	f[0]=oo;
	g[0]=oo;
	
	int intsiz=sizeof(int);
	int usesiz=sizeof(int)*(m+1);
	
	int gi,i1,j;
	int cur,curl,curh;
	
	for (gi=0;gi<n;gi++)
	{
		memset(g,1,usesiz);
		cur=X[gi];
		
		for (i=cur+1,i1=1;i<=m;i++,i1++)
			g[i]=f[i1]+1;
		for (;i1<=m;i1++)
			g[m]=min(g[m],f[i1]+1);
		
		for (i=cur+1,i1=1;i<=m;i++,i1++)
			g[i]=min(g[i],g[i1]+1);
		for (;i1<m;i1++)
			g[m]=min(g[m],g[i1]+1);
		
		for (i=1,i1=Y[gi]+1;i1<=m;i++,i1++)
			g[i]=min(g[i],f[i1]);
		
		if (H[gi+1]<=m)
		{
			curl=L[gi+1];
			curh=H[gi+1];
			memset(g,1,intsiz*(curl+1));
			memset(g+curh,1,usesiz-intsiz*curh);
			
			for (j=curl+1;j<curh;j++)
				if (g[j]<oo) break;
			if (j==curh)
				FaIl(metube);
			
			metube++;
		}
		
		swap(f,g);
	}
	
	int ans=f[m];
	for (i=1;i<m;i++)
		ans=min(ans,f[i]);
	
	printf("1\n%d\n",ans);
	
	return 0;
}

