#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <utility>

using namespace std;
typedef int arr[222222];

int n;
int i,u,v;
arr SqR;
arr U,V;
arr w,sqw;
arr sq_sumw;
arr sum_sqw;
arr max1w;
arr max2w;
int ans1,ans2;

int read()
{
	static char ch;
	int ret;
	for (ch=getchar();ch<'0'||ch>'9';ch=getchar());
	for (ret=0;ch>='0'&&ch<='9';ch=getchar()) ret=ret*10+(ch&15);
	return ret;
}

int main()
{
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	
	for (i=0;i<=10007;i++)
		SqR[i]=i*i%10007;
	
	n=read();
	
	for (i=1;i<n;i++)
	{
		U[i]=read();
		V[i]=read();
	}
	
	if (n<=2)
	{
		printf("0 0\n");
		return 0;
	}
	
	for (i=1;i<=n;i++)
	{
		w[i]=read();
		sqw[i]=SqR[w[i]];
	}
	
	for (i=1;i<n;i++)
	{
		u=U[i]; v=V[i];
		sq_sumw[u]+=w[v];
		sum_sqw[u]+=sqw[v];
		sq_sumw[v]+=w[u];
		sum_sqw[v]+=sqw[u];
		
		if (max1w[u]<w[v])
		{
			max2w[u]=max1w[u];
			max1w[u]=w[v];
		}
		else if (max2w[u]<w[v])
			max2w[u]=w[v];
		
		if (max1w[v]<w[u])
		{
			max2w[v]=max1w[v];
			max1w[v]=w[u];
		}
		else if (max2w[v]<w[u])
			max2w[v]=w[u];
	}
	
	for (i=1;i<=n;i++)
	{
		sq_sumw[i]=SqR[sq_sumw[i]%10007];
		sum_sqw[i]=sum_sqw[i]%10007;
	}
	
	ans1=0;
	for (i=1;i<=n;i++)
		if (ans1<max1w[i]*max2w[i])
			ans1=max1w[i]*max2w[i];
	
	ans2=0;
	for (i=1;i<=n;i++)
	{
		ans2+=sq_sumw[i]-sum_sqw[i];
		if (ans2<0) ans2+=10007;
		if (ans2>=10007) ans2-=10007;
	}
	
	printf("%d %d\n",ans1,ans2);
	
	return 0;
}

