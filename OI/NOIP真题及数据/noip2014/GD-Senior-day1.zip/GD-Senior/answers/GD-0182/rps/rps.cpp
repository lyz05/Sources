#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <string>
#include <cmath>
#include <cctype>
#include <algorithm>
#include <map>
#include <set>
#include <vector>
using namespace std;

typedef long long int LL;

void setIO(string s,string ot){
	freopen((s+".in").c_str(),"r",stdin);
	freopen((s+"."+ot).c_str(),"w",stdout);
}

int wl[6][6];

const int maxN=205;

int a[maxN],b[maxN];
int NA,NB,N;

void init(){
	for (int i=0; i!=5; i++) wl[i][i]=3;
	wl[0][2]=wl[0][3]=wl[1][3]=wl[2][4]=wl[3][4]=1;
	for (int i=0; i!=5; i++){
		for (int j=0; j!=i; j++){
			wl[i][j]=wl[j][i]^1;
		}
	}
}

void readInput(){
	cin>>N>>NA>>NB;
	for (int i=0; i!=NA; i++) cin>>a[i];
	for (int i=0; i!=NB; i++) cin>>b[i];
}

void solve(){
	int A=0,B=0;
	int pa=0,pb=0;
	for (int i=0; i!=N; i++){
		if (wl[a[pa]][b[pb]]==1) A++;
		if (wl[a[pa]][b[pb]]==0) B++;
		pa++;
		pb++;
		if (pa==NA) pa=0;
		if (pb==NB) pb=0;
	}
	cout<<A<<' '<<B<<endl;
}

int main(){
	setIO("rps","out");
	init();
	readInput();
	solve();
	return 0;
}
