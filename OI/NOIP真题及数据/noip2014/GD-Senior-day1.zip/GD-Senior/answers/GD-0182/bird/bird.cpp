#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <string>
#include <cmath>
#include <cctype>
#include <algorithm>
#include <map>
#include <set>
#include <vector>
using namespace std;

typedef long long int LL;

void setIO(string s,string ot){
	freopen((s+".in").c_str(),"r",stdin);
	freopen((s+"."+ot).c_str(),"w",stdout);
}

const int maxN=10010,maxM=1010,INF=123456789;

int S[maxN];
int f[maxN][maxM];
int N,M,K;
int Up[maxN],Down[maxN];
int Upper[maxN],Lower[maxN];

inline void upMin(int &t,int tmp){
	if (tmp<t) t=tmp;
}

void readInput(){
	scanf("%d%d%d",&N,&M,&K);
	for (int i=1; i<=N; i++){
		scanf("%d%d",Up+i,Down+i);
	}
	for (int i=0; i<=N; i++){
		Upper[i]=M+1;
		Lower[i]=0;
	}
	for (int i=0; i!=K; i++){
		int pos,x,y;
		scanf("%d%d%d",&pos,&x,&y);
		Lower[pos]=x;
		Upper[pos]=y;
		S[pos]=1;
	}
	for (int i=1; i<=N; i++) S[i]+=S[i-1];
}

void solve(){
	f[0][0]=INF;
	for (int i=1; i<=N; i++){
		int *g=f[i];
		fill(g+1,g+M+1,INF);
		int L=Lower[i],U=Upper[i];
		int UP=Up[i],DOWN=Down[i];
		for (int j=1; j<=M; j++){
			upMin(g[min(j+UP,M)],f[i-1][j]+1);
		}
		for (int j=1; j<=M; j++){
			upMin(g[min(j+UP,M)],g[j]+1);
		}
		for (int j=L+1; j<U; j++){
			if (j+DOWN<=M){
				upMin(g[j],f[i-1][j+DOWN]);
			}
		}
		fill(g,g+L+1,INF);
		if (U<=M) fill(g+U,g+M+1,INF);
	}
	int ans=INF;
	for (int i=1; i<=M; i++){
		upMin(ans,f[N][i]);
	}
	if (ans<INF){
		cout<<1<<endl<<ans<<endl;
		return;
	}
	for (int i=N-1; i!=-1; i--){
		for (int j=1; j<=M; j++){
			if (f[i][j]<INF){
				cout<<0<<endl<<S[i]<<endl;
				return;
			}
		}
	}
}

int main(){
	setIO("bird","out");
	readInput();
	solve();
	return 0;
}
