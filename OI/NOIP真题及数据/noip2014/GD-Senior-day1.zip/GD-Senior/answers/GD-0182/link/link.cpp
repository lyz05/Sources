#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <string>
#include <cmath>
#include <cctype>
#include <algorithm>
#include <map>
#include <set>
#include <vector>
using namespace std;

typedef long long int LL;

void setIO(string s,string ot){
	freopen((s+".in").c_str(),"r",stdin);
	freopen((s+"."+ot).c_str(),"w",stdout);
}

const int maxN=200100,Mod=10007;

int N;
int w[maxN];

struct pth{
	int nd;
	pth *nx;
}E[maxN*2],*Pe,*fir[maxN];

void add_edge(int x,int y){
	Pe->nd=y;
	Pe->nx=fir[x];
	fir[x]=Pe++;
}

void readInput(){
	Pe=E;
	scanf("%d",&N);
	for (int i=0; i!=N-1; i++){
		int x,y;
		scanf("%d%d",&x,&y);
		x--,y--;
		add_edge(x,y);
		add_edge(y,x);
	}
	for (int i=0; i!=N; i++){
		scanf("%d",w+i);
	}
}

void solve(){
	int Max=0,Sum=0;
	for (int p=0; p!=N; p++){
		int m1=0,m2=0;
		LL S=0;
		for (pth *u=fir[p]; u; u=u->nx){
			int t=w[u->nd];
			S+=t;
			Sum-=t*t%Mod;
			if (Sum<0) Sum+=Mod;
			if (t>=m1){
				m2=m1;
				m1=t;
			}	else{
				if (m2<t) m2=t;
			}
		}
		Max=max(Max,m1*m2);
		Sum+=S*S%Mod;
		if (Sum>=Mod) Sum-=Mod;
	}
	cout<<Max<<' '<<Sum<<endl;
}

int main(){
	setIO("link","out");
	readInput();
	solve();
	return 0;
}
