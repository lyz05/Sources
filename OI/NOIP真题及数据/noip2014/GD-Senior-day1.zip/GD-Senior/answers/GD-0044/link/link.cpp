#include<fstream>
using namespace std;
int main()
{
	ifstream fin;
	ofstream fout;
	fin.open("link.in");
	fout.open("link.out");
	int n,i,j,sum=0,max=0,p,q;
	fin>>n;
	int a[2*n-2],w[n];
	for(i=0;i<=2*n-3;i++)
	   fin>>a[i];
	for(i=0;i<=n-1;i++)
	   fin>>w[i];
	for(i=0;i<=2*n-4;i++)
	{
		for(j=i+1;j<=2*n-3;j++)
		{
			if(a[i]==a[j])
			{
				if(i%2==0)
				  p=i+1;
				else p=i-1;
				if(j%2==0)
				  q=j+1;
				else q=j-1;
				if(w[a[p]-1]*w[a[q]-1]>max)
				  max=w[a[p]-1]*w[a[q]-1];
				sum=sum+w[a[p]-1]*w[a[q]-1];
				sum=sum%10007;
			}
		}
	}
	sum=sum*2;
	sum=sum%10007;
	fout<<max<<" "<<sum<<endl;
	fin.close();
	fout.close();
	return 0; 
}
