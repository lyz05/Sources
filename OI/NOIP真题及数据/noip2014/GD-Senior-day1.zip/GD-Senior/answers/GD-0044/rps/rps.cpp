#include<fstream>
using namespace std;
int main()
{
	ifstream fin;
	ofstream fout;
	fin.open("rps.in");
	fout.open("rps.out");
	int n,na,nb,a=0,b=0,i;
	int x[5][5]={{0,-1,1,1,-1},{1,0,-1,1,-1},{-1,1,0,-1,1},{-1,-1,1,0,1},{1,1,-1,-1,0}};
	fin>>n>>na>>nb;
	int p[n],q[n];
	for(i=0;i<=n-1;i++)
	{
		if(i<=na-1)
		  fin>>p[i];
		if(i>=na)
		  p[i]=p[i%na];
	}
	for(i=0;i<=n-1;i++)
	{
		if(i<=nb-1)
		  fin>>q[i];
		if(i>=nb)
		  q[i]=q[i%nb];
	}
	for(i=0;i<=n-1;i++)
	{
		if(x[p[i]][q[i]]==1)
		  a++;
		if(x[p[i]][q[i]]==-1)
		  b++;
	}
	fout<<a<<" "<<b<<endl;
	fin.close();
	fout.close();
	return 0; 
}
