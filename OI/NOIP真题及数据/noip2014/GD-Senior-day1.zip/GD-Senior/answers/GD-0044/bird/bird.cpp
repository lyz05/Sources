#include<fstream>
using namespace std;
bool d[10005][1005];
int p[10005],x[10005],y[10005],h0[10005],l0[10005],T;
bool can;
int pire=0,kick=0;
bool g(int l,int k)
{
	int i;
	for(i=0;i<=k-1;i++)
	{
	   if(p[i]==l)
	   {
	     T=i;
		 return true;
       }
	}
	return false;
}
bool s(int l,int m)
{
	int k=0,i;
	for(i=1;i<=m;i++)
	   if(d[l][i]==true)
	     return true;
	return false;
}
void ne(int l,int m,int k)
{
	int i,j,r;
	for(i=1;i<=m;i++)
    {
    	if(d[l][i]==true)
    	{
    		if(i-y[l]>0)
    		  d[l+1][i-y[l]]=true;
    		r=x[l];
    		while(i+r<m)
    		{
    			d[l+1][i+r]=true;
				r=r+x[l];
    		}
    		d[l+1][m]=true;
    	}
    }
    if(g(l+1,k)==true)
    {
    	for(i=0;i<=l0[T];i++)
    	   d[l+1][i]=false;
        for(i=h0[T];i<=m;i++)
           d[l+1][i]=false;
        pire++;
    }
}
int main()
{
	ifstream fin;
	ofstream fout;
	fin.open("bird.in");
	fout.open("bird.out");
	int n,m,i,j,k;
	fin>>n>>m>>k;
	for(i=0;i<=n-1;i++)
	   fin>>x[i]>>y[i];
	for(i=0;i<=k-1;i++)
	   fin>>p[i]>>l0[i]>>h0[i];
	for(i=0;i<=n;i++)
	   for(j=0;j<=m;j++)
	      d[i][j]=false;
	for(i=0;i<=n;i++)
	{
		ne(i,m,k);
		if(s(i+1,m)==false)
		{
    	  for(i=m;i>=0;i--)
    	  {
    	     for(j=0;j<=n;j++)
    	        fout<<d[i][j]<<" ";
    	     fout<<endl;
    	  }
		  fout<<0<<endl<<pire<<endl;
    	  break;
	    }
	}
	fin.close();
	fout.close();
	return 0; 
}
