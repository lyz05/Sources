#include<iostream>
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
using namespace std;
int n;
int a[200010],b[200010][4];
int e[200010][3];
int ma,su;
int main()
{	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	cin>>n;
	for (int i=1;i<n;i++)
	{	scanf("%d%d",&e[i][1],&e[i][2]); 
	}
	for (int i=1;i<=n;i++)
	{	scanf("%d",&a[i]); 
	}
	int x1,y1;
	for (int i=1;i<n;i++)
	{	x1=e[i][1];
		y1=e[i][2];
		b[x1][1]+=a[y1];
		b[x1][1]=b[x1][1]%10007;
		if(a[y1]>b[x1][2]) {int o=b[x1][2];b[x1][2]=a[y1];b[x1][3]=o;}
		else if(a[y1]>b[x1][3]) b[x1][3]=a[y1];
		b[y1][1]+=a[x1];
		b[y1][1]=b[y1][1]%10007;
		if(a[x1]>b[y1][2]) {int o=b[y1][2];b[y1][2]=a[x1];b[y1][3]=o;}
		else if(a[x1]>b[y1][3]) b[y1][3]=a[x1];
	}
	int p1,p2,q;
	for (int i=1;i<n;i++)
	{	int x1=e[i][1];
		int y1=e[i][2];
		if (ma<a[x1]*b[y1][3]) {ma=a[x1]*b[y1][3];}
		if (ma<a[y1]*b[x1][3]) {ma=a[y1]*b[x1][3];}
		p1=(a[x1]*b[y1][1])%10007;
		p2=(a[x1]*a[x1])%10007;
		q=p1-p2;
		if (q<0) q=q+10007;
		su+=q%10007;
		su=su%10007;
		p1=(a[y1]*b[x1][1])%10007;
		p2=(a[y1]*a[y1])%10007;
		q=p1-p2;
		if (q<0) q=q+10007;
		su+=q%10007;
		su=su%10007;
	}
	cout<<ma<<" "<<su;
	return 0;
}


