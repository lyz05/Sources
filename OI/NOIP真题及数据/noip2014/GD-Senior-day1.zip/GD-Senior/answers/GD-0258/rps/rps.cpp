#include<iostream>
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
using namespace std;
int a[300],b[300];
int sum1,sum2;
int main()
{	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	int f[10][10]={{0,0,1,1,0},{1,0,0,1,0},{0,1,0,0,1},{0,0,1,0,1},{1,1,0,0,0}};
	int n=0,l1=0,l2=0;
	cin>>n>>l1>>l2;
	for (int i=1;i<=l1;i++)
	{	cin>>a[i];	
	}
	for (int i=1;i<=l2;i++)
	{	cin>>b[i];	
	}
	int p1=1;
	for (int i=l1+1;i<=n;i++)
	{	a[i]=a[p1];
		if (p1==l1) p1=1;
		else p1++;
	}
	p1=1;
	for (int i=l2+1;i<=n;i++)
	{	b[i]=b[p1];
		if (p1==l2) p1=1;
		else p1++;
	}
	for (int i=1;i<=n;i++)
	{	if (a[i]!=b[i]) {sum1=sum1+f[a[i]][b[i]];sum2=sum2+f[b[i]][a[i]];}
	}
	cout<<sum1<<" "<<sum2;
	return 0;
}


