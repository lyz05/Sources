#include<cstdio>

int f[5][5]={{ 0,-1, 1, 1,-1}, //f[a][b] a win==1  b win==-1
			 { 1, 0,-1, 1,-1},
			 {-1, 1, 0,-1, 1},
			 {-1,-1, 1, 0, 1},
			 { 1, 1,-1,-1, 0}},
	pa[205],pb[205],n,na,nb,ca=0,cb=0;


int main() {
	freopen("rps.in","r",stdin); freopen("rps.out","w",stdout);
	int i,x;
	scanf("%d%d%d",&n,&na,&nb);
	for(i=0;i<na;i++) scanf("%d",pa+i);
	for(i=0;i<nb;i++) scanf("%d",pb+i);
	for(i=0;i<n;i++) {
		x=f[pa[i%na]][pb[i%nb]];
		switch(x) {
			case 1:ca++; break;
			case -1:cb++;
		}
	}
	printf("%d %d",ca,cb);
	fclose(stdin); fclose(stdout);
	return 0;
}
