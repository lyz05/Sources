#include<cstdio>
#include<vector>

std::vector<int> t[200005];
int w[200005],mx=0,s,n,M=10007;

inline void maxz(int &x,int y){ if(x<y)x=y; }
inline void maxz2(int &x,int &y,int z) { if(x<z)y=x,x=z; else if(y<z)y=z; }
inline long long sqr(long long x) { return x*x; }

void calc(int x){
	if(t[x].size()==1) return;
	long long a1=0,a2=0;
	int b1=0,b2=0,i;
	for(i=0;i<t[x].size();i++) {
		a1+=w[t[x][i]];
		a2+=sqr(w[t[x][i]]);
		maxz2(b1,b2,w[t[x][i]]);
	}
	s+=(sqr(a1)-a2)%M;
	maxz(mx,b1*b2);
}

int main() {
	freopen("link.in","r",stdin); freopen("link.out","w",stdout);
	int i,u,v;
	scanf("%d",&n);
	for(i=1;i<n;i++){
		scanf("%d%d",&u,&v);
		t[u].push_back(v);
		t[v].push_back(u);
	}
	for(i=1;i<=n;i++) scanf("%d",w+i);
	for(i=1;i<=n;i++) calc(i);
	printf("%d %d",mx,s%M);	
	fclose(stdin); fclose(stdout);
	return 0;
}
