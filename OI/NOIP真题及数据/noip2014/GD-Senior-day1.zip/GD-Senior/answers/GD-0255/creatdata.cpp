#include<cstdio>
#include<cstdlib>
#include<ctime>

FILE* f;
bool cv[10000];

int random(int x){ return (rand()*(RAND_MAX+1)+rand())%x; };

int main() {
	f=fopen("bird.in","w");
	srand(time(0));
	int i,n,m,k,p;
	n=1000; m=100; k=100;
	fprintf(f,"%d %d %d\n",n,m,k);
	for(i=0;i<n;i++) fprintf(f,"%d %d\n",1,1);
	for(i=0;i<k;i++){
		while(cv[p=random(n)]);
		cv[p]=true;
		fprintf(f,"%d %d %d\n",p,random(m>>1),random(m>>1)+m/2);
	}
	fclose(f);
	return 0;
}
