#include<cstdio>
#include<cstring>

const int N=10002;
int f[N][1002],n,m,k,x[N],y[N],l[N],h[N];

inline void minz(int &x,int y) { if(x>y) x=y; }

int main() {
	freopen("bird.in","r",stdin); freopen("bird.out","w",stdout);
	int i,j,p,lp,hp,na;
	bool fl;              
	scanf("%d%d%d",&n,&m,&k);
	for(i=0;i<n;i++) scanf("%d%d",x+i,y+i);
	for(i=0;i<k;i++) scanf("%d%d%d",&p,&lp,&hp),l[p]=lp,h[p]=hp;
	for(i=0;i<=n;i++) if(!h[i]) h[i]=m+1;
	memset(f,0x7f,sizeof(f)); na=**f;
	for(i=1;i<=m;i++) f[0][i]=0;
	p=0;
	for(i=0;i<n;i++){
		fl=true;
		for(j=l[i]+1;j<h[i];j++) {
			if (f[i][j]==na) continue;
			if( j-y[i]>l[i+1]) minz(f[i+1][j-y[i]],f[i][j]);
			for(hp=1;j+hp*x[i]<h[i+1];hp++) minz(f[i+1][j+hp*x[i]],f[i][j]+hp);
			if(j+hp*x[i]>=m) minz(f[i+1][m],f[i][j]+hp);
			fl=false;
		}
		if(fl) break;
		if(h[i]<=m) p++;
	}
	if(fl) printf("0\n%d",p);
	else {
		hp=na;
		for(i=1;i<=m;i++) minz(hp,f[n][i]);
		printf("1\n%d",hp);
	}
	fclose(stdin); fclose(stdout);
	return 0;
}
