#include <fstream>
using namespace std;
ifstream fin("bird.in");
ofstream fout("bird.out");

int up[10005],down[10005];
int n,m,k,ans=10000007;
int f[1005][1005];

void init();
void work();
int main()
{
   init();
   work();
   fout<<1<<endl<<ans<<endl;
   return 0;
}

void init()
{
   fin>>n>>m>>k;
   for (int i=1;i<=n;i++) fin>>up[i]>>down[i];	
}

void work()
{
   for (int i=1;i<=n;i++)
   
   	 for (int j=1;j<=m;j++)
   	 {
   	 	int minn=10000007;
   	 	int now=j-up[i];
   	 	int count=0;
   	 	for (;now>0;now-=up[i]) 
   	 	{
   	 	   count++;	
		   minn=min(minn,f[i-1][now]+count);
		 
	    }
	    if (j+down[i]<=m) minn=min(minn,f[i-1][j+down[i]]);
	    f[i][j]=minn; 
		if (j==m) f[i][j]=min(f[i][j],f[i-1][m]+1); 
     }
   
   for (int i=1;i<=m;i++) ans=min(ans,f[n][i]);
}
