#include <fstream>
using namespace std;
ifstream fin("link.in");
ofstream fout("link.out");

int a[2002][2002];
bool f[2002][2002];
int v[2002];
int maxx,n,ans;

void init();
void work();
int main()
{	
   init();
   work();
   fout<<maxx<<" "<<ans<<endl;
   return 0;
}

void init()
{
   fin>>n;
   for (int i=1;i<n;i++)
   {
   	  int a1,a2;
   	  fin>>a1>>a2;
	  a[a1][0]++;
	  a[a2][0]++;
	  a[a1][a[a1][0]]=a2;
	  a[a2][a[a2][0]]=a1;
	  f[a1][a2]=f[a2][a1]=1;
   }	
   
   for (int i=1;i<=n;i++) {
   	 fin>>v[i];	
   	 f[i][i]=1;
   }
}

void work()
{ 
   for (int i=1;i<=n;i++)  {
   	
   	  for (int j=1;j<=a[i][0];j++)	{
   	  	
   	    int l1=a[i][j];
		for (int k=1;k<=a[l1][0];k++) {
			
		  int l2=a[l1][k];
		  if (f[i][l2]==0) {
		  	maxx=max(maxx,v[i]*v[l2]); 
		  	ans=(ans+v[i]*v[l2])%10007;
		  }		  	
		}
	  }	
   }		
}


