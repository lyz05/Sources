#include <fstream>
using namespace std;
ifstream fin("rps.in");
ofstream fout("rps.out");

void init();
void work();

int a[202],b[202];
int n,na,nb,ansa,ansb;

int main()
{	 
   init();
   work();
   fout<<ansa<<" "<<ansb<<endl;
   return 0;
}

void init()
{
   fin>>n>>na>>nb;
   for (int i=1;i<=na;i++) fin>>a[i];
   for (int i=1;i<=nb;i++) fin>>b[i];
}

void work()
{
   int sa=1,sb=1;	
   for (int i=1;i<=n;i++)
     {  
	   if (a[sa]!=b[sb]) {
	   	  
   	   int k1=a[sa],k2=b[sb];
   	   
   	   if (k1==0){
	  	 if (k2==2 || k2==3) ansa++;
	  	 if (k2==1 || k2==4) ansb++;
	   }	 
	   
	    
	   if (k1==1){ 	
	  	 if (k2==3 || k2==0) ansa++;
	     if (k2==2 || k2==4) ansb++;
	   } 
	   
	   
	   if (k1==2){  	
	   	 if (k2==4 || k2==1) ansa++;
	   	 if (k2==0 || k2==3) ansb++;
	   }
      
	   
	   if (k1==3){  	
	   	 if (k2==4 || k2==2) ansa++;
	   	 if (k2==1 || k2==0) ansb++;	 
	   }
	   
	   if (k1==4){  	 
		 if (k2==0 || k2==1) ansa++;
		 if (k2==2 || k2==3) ansb++;	  	
       }
   	  
     }
   	   sa++;
   	   sb++;
   	   if (sa>na) sa=1;
   	   if (sb>nb) sb=1;
     }	
}
