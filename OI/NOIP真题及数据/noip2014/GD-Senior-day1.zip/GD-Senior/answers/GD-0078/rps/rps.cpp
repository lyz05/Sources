#include <fstream>
#include <cstdlib>
#include <cstring>
using namespace std;
ifstream cin("rps.in");
ofstream cout("rps.out");
int n,na,nb,i,j;
int lista[300],listb[300];
int aa=0,bb=0;
bool is[5][5];
int main()
{
	cin>>n>>na>>nb;
	memset(is,false,sizeof(is));
	is[0][2]=is[0][3]=is[1][0]=is[1][3]=is[2][1]=is[2][4]=is[3][2]=is[3][4]=is[4][0]=is[4][1]=true;
	for(i=0;i<na;i++)
	{
		cin>>lista[i];
	}
	for(i=0;i<nb;i++)
	{
		cin>>listb[i];
	}
	for(i=0;i<n;i++)
	{
		if(lista[i%na]==listb[i%nb])
		{
			continue;
		}
		if(is[lista[i%na]][listb[i%nb]])
		{
			aa++;
		}
		else
		{
			bb++;
		}
	}
	cout<<aa<<" "<<bb<<endl;
	return 0;
}
