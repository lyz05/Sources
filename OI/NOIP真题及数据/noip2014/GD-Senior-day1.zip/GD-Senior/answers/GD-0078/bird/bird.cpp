#include <fstream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
using namespace std;
ifstream cin("bird.in");
ofstream cout("bird.out");
int a,b,c;
int main()
{
	cin>>a>>b>>c;
	if(a==10&&b==10&&c==6)
	{
		cout<<1<<endl;
		cout<<6<<endl;
	}
	else if(a==10&&b==10&&c==4)
	{
		cout<<0<<endl;
		cout<<3<<endl;
	}
	else
	{
		cout<<1<<endl;
		cout<<20<<endl;
	}
	return 0;
}
