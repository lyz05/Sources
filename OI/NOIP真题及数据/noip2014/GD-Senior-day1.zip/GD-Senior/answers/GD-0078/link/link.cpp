#include <fstream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#define MAXN 10007
using namespace std;
typedef struct{
	int w;
	int num;
	int fa;
	int max;
	int max2;
	long long sum;
	long long minus;
	int *next;
}note;
note tt[200005];
ifstream cin("link.in");
ofstream cout("link.out");
int n,m,i,j;
long long ans,max0;
int root;
int *u=NULL,*v=NULL;
void build(int d)
{
//	cout<<"building "<<d+1<<endl;
	int i,j=0;
	while(tt[d].num==2)
	{
//		cout<<"queue"<<endl;
		if(tt[d].next[1]==tt[d].fa)
		{
			i=tt[d].next[1];
			tt[d].next[1]=tt[d].next[0];
			tt[d].next[0]=i;
		}
		tt[tt[d].next[1]].fa=d;
		tt[d].sum+=tt[tt[d].next[1]].w;
		tt[d].minus+=tt[tt[d].next[1]].w*tt[tt[d].next[1]].w;
		tt[d].max=tt[tt[d].next[1]].w;
		tt[d].max2=0;
		d=tt[d].next[1];
	}
	if(tt[d].num<=1)
	{
		tt[d].sum=0;
		tt[d].minus=0;
		return ;
	}
	for(i=0;i<tt[d].num;i++)
	{
		if(tt[d].next[i]==tt[d].fa)
		{
			j=i;
			continue;
		}
		if(tt[tt[d].next[i]].w>tt[d].max)
		{
			tt[d].max2=tt[d].max;
			tt[d].max=tt[tt[d].next[i]].w;
		}
		else if(tt[tt[d].next[i]].w>tt[d].max2)
		{
			tt[d].max2=tt[tt[d].next[i]].w;
		}
		tt[tt[d].next[i]].fa=d;
		tt[d].sum+=tt[tt[d].next[i]].w;
		tt[d].minus+=tt[tt[d].next[i]].w*tt[tt[d].next[i]].w;
		build(tt[d].next[i]);
	}
	i=tt[d].next[j];
	tt[d].next[j]=tt[d].next[0];
	tt[d].next[0]=i;
}
int main()
{
	cin>>n;
	u=(int*)calloc(n+2,sizeof(int));
	v=(int*)calloc(n+2,sizeof(int));
	for(i=0;i<n;i++)
	{
		tt[i].num=0;
		tt[i].sum=0;
		tt[i].minus=0;
		tt[i].max=0;
		tt[i].max2=10001;
		tt[i].next=NULL;
	}
	for(i=0;i<n-1;i++)
	{
		cin>>u[i]>>v[i];
		u[i]--;
		v[i]--;
		tt[u[i]].num++;
		tt[v[i]].num++;
	}
	max0=0;
	for(i=0;i<n;i++)
	{
		if(tt[i].num>max0)
		{
			max0=tt[i].num;
			j=i;
		}
		tt[i].next=(int*)calloc(tt[i].num+2,sizeof(int));
		tt[i].num=0;
	}
	tt[j].next[0]=j;
	tt[j].num=1;
	for(i=0;i<n-1;i++)
	{
		tt[u[i]].next[tt[u[i]].num++]=v[i];
		tt[v[i]].next[tt[v[i]].num++]=u[i];
	}
	for(i=0;i<n;i++)
	{
		cin>>tt[i].w;
	}
	tt[j].fa=j;
	root=j;
	build(root);
	max0=ans=0;
/*	for(i=0;i<n;i++)
	{
		cout<<"tree "<<i+1<<":"<<tt[i].max<<" "<<tt[i].max2;
		cout<<endl;
	}*/
	for(i=0;i<n;i++)
	{
		if(tt[i].max*tt[i].max2>max0)
		{
			max0=tt[i].max*tt[i].max2;
		}
		ans+=(tt[i].sum*tt[i].sum-tt[i].minus)%MAXN;
		if(tt[i].fa!=i)
		{
			ans+=(2*tt[i].sum*tt[tt[i].fa].w)%MAXN;
			if(tt[tt[i].fa].w*tt[i].max>max0)
			{
				max0=tt[tt[i].fa].w*tt[i].max;
			}
		}
	}
	cout<<max0<<" "<<ans%MAXN<<endl;
	free(u);
	free(v);
	for(i=0;i<n;i++)
	{
		free(tt[i].next);
	}
	return 0;
}
/*
5
1 2
2 3
3 4
4 5
1 5 2 3 10

*/
