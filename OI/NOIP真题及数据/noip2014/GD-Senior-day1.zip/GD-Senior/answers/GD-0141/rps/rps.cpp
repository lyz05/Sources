#include<cstdio>

const int maxn=300;
int N,NA,NB,a[maxn],b[maxn],ca,cb;
int Win(int a,int b) {
	if(a==0)
		return (b==2)||(b==3);
	else if(a==1)
		return (b==0)||(b==3);
	else if(a==2)
		return (b==1)||(b==4);
	else if(a==3)
		return (b==2)||(b==4);
	else return (b==0)||(b==1);
}
void readin() {
	scanf("%d%d%d",&N,&NA,&NB);
	int i;
	for(i=0;i<NA;i++)
		scanf("%d",a+i);
	for(i=0;i<NB;i++)
		scanf("%d",b+i);
}
void work() {
	ca=cb=0;
	for(int i=0;i<N;i++) {
		ca+=Win(a[i%NA],b[i%NB]);
		cb+=Win(b[i%NA],a[i%NB]);
	}
}
void print() {
	printf("%d %d\n",ca,cb);
}
int main() {
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	
	readin();
	work();
	print();
	
	return 0;
}

