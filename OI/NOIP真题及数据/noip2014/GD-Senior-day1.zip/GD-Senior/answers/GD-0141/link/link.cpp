#include<cstdio>
#include<vector>
using namespace std;

const int maxn=200100,modn=10007;
vector<int> G[maxn];
int n,fa[maxn],W[maxn],bj[maxn],Sum[maxn],Max[maxn],Wr[maxn],que[maxn],a1,a2;
inline void upd(int &a,int b)
{ if(b>a) a=b; }
inline int Po(int a)
{ return a<0?(a+modn):a; }
void readin() {
	scanf("%d",&n);
	int i;
	for(i=1;i<n;i++) {
		int a,b;
		scanf("%d%d",&a,&b);
		G[a].push_back(b);
		G[b].push_back(a);
	}
	for(i=1;i<=n;i++)
		scanf("%d",W+i);
}
void bfs() {
	int u,v,i,qt,qh;
	qt=0;qh=1;que[0]=1;
	while(qt<qh) {
		u=que[qt++];
		Sum[u]=Max[u]=0;
		bj[u]=1;
		for(i=0;i<G[u].size();i++) {
			v=G[u][i];
			if(!bj[v]) {
				fa[v]=u;
				Sum[u]=(Sum[u]+W[v])%modn;
				if(W[v]>Max[u]) {
					Max[u]=W[v];
					Wr[u]=v;
				}
				que[qh++]=v;
			}
		}
	}
}
int GetSec(int u) {
	int ret=0;
	for(int i=0;i<G[u].size();i++) {
		int v=G[u][i];
		if(fa[v]==u && v!=Wr[u] && W[v]>ret)
			ret=W[v];
	}
	return ret;
}
void work() {
	int i;
	for(i=1;i<=n;i++) bj[i]=0;
	fa[1]=0;bfs();
	a1=a2=0;
	for(i=1;i<=n;i++) {
		if(fa[i]!=0) {
			a1=(a1+W[fa[i]]*Sum[i]*2)%modn;
			upd(a2,W[fa[i]]*Max[i]);
			if(i==Wr[fa[i]])
				upd(a2,W[i]*GetSec(fa[i]));
			else
				upd(a2,W[i]*Max[fa[i]]);
			a1=(a1+Po(Sum[fa[i]]-W[i])*W[i])%modn;
		}
	}
}
void print() {
	printf("%d %d\n",a2,a1);
}
int main() {
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	
	readin();
	work();
	print();
	
	return 0;
}

