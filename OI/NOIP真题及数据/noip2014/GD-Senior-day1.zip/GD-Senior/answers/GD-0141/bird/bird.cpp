#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;

const int maxn=10010,maxm=1010,INF=0x3fffffff;
int dp[maxn][maxm],n,m,k,P[maxn],X[maxn],Y[maxn],hp[maxn],ab;

void upd(int &a,int b)
{ if(b<a) a=b; }
void readin() {
	memset(dp,0,sizeof(dp));
	scanf("%d%d%d",&n,&m,&k);
	int i,j,p,L,H;
	for(i=0;i<n;i++) {
		scanf("%d%d",X+i,Y+i);
	}
	for(i=0;i<k;i++) {
		scanf("%d%d%d",P+i,&L,&H);
		p=P[i];
		for(j=1;j<=L;j++)
			dp[p][j]=INF;
		for(j=H;j<=m;j++)
			dp[p][j]=INF;
	}
}
void work() {
	int i,j,k,ok;
	ab=0;
	for(i=1;i<=n;i++) {
		ok=0;
		for(j=1;j<=m;j++) {
			if(j==m) {
				hp[m]=INF;
				for(k=m-X[i-1];k<=m;k++)
					upd(hp[m],min(hp[k],dp[i-1][k])+1);
			} else if(j>X[i-1])
				hp[j]=min(hp[j-X[i-1]],dp[i-1][j-X[i-1]])+1;
			else
				hp[j]=INF;
			if(dp[i][j]<INF) {
				dp[i][j]=hp[j];
				if(j+Y[i-1]<=m)
					upd(dp[i][j],dp[i-1][j+Y[i-1]]);
				if(dp[i][j]<INF) ok=1;
			}
		}
		if(!ok) {
			ab=i;
			break;
		}
	}
}
void print() {
	int ans,i;
	if(ab==0) {
		ans=INF;
		for(i=1;i<=m;i++)
			ans=min(ans,dp[n][i]);
		printf("1\n%d\n",ans);
	} else {
		ans=0;
		for(i=0;i<k;i++)
			if(P[i]<ab)
				ans++;
		printf("0\n%d\n",ans);
	}
}
int main() {
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	
	readin();
	work();
	print();
	
	return 0;
}

