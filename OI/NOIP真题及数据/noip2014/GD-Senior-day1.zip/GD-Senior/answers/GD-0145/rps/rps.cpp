#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <cmath>

using namespace std;

const int Maxn=500;
const int T[5][5]={{0,0,1,1,0},
                   {1,0,0,1,0},
                   {0,1,0,0,1},
                   {0,0,1,0,1},
                   {1,1,0,0,0}};
int n,na,nb,x,y,ansx,ansy,a[Maxn],b[Maxn];

int main()
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	scanf("%d%d%d",&n,&na,&nb);
	for (int i=1; i<=na; i++) scanf("%d",&a[i]);
	for (int i=1; i<=nb; i++) scanf("%d",&b[i]);
	x=0; y=0;
	for (int i=1; i<=n; i++)
	{
	    x++; 
	    if (x>na) x=1;
	    y++;
	    if (y>nb) y=1;
	    ansx+=T[a[x]][b[y]];
	    ansy+=T[b[y]][a[x]];
	}
	printf("%d %d\n",ansx,ansy);
    return 0;
}
