#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <cmath>

using namespace std;

const int Maxn=10100,Maxm=1100;
int n,m,k,p,l,h,ans,Left[Maxn],x[Maxn],y[Maxn],Right[Maxn],f[Maxn][Maxm];
bool boo[Maxn];

bool Check(int x)
{
    for (int i=Left[x]; i<=Right[x]; i++) if (f[x][i]<200000000) return true;
    return false;
}

int main()
{
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for (int i=0; i<n; i++) scanf("%d%d",&x[i],&y[i]);
	for (int i=0; i<=n; i++) 
	{
	    Left[i]=1; Right[i]=m;
	}
	for (int i=1; i<=k; i++) 
	{
	    scanf("%d%d%d",&p,&l,&h);
	    Left[p]=l+1; Right[p]=h-1;
	    boo[p]=true;
	}
	for (int i=1; i<=n; i++)
	for (int j=0; j<=m; j++) f[i][j]=200000000;
	for (int i=0; i<n; i++)
	for (int j=Left[i]; j<=Right[i]; j++)
	{
		int Temp=(m-j)/x[i]+1;
	    for (int s=1; s<=Temp; s++)
	    {
	        int u=j+s*x[i];
	        if (u>m) u=m;
	        f[i+1][u]=min(f[i+1][u],f[i][j]+s);
	    }
	    Temp=j-y[i];
	    if (Temp<0) Temp=0;
	    f[i+1][Temp]=min(f[i+1][Temp],f[i][j]);
	}
	ans=200000000;
	for (int i=Left[n]; i<=Right[n]; i++) ans=min(ans,f[n][i]);
	if (ans<200000000) 
	{
	    printf("%d\n",1);
	    printf("%d\n",ans);
	    return 0;
	}
	printf("%d\n",0);
	for (int i=n; i>=0; i--) if (Check(i))
	{
		ans=0;
		for (int j=0; j<=i; j++) if (boo[j]) ans++;
		printf("%d\n",ans);
		return 0;
	}
	return 0;
}
