#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <cmath>

using namespace std;

const int Maxn=300000,mo=10007;
int n,m,X,head,tail,MAX,ans,s[Maxn],p[Maxn],g[Maxn],Father[Maxn],num[Maxn],a[Maxn],f[Maxn],b[Maxn],bb[Maxn];
bool boo[Maxn];
struct Tpoint
{
    int x,y;
}A[Maxn*2];

bool cmp(Tpoint a,Tpoint b)
{
    return a.x<b.x;
}

void BFS()
{
    head=1; tail=1;
    p[1]=1;
    memset(boo,0,sizeof(boo));
    memset(Father,0,sizeof(Father));
    boo[1]=true;
    for ( ; head<=tail; head++)
    {
        for (int i=num[p[head]]; i<=m; i++) if (A[i].x==p[head])
        {
            if (!boo[A[i].y])
            {
            	tail++;
            	p[tail]=A[i].y;
            	Father[p[tail]]=p[head];
            	s[p[tail]]=s[p[head]]+1;
            	boo[p[tail]]=true;
            }
        } else break;
    }
}

int main()
{
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	scanf("%d",&n);
	m=n-1;
	for (int i=1; i<=m; i++) scanf("%d%d",&A[i].x,&A[i].y);
	for (int i=1; i<=n; i++) scanf("%d",&a[i]);
	for (int i=1; i<=m; i++)
	{
	    A[i+m].x=A[i].y;
	    A[i+m].y=A[i].x;
	}
	m=m*2;
	sort(A+1,A+m+1,cmp);
	for (int i=1; i<=m; i++) if (A[i].x!=A[i-1].x) num[A[i].x]=i;
	BFS();
	
	for (int i=n; i>0; i--) f[Father[p[i]]]+=a[p[i]];
	for (int i=2; i<=n; i++) 
	{
		X=(f[Father[i]]-a[i])%mo;
		X=(X*a[i])%mo;
		ans=(ans+X)%mo;
	}
	
	memset(f,0,sizeof(f));
	for (int i=n; i>0; i--)
	{
		X=Father[Father[p[i]]];
		g[X]=max(g[X],a[i]);
		f[X]=(f[X]+a[p[i]])%mo;
	}
	for (int i=1; i<=n; i++)
	{
		X=(f[i]*a[i])%mo;
		X=(X*2)%mo;
		ans=(ans+X)%mo;
	}
	
	for (int i=1; i<=n; i++)
	{
		if (a[i]>=b[s[i]])
		{
			bb[s[i]]=b[s[i]];
		    b[s[i]]=a[i];
		} else if (a[i]>=bb[s[i]])
		{
		    b[s[i]]=a[i];
		}
	}
	for (int i=1; i<=n; i++) 
	{
	    MAX=max(MAX,b[i]*bb[i]);
	    MAX=max(MAX,a[i]*g[i]);
	}
	printf("%d %d\n",MAX,ans);
	return 0;
}
