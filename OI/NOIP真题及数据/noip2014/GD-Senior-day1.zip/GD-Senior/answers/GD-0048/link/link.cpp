#include<fstream>
using namespace std;
	int n,p=1,key=0,sum=0;
	int biana[200000],bianb[200000];
	int pointsr[200001];
	int pointsto[200002];
	int pointsed[399999];
bool ifdistwo(int x,int y)
{
	for (int m=pointsto[x];m<pointsto[x+1];m++)
	    if (pointsed[m]==y)    return false;
	for (int m=pointsto[x];m<pointsto[x+1];m++)
	{
		for (int n=pointsto[pointsed[m]];n<pointsto[pointsed[m]+1];n++)
		    if (pointsed[n]==y&&x!=y)    return true;
	}
	return false;
}
int main()
{
	ifstream fin;
	ofstream fout;
	fin.open("link.in");
	fout.open("link.out");
	fin>>n;
	for (int a=1;a<n;a++)
	{
		fin>>biana[a]>>bianb[a];
	}
	for (int a=1;a<=n;a++)    fin>>pointsr[a];
	for (int a=1;a<=n;a++)
	{
		pointsto[a]=p;
		for (int b=1;b<n;b++)
        {
			if (biana[b]==a)
				{pointsed[p]=bianb[b];    p++;}
			if (bianb[b]==a)
				{pointsed[p]=biana[b];    p++;}
		}
		pointsto[a+1]=p;
	}
	for (int a=1;a<=n;a++)
	    for (int b=1;b<=n;b++)
	        if (ifdistwo(a,b)==true)    
			    {sum+=pointsr[a]*pointsr[b];    sum=sum%10007;
			    if (pointsr[a]*pointsr[b]>key)    key=pointsr[a]*pointsr[b];}
    fout<<key<<" "<<sum;
    fin.close();
	fout.close();
    return 0;
}
