#include<fstream>
using namespace std;
bool ifxwin(int x,int y)
{
	if (x==0&&(y==2||y==3))    return true;
	if (x==1&&(y==0||y==3))    return true;
	if (x==2&&(y==1||y==4))    return true;
	if (x==3&&(y==2||y==4))    return true;
	if (x==4&&(y==0||y==1))    return true;
	return false;
}
int main()
{
	ifstream fin;
	ofstream fout;
	fin.open("rps.in");
	fout.open("rps.out");
	int n,na,nb;
	fin>>n>>na>>nb;
	int pointsa=0,pointsb=0;
	int aguil[201];
	int bguil[201];
	for (int a=1;a<=na;a++)
	{
		fin>>aguil[a];
	}
	for (int a=1;a<=nb;a++)
	{
		fin>>bguil[a];
	}
	int p=1,q=1;
	for (int a=1;a<=n;a++)
	{
		if (ifxwin(aguil[p],bguil[q])==true)    pointsa++;
		if (ifxwin(bguil[q],aguil[p])==true)    pointsb++;
		p+=1;    q+=1;
		if (p>na)    p-=na;
		if (q>nb)    q-=nb;
	}
	fout<<pointsa<<" "<<pointsb;
	fin.close();
	fout.close();
	return 0;
}
