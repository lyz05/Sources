#include<fstream>
using namespace std;
int main()
{
	ifstream fin;
	ofstream fout; 
	fin.open("bird.in");
	fout.open("bird.out");
	int n,m,k,key=0,ans=0,where;
	fin>>n>>m>>k;
	int drop[n],up[n],benifit[n];
	for (int a=0;a<n;a++)
	{
		fin>>up[a]>>drop[a];
		benifit[a]=up[a]+drop[a];
	}
	int nowheightt[n+1];
	nowheightt[0]=m;
	for (int b=1;b<=n;b++)
		    {nowheightt[b]=nowheightt[b-1]-drop[b-1];    }
	for (;;)
	{
		key=0;
		for (int b=0;b<n;b++)
		    if (nowheightt[b]+benifit[b]>m)    benifit[b]=m-nowheightt[b]+drop[b];
		for (int b=0;b<n;b++)
		    if (benifit[b]>key&&nowheightt[b]>0)    {key=benifit[b];    where=b;}
		for (int b=where+1;b<=n;b++)    nowheightt[b]+=benifit[where];    
		ans++;
		if (nowheightt[n]>0)    break;
		benifit[where]=up[where];
	}
	fout<<1<<endl;
	fout<<ans<<endl;
	fin.close();
	fout.close();
	return 0;
}
