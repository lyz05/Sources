#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include <cstdlib>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <bitset>
#include <ctime>
#include <map>
#include <queue>
#include <set>
using namespace std;

const int maxn=10000+15;
const int maxh=1000+15;
int n,m,k,x[maxn],y[maxn],ll[maxn],rr[maxn];
int p,l,h;
int f[maxn][maxh];
int g[maxn][maxh];
int main()
{
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
    scanf("%d%d%d",&n,&m,&k);
    for (int i=0;i<n;i++) scanf("%d%d",&x[i],&y[i]);
    for (int i=0;i<=n;i++) ll[i]=1,rr[i]=m;
    for (int i=1;i<=k;i++) 
    {
    	scanf("%d%d%d",&p,&l,&h);
    	ll[p]=l+1;
    	rr[p]=h-1;
    }
    memset(f,-1,sizeof(f));
    memset(g,-1,sizeof(g));
    int s=0;
    for (int i=ll[0];i<=rr[0];i++) f[0][i]=0;
    for (int i=0,j;i<n;i++)
     {
     	if (rr[i]!=m) s++;
        for (j=ll[i];j<=rr[i];j++)
         if (f[i][j]!=-1) break;
        if (j>rr[i])
        {
        	printf("0\n");
        	printf("%d\n",s-1);
        	return 0;
        }
        for (int j=ll[i];j<=rr[i];j++)
         if (f[i][j]!=-1)
         {
          if (f[i+1][min(m,j+x[i])]==-1 || f[i+1][min(m,j+x[i])]>f[i][j]+1)
          f[i+1][min(m,j+x[i])]=f[i][j]+1;
		  if (j>y[i])
           g[i+1][j-y[i]]=f[i][j];
         }
        for (int j=1;j<=rr[i+1];j++) 
         if (f[i+1][j]!=-1)
          if (min(m,j+x[i])<=rr[i+1])
           if (f[i+1][min(m,j+x[i])]==-1 || f[i+1][min(m,j+x[i])]>f[i+1][j]+1)
            f[i+1][min(m,j+x[i])]=f[i+1][j]+1;
        for (int j=ll[i+1];j<=rr[i+1];j++)
         if (g[i+1][j]!=-1)
          if (f[i+1][j]==-1 || f[i+1][j]>g[i+1][j])
           f[i+1][j]=g[i+1][j];
     }
    printf("1\n");
    int minn=-1;
    for (int i=ll[n];i<=rr[n];i++)
     if (f[n][i]!=-1)
      if (minn==-1 || minn>f[n][i])
       minn=f[n][i];
    printf("%d\n",minn);
	return 0;
}

