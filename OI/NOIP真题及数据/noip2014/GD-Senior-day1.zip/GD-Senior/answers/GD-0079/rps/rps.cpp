#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include <cstdlib>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <bitset>
#include <ctime>
#include <map>
#include <queue>
#include <set>
using namespace std;

const int mat[5][5]={{0,0,1,1,0},{1,0,0,1,0},{0,1,0,0,1},{0,0,1,0,1},{1,1,0,0,0}};
int s1,s2,n,na,nb,e1,e2,a[205],b[205];
int main()
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
    scanf("%d%d%d",&n,&na,&nb);
    for (int i=0;i<na;i++) scanf("%d",&a[i]);
    for (int i=0;i<nb;i++) scanf("%d",&b[i]);
    int e1=0,e2=0;
    for (int i=0;i<n;i++)
    {
    	s1+=mat[a[e1]][b[e2]];
    	s2+=mat[b[e2]][a[e1]];
    	e1++;
    	e1%=na;
    	e2++;
    	e2%=nb;
    }
    printf("%d %d\n",s1,s2);
	return 0;
}

