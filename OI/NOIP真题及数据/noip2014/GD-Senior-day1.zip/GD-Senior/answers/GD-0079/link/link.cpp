#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include <cstdlib>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <bitset>
#include <ctime>
#include <map>
#include <queue>
#include <set>
using namespace std;

const int maxn=200000+15;
const int modd=10007;
int n,x,y,w[maxn];
int fre,Head[maxn],Node[2*maxn],Next[2*maxn];
int sums[maxn],maxs[maxn],sems[maxn];
int ans1,ans2;
int inser(int x,int y)
{
	Node[++fre]=y;
	Next[fre]=Head[x];
	Head[x]=fre;
	return 0;
}
int main()
{
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
    scanf("%d",&n);
    if (n==2)
    {
    	printf("0 0\n");
    	return 0;
    }
    for (int i=1;i<n;i++)
    {
    	scanf("%d%d",&x,&y);
    	inser(x,y);
    	inser(y,x);
    }
    for (int i=1;i<=n;i++) scanf("%d",&w[i]);
    memset(maxs,0,sizeof(maxs));
    memset(sems,0,sizeof(sems));
    for (int i=1;i<=n;i++)
    {
    	for (int u=Head[i];u;u=Next[u])
    	 sums[i]+=w[Node[u]],
		 sums[i]%=modd;
    	for (int u=Head[i];u;u=Next[u])
    	 if (maxs[i]==0 || w[maxs[i]]<w[Node[u]])
    	 	maxs[i]=Node[u];
    	for (int u=Head[i];u;u=Next[u])
    	 if (Node[u]!=maxs[i])
    	  if (sems[i]==0 || w[sems[i]]<w[Node[u]])
    	   sems[i]=Node[u];
    	if (sems[i]!=0) ans1=max(ans1,w[maxs[i]]*w[sems[i]]);
    	for (int u=Head[i];u;u=Next[u])
    	 ans2+=w[Node[u]]*(sums[i]+modd-w[Node[u]])%modd,
    	 ans2%=modd;
    }
    printf("%d %d\n",ans1,ans2);
	return 0;
}

