#include<algorithm>
#include<cstdio>
#include<iostream>
using namespace std;
int r,n,ans,mod,l,x,y,ans1;
int fa[300001],a[300001],d[300001],g[300001],b[600001][2],c[300001],e[300001];
int max(int x,int y){
	if (x>y)return(x);return(y);
}
void bfs(){
	l=0;
	r=1;
	d[1]=1;
	while (l!=r){
		l++;
		for (x=g[d[l]];x!=0;x=b[x][1])
			if (fa[d[l]]!=b[x][0]){
				r++;
				d[r]=b[x][0];
				fa[d[r]]=d[l];
			}
	}
	for (int i=r;i>=2;i--){
		x=d[i];
		y=fa[d[i]];
		ans=(ans+c[y]*a[x]%mod+c[x]*a[y]%mod)%mod;
		ans1=max(max(ans1,e[x]*a[y]),e[y]*a[x]);
		c[y]=(c[y]+a[x])%mod;
		e[y]=max(e[y],a[x]);
	}	
}
int main(){
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n-1;i++){
		scanf("%d %d",&x,&y);
		b[i][0]=x;
		b[i][1]=g[y];
		g[y]=i;
		b[i+n][0]=y;
		b[i+n][1]=g[x];
		g[x]=i+n;
	}
	mod=10007;
	for (int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	bfs();
	ans=(ans*2)%mod;
	printf("%d %d",ans1,ans);
	return 0;
}
