#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int x,y,n,na,nb,ansa,ansb;
int a[500],b[500],f[10][10];
int main(){
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	scanf("%d %d %d",&n,&na,&nb);
	for (int i=1;i<=na;i++)
		scanf("%d",&a[i]);
	for (int i=1;i<=nb;i++)
		scanf("%d",&b[i]);
	f[0][2]=1;
	f[0][3]=1;
	f[1][0]=1;
	f[1][3]=1;
	f[2][1]=1;
	f[2][4]=1;
	f[3][2]=1;
	f[3][4]=1;
	f[4][0]=1;
	f[4][1]=1;
	for (int i=1;i<=n;i++){
		x=x%na+1;
		y=y%nb+1;
		ansa+=f[a[x]][b[y]];
		ansb+=f[b[y]][a[x]];
	}
	printf("%d %d",ansa,ansb);
	return 0;
}
