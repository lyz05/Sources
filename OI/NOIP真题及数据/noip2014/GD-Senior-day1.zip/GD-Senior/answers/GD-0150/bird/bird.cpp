#include<algorithm>
#include<cstdio>
#include<iostream>
using namespace std;
int n,m,k,ans,x,y,z,s;
bool p;
bool bz[20000];
int a[20000][2],b[20000][2],f[2][20000];
int main(){
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	scanf("%d %d %d",&n,&m,&k);
	for (int i=1;i<=n;i++){
		scanf("%d %d",&a[i-1][0],&a[i-1][1]);
		b[i][0]=1;
		b[i][1]=m;
	}
	for (int i=1;i<=k;i++){
		scanf("%d %d %d",&x,&y,&z);
		b[x][0]=y+1;
		b[x][1]=z-1;
		bz[x]=true;
	}
	for (int i=1;i<=m;i++)
		f[0][i]=1;
	x=0;
	y=1;
	b[0][0]=1;
	b[0][1]=m;
	for (int i=0;i<=n-1;i++){
		p=false;
		if (bz[i])ans++;
		for (int j=b[i][0];j<=b[i][1];j++)
			if (f[x][j]!=0){
				if ((j+a[i][0]<=b[i+1][1])||(b[i+1][1]==m)){
					z=j+a[i][0];
					s=1;
					while (z<b[i+1][0]){
						s++;
						z+=a[i][0];
					}
					if (z>m)z=m;
					while (z<=b[i+1][1]){
						if (z>m)z=m;
						if ((f[y][z]==0)||(f[y][z]>f[x][j]+s)){
							p=true;
							f[y][z]=f[x][j]+s;
						}
						if (z==m)break;
						z+=a[i][0];
						s++;
					}
				}
				if (j-a[i][1]>=b[i+1][0]){
					z=j-a[i][1];
					if (z<=b[i+1][1])
						if ((f[y][z]==0)||(f[y][z]>f[x][j])){
							p=true;
							f[y][z]=f[x][j];
						}	
				}
				f[x][j]=0;
			}
		if (p==false){
			printf("0\n");
			printf("%d",ans);
			break;
		}
		x=y;
		y=y xor 1;
	}
	if (p){
		ans=0;
		for (int i=b[n][0];i<=b[n][1];i++)
			if (f[x][i]!=0)
				if ((ans==0)||(ans>f[x][i]))
					ans=f[x][i];
		ans--;
		printf("1\n");
		printf("%d",ans);
	}
	return 0;
}
