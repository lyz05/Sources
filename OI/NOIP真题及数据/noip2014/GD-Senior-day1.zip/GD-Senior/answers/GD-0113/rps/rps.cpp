#include<cstdio>
#include<cstring>
#include<iostream>
#define fo(i,a,b) for(int i=a;i<=b;i++)
using namespace std;

const int fx[5][5] = {{0,-1,1,1,-1},{1,0,-1,1,-1},{-1,1,0,-1,1},{-1,-1,1,0,1},
{1,1,-1,-1,0}};
const int N = 2005;
int a[N] , b[N] , n , na , nb;

void Init()
{
	scanf("%d%d%d",&n,&na,&nb);
	fo(i,0,na-1) scanf("%d",&a[i]);
	fo(i,0,nb-1) scanf("%d",&b[i]);
}

void Work()
{
	int ans1 = 0 , ans2 = 0;
	fo(i,0,n-1)
	{
		int t1 = i%na , t2 = i%nb;
		if (fx[a[t1]][b[t2]] == 1) ans1++;else
		if (fx[a[t1]][b[t2]] == -1) ans2++;
	}
	printf("%d %d\n",ans1,ans2);
}

int main()
{
	freopen("rps.in","r",stdin); freopen("rps.out","w",stdout);

	Init();
	Work();

	return 0;
}
