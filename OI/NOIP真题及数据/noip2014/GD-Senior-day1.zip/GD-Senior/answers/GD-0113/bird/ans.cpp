#include<cstdio>
#include<cstring>
#include<algorithm>
#define fo(i,a,b) for(int i=a;i<=b;i++)
using namespace std;

const int maxlong = int(1e9);
const int N = 10005;
int l[N] , r[N] , n , m , K , sum[N] , up[N] , down[N];
int f[N][1005];

void Init()
{
	scanf("%d%d%d",&n,&m,&K);
	fo(i,0,n) l[i] = 0 , r[i] = m+1;
	fo(i,0,n-1) scanf("%d%d",&up[i],&down[i]);
	fo(i,1,K)
	{
		int p,up,down;
		scanf("%d%d%d",&p,&down,&up);
		l[p] = down; r[p] = up;
		sum[p]++;
	}
	fo(i,1,n) sum[i] += sum[i-1];
}

void Work()
{
	fo(i,1,n) fo(j,0,m) f[i][j] = maxlong;
	fo(i,0,n-1)
	{
		fo(j,l[i]+1,r[i]-1)
			fo(k,0,1000)
			{
				if (!k)
				{
					int t = j - down[i];
					t = max(t,0);
					f[i+1][t] = min(f[i+1][t] , f[i][j]);
				}
				else
				{
					int t = j + up[i]*k;
					t = min(t,m);
					f[i+1][t] = min(f[i+1][t] , f[i][j]+k);
					if (t == m) break;
				}
			}
	}
	int ans = maxlong;
	fo(i,l[n]+1,r[n]-1)	ans = min(ans , f[n][i]);
	if (ans != maxlong) printf("1\n%d\n",ans);else
	{
		ans = 0;
		for(int i=n;i>0;i--)
		{
			bool ok = 0;
			fo(j,l[i]+1,r[i]-1)
			if (f[i][j] != maxlong)
			{
				ok = 1; ans = sum[i];
			}
			if (ok) break;
		}
		printf("0\n%d\n",ans);
	}
}

int main()
{
	freopen("bird.in","r",stdin); freopen("ans.out","w",stdout);
	
	Init();
	Work();
	
	return 0;
}
