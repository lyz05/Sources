#include<cstdio>
#include<cstring>
#include<algorithm>
#define fo(i,a,b) for(int i=a;i<=b;i++)
using namespace std;

const int maxlong = int(1e9);
const int N = 10005;
int l[N] , r[N] , up[N] , down[N] , sum[N];
int n , m , K;
int f[N][1005] , tong[N][2];

void Init()
{
	scanf("%d%d%d",&n,&m,&K);
	fo(i,0,n-1) scanf("%d%d",&up[i],&down[i]);
	fo(i,0,n) l[i] = 0 , r[i] = m+1;
	fo(i,1,K)
	{
		int p,down,up;
		scanf("%d%d%d",&p,&down,&up);
		l[p] = down; r[p] = up; sum[p]++;
	}
	fo(i,1,n) sum[i] += sum[i-1];
}

int get(int l,int r,int p)
{
	if (l==r) return 1;
	int x = l-r;
	if (x%p == 0) return x/p;else return x/p+1;
}

void Work()
{
	fo(i,1,n) fo(j,0,m) f[i][j] = maxlong;
	fo(i,0,n-1)
	{
		fo(j,0,up[i]) tong[j][0] = maxlong , tong[j][1] = 0;
		fo(j,l[i]+1,r[i]-1)
		{
			int t = max(0,j-down[i]);
			f[i+1][t] = min(f[i+1][t] , f[i][j]);
		}
		
		fo(j,l[i]+1,r[i]-1)
		{
			int d = j%up[i];
			if (f[i][j] < tong[d][0] + get(j,tong[d][1],up[i]))
			{
				tong[d][0] = f[i][j]; tong[d][1] = j;
			}
			int t = min(m , j + up[i]);
			f[i+1][t] = min(f[i+1][t] , tong[d][0] + get(t,tong[d][1],up[i]));
			//if (t == m) break;
		}
		
		fo(j,r[i],m-up[i])
		{
			int t = min(m , j + up[i]) , d = j%up[i];
			f[i+1][t] = min(f[i+1][t] , tong[d][0] + get(t,tong[d][1],up[i]));
		}
		
		fo(j,0,up[i]-1) f[i+1][m] = min(f[i+1][m] , tong[j][0] + get(m,tong[j][1],up[i]));
	}
	
	int ans = maxlong;
	fo(j,1,m) ans = min(ans , f[n][j]);
	if (ans!=maxlong) printf("1\n%d\n",ans);else
	{
		ans = 0;
		for(int i=n;i>=0;i--)
		{
			bool ok = 0;
			fo(j,l[i]+1,r[i]-1)
			if (f[i][j]!=maxlong)
			{
				ok = 1; ans = sum[i];
			}
			if (ok) break;
		}
		printf("0\n%d\n",ans);
	}
}

int main()
{
	freopen("bird.in","r",stdin); freopen("bird.out","w",stdout);
	
	Init();
	Work();
	
	return 0;
}
