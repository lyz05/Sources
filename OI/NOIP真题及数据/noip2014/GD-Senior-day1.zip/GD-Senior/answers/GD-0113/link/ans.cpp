#include<cstdio>
#include<cstring>
#include<iostream>
#define fo(i,a,b) for(int i=a;i<=b;i++)
using namespace std;

const int mo = 10007;
const int N = int(4e5)+5;
int adj[N] , next[N] , g[N] , tot;
int n , w[N];
int bf[N][3];
long long ans1 , ans2;

void ins(int x,int y)
{
	adj[++tot]=y; next[tot]=g[x]; g[x]=tot;
}

void dfs(int x,int fa,int dep,long long t)
{
	bf[1][0] = x; bf[1][1] = 0; bf[1][2] = 0;
	int i = 0 , j = 1;
	while (i<j)
	{
		x = bf[++i][0];
		for(int p=g[x];p!=0;p=next[p])
		if (adj[p]!=bf[i][1])
		{
			bf[++j][0] = adj[p];
			bf[j][1] = x;
			bf[j][2] = bf[i][2] + 1;
			if (bf[j][2] == 2)
			{
				if (ans2 < t*w[bf[j][0]]) ans2 = t*w[bf[j][0]];
				ans1 = (ans1 + t*w[bf[j][0]])%mo;
				j--;
			}
		}
	}
}

int main()
{
	freopen("link.in","r",stdin); freopen("ans.out","w",stdout);
	
	scanf("%d",&n);
	fo(i,1,n-1)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		ins(x,y); ins(y,x);
	}
	fo(i,1,n) scanf("%d",&w[i]);
	ans1 = 0 , ans2 = 0;
	fo(i,1,n) dfs(i,0,0,w[i]);
	cout<<ans2<<' '<<ans1<<endl;
	
	return 0;
}

