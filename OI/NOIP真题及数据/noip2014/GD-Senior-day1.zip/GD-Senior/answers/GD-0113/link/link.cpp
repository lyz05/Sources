#include<cstdio>
#include<cstring>
#include<iostream>
#define fo(i,a,b) for(int i=a;i<=b;i++)
using namespace std;

const int mo = 10007;
const int N = int(4e5)+5;
int w[N] , adj[N] , next[N] , g[N] , n , tot;

void ins(int x,int y)
{
	adj[++tot]=y; next[tot]=g[x]; g[x]=tot;
}

void Init()
{
	scanf("%d",&n);
	fo(i,1,n-1)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		ins(x,y); ins(y,x);
	}
	fo(i,1,n) scanf("%d",&w[i]);
}

void Work()
{
	//ans1��ʾ�� �� ans2��ʾ���ֵ 
	long long ans1 = 0 , ans2 = 0;
	fo(i,1,n)
	{
		long long sum = 0 , big1 = 0 , big2 = 0;
		for(int p=g[i];p!=0;p=next[p])
		{
			sum+=w[adj[p]];
			if (w[adj[p]] > big1) big2 = big1 , big1 = w[adj[p]];else
			if (w[adj[p]] > big2) big2 = w[adj[p]];
		}
		if (ans2 < big1*big2) ans2 = big1*big2;
		for(int p=g[i];p!=0;p=next[p]) 
		ans1 = (ans1 + (sum-w[adj[p]])*w[adj[p]])%mo;
	}
	cout<<ans2<<' '<<ans1<<endl;
}

int main()
{
	freopen("link.in","r",stdin); freopen("link.out","w",stdout);
	
	Init();
	Work();
	
	return 0;
}

