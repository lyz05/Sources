#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#define Mod 10007
#define Maxn 200000
using namespace std;

struct node
{
	int x,y,d,next;
}a[Maxn*2+10];int len,first[Maxn+10];
int w[Maxn],maxx=0,zh=0;
void ins(int x,int y)
{
	len++;a[len].x=x;a[len].y=y;
	a[len].d=1;a[len].next=first[x];first[x]=len;
}
int mymax(int x,int y){return (x>y)?x:y;}
void dfs(int x,int fa,int ffa)
{
	if (ffa>0) 
	{
		int ww=(w[x]*w[ffa])%Mod;
		maxx=mymax(ww,maxx);
		zh=(zh+ww)%Mod;
		return;
	}
	for (int k=first[x];k!=-1;k=a[k].next)
	{
		int y=a[k].y;
		if (y!=fa) dfs(y,x,fa);
	}
}
int main()
{
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	int n,i,x,y;len=0;
	memset(first,-1,sizeof(first));
	scanf("%d",&n);
	for (i=1;i<n;i++)
	{
		scanf("%d%d",&x,&y);
		ins(x,y);ins(y,x);
	}
	for (i=1;i<=n;i++)
	 scanf("%d",&w[i]);
	for (i=1;i<=n;i++) dfs(i,-1,-1);
	printf("%d %d\n",maxx,zh);
	return 0;
}
