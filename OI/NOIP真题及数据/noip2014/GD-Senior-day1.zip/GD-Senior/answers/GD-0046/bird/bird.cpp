#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;

struct n1{int x,y;}a[11000];
struct n2{int x,y,t;}g[11000];
int cmp(const void *x,const void *y)
{
	n2 xx=*(n2 *)x;
	n2 yy=*(n2 *)y;
	return xx.t-yy.t;
}
int bo[2][1100],n,m;
int mymin(int x,int y){return (x<y)?x:y;}
void hh(int t,int p)
{
	for (int i=1;i<=m;i++)
	 if (bo[t][i]!=-1)
	  if (i<=g[p].x || i>=g[p].y)
	   bo[t][i]=-1;
}
int main()
{
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	int k,i,j,t,p;bool bk;
	scanf("%d%d%d",&n,&m,&k);
	for (i=0;i<n;i++)
	 scanf("%d%d",&a[i].x,&a[i].y);
	for (i=1;i<=k;i++)
	 scanf("%d%d%d",&g[i].t,&g[i].x,&g[i].y);
	qsort(g+1,k,sizeof(n2),cmp);
	memset(bo[0],0,sizeof(bo[0]));t=0;p=1;
	for (i=0;i<n;i++)
	{
		bk=false;if (p<=k && g[p].t==i) {hh(t,p);p++;}
		memset(bo[1-t],-1,sizeof(bo[1-t]));
		for (j=1;j<=m;j++)
		 if (bo[t][j]!=-1)
		 {
		 	bk=true;int cs=1;
		 	while (j+cs*a[i].x<=m) 
			{
				if (bo[1-t][j+cs*a[i].x]==-1 || bo[1-t][j+cs*a[i].x]>bo[t][j]+cs)
				bo[1-t][j+cs*a[i].x]=bo[t][j]+cs;cs++;
			}if (bo[1-t][m]==-1 || bo[1-t][m]>bo[t][j]+cs) bo[1-t][m]=bo[t][j]+cs;
		 	if (j-a[i].y>=0) bo[1-t][j-a[i].y]=bo[t][j];
		 }t=1-t;
		 if (!bk) break;
	}
	if (!bk) {if (p>=2) p-=2;else p=0;printf("0\n%d\n",p);}
	else
	{
		int ans=0x7fffffff;
		for (i=1;i<=m;i++)
	 	 if (bo[t][i]!=-1) ans=mymin(ans,bo[t][i]);
	 	printf("1\n%d\n",ans);
	}return 0;
}
