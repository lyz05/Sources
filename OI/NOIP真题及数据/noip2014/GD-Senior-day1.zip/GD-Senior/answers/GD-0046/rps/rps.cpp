#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
using namespace std;

int bo[5][5],a[210],b[210];
void fz()
{
	bo[0][0]=0;bo[0][1]=-1;bo[0][2]=1;bo[0][3]=1;bo[0][4]=-1;
	bo[1][0]=1;bo[1][1]=0;bo[1][2]=-1;bo[1][3]=1;bo[1][4]=-1;
	bo[2][0]=-1;bo[2][1]=1;bo[2][2]=0;bo[2][3]=-1;bo[2][4]=1;
	bo[3][0]=-1;bo[3][1]=-1;bo[3][2]=1;bo[3][3]=0;bo[3][4]=1;
	bo[4][0]=1;bo[4][1]=1;bo[4][2]=-1;bo[4][3]=-1;bo[4][4]=0;
}
int main()
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	int n,na,nb,i,ga,gb;
	scanf("%d%d%d",&n,&na,&nb);
	for (i=1;i<=na;i++)
	 scanf("%d",&a[i]);
	for (i=1;i<=nb;i++)
	 scanf("%d",&b[i]);
	fz();ga=gb=0;
	for (i=1;i<=n;i++)
	{
		int xx=i%na,yy=i%nb;
		if (xx==0) xx=na;
		if (yy==0) yy=nb;
		int tt=bo[a[xx]][b[yy]];
		if (tt==1) ga++;
		else if (tt==-1) gb++;
 	}printf("%d %d\n",ga,gb);
	return 0;
}
