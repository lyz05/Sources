#include<iostream>
#include<stdio.h>
#include<string.h>
using namespace std;
int f[1000][100],x[1000],y[1000];
struct str
{
 int x;
 int y;
 int n;
}w[1000];
int main()
{
    freopen("bird.in","r",stdin);
    freopen("bird.out","w",stdout); 
    int n,m,k;
    int t;
    memset(f,-1,sizeof(f));
    scanf("%d%d%d",&n,&m,&k);
    for(int i=0;i<n;i++)
      scanf("%d%d",&x[i],&y[i]);
    for(int i=1;i<=k;i++)
      {
       scanf("%d%d%d",&w[i].n,&w[i].x,&w[i].y);
       if(w[i].x>w[i].y)
         {
          t=w[i].x;
          w[i].x=w[i].y;
          w[i].y=t;
         }
      }
    for(int i=1;i<k;i++)
    for(int j=i+1;j<=k;j++)
     if(w[i].n>w[j].n)
      {
       t=w[i].n;
       w[i].n=w[j].n;
       w[j].n=t;
       t=w[i].x;
       w[i].x=w[j].x;
       w[j].x=t;
       t=w[i].y;
       w[i].y=w[j].y;
       w[j].y=t;
      }
    //for(int i=1;i<=k;i++)cout<<" "<<w[i].n<<" "<<w[i].x<<" "<<w[i].y<<endl;
    for(int i=1;i<=m;i++)
      f[0][i]=0;
    int ans=0,p,r,h,bb;
if(n<=100)
{
    p=3;   
    for(int i=1;i<=n;i++)
      {
       bb=0;
       if(w[ans+1].n==i)
         {r=w[ans+1].x+1;h=w[ans+1].y-1;}
       else {r=1;h=m;}
       for(int j=r;j<=h;j++)
         {
          for(int op=1;op<=p;op++)
            if(op*x[i-1]<j)
              if(f[i-1][j-op*x[i-1]]!=-1)
               {
                 if(op+f[i-1][j-op*x[i-1]]<f[i][j]||f[i][j]==-1)
                 f[i][j]=op+f[i-1][j-op*x[i-1]];
                 if(w[ans+1].n==i)bb=1; 
                 
               }
        int xx=m;
          if(j+y[i-1]<xx)
            xx=j+y[i-1];
            if(f[i-1][xx]!=-1)
              if(f[i-1][xx]<f[i][j]||f[i][j]==-1)
                {
                 f[i][j]=f[i-1][xx];
                 if(w[ans+1].n==i)bb=1;
                }
         }//cout<<"**"<<x[i-1]<<endl;
       if(bb)ans++;
      }
}
    if(ans==k)
      {
        ans=9999999;
         for(int i=1;i<=m;i++)
           if(f[n][i]!=-1&&f[n][i]<ans)
             ans=f[n][i];
        printf("1 %d\n",ans);
      }
    else
      {
       printf("0 %d\n",ans);
      }
   // for(int j=m;j>=0;j--){for(int i=0;i<=n;i++)cout<<f[i][j]<<"  ";cout<<endl;}
    return 0;
}





















