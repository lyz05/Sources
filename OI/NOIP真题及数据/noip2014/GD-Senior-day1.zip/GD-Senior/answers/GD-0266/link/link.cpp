#include<iostream>
#include<stdio.h>
#include<string.h>
using namespace std;
int tt=10007;
int n,w[200001],v[200001];
int e[200001],q[200001][2],t=0;
int main()
{
    freopen("link.in","r",stdin);
    freopen("link.out","w",stdout); 
    scanf("%d",&n);
    int x,y,m=0,ans=0;
    memset(e,0,sizeof(e));
    memset(q,0,sizeof(q));
      for(int i=1;i<n;i++)
        {
         scanf("%d%d",&x,&y);
         t++;
         q[t][1]=e[x];
         e[x]=t;
         q[t][0]=y;
         t++;
         q[t][1]=e[y];
         e[y]=t;
         q[t][0]=x;
        }
      for(int i=1;i<=n;i++)
        scanf("%d",&w[i]);
    for(int i=1;i<=n;i++)
    {
     memset(v,0,sizeof(v));
     int next=e[i];
     while(next!=0)
       {
        v[q[next][0]]=1;
        next=q[next][1];
       }
     v[i]=1;
     next=e[i];
     while(next!=0)
       {
        int rt=q[next][0],mm;
        rt=e[rt];
        while(rt!=0)
          {
           if(v[q[rt][0]]!=1)
               {
                 mm=w[i]*w[q[rt][0]];
                 if(mm>m)m=mm;
                ans=(ans+mm)%tt;
                v[q[rt][0]]=1;
               }
           rt=q[rt][1];
           
          }
        next=q[next][1];
       }
    }
    printf("%d %d\n",m,ans);
    return 0;
}














