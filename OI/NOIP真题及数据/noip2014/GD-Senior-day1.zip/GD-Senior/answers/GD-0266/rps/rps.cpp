#include<iostream>
#include<stdio.h>
#include<string.h>
using namespace std;
int sa[1000]={0},sb[1000]={0};
int main()
{
    freopen("rps.in","r",stdin);
    freopen("rps.out","w",stdout);
    int n,a,b,ans[2]={0,0},ta,tb;
    scanf("%d%d%d",&n,&a,&b);
    for(int i=0;i<a;i++)
      scanf("%d",&sa[i]);
    for(int i=0;i<b;i++)
      scanf("%d",&sb[i]);
    ta=tb=0;
    for(int i=1;i<=n;i++)
      {
        if(sa[ta]==0) 
          {
           if(sb[tb]==1||sb[tb]==4)
             ans[1]++;
           if(sb[tb]==2||sb[tb]==3)
             ans[0]++;
          }
        if(sa[ta]==1) 
          {
           if(sb[tb]==2||sb[tb]==4)
             ans[1]++;
           if(sb[tb]==0||sb[tb]==3)
             ans[0]++;
          }
        if(sa[ta]==2) 
          {
           if(sb[tb]==0||sb[tb]==3)
             ans[1]++;
           if(sb[tb]==1||sb[tb]==4)
             ans[0]++;
          }
        if(sa[ta]==3) 
          {
           if(sb[tb]==0||sb[tb]==1)
             ans[1]++;
           if(sb[tb]==2||sb[tb]==4)
             ans[0]++;
          }
        if(sa[ta]==4) 
          {
           if(sb[tb]==2||sb[tb]==3)
             ans[1]++;
           if(sb[tb]==0||sb[tb]==1)
             ans[0]++;
          }
        ta++;
        tb++;
        ta%=a;
        tb%=b;
      }
    printf("%d %d\n",ans[0],ans[1]);
    return 0;
}







