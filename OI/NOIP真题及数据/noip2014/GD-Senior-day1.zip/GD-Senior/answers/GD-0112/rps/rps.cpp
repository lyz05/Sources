#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;

const int maxn=205;

const int V[5][5]=
{
	{ 0, 0, 1, 1, 0 },
	{ 1, 0, 0, 1, 0 },
	{ 0, 1, 0, 0, 1 },
	{ 0, 0, 1, 0, 1 },
	{ 1, 1, 0, 0, 0 }
};

int N, NA, NB, sumA, sumB, A[maxn], B[maxn];

int main()
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	scanf("%d%d%d",&N,&NA,&NB);
	for (int i=0;i<NA;i++) scanf("%d",&A[i]);
	for (int i=0;i<NB;i++) scanf("%d",&B[i]);
	for (int t=0,i=0,j=0;t<N;t++,i=(i+1)%NA,j=(j+1)%NB)
	{
		sumA+=V[A[i]][B[j]];
		sumB+=V[B[j]][A[i]];
	}
	printf("%d %d\n",sumA,sumB);
	return 0;
}

