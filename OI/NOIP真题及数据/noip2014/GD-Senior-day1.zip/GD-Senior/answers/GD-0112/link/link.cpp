#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;

inline void READ(int &x)
{
	char c;
	x=0;
	do c=getchar(); while (c<'0' || c>'9');
	do x=x*10+c-48, c=getchar(); while (c>='0' && c<='9');
}

typedef long long ll;

const int maxn=200005, mo=10007;

int N, m, W[maxn], a[maxn], b[maxn<<1], c[maxn<<1];
ll ans1, ans2;

void Bfs()
{
	static int X[maxn], FA[maxn];
	int st, en;
	X[1]=1, FA[1]=0;
	for (st=en=1;st<=en;st++)
	{
		int x(X[st]), fa(FA[st]);
		ll FIRST(0), SECOND(0), SUM(0), SQSUM(0);
		for (int i=a[x];i;i=c[i]) if (b[i]!=fa)
		{
			en++, X[en]=b[i], FA[en]=x;
			if (W[b[i]]>FIRST)
				SECOND=FIRST, FIRST=W[b[i]];
			else
				SECOND=max<ll>(SECOND,W[b[i]]);
			SUM+=W[b[i]];
			SQSUM+=W[b[i]]*W[b[i]];
		}
		ans1=max(ans1,max(W[fa]*FIRST,FIRST*SECOND));
		ans2+=W[fa]*SUM*2+(SUM%mo)*(SUM%mo)-SQSUM, ans2=((ans2%mo)+mo)%mo;
	}
}

int main()
{
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	READ(N);
	for (int i=1;i<N;i++)
	{
		int x, y;
		READ(x), READ(y);
		m++, b[m]=y, c[m]=a[x], a[x]=m;
		m++, b[m]=x, c[m]=a[y], a[y]=m;
	}
	for (int i=1;i<=N;i++)
		READ(W[i]);
	Bfs();
	cout << ans1 << ' ' << ans2 << endl;
	return 0;
}

