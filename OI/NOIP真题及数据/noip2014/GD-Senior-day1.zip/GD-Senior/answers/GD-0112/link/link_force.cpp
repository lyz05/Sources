#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;

const int maxn=5005, mo=10007;

int N, W[maxn];
long long ans1, ans2;
bool A[maxn][maxn];

int main()
{
	freopen("link.in","r",stdin);
	freopen("link.ans","w",stdout);
	scanf("%d",&N);
	for (int i=1;i<N;i++)
	{
		int x, y;
		scanf("%d%d",&x,&y);
		A[x][y]=A[y][x]=true;
	}
	for (int i=1;i<=N;i++)
		scanf("%d",&W[i]);
	for (int i=1;i<=N;i++)
		for (int j=1;j<=N;j++) if (i!=j)
			for (int k=1;k<=N;k++) if (A[k][i] && A[k][j])
			{
				ans1=max<long long>(ans1,W[i]*W[j]);
				ans2+=W[i]*W[j], ans2%=mo;
			}
	printf("%I64d %I64d\n",ans1,ans2);
	return 0;
}

