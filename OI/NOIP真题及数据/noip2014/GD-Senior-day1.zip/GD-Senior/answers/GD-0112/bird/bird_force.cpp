#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;

const int maxn=10005, maxm=1005, inf=0x7f7f7f7f;

int N, M, K, X[maxn], Y[maxn], L[maxn], H[maxn], f[maxn][maxm];

int main()
{
	freopen("bird.in","r",stdin);
	freopen("bird.ans","w",stdout);
	scanf("%d%d%d",&N,&M,&K);
	for (int i=0;i<N;i++) scanf("%d%d",&X[i],&Y[i]);
	memset(H,127,sizeof H);
	for (int i=1;i<=K;i++)
	{
		int p, l, h;
		scanf("%d%d%d",&p,&l,&h);
		L[p]=l, H[p]=h;
	}
	memset(f,127,sizeof f);
	for (int i=L[0]+1;i<=min(M,H[0]-1);i++)
		f[0][i]=0;
	for (int i=0;i<N;i++)
		for (int j=0;j<=M;j++)
		{
			if (f[i][j]<inf && j-Y[i]>L[i+1] && j-Y[i]<H[i+1])
				f[i+1][j-Y[i]]=min(f[i+1][j-Y[i]],f[i][j]);
			for (int k=1;k;k++)
			{
				int _j(min(M,j+X[i]*k));
				if (_j>L[i+1] && _j<H[i+1])
					f[i+1][_j]=min(f[i+1][_j],f[i][j]+k);
				if (_j==M) break;
			}
		}
	int far(0), click(inf), now(0);
	for (int i=0;i<=N;i++)
	{
		if (H[i]<inf) now++;
		for (int j=0;j<=M;j++) if (f[i][j]<inf)
		{
			far=now;
			if (i==N) click=min(click,f[i][j]);
		}
	}
	if (far<now)
		printf("0\n%d\n",far);
	else
		printf("1\n%d\n",click);
	return 0;
}

