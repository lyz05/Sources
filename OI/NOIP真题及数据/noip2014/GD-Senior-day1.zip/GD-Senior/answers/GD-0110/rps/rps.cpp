#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

const int A[5][5] = 
{{0,0,1,1,0},
 {1,0,0,1,0},
 {0,1,0,0,1},
 {0,0,1,0,1},
 {1,1,0,0,0}};
 
const int N = 1005;

int n, p, q, a[N], b[N];
int s[2];

int main()
{
	freopen("rps.in", "r", stdin);
	freopen("rps.out", "w", stdout);
	
	scanf("%d%d%d", &n, &p, &q);
	for(int i=0; i<p; i++) scanf("%d", &a[i]);
	for(int i=0; i<q; i++) scanf("%d", &b[i]);
	
	s[0] = s[1] = 0;
	for(int i=0; i<n; i++)
	{
		a[i] = a[i%p], b[i] = b[i%q];
		if(a[i]==b[i]) continue;
		s[A[b[i]][a[i]]] ++;
	}
	printf("%d %d\n", s[0], s[1]);
	
	return 0;
}

