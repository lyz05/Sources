#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

const int N = 10005;
const int M = 1005;

int n, m, k;
int o[N], ob[N], oa[N];
int x[N], y[N];
int f[2][M], tax[M];

void opt(int &x, int y) {if(y<x) x=y;}

int main()
{
	freopen("bird.in", "r", stdin);
	freopen("bird.out", "w", stdout);
	
	scanf("%d%d%d", &n, &m, &k);
	for(int i=0; i<n; i++) scanf("%d%d", &x[i], &y[i]);
	for(int i=1, p, l, h; i<=k; i++) scanf("%d%d%d", &p, &l, &h), o[p]=1, ob[p]=l, oa[p]=h;
	
	
	for(int i=1; i<=m; i++) f[0][i] = 0;
	for(int i=0, cnt=0; i<n; i++)
	{
		int e(i&1), g(1-e);
		for(int j=1; j<=m; j++) f[g][j] = 1e9;
		
		if(o[i])
		{
			for(int j=1; j<=ob[i]; j++) f[e][j] = 1e9;
			for(int j=oa[i]; j<=m; j++) f[e][j] = 1e9;
		}
		
		int fail(1);
		for(int j=1; j<=m && fail; j++) if(f[e][j]<1e9) fail=0;
		if(fail) {printf("0\n%d\n", cnt); return 0;}
		
		cnt += o[i];
		
		for(int j=y[i]+1; j<=m; j++) opt(f[g][j-y[i]], f[e][j]);
		for(int j=0; j<x[i]; j++) tax[j] = 1e9;
		
		for(int j=1; j<=m; j++) opt(f[g][j], tax[j%x[i]] + j/x[i]), opt(tax[j%x[i]], f[e][j] - j/x[i]);
		for(int j=1; j<m; j++) opt(f[g][m], f[e][j] + (m-j-1)/x[i]+1);
		opt(f[g][m], f[e][m] + 1);
	}
	
	int ans(1e9);
	for(int i=1; i<=m; i++) opt(ans, f[n&1][i]);
	printf("1\n%d\n", ans);
	
	
	return 0;
}

