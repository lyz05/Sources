#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

const int N = 200005;
const int MOD = 10007;

int to[N+N], next[N+N], end[N], tms;
int n, w[N];

int main()
{
	freopen("link.in", "r", stdin);
	freopen("link.out", "w", stdout);
	
	scanf("%d", &n);
	for(int i=1, x, y; i<n; i++)
	{
		scanf("%d%d", &x, &y);
		to[++tms]=y, next[tms]=end[x], end[x]=tms;
		to[++tms]=x, next[tms]=end[y], end[y]=tms;
	}
	for(int i=1; i<=n; i++) scanf("%d", &w[i]);
	
	int ans(0), most(0);
	for(int x=1; x<=n; x++)
	{
		int r(0), b1(0), b2(0);
		for(int p=end[x], y; p; p=next[p])
		{
			y = to[p];
			(ans += (r * w[y]) % MOD) %= MOD;
			(r += w[y]) %= MOD;
			if(w[y] > b1) b2 = b1, b1 = w[y];
			else if(w[y] > b2) b2 = w[y];
		}
		if(b1*b2>most) most=b1*b2;
	}
	ans = (ans * 2) % MOD;
	printf("%d %d\n", most, ans);
	
	return 0;
}


