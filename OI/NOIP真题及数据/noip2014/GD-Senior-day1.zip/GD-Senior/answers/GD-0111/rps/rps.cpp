#include<cstdio>
#include<iostream>
#include<cstring>
#include<algorithm>
using namespace std;
#define maxn 210
int n,na,nb,a[maxn],b[maxn],ca,cb;
int f[5][5]={
    {0,-1,1,1,-1},
    {1,0,-1,1,-1},
    {-1,1,0,-1,1},
    {-1,-1,1,0,1},
    {1,1,-1,-1,0}
};
int main(){
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
    scanf("%d%d%d",&n,&na,&nb);
    for (int i=0;i<na;i++) scanf("%d",a+i);
    for (int i=0;i<nb;i++) scanf("%d",b+i);
    int l=0,r=0;
    for (int i=1;i<=n;i++) {
	switch (f[a[l]][b[r]]) {
	    case 1:
		ca++;
		break;
	    case -1:
		cb++;
		break;
	}
	(l+=1)%=na;(r+=1)%=nb;
    } 
    printf("%d %d",ca,cb);
    return 0;
}
