#include<cstdio>
#include<iostream>
#include<cstring>
#include<algorithm>
using namespace std;
#define maxn 10100
#define maxm 1010
#define inf 0x7fffffff
int n,m,k,up[maxn],down[maxn],l[maxn],h[maxn];
bool is[maxn],b[maxn][maxm],bo[maxn][maxm];
int sum[maxn][maxm],f[maxn][maxm];
int fail(int x) {
    int cnt=0;
    for (int i=1;i<x;i++) if (is[i]) cnt++;
    printf("%d\n%d\n",0,cnt);
}
int main(){
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
    scanf("%d%d%d",&n,&m,&k);
    for (int i=1;i<=n;i++) scanf("%d%d",&up[i],&down[i]);
    for (int i=1;i<=n;i++) l[i]=0,h[i]=m+1;
    for (int i=1;i<=k;i++) {
    	int x;
	scanf("%d",&x);
	is[x]=1;
	scanf("%d%d",l+x,h+x);
    }
    for (int i=1;i<=m;i++) b[0][i]=1,f[0][i]=0;
    
    for (int i=1;i<=n;i++) {
	bool flag=1;
	for (int j=1;j<=l[i];j++) {
		if (b[i-1][j]) {
		if (bo[i][j%up[i]]) sum[i][j%up[i]]=min(sum[i][j%up[i]],f[i-1][j]);
		else sum[i][j%up[i]]=f[i-1][j];
		bo[i][j%up[i]]=1;
	    }
	    sum[i][j%up[i]]++;
	}
	for (int j=l[i]+1;j<h[i];j++) {
		f[i][j]=inf;
	    if (j+down[i]<=m&&b[i-1][j+down[i]]){ 
		f[i][j]=min(f[i-1][j+down[i]],f[i][j]);
		b[i][j]=1;
		flag=0;
	    }
	    if (bo[i][j%up[i]]) {
		f[i][j]=min(sum[i][j%up[i]],f[i][j]);
		b[i][j]=1;flag=0;
	    }
		if (j==m) {
	    	for (int k=0;k<up[i];k++) 
			if (bo[i][k]) {
				f[i][j]=min(sum[i][k],f[i][j]);
				b[i][j]=1;flag=0;
	    	}
	    	if (b[i-1][m]) {
				f[i][j]=min(f[i-1][m]+1,f[i][j]);
				b[i][j]=1;flag=0;
	    	}
	    }
	    if (b[i-1][j]) {
		if (bo[i][j%up[i]]) sum[i][j%up[i]]=min(sum[i][j%up[i]],f[i-1][j]);
		else sum[i][j%up[i]]=f[i-1][j];
		bo[i][j%up[i]]=1;
	    }
	    sum[i][j%up[i]]++;
	    
	}
	if (flag) {
	    fail(i);
	    return 0;
	}
    }
    printf("%d\n",1);
    int ans=inf;
    for (int i=1;i<=m;i++) ans=min(ans,f[n][i]);
    printf("%d\n",ans);
    return 0;
}

