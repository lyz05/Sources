#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;
#define maxn 200010
#define mod 10007
#define fi first
#define se second
typedef long long ll;
typedef pair<ll,ll> ii;
struct edges{
    int to,next;
}edge[maxn*2];
int next[maxn],l;
int addedge(int x,int y){
    edge[++l]=(edges){y,next[x]};next[x]=l;
    edge[++l]=(edges){x,next[y]};next[y]=l;
    return 0;
}
ll sum[maxn],ans,mx;
ii Max[maxn];
ll w[maxn];
int q[maxn],pre[maxn];
int dfs(){
    int l=1,r=1;
    q[l]=1;
    while (l<=r) {
        int u=q[l],v;
	for (int i=next[u];i;i=edge[i].next) {
	    if ((v=edge[i].to)==pre[u]) continue;
	    q[++r]=v;
	    pre[v]=u;
	    sum[u]+=w[v];
	    if (Max[u].fi<w[v]) {
		swap(Max[u].fi,Max[u].se);
		Max[u].fi=w[v];
	    }else if (Max[u].se<w[v]) Max[u].se=w[v];
	}
	for (int i=next[u];i;i=edge[i].next) {
	    if ((v=edge[i].to) == pre[u]) continue;
	    (ans+= (sum[u]-w[v])*w[v]) %= mod; // sum finish

	    if (w[v]==Max[u].fi) mx=max(Max[u].se*w[v],mx);
	    else mx=max(Max[u].fi*w[v],mx);
	}
	l++;
    }
    while (r--) {
	int u=q[r],v;
	ll cnt=0;
	for (int i=next[u];i;i=edge[i].next) {
	    if ((v=edge[i].to)==pre[u]) continue;
	    sum[v]%=mod;
	    (cnt+=sum[v])%=mod;
	    mx=max(Max[v].fi*w[u],mx);
	}
	(ans+=cnt*w[u]*2)%=mod;
    }
    return 0;
}
int main(){
	int n;
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
    scanf("%d",&n);
    for (int i=1;i<n;i++) {
    	int x,y;
	scanf("%d%d",&x,&y);
	addedge(x,y);
    }
    for (int i=1;i<=n;i++) scanf("%lld",w+i);
    dfs();
    cout << mx << ' '<< ans << endl;
    return 0;
}
