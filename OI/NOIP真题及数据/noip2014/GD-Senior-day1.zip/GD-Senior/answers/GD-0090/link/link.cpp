#include <cstdio>
#include <algorithm>
#include <utility>
#include <cmath>
#include <queue>
#include <cstring>
#include <cstdlib>
#include <deque>
#include <ctime>
#include <map>
using namespace std;
const int mod=10007;
const int maxn=int(2e5)+100;

struct line
{ int id,next; };

int n,now,maxans,ans;
int h[maxn],father[maxn],maxson[maxn][5],a[maxn],q[maxn],sum[maxn];
line t[maxn*2];

void join(int u,int v)
{
    t[now].id=v; t[now].next=h[u]; h[u]=now++;
    t[now].id=u; t[now].next=h[v]; h[v]=now++;
}
void init()
{
    scanf("%d",&n);
    for (int i=1;i<=n;++i) h[i]=-1;
    for (int i=1;i<n;++i)
    {
        int u,v;
        scanf("%d%d",&u,&v);
        join(u,v);
    }
    for (int i=1;i<=n;++i) scanf("%d",&a[i]);
}
void bfs()
{
    int head=1,tail=1;
    q[1]=1;
    for (int i=1;i<=n;++i) father[i]=-1;
    father[1]=0;
    while (head<=tail)
    {
        int cur=q[head++];
        for (int i=h[cur];i>-1;i=t[i].next)
        if (father[t[i].id]==-1)
        {
            father[t[i].id]=cur;
            q[++tail]=t[i].id;
        }
    }
}
void solve()
{
    for (int i=n;i>0;--i)
    {
        int cur=q[i];
        if (father[cur]==0) continue;
        int nid=father[cur];
        if (father[nid]!=0) 
        {
            maxans=max(maxans,a[cur]*a[father[nid]]);
            ans=(ans+a[cur]*a[father[nid]])%mod;
        }
        ans=(ans+a[cur]*sum[nid])%mod;
        sum[nid]=(sum[nid]+a[cur])%mod;
        if (a[cur]>maxson[nid][1])
        {
            maxson[nid][1]=a[cur];
            if (a[cur]>maxson[nid][0]) swap(maxson[nid][0],maxson[nid][1]);
        }
    }
    for (int i=1;i<=n;++i)
    if (maxson[i][0]!=0 && maxson[i][1]!=0) maxans=max(maxson[i][0]*maxson[i][1],maxans);
}
int main()
{
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	init();
	bfs();
	solve();
	ans=(ans*2)%mod;
	printf("%d %d\n",maxans,ans);
	return 0;
}

