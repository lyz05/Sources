#include <cstdio>
#include <algorithm>
#include <utility>
#include <cmath>
#include <queue>
#include <cstring>
#include <cstdlib>
#include <deque>
#include <ctime>
#include <map>
using namespace std;
const int maxn=int(1e4)+100;
const int maxm=1100;
const int oo=int(1e9);

int n,m,s,ans;
int up[maxn],down[maxn],low[maxn],high[maxn];
int f[maxn][maxm];
bool cannot;
bool role[maxn];


void init()
{
    scanf("%d%d%d",&n,&m,&s);
    for (int i=0;i<n;++i) scanf("%d%d",&up[i],&down[i]);
    for (int i=0;i<=n;++i) { low[i]=0; high[i]=m+1; } 
    for (int i=1;i<=s;++i)
    {
        int x,L,H;
        scanf("%d%d%d",&x,&L,&H);
        low[x]=L; high[x]=H;
        role[x]=true;
    }
}
void solve()
{
    cannot=false;
    for (int i=1;i<=n;++i)
        for (int j=0;j<=m;++j) f[i][j]=oo;
    for (int i=1;i<=m;++i) f[0][i]=0;
    f[0][0]=oo;
    for (int i=1;i<=n;++i)
    {
        int st=max(up[i-1]+1,low[i]+1);
        for (int j=st;j<high[i];++j)
        {
            f[i][j]=min(f[i][j],min(f[i][j-up[i-1]],f[i-1][j-up[i-1]])+1);
            if (j==m)
            for (int k=m-up[i-1];k<high[i-1];++k) f[i][j]=min(f[i][j],f[i-1][k]+1);
        }
        int la=min(high[i-1]-down[i-1],high[i]);
        for (int j=low[i]+1;j<la;++j) f[i][j]=min(f[i][j],f[i-1][j+down[i-1]]);
        bool flag=false;
        for (int j=1;j<=m;++j)
        if (f[i][j]<oo) { flag=true; break; }
        if (!flag) { cannot=true; ans=i; return; }
    }
}
int main()
{
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	init();
	solve();
	if (cannot)
    {
        int sum=0;
        for (int i=0;i<ans;++i)
        if (role[i]) ++sum;
        printf("0\n");
        printf("%d\n",sum);
    }
	else
	{
	    ans=oo;
	    for (int i=low[n]+1;i<high[n];++i) ans=min(f[n][i],ans);
	    printf("1\n"); printf("%d\n",ans);
    }
	return 0;
}

