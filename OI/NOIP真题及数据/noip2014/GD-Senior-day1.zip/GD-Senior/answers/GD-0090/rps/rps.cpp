#include <cstdio>
#include <algorithm>
#include <utility>
#include <cmath>
#include <queue>
#include <cstring>
#include <cstdlib>
#include <deque>
#include <ctime>
#include <map>
using namespace std;
const int rule[5][5]={{0,-1,1,1,-1},
                     {1,0,-1,1,-1},
                     {-1,1,0,-1,1},
                     {-1,-1,1,0,1},
                     {1,1,-1,-1,0}};

int n,na,nb,ansa,ansb;
int a[500],b[500];

void solve()
{
    for (int i=1;i<=na;++i) scanf("%d",&a[i]);
    for (int i=1;i<=nb;++i) scanf("%d",&b[i]);
    for (int i=1,j=1,k=1;i<=n;++i)
    {
        if (rule[a[j]][b[k]]==1) ++ansa;
        if (rule[b[k]][a[j]]==1) ++ansb;
        ++j; ++k;
        if (j>na) j=1;
        if (k>nb) k=1;
    }
}
int main()
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	scanf("%d%d%d",&n,&na,&nb);
	solve();
	printf("%d %d\n",ansa,ansb);
	return 0;
}
