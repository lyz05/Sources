#include<fstream>
using namespace std;
ifstream fin("link.in");
ofstream fout("link.out");
long val[2001]={0},n,xx[2001][2001]={0},mmax=-1,ans=0;
bool map[2001][2001]={0};
int main()
{
	long sa,sb,s,temp;
	fin>>n;
	for(s=1;s<=n-1;s++){
		fin>>sa>>sb;
		map[sa][sb]=map[sb][sa]=true;
	}
	for(s=1;s<=n;s++){fin>>val[s];}
	for(s=1;s<=n;s++){
		for(sa=1;sa<=n;sa++){
			if(map[s][sa]){
				for(sb=1;sb<=n;sb++){
					if(map[sa][sb]&&(!map[s][sb])&&s!=sb){
						temp=val[s]*val[sb];
						ans+=temp;
						ans%=10007;
						if(temp>mmax){
							mmax=temp;
						}
					}
				}
			}
		}
	}
	fout<<mmax<<' '<<ans;
	fin.close();
	fout.close();
}