#include<fstream>
using namespace std;
ifstream cin("bird.in");
ofstream cout("bird.out");
struct{
	long u,d;
	bool b;
}kk[10001]={0};
long map[10001][1001]={0},ud[10001][2],n,m,k,sum=0,succeed=true,mmin;
bool found=false,ff,xx[10001][1001]={0};
int main()
{
	long s,sa,sb,tem,bg,ed,i,j;
	cin>>n>>m>>k;
	for(s=1;s<=n;s++){
		cin>>ud[s][0]>>ud[s][1];
	}
	for(s=1;s<=k;s++){
		cin>>sa>>kk[sa].d>>kk[sa].u;
		kk[sa].b=true;
	}
	for(sa=1;sa<=n;sa++){
		ff=false;
		if(kk[sa].b){
			bg=kk[sa].d+1;
			ed=kk[sa].u-1;
			for(sb=1;sb<=bg;sb++)map[sa][sb]=-1;
			for(sb=ed;sb<=m;sb++)map[sa][sb]=-1;
		}
		else {
			bg=1;ed=m;
		}
		for(sb=bg;sb<=ed;sb++){
			bool down=false;
			mmin=1000000;
			found=false;
			if((map[sa-1][sb-ud[sa][0]]!=-1&&sb-ud[sa][0]>0)||(sa==1&&sb-ud[sa][0]==0)){
				mmin=map[sa-1][sb-ud[sa][0]]+1;
				found=true;
			}
			k=1;
			tem=sb-k*ud[sa][0];
			while(tem>0){
				if(map[sa][tem]!=-1){
					if(xx[sa][tem])break;
					if(map[sa][tem]+k<mmin){
						mmin=map[sa][tem]+k;
					}
					found=true;
				}
				k++;
				tem=sb-k*ud[sa][0];
			}
			if(map[sa-1][sb+ud[sa][1]]!=-1&&sb+ud[sa][1]<=m){
				if(map[sa-1][sb+ud[sa][1]]<mmin){
					mmin=map[sa-1][sb+ud[sa][1]];
					down=true;
				}
				found=true;
			}
			if(sb==m){
				if(map[sa-1][m]+1<mmin&&map[sa-1][m]!=-1){
					mmin=map[sa-1][m]+1;
					down=false;
					found=true;
				}
				for(tem=m-ud[sa][0];tem<=m;tem++){
					if(map[sa-1][tem]!=-1){
					if(map[sa-1][tem]+1<mmin){
						mmin=map[sa-1][tem]+1;
						down=false;
					}
					found=true;
					}
				}
			}
			if(found){ff=true;map[sa][sb]=mmin;}
			else {
				map[sa][sb]=-1;
			}
			xx[sa][sb]=down;
		}
		if(kk[sa].b&&ff)sum++;
		if(!ff){
			succeed=false;
			cout<<0<<' '<<sum;
			break;
		}
	}
	if(succeed){
		mmin=1000000;
		for(sa=1;sa<=m;sa++){
			if(map[n][sa]<mmin&&map[n][sa]!=-1)mmin=map[n][sa];
		}
		cout<<1<<' '<<mmin;
	}
	cin.close();
	cout.close();
	return 0;
}