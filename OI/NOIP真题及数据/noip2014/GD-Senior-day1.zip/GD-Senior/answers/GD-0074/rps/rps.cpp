#include<fstream>
using namespace std;
ifstream fin("rps.in");
ofstream fout("rps.out");
long map[5][5]={0,0,1,1,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,1,1,1,0,0,0},n,na,nb;
long aa[210],bb[210];
int main()
{
	long s,sa,sb,ansa=0,ansb=0;
	fin>>n>>na>>nb;
	for(sa=0;sa<na;sa++)fin>>aa[sa];
	for(sb=0;sb<nb;sb++)fin>>bb[sb];
	sa=0;sb=0;
	for(s=1;s<=n;s++){
		ansa+=map[aa[sa]][bb[sb]];
		ansb+=map[bb[sb]][aa[sa]];
		sa++;sa%=na;
		sb++;sb%=nb;
	}
	fout<<ansa<<' '<<ansb;
	fin.close();
	fout.close();
}
