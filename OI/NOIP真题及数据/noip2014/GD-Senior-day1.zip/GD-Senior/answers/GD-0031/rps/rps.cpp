#include<cstdio>
#include<cmath>
#include<algorithm>
#include<vector>
using namespace std;
const int g[5][5]={{0,0,1,1,0},{1,0,0,1,0},{0,1,0,0,1},{0,0,1,0,1},{1,1,0,0,0}};
int main()
{
  freopen("rps.in","r",stdin);
  freopen("rps.out","w",stdout);
  int n,a[201],b[201],ra,rb,i;
  scanf("%d %d %d",&n,&ra,&rb);
  for(i=1;i<=ra;i++)
  scanf("%d",&a[i]);
  for(i=1;i<=rb;i++)
  scanf("%d",&b[i]);
  int j,ga=0,gb=0;
  i=j=0;
  while(n--)
  {
  	i++;
  	if(i>ra)i=1;
  	j++;
  	if(j>rb)j=1;
  	ga+=g[a[i]][b[j]];
  	gb+=g[b[j]][a[i]];
}
 printf("%d %d",ga,gb);
  return 0;
}



