#include<cstdio>
#include<cmath>
#include<algorithm>
#include<vector>
#include<cstring>
#include<iostream>
using namespace std;
long long sum,maxi;
vector<long> v[200001];
long w[200001],n,x,y;
bool b[200001];
void DFS(long t,long fa)
{
	b[t]=false;
	long long s2=(-w[fa]*w[fa])%10007,s=w[fa];
	long opt1=w[fa],opt2=0;
	for(long i=0;i<v[t].size();i++)
	if(b[v[t][i]])
	{
		x=w[v[t][i]];
		if(x>opt1){opt2=opt1;opt1=x;}
		else
		if(x>opt2)opt2=x;
		s2=(s2+(-x*x)%10007)%10007;
		s=(s+x)%10007;
		DFS(v[t][i],t);
	}
	maxi=max(maxi,(long long)(opt1*opt2));
	sum=(sum+s*s%10007+s2)%10007;
}
int main()
{
  freopen("link.in","r",stdin);
  freopen("link.out","w",stdout);
  ios::sync_with_stdio(false);
  scanf("%ld",&n);
  long i;
  for(i=1;i<n;i++)
  {
  	scanf("%ld %ld",&x,&y);
  	v[x].push_back(y);
  	v[y].push_back(x);
  }
  w[0]=0;
  for(i=1;i<=n;i++)
  scanf("%ld",&w[i]);
  memset(b,true,sizeof(b));
  sum=maxi=0;
  DFS(1,0);
  cout<<maxi<<' '<<sum<<endl;
  return 0;
}



