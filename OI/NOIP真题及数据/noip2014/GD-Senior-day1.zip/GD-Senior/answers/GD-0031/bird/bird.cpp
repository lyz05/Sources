#include<cstdio>
#include<cmath>
#include<algorithm>
#include<vector>
#include<cstring>
using namespace std;
int n,m,k,i,x,j,g=0;

long f[10001][1001],up[10001],down[10001],L[10001],H[10001];
inline int getans(int w,int i)
{
	if(w==m)return 1;
	if(!((m-w)%up[i]))return (m-w)/up[i];
	else return (m-w)/up[i]+1;
}
int main()
{
  freopen("bird.in","r",stdin);
  freopen("bird.out","w",stdout);
  memset(f,255,sizeof(f));
  scanf("%d %d %d",&n,&m,&k);
  for(i=0;i<n;i++)scanf("%ld %ld",&up[i],&down[i]);
  memset(L,255,sizeof(L));
  memset(H,255,sizeof(H));
  for(i=1;i<=k;i++)
  {
  	scanf("%d",&x);
  	scanf("%ld %ld",&L[x],&H[x]);
  }
  for(i=1;i<=m;i++)f[0][i]=0;
  for(i=1;i<=n;i++)
  {
    x=0;
  for(j=1;j<m;j++)
  {
  	if(L[i]>=0 && (j<=L[i] || j>=H[i]))continue;
  	if(j+down[i-1]>0 && j+down[i-1]<=m)
  	 if(f[i-1][j+down[i-1]]!=-1)f[i][j]=f[i-1][j+down[i-1]];
  	for(k=1;;k++)
  	{
  		if(j-up[i-1]*k<=0)break;
  		if(f[i-1][j-up[i-1]*k]>=0)
  		{
  		  if(f[i][j]==-1)f[i][j]=f[i-1][j-up[i-1]*k]+k;
		  else
		  f[i][j]=min(f[i][j],f[i-1][j-up[i-1]*k]+k);	
  		}
  	}
  	if(f[i][j]>=0)x=1;
  }
   if(H[i]==-1)
   {
   	 for(j=1;j<=m;j++)
   	 {
   	 	if(f[i-1][j]!=-1)
   	 	{
   	 		if(f[i][m]==-1)f[i][m]=f[i-1][j]+getans(j,i-1);
   	 		else f[i][m]=min(f[i][m],f[i-1][j]+getans(j,i-1));
   	 	}
   	 	
   	 }
   	 if(f[i][m]>=0)x=1;
   }
   if(!x)
   {
   	printf("0\n%d",g);
   	return 0;
   }
   else
   {
   	if(L[i]>=0)g++;
   }
  }  
  printf("1\n");
  long ans=2147483647;
  for(i=1;i<=m;i++)
  if(f[n][i]!=-1 && f[n][i]<ans)ans=f[n][i];
  printf("%ld",ans);
  return 0;
}



