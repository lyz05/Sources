#include<fstream>
using namespace std;
ifstream cin("bird.in"); ofstream cout("bird.out");
struct
{
	int up,down;
} q[10005];
struct
{
	int i,j,n;
	bool f;
} ch[10005];
int n,m,nm,minn,ans,f[10005][1005];

void init()
{
	int a,i,j,k,l;
	cin>>n>>m>>nm;
	for (a=0;a<n;a++) cin>>q[a].up>>q[a].down;
	for (a=1;a<=nm;a++)
	{
		cin>>k>>i>>j;
		ch[k].f=true; ch[k].i=i; ch[k].j=j; ch[k].n=a;
		for (l=0;l<=i;l++) f[k][l]=-1;
		for (l=j;l<=m;l++) f[k][l]=-1;
	}
	return ;
}

void doit()
{
	int a,i,j,k,hi,z,num;
	bool pd;
	num=0;
	for (i=1;i<=n;i++)
	{
		if (!ch[i].f)
		{
			for (j=1;j<m;j++)
			{
				minn=1000000000;
				if (f[i-1][j+q[i-1].down]!=-1 && j+q[i-1].down<=m) minn=f[i-1][j+q[i-1].down];
				hi=j-q[i-1].up; z=1;
				while (hi>0)
				{
					if (f[i-1][hi]!=-1 && f[i-1][hi]+z<minn) minn=f[i-1][hi]+z;
					hi=hi-q[i-1].up; z++;	
				}
				if (minn!=1000000000) f[i][j]=minn; else f[i][j]=-1;
			}
			minn=1000000000;
			for (j=1;j<=m;j++)
			{
				if (f[i-1][j]!=-1)
				{
					k=(m-j)/q[i-1].up;
					if ((m-j)%q[i-1].up!=0 || j==m) k++;
					if (f[i-1][j]+k<minn) minn=f[i-1][j]+k;
				}
			}
			if (minn!=1000000000) f[i][m]=minn; else f[i][m]=-1;
		} else if (ch[i].f)
		{
			pd=false;
			for (j=ch[i].i+1;j<=ch[i].j-1;j++)
			{
				minn=1000000000;
				if (f[i-1][j+q[i-1].down]!=-1 && j+q[i-1].down<=m) minn=f[i-1][j+q[i-1].down];
				hi=j-q[i-1].up; z=1;
				while (hi>0)
				{
					if (f[i-1][hi]!=-1 && f[i-1][hi]+z<minn) minn=f[i-1][hi]+z;
					hi=hi-q[i-1].up; z++;	
				}
				if (minn!=1000000000) { f[i][j]=minn; pd=true; num++; } else f[i][j]=-1;
			}
			if (!pd) { cout<<0<<endl<<num; return ; }
		}
	}
	cout<<1<<endl; ans=1000000000;
	for (a=1;a<=m;a++) if (f[n][a]<ans && f[n][a]!=-1) ans=f[n][a];
	cout<<ans;
	return ;
}

int main()
{
	ios::sync_with_stdio(false);
	init();
	doit();
	cin.close(); cout.close();
	return 0;
}
