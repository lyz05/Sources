#include<fstream>
using namespace std;
ifstream cin("rps.in"); ofstream cout("rps.out");
int n,x,y,f[5][5],q[205],w[205],ansx,ansy;

void init()
{
	int a,i,j;
	cin>>n>>x>>y;
	for (a=0;a<x;a++) cin>>q[a];
	for (a=0;a<y;a++) cin>>w[a];
	f[0][2]=1; f[0][3]=1; f[1][3]=1; f[2][4]=1; f[3][4]=1;
	for (i=1;i<=4;i++)
		for (j=0;j<i;j++)
			if (f[j][i]==0) f[i][j]=1;
	return ;
}

void doit()
{
	int a,i,j;
	i=0; j=0;
	for (a=1;a<=n;a++)
	{
		ansx+=f[q[i]][w[j]]; ansy+=f[w[j]][q[i]];
		i++; i=i%x;
		j++; j=j%y;
	}
	return ;
}

int main()
{
	init();
	doit();
	cout<<ansx<<' '<<ansy;
	cin.close(); cout.close();
	return 0;
}
