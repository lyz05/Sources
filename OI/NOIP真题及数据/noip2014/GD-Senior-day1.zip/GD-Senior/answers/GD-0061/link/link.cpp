#include<fstream>
using namespace std;
ifstream cin("link.in"); ofstream cout("link.out");
struct
{
	int x,y;
} q[200005];
int n,m,xx[200005],yy[200005],maxn,ans,v[200005];

void sort(int l,int r)
{
	int i,j,x,y;
	i=l; j=r; x=q[(i+j)/2].x;
	do
	{
		while (q[i].x<x) i++;
		while (x<q[j].x) j--;
		if (i<=j)
		{
			y=q[i].x; q[i].x=q[j].x; q[j].x=y;
			y=q[i].y; q[i].y=q[j].y; q[j].y=y;
			i++; j--;
		}
	} while (i<=j);
	if (l<j) sort(l,j);
	if (i<r) sort(i,r);
	return ;
}

void clb()
{
	int a;
	xx[q[1].x]=1;
	for (a=2;a<=m;a++)
		if (q[a].x!=q[a-1].x)
		{
			yy[q[a-1].x]=a-1;
			xx[q[a].x]=a;
		}
	yy[q[m].x]=m;
	return ;
}

void init()
{
	int a;
	cin>>n; m=n+n-2;
	for (a=1;a<n;a++)
	{
		cin>>q[a+a-1].x>>q[a+a-1].y;
		q[a+a].x=q[a+a-1].y; q[a+a].y=q[a+a-1].x;
	}
	for (a=1;a<=n;a++) cin>>v[a];
	sort(1,m); clb();
	return ;
}

void doit()
{
	int a,i,j,k,max1,max2,num;
	for (a=1;a<=n;a++)
	{
		k=0; max1=0; max2=0;
		for (i=xx[a];i<=yy[a];i++)
		{
			if (v[q[i].y]>max1) { max2=max1; max1=v[q[i].y]; }
			else if (v[q[i].y]>max2) { max2=v[q[i].y]; }
			ans=(ans+(k*v[q[i].y])%10007)%10007;
			k=(k+v[q[i].y])%10007;
		}
		num=max1*max2; if (num>maxn) maxn=num;
	}
	ans=(ans+ans)%10007;
	cout<<maxn<<' '<<ans;
	return ;
}

int main()
{
	init();
	doit();
	cin.close(); cout.close();
	return 0;
}
