#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

const int N = 20010, M = 2010;
int up[N], down[N], Lim_up[N], Lim_down[N], gd[N], g[M], f[2][M];
int n, m, K, thr;

int main() {
	freopen("bird.in", "r", stdin);
	freopen("bird.out", "w", stdout);
	
	scanf("%d%d%d", &n, &m, &K);
	for (int i = 0; i < n; i++) scanf("%d%d", &up[i], &down[i]);
	for (int i = 0; i <= n; i++) Lim_up[i] = m + 1, Lim_down[i] = 0;
	for (int i = 1, p, x, y; i <= K; i++) {
		scanf("%d%d%d", &p, &x, &y);
		Lim_down[p] = x;
		Lim_up[p] = y;
		gd[p] = 1;
	}
	memset(f, 1, sizeof(f));
	for (int i = 1; i <= m; i++) f[0][i] = 0;
	for (int i = 0; i < n; i++) {
		int ii = i & 1, pass = 0;
		memset(g, 1, sizeof(g));
		memset(f[ii ^ 1], 1, sizeof(f[ii ^ 1]));
		for (int j = 1; j <= m; j++) {
			g[j] = f[ii][j];
			if (j - up[i] >= 0) g[j] = min(g[j], g[j - up[i]] + 1);
			
			int k = min(j + up[i], m);
			if (k > Lim_down[i + 1] && k < Lim_up[i + 1]) {
				f[ii ^ 1][k] = min(f[ii ^ 1][k], g[j] + 1);
				if (f[ii ^ 1][k] <= 1e7) pass = 1;
			}
			
			k = j - down[i];
			if (k > Lim_down[i + 1] && k < Lim_up[i + 1]) {
				f[ii ^ 1][k] = min(f[ii ^ 1][k], f[ii][j]);
				if (f[ii ^ 1][k] <= 1e7) pass = 1;
			}
		}
		
		if (pass && gd[i + 1]) thr++;
	}
	
	int ii = n & 1, ans = 1e7;
	for (int i = 1; i <= m; i++) ans = min(ans, f[ii][i]);
	if (ans == 1e7) printf("0\n%d\n", thr); else printf("1\n%d\n", ans);
	return 0;	
}

