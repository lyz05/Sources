#include <cstdio>
#include <cstring>
#include <algorithm>
#include <ctime>
using namespace std;

int ra(int x) {return rand() % x + 1;}

int main() {
	freopen("bird.in", "w", stdout);
	srand(time(0));
	int n = 500, m = 1000, k = n;
	printf("%d %d %d\n", n, m, k);
	for (int i = 1; i <= n; i++) printf("%d %d\n", ra(100), ra(100));
	for (int i = 1; i <= n; i++) printf("%d %d %d\n", i, ra(300) - 1, m + 1 - ra(300));
	
	return 0;	
}

