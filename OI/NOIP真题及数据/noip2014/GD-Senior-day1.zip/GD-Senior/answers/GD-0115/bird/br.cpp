#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

const int N = 2100, M = 1100;

int up[N], down[N], Lim_up[N], Lim_down[N], gd[N], f[N][M];
int n, m, K, thr;

int main() {
	freopen("bird.in", "r", stdin);
	freopen("br.out", "w", stdout);
	
	scanf("%d%d%d", &n, &m, &K);
	for (int i = 0; i < n; i++) scanf("%d%d", &up[i], &down[i]);
	for (int i = 0; i <= n; i++) Lim_up[i] = m + 1, Lim_down[i] = 0;
	for (int i = 1, p, x, y; i <= K; i++) {
		scanf("%d%d%d", &p, &x, &y);
		Lim_down[p] = x;
		Lim_up[p] = y;
		gd[p] = 1;
	}
	
	memset(f, 1, sizeof(f));
	for (int i = 1; i <= m; i++) f[0][i] = 0;
	
	for (int i = 0; i < n; i++) {
		int pass = 0;
		for (int j = Lim_down[i] + 1; j < Lim_up[i]; j++) {
			int k = j - down[i], c;
			if (k > Lim_down[i + 1] && k < Lim_up[i + 1]) {
				f[i + 1][k] = min(f[i + 1][k], f[i][j]);
				if (f[i + 1][k] <= 1e7) pass = 1;
			}
			
			for (k = j, c = 0; ; ) {
				k += up[i]; c++;
				if (gd[i + 1] && k >= Lim_up[i + 1]) break;
				if (!gd[i + 1] && k >= m + up[i]) break;
				k = min(k, m);
				
				if (k > Lim_down[i + 1]) {
					f[i + 1][k] = min(f[i + 1][k], f[i][j] + c);
					if (f[i + 1][k] <= 1e7) pass = 1;
				}

			}
		}
		
		if (pass && gd[i + 1]) thr++;
	}
	
	int ans = 1e7;
	for (int i = 1; i <= m; i++) ans = min(ans, f[n][i]);
	if (ans == 1e7) printf("0\n%d\n", thr); else printf("1\n%d\n", ans);
	
	return 0;	
}

