#include <cstdio>
#include <cstring>
#include <algorithm>
#include <ctime>
using namespace std;

int ra(int x) {return rand() % x + 1;}

int main() {
	freopen("link.in", "w", stdout);
	srand(time(0));
	int n = 2000;
	printf("%d\n", n);
	for (int i = 2; i <= n; i++) printf("%d %d\n", i, ra(i - 1)); puts("");
	for (int i = 1; i <= n; i++) printf("%d ", ra(10000));
	
	return 0;
}

