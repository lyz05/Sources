#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

const int N = 400010, mo = 10007;
int adj[N], next[N], last[N], mm, a[N];
int n, sum, ma;

void Link(int x, int y) {
	adj[++mm] = y; next[mm] = last[x]; last[x] = mm;	
}

void Init() {
	scanf("%d", &n);
	for (int i = 1, x, y; i < n; i++) scanf("%d%d", &x, &y), Link(x, y), Link(y, x);
	for (int i = 1; i <= n; i++) scanf("%d", &a[i]);
}

void Work() {
	for (int u = 1; u <= n; u++) {
		int s = 0, del = 0, ma0 = 0, ma1 = 0;
		for (int p = last[u]; p; p = next[p]) {
			int v = adj[p];
			s = (s + a[v]) % mo;
			del = (del + a[v] * a[v]) % mo;
			
			if (a[v] > ma0) ma1 = ma0, ma0 = a[v]; else if (a[v] > ma1) ma1 = a[v];
		}
		sum = (sum + s * s) % mo;
		sum = (sum - del + mo) % mo;
		
		ma = max(ma, ma0 * ma1);
	}
	
	printf("%d %d\n", ma, sum);
}

int main() {
	freopen("link.in", "r", stdin);
	freopen("link.out", "w", stdout);
	
	Init();
	Work();
	
	return 0;
}

