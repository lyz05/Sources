#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

const int N = 410000, mo = 10007;
int adj[N], next[N], last[N], mm, a[N];
int sum, ma, n;

void Work(int S, int x, int d) {
	if (d == 2) {
		if (x == S) return;
		sum = (sum + a[x] * a[S]) % mo;
		ma = max(ma, a[x] * a[S]);
		return;	
	}
	
	for (int p = last[x]; p; p = next[p]) Work(S, adj[p], d + 1);
}

void Link(int x, int y) {adj[++mm] = y; next[mm] = last[x]; last[x] = mm;}

int main() {
	freopen("link.in", "r", stdin);
	freopen("br.out", "w", stdout);
	
	scanf("%d", &n);
	for (int i = 1, x, y; i < n; i++) scanf("%d%d", &x, &y), Link(x, y), Link(y, x);
	for (int i = 1; i <= n; i++) scanf("%d", &a[i]);
	for (int i = 1; i <= n; i++) Work(i, i, 0);
	printf("%d %d\n", ma, sum);
	
	return 0;	
}

