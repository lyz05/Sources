#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

const int win[5][5] = {{0,0,1,1,0},{1,0,0,1,0},{0,1,0,0,1},{0,0,1,0,1},{1,1,0,0,0}};
const int N = 210;
int a[N], b[N], n, na, nb, sa, sb;

int main() {
	freopen("rps.in", "r", stdin);
	freopen("rps.out", "w", stdout);
	
	scanf("%d%d%d", &n, &na, &nb);
	for (int i = 0; i < na; i++) scanf("%d", &a[i]);
	for (int i = 0; i < nb; i++) scanf("%d", &b[i]);
	for (int i = 0; i < n; i++) {
		int x = a[i % na], y = b[i % nb];
		if (x == y) continue;
		if (win[x][y]) sa++; else sb++;	
	}
	
	printf("%d %d\n", sa, sb);
	
	return 0;	
}

