#include<fstream>
using namespace std;
ifstream fin("link.in");
ofstream fout("link.out");
long n,ans=0,ma=0,a[2001][2001],l[200001],x[200001],y[200001];
int w[200001],f[2001][2001];
int main()
{  long i,s;
	fin>>n;
	for(i=1;i<=n;i++) l[i]=0;
	for(i=1;i<=n-1;i++){
		fin>>x[i]>>y[i];
		f[x[i]][y[i]]=f[y[i]][x[i]]=100;
		if(x[i]>y[i]) {s=x[i]; x[i]=y[i]; y[i]=s;}
	}
	for(i=1;i<=n;i++) fin>>w[i];
	for(i=1;i<=n-1;i++){
		for(s=0;s<l[x[i]];s++){
			if(f[a[x[i]][s]][y[i]]!=100){
			if(w[a[x[i]][s]]*w[y[i]]>ma) ma=w[a[x[i]][s]]*w[y[i]];
			ans+=(w[a[x[i]][s]]*w[y[i]])%10007;
		    }
		}
		for(s=0;s<l[y[i]];s++){
			if(f[a[y[i]][s]][x[i]]!=100){
			if(w[a[y[i]][s]]*w[x[i]]>ma) ma=w[a[y[i]][s]]*w[x[i]];
			ans+=(w[a[y[i]][s]]*w[x[i]])%10007;
		    }
		}
		a[x[i]][l[x[i]]]=y[i]; l[x[i]]++;
		a[y[i]][l[y[i]]]=x[i]; l[y[i]]++;
	}
	fout<<ma<<' '<<(ans*2)%10007<<endl;
	fin.close();
	fout.close();
	return 0;
}
