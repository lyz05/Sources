#include<fstream>
using namespace std;
ifstream fin("rps.in");
ofstream fout("rps.out");
long n,na,nb,ansa=0,ansb=0;
long a[201],b[201];
long cq(long x,long y)
{  if(x==y) return 2;
	if(x==0){
		if(y==1) return 1;
		if(y==4) return 1;
		return 0;
	}
	if(x==1){
		if(y==2) return 1;
		if(y==4) return 1;
		return 0;
	}
	if(x==2){
		if(y==0) return 1;
		if(y==3) return 1;
		return 0;
	}
	if(x==3){
		if(y==0) return 1;
		if(y==1) return 1;
		return 0;
	}
	if(x==4){
		if(y==2) return 1;
		if(y==3) return 1;
		return 0;
	}
}
int main()
{  long i,aa,bb;
	fin>>n>>na>>nb;
	for(i=0;i<na;i++) fin>>a[i];
	for(i=0;i<nb;i++) fin>>b[i];
	for(i=0;i<n;i++){
		aa=(i%na);
		bb=(i%nb);
		if(cq(a[aa],b[bb])==0) ansa++;
		else if(cq(a[aa],b[bb])==1) ansb++;
	}
	fout<<ansa<<' '<<ansb<<endl;
	fin.close();
	fout.close();
	return 0;
}
