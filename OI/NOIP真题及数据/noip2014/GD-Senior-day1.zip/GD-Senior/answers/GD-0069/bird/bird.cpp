#include<fstream>
using namespace std;
ifstream fin("bird.in");
ofstream fout("bird.out");
struct po
{	long x,y,dian,pass;
};
long n,m,k,t,w,ma=0;
long rise[10001],fall[10001];
long p,l[10001],h[10001];
po a[2000001];
bool f[10001][1001],z[10001];
int main()
{  long i,ww;
	fin>>n>>m>>k;
	for(i=0;i<=n-1;i++) {fin>>rise[i]>>fall[i]; z[i]=false;}
	for(i=1;i<=k;i++) {fin>>p; fin>>l[p]>>h[p]; z[p]=true;}
	t=0; w=m;
	for(i=1;i<=m;i++){
		a[t].x=0; a[t].y=i; a[t].dian=0; a[t].pass=0; t++;
	}
	t=0;
	while(t<w){
		if(a[t].x==n) {fout<<1<<endl<<a[t].dian<<endl; break;}
		if(a[t].pass>ma) ma=a[t].pass;
		if(!z[a[t].x+1]){
			for(i=1;a[t].y+i*rise[a[t].x]<m;i++){
				if(!f[a[t].x+1][a[t].y+i*rise[a[t].x]]){
					f[a[t].x+1][a[t].y+i*rise[a[t].x]]=true;
					a[w].x=a[t].x+1; a[w].y=a[t].y+i*rise[a[t].x];
					a[w].dian=a[t].dian+i; a[w].pass=a[t].pass;
					w++;
				}
				else{
					ww=w;
					while(ww>t&&a[ww].x!=a[t].x+1&&a[ww].y!=a[t].y+i*rise[a[t].x]) ww--;
					if(ww>t) {
						if(a[t].dian+i<a[ww].dian) a[ww].dian=a[t].dian+i;
					}
				}
			}
			if(!f[a[t].x+1][m]){
				f[a[t].x+1][m]=true;
				a[w].x=a[t].x+1; a[w].y=m;
				a[w].dian=a[t].dian+i; a[w].pass=a[t].pass;
				w++;
			}
			else{
				ww=w;
				while(ww>t&&a[ww].x!=a[t].x+1&&a[ww].y!=m) ww--;
				if(ww>t) {
					if(a[t].dian+i<a[ww].dian) a[ww].dian=a[t].dian+i;
				}
			}
			if(a[t].y-fall[a[t].x]>0){
				if(!f[a[t].x][a[t].y-fall[a[t].x]]){
					f[a[t].x+1][a[t].y-fall[a[t].x]]=true;
					a[w].x=a[t].x+1; a[w].y=a[t].y-fall[a[t].x];
					a[w].dian=a[t].dian; a[w].pass=a[t].pass;
					w++;
				}
				else{
					ww=w;
					while(ww>t&&a[ww].x!=a[t].x+1&&a[ww].y!=a[t].y-fall[a[t].x]) ww--;
					if(ww>t) {
						if(a[t].dian<a[ww].dian) a[ww].dian=a[t].dian;
					}
				}
			}
		}
		else{
			i=1;
			while(a[t].y+rise[a[t].x]*i<=m){
			if(a[t].y+rise[a[t].x]*i>l[a[t].x+1]&&a[t].y+rise[a[t].x]*i<h[a[t].x+1]){
				if(!f[a[t].x+1][a[t].y+i*rise[a[t].x]]){
					f[a[t].x+1][a[t].y+i*rise[a[t].x]]=true;
					a[w].x=a[t].x+1; a[w].y=a[t].y+i*rise[a[t].x];
					a[w].dian=a[t].dian+i; a[w].pass=a[t].pass+1;
					w++;
				}
				else{
					ww=w;
					while(ww>t&&a[ww].x!=a[t].x+1&&a[ww].y!=a[t].y+i*rise[a[t].x]) ww--;
					if(ww>t) {
						if(a[t].dian+i<a[ww].dian) a[ww].dian=a[t].dian+i;
					}
				}
			}
			i++;
			}
			if(a[t].y-fall[a[t].x]>l[a[t].x+1]&&a[t].y-fall[a[t].x]<h[a[t].x+1]){
				if(!f[a[t].x+1][a[t].y-fall[a[t].x]]){
					f[a[t].x+1][a[t].y-fall[a[t].x]]=true;
					a[w].x=a[t].x+1; a[w].y=a[t].y-fall[a[t].x];
					a[w].dian=a[t].dian; a[w].pass=a[t].pass+1;
					w++;
				}
				else{
					ww=w;
					while(ww>t&&a[ww].x!=a[t].x+1&&a[ww].y!=a[t].y-fall[a[t].x]) ww--;
					if(ww>t) {
						if(a[t].dian<a[ww].dian) a[ww].dian=a[t].dian;
					}
				}
			}
		}
		t++;
	}
	if(t==w) fout<<0<<endl<<ma<<endl;
	fin.close();
	fout.close();
	return 0;
}
