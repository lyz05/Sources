#include <iostream>
#include <fstream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <cstring>
using namespace std;
#define mmst(a, b) memset(a, b, sizeof(a))
#define mmcp(a, b) memcpy(a, b, sizeof(b))

typedef long long LL;

const int maxn = 2*200005, mod = 10007;

int n, asum, amax, w[maxn], mson[maxn], sum[maxn];
int N, head[maxn], o[maxn], fa[maxn];

struct Edge
{
	int v, ne;
	Edge(int _v = 0, int _ne = 0) : v(_v), ne(_ne) {}
}e[maxn*2];

void Insert(int u, int v)
{
	N++;
	e[N] = Edge(v, head[u]);
	head[u] = N;
}

inline void Add(int &a, const int &b)
{
	a = (a+b) % mod;
}

void Bfs(int root)
{
	int h, t, i, u, v, smax;
	
	o[0] = root; fa[root] = 0;
	for (h = t = 0; h <= t; h++)
	{
		u = o[h];
		for (i = head[u]; i != -1; i = e[i].ne)
		{
			v = e[i].v;
			if (v == fa[u]) continue;
			t++;
			o[t] = v;
			fa[v] = u;
		}
	}
	
	for (h = t; h >= 0; h--)
	{
		u = o[h]; smax = 0;
		for (i = head[u]; i != -1; i = e[i].ne)
		{
			v = e[i].v;
			if (v == fa[u]) continue;
			Add(asum, w[u]*sum[v]+sum[u]*w[v]);
			Add(sum[u], w[v]);
			amax = max(amax, mson[v]*w[u]);
			if (w[v] > mson[u]) 
			{
				smax = mson[u];
				mson[u] = w[v];
			} else {
				if (w[v] > smax) smax = w[v];
			}
		}
		amax = max(amax, mson[u]*smax);
	}
}

int main()
{
	int i, u, v;
	
	freopen("link.in", "r", stdin);
	freopen("link.out", "w", stdout);
	
	N = -1; mmst(head, -1);
	
	scanf("%d", &n);
	for (i = 1; i < n; i++)
	{
		scanf("%d%d", &u, &v);
		Insert(u, v);
		Insert(v, u);
	}
	for (i = 1; i <= n; i++) scanf("%d", &w[i]);
	
	amax = 0; asum = 0;
	Bfs(1);
	asum = 2*asum % mod;
	
	printf("%d %d\n", amax, asum);
	
	return 0;
}

