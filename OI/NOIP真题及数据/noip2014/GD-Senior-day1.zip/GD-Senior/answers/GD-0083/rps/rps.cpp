#include <iostream>
#include <fstream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <cstring>
using namespace std;
#define mmst(a, b) memset(a, b, sizeof(a))
#define mmcp(a, b) memcpy(a, b, sizeof(b))

typedef long long LL;

const int score[5][5] = { {0, 0, 1, 1, 0},
						  {1, 0, 0, 1, 0},
						  {0, 1, 0, 0, 1},
						  {0, 0, 1, 0, 1},
						  {1, 1, 0, 0, 0}
						};

const int maxn = 205;

int a[maxn], b[maxn];

int main()
{
	int i, n, na, nb, sa, sb;
	
	freopen("rps.in", "r", stdin);
	freopen("rps.out", "w", stdout);
	
	scanf("%d%d%d", &n, &na, &nb);
	for (i = 0; i < na; i++) scanf("%d", &a[i]);
	for (i = 0; i < nb; i++) scanf("%d", &b[i]);
	
	sa = sb = 0;
	for (i = 0; i < n; i++)
	{
		sa += score[ a[i%na] ][ b[i%nb] ];
		sb += score[ b[i%nb] ][ a[i%na] ];
	}
	
	printf("%d %d\n", sa, sb);
	
	return 0;
}

