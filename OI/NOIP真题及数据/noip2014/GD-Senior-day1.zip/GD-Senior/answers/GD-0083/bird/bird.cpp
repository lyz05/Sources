#include <iostream>
#include <fstream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <cstring>
using namespace std;
#define mmst(a, b) memset(a, b, sizeof(a))
#define mmcp(a, b) memcpy(a, b, sizeof(b))

typedef long long LL;

const int maxn = 10005, oo = 999999999;

int n, m, K, x[maxn], y[maxn], l[maxn], h[maxn], f[2][maxn];

inline int min(const int &a, const int &b)
{
	if (a < b) return a;
	return b;
}

inline void Update(int &a, const int &b)
{
	a = min(a, b);
}

int main()
{
	int i, j, k, p, q, ans, mi;
	
	freopen("bird.in", "r", stdin);
	freopen("bird.out", "w", stdout);
	
	scanf("%d%d%d", &n, &m, &K);
	for (i = 0; i < n; i++) scanf("%d%d", &x[i], &y[i]);
	for (i = 1; i <= n; i++) 
	{
		l[i] = 0;
		h[i] = m+1;
	}
	for (i = 1; i <= K; i++) 
	{
		scanf("%d", &p);
		scanf("%d%d", &l[p], &h[p]);
	}
	
	p = 0; q = 1; ans = 0;
	for (i = 0; i < n; i++)
	{
		swap(p, q);
		for (j = 1; j <= m; j++) f[p][j] = oo;
		for (j = 1; j <= m; j++)
		{
			if (f[q][j] == oo) continue;
			if (j-y[i] > l[i+1] && j-y[i] < h[i+1]) Update(f[p][ j-y[i] ], f[q][j]);
			for (k = 1; h[i+1] == m+1 || j+x[i]*k < h[i+1]; k++) 
			{
				if (j+x[i]*k <= l[i+1]) continue;
				Update(f[p][ min(j+x[i]*k, m) ], f[q][j]+k);
				if (j+x[i]*k >= h[i+1]) break;
			}
			ans = i;
		}
	}
	
	mi = oo;
	for (i = 1; i <= m; i++) Update(mi, f[p][i]);
	if (mi != oo) printf("1\n%d\n", mi);
		else {
			mi = 0;
			for (i = 1; i <= ans; i++) if (h[i] != m+1) mi++;
			printf("0\n%d\n", mi);
		}
	
	return 0;
}

