#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cctype>
#include<vector>
#include<cmath>
#include<queue>
#include<cmath>
#include<ctime>
#include<set>
#include<map>
#define read(a) a=readint()
#define For(i,a,b) for ( int i = a ; i < b ; i++ )
using namespace std ;

typedef long long ll ;
typedef double db ;
typedef long double ldb ;

const int maxn = 200 + 10 ;
const int maxm = 1000 + 10 ;
const int inf = 2147483647 ;
const int mod = 10007 ;
const double eps = 1e-7 ;

const int score[ 5 ][ 5 ] = { { 0 , 0 , 1 , 1 , 0 } , 
							  { 1 , 0 , 0 , 1 , 0 } , 
							  { 0 , 1 , 0 , 0 , 1 } ,
							  { 0 , 0 , 1 , 0 , 1 } ,
							  { 1 , 1 , 0 , 0 , 0 } } ; 

int n , NA , NB ;
int a[ maxn ] , b[ maxn ] ;

int readint ( )
{
	char c = getchar ( );
	while ( !isdigit ( c ) ) c = getchar ( ) ;
	int x = c - '0' ;
	while ( isdigit ( c = getchar ( ) ) ) x = x * 10 + c - '0' ;
	return x ;
}

void input ( )
{
	read ( n ) ;
	read ( NA ) ;
	read ( NB ) ;
	For ( i , 0 , NA ) read ( a[ i ] ) ;
	For ( i , 0 , NB ) read ( b[ i ] ) ;
}

int nxtA ( int i )
{
	i++ ;
	if ( i >= NA ) i %= NA ;
	return i ;
}

int nxtB ( int i )
{
	i++ ;
	if ( i >= NB ) i %= NB ;
	return i ;
}

void solve ( )
{
	int i = 0 , j = 0 ;
	int ans1 = 0 , ans2 = 0 ;
	For ( turn , 0 , n )
	{
		ans1 += score[ a[ i ] ][ b[ j ] ] ;
		ans2 += score[ b[ j ] ][ a[ i ] ] ;
		i = nxtA( i ) ;
		j = nxtB( j ) ;
	}
	cout << ans1 << " " << ans2 << endl ;
}

int main ( )
{
	freopen ( "rps.in" , "r" , stdin ) ;
	freopen ( "rps.out" , "w" , stdout ) ;
	input ( ) ;
	solve ( ) ;
	fclose ( stdin ) ; 
	fclose ( stdout ) ;
	return 0 ;
}

