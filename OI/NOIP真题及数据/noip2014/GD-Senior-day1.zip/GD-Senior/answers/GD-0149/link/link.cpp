#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cctype>
#include<vector>
#include<cmath>
#include<queue>
#include<cmath>
#include<ctime>
#include<set>
#include<map>
#define read(a) a=readint()
#define For(i,a,b) for ( int i = a ; i < b ; i++ )
using namespace std ;

typedef long long ll ;
typedef double db ;
typedef long double ldb ;

const int maxn = 200000 + 10 ;
const int maxm = 1000 + 10 ;
const int inf = 2147483647 ;
const int mod = 10007 ;
const double eps = 1e-7 ;

int n , m ;
vector < int > G[ maxn ] ;
int tot , maxv;
bool vis[ maxn ] ;
int sum[ maxn ] , w[ maxn ] ;

int readint ( )
{
	char c = getchar ( );
	while ( !isdigit ( c ) ) c = getchar ( ) ;
	int x = c - '0' ;
	while ( isdigit ( c = getchar ( ) ) ) x = x * 10 + c - '0' ;
	return x ;
}

void input ( )
{
	read ( n ) ;
	For ( i , 1 , n )
	{
		int u , v ;
		read ( u ) ;
		read ( v ) ;
		G[ u ].push_back ( v ) ;
		G[ v ].push_back ( u ) ;
	}
	For ( i , 1 , n + 1 )
		read ( w[ i ] ) ;
}

void dfs ( int u , int fa , int fa2 )
{
	vis[ u ] = true ;
	sum[ fa2 ] += w[ u ] ;
	sum[ fa2 ] %= mod ;
	int tmp = 0 ;
	int max1 = 0 , max2 = 0 ;
	For ( i , 0 , G[ u ].size ( ) )
	{
		int v = G[ u ][ i ] ;
		if ( v == fa ) continue ;
		dfs ( v , u , fa ) ;
		tmp += w[ v ] ;
		maxv = max ( maxv , w[ v ] * w[ fa ] ) ;
		if ( w[ v ] > max1 )
		{
			max2 = max1 ;
			max1 = w[ v ] ;
		}
		else if ( w[ v ] > max2 )
			max2 = w[ v ] ;
	}
	maxv = max ( maxv , max1 * max2 ) ;
	For ( i , 0 , G[ u ].size ( ) )
	{
		int v = G[ u ][ i ] ;
		if ( v == fa ) continue ;
		tot += int ( ( ll ) w[ v ] * ( tmp - w[ v ] ) ) % mod ;
		tot %= mod ;
	}
}

void solve ( )
{
	maxv = 0 ;
	tot = 0 ;
	dfs ( 1 , 0 , 0 ) ;
	For ( i , 1 , n + 1 ) tot += sum[ i ] * w[ i ] * 2 , tot %= mod ;
	printf ( "%d %d\n" , maxv , tot ) ;
}

int main ( )
{
	freopen ( "link.in" , "r" , stdin ) ;
	freopen ( "link.out" , "w" , stdout ) ;
	input ( ) ;
	solve ( ) ;
	fclose ( stdin ) ; 
	fclose ( stdout ) ;
	return 0 ;
}

