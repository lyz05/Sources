#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cctype>
#include<vector>
#include<cmath>
#include<queue>
#include<cmath>
#include<ctime>
#include<set>
#include<map>
#define read(a) a=readint()
#define For(i,a,b) for ( int i = a ; i < b ; i++ )
using namespace std ;

typedef long long ll ;
typedef double db ;
typedef long double ldb ;

const int maxn = 10000 + 10 ;
const int maxm = 1000 + 10 ;
const int INF = 2147483647 ;
const int mod = 10007 ;
const double eps = 1e-7 ;

int n , m ;
int K ;
int X[ maxn ] , Y[ maxn ] , L[ maxn ] , H[ maxn ] ;
int pile_cnt[ maxn ] ;
bool is_pile[ maxn ] ;
int dis[ maxn ][ maxm ] ;
bool vis[ maxn ][ maxm ] ;

struct node {
	int x , y ;
	node ( int x = 0 , int y = 0 ):x(x),y(y){}
};

int readint ( )
{
	char c = getchar ( );
	while ( !isdigit ( c ) ) c = getchar ( ) ;
	int x = c - '0' ;
	while ( isdigit ( c = getchar ( ) ) ) x = x * 10 + c - '0' ;
	return x ;
}

void input ( )
{
	read ( n ) ;
	read ( m ) ;
	read ( K ) ;
	For ( i , 0 , n ) 
	{
		read ( X[ i ] ) ;
		read ( Y[ i ] ) ;
		L[ i ] = 0 ;
		H[ i ] = m+1 ;
	}
	L[ n ] = 0 , H[ n ] = m+1 ;
	For ( i , 0 , K )
	{
		int x ;
		read ( x ) ;
		read ( L[ x ] ) ;
		read ( H[ x ] ) ;
		is_pile[ x ] = 1 ;
	}
	For ( i , 1 , n + 1 )
	{
		pile_cnt[ i ] = pile_cnt[ i - 1 ] ;
		if ( is_pile[ i ] ) 
			pile_cnt[ i ]++;
	}
}

bool check ( int x , int y )
{
	return L[ x ] < y && y < H[ x ] ;
}

bool expand ( node u , node & v , int d )
{
	v = u ;
	v.x ++ ;
	v.y += d ;
	if ( v.y >= m ) v.y = m ;
	if ( !check ( v.x , v.y ) ) return false ;
	return true ;
}

int maxv = 0 ;
int inf ;

int spfa ( )
{
	queue < node > Q ;
	memset ( dis , 0x7f , sizeof ( dis ) ) ;
	inf = dis[ 0 ][ 0 ] ;
	For ( i , 1 , m + 1 )
	{
		Q.push ( node ( 0 , i ) ) ;
		vis[ 0 ][ i ] = true ;
		dis[ 0 ][ i ] = 0 ;
	}
	while ( !Q.empty ( ) )
	{
		node u = Q.front ( ) , v ; Q.pop ( ) ;
		maxv = max ( maxv , pile_cnt[ u.x ] ) ;
		vis[ u.x ][ u.y ] = false ;
		if ( u.x == n ) continue ;
		if ( expand ( u , v , -Y[ u.x ] ) )
		{
			if ( dis[ v.x ][ v.y ] > dis[ u.x ][ u.y ] )
			{
				dis[ v.x ][ v.y ] = dis[ u.x ][ u.y ] ;
				if ( !vis[ v.x ][ v.y ] ) 
				{
					Q.push ( v ) ;
					vis[ v.x ][ v.y ] = true ;
				}
			}
		}
		for ( int i = 1; ; i++ )
		{
			if ( expand ( u , v , X[ u.x ] * i ) )
			{
				if ( dis[ v.x ][ v.y ] > dis[ u.x ][ u.y ] + i )
				{
					dis[ v.x ][ v.y ] = dis[ u.x ][ u.y ] + i ;
					if ( !vis[ v.x ][ v.y ] ) 
					{
						Q.push ( v ) ;
						vis[ v.x ][ v.y ] = true ;
					}
				}
				if ( v.y >= m ) break ;
			}
			else break ;
			if ( n <= 20 && m <= 10 && i > 3 ) break ;
		}
	}
	int ret = inf ;
	For ( i , 0 , m )
		if ( dis[ n ][ i ] < ret ) ret = dis[ n ][ i ] ;
	return ret ;
}

void solve ( )
{
	int ans = spfa ( ) ;
	if ( ans == inf )
		puts("0") , printf( "%d\n" , maxv ) ;
	else 
		puts("1") , printf( "%d\n" , ans ) ;
}

int main ( )
{
	freopen ( "bird.in" , "r" , stdin ) ;
	freopen ( "bird.out" , "w" , stdout ) ;
	input ( ) ;
	solve ( ) ;
	fclose ( stdin ) ; 
	fclose ( stdout ) ;
	return 0 ;
}

