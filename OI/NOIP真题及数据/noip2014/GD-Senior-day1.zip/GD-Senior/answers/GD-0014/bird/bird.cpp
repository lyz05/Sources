#include<cstdio>
#include<cstring>
#include<algorithm>
#define to(i,l,r) for (int i=l;i<=r;i++)
#define down(i,l,r) for (int i=l;i>=r;i--)
#define maxn 1001
using namespace std;
int main(){
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	  int n,m,k;scanf("%d%d%d",&n,&m,&k);
	  int yon[maxn-1][2];
	     to(i,0,n-1) 
	  scanf("%d%d",&yon[i][0],&yon[i][1]);
	  bool f[maxn][maxn];memset(f,true,sizeof(f));
	  to(i,1,k) {
	    int p,l,h;
		scanf("%d%d%d",&p,&l,&h);
		to(j,1,m-h) f[j][p]=false;
		down(j,m,m-l+1) f[j][p]=false;
		}	 
		int first=0,ans=0,ans2=0;
	     to(i,1,m-yon[0][1]-1)
		  if (f[i+yon[0][1]][1]) {
	   	    first=i;break;};
		 if (first==0) {
		 	 down(i,m-1,yon[0][0]+1)
		 	  if (f[i-yon[0][0]][1]){
		 	  	first=i;ans++;break;
		 	  } 
		 }
	   	if (first==0) 
		   {printf("%d\n%d\n",0,0);
	   	   fclose(stdin);fclose(stdout);
			return 0;}	 	   
	   if (ans==0) first=first+yon[0][1];
	   if (ans==1) first=first-yon[0][0];
	   if (first<0) first=0;
	   to (i,1,n-1)
	     {
	     	if (first+yon[i][1]>=10||!f[first+yon[i][1]][i+1]){
	     	 bool ff=false;
	     	   to(j,1,m/yon[i][1]) {int kkk=first-j*yon[i][0];if (kkk<0) kkk=0;
	     	   if (f[kkk][i+1]) {first=first-j*yon[i][0];
	     	       if (first<0)first=0;
				   ff=true;ans+=j;ans2++;
				   break;}
				}
	         if (!ff) {printf("%d\n%d\n",0,ans2);fclose(stdin);fclose(stdout);
			  return 0;
	         }
		 } else 
		 first=first+yon[i][1];
	     }
	    printf("%d\n%d\n",1,ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
