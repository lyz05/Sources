#include<cstdio>
#include<climits>
#include<cstring>
#include<algorithm>
#define to(i,l,r) for (int i=l;i<=r;i++)
#define maxn 10001
using namespace std;
int main(){
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	  int n,u[maxn],v[maxn],ans[maxn][maxn],w[maxn];
	  memset(ans,0,sizeof(ans));
	  int max=-50000;
	  scanf("%d",&n);
	  to(i,1,n-1) scanf("%d%d",&u[i],&v[i]);
	   to(i,1,n)  scanf("%d",&w[i]);
       to(i,1,n-1) to(j,i+1,n-1) 
		{ if (u[i]==u[j]) 
		   { ans[v[i]][v[j]]=w[v[i]]*w[v[j]];
		  if (ans[v[i]][v[j]]>max)  max=ans[v[i]][v[j]];}
       	  if (u[i]==v[j]) {
       	   ans[v[i]][u[j]]=w[v[i]]*w[u[j]];
       	    if (ans[v[i]][u[j]]>max) max=ans[v[i]][u[j]];}
			 if (v[i]==u[j]) {
			 ans[u[i]][v[j]]=w[u[i]]*w[v[j]];
              if (ans[u[i]][v[j]]>max) max=ans[u[i]][v[j]];}
       	  if (v[i]==v[j]) { ans[u[i]][u[j]]=w[u[i]]*w[u[j]];
	         if (ans[u[i]][u[j]]>max) max=ans[u[i]][u[j]];}
	   }
	   int sum=0;
	   to(i,1,n) to(j,1,n) 
	    if (ans[i][j]!=0) 
		 {sum+=ans[i][j];sum=sum%10007;}
	   sum=sum*2;sum=sum%10007;
	   printf("%d %d",max,sum);
	fclose(stdin);fclose(stdout);
	return 0;
}
