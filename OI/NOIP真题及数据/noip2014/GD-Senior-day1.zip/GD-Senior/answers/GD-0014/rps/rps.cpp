#include<cstdio>
#include<cstring>
#include<algorithm>
#define to(i,l,r) for (int i=l;i<=r;i++)
#define down(i,l,r) for (int i=l;i>=r;i--)
#define maxn 201
using namespace std;
int opt[5][5];
int main(){
	int n,na,nb,a[maxn],b[maxn];
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	scanf("%d%d%d",&n,&na,&nb);
	to(i,1,na) scanf("%d",&a[i]);
	to(i,1,nb) scanf("%d",&b[i]);
	opt[0][0]=0;opt[0][1]=-1;opt[0][2]=1;opt[0][3]=1;opt[0][4]=-1;
    opt[1][0]=1;opt[1][1]=0;opt[1][2]=-1;opt[1][3]=1;opt[1][4]=-1;
    opt[2][0]=-1;opt[2][1]=1;opt[2][2]=0;opt[2][3]=-1;opt[2][4]=1;
    opt[3][0]=-1;opt[3][1]=-1;opt[3][2]=1;opt[3][3]=0;opt[3][4]=1;
    opt[4][0]=1;opt[4][1]=1;opt[4][2]=-1;opt[4][3]=-1;opt[4][4]=0;
	int nowa=0,nowb=0,ansa=0,ansb=0;
	to(i,1,n) {
		nowa++;nowb++;
		if (nowa>na) nowa=1;
		if (nowb>nb) nowb=1;
		if (opt[a[nowa]][b[nowb]]==-1) ansb++;
		else
		if (opt[a[nowa]][b[nowb]]==1) ansa++;
	}
	printf("%d %d",ansa,ansb);
	fclose(stdin);fclose(stdout);
	return 0;
}
