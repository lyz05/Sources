#include<algorithm>
#include<cstring>
#include<cstdlib>
#include<cstdio>
using namespace std;
const int maxn=200000+10;
const int Mod=10007;
int fre,head[maxn],node[maxn*2],next[maxn*2];
int N,w[maxn],sum[maxn],ans1,ans2;
int work(int );
int calcsum(int );
void add(int ,int );
int main()
{
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	memset(head,-1,sizeof(head));
	scanf("%d",&N);
	for (int i=1;i<N;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		add(x,y);  add(y,x);
	}
	for (int i=1;i<=N;i++)
	scanf("%d",&w[i]);
	for (int i=1;i<=N;i++)
	sum[i]=calcsum(i);
	for (int i=1;i<=N;i++)
	ans2=(ans2+work(i))%Mod;
	printf("%d %d\n",ans1,(ans2+Mod)%Mod);
	return 0;
}
int calcsum(int u)
{
	int Max1=0,Max2=0,tmp=0;
	for (int i=head[u];i!=-1;i=next[i])
	{
		int v=node[i];
		if (w[v]>Max2) Max2=w[v];
		if (w[v]>Max1) Max2=Max1,Max1=w[v];
		tmp=(tmp+w[v])%Mod;
	}
	ans1=max(ans1,Max1*Max2);
	return tmp;
}
int work(int u)
{
	int tmp=0;
	for (int i=head[u];i!=-1;i=next[i])
	{
		int v=node[i];
		tmp=(tmp+w[u]*(sum[v]-w[u]))%Mod;
	}
	return tmp;
}
void add(int u,int v)
{
	node[fre]=v;
	next[fre]=head[u];
	head[u]=fre;
	fre++;
	return ;
}
