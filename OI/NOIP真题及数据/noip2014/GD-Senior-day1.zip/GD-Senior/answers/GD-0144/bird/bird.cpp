#include<algorithm>
#include<cstring>
#include<cstdlib>
#include<cstdio>
using namespace std;
const int oo=10000000+10;
const int maxn=10000+10;
const int maxm=1000+10;
int N,M,K,L[maxn],H[maxn],x[maxn],y[maxn];
int sum[maxn],F[2][maxm];
int main()
{
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	scanf("%d%d%d",&N,&M,&K);
	for (int i=1;i<=N;i++)
	{
		scanf("%d%d",&x[i],&y[i]);
		L[i]=1,H[i]=M;
	}
	L[0]=1,H[0]=M;
	for (int i=1;i<=K;i++)
	{
		int a,b,c;
		scanf("%d%d%d",&a,&b,&c);
		L[a]=b+1,H[a]=c-1;
		sum[a]++;
	}
	for (int i=1;i<=N+1;i++)
	sum[i]+=sum[i-1];
	for (int i=1;i<=N;i++)
	{
		int i1=i&1;
		int i2=i1^1;
		bool bo=false;
		memset(F[i1],-1,sizeof(F[i1]));
		for (int j=L[i-1];j<=H[i-1];j++)
		if (F[i2][j]>=0)
		{
			bo=true;

			if (j>y[i]) 
			{
				if (F[i1][j-y[i]]!=-1)F[i1][j-y[i]]=min(F[i1][j-y[i]],F[i2][j]);
						else F[i1][j-y[i]]=F[i2][j];
			}
			for (int k=1;k*x[i]+j<=H[i];k++)
			if (F[i1][k*x[i]+j]==-1) F[i1][k*x[i]+j]=F[i2][j]+k;
					    else F[i1][k*x[i]+j]=min(F[i1][k*x[i]+j],F[i2][j]+k);
	
			int tmp=(M-j)/x[i]+1;
			if (H[i]==M)
			{
				if (F[i1][M]==-1) F[i1][M]=F[i2][j]+tmp;
					     else F[i1][M]=min(F[i1][M],F[i2][j]+tmp);
			}
			
		}
		if (!bo)
		{
			printf("0\n%d\n",sum[i]-1);
			return 0;
		}
	}
	int ans=oo;
	for (int j=L[N];j<=H[N];j++)
	if (F[N&1][j]!=-1) ans=min(ans,F[N&1][j]);
	if (ans==oo) printf("0\n%d\n",sum[N]-1);
		else printf("1\n%d\n",ans);
	return 0;
}
