#include<algorithm>
#include<cstring>
#include<cstdlib>
#include<cstdio>
using namespace std;
int N,NA,NB,ansA,ansB,a[222],b[222];
int F[10][10];

int main()
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	F[0][0]=0,F[0][1]=-1,F[0][2]=1,F[0][3]=1,F[0][4]=-1;
	F[1][0]=1,F[1][1]=0,F[1][2]=-1,F[1][3]=1,F[1][4]=-1;
	F[2][0]=-1,F[2][1]=1,F[2][2]=0,F[2][3]=-1,F[2][4]=1;
	F[3][0]=-1,F[3][1]=-1,F[3][2]=1,F[3][3]=0,F[3][4]=1;
	F[4][0]=1,F[4][1]=1,F[4][2]=-1,F[4][3]=-1,F[4][4]=0;
	/*for (int i=0;i<5;i++)
	{
	    for (int j=0;j<5;j++)
	    printf("%d ",F[i][j]);
	    printf("\n");
	    }*/
	scanf("%d%d%d",&N,&NA,&NB);
	for (int i=0;i<NA;i++) scanf("%d",&a[i]);
	for (int i=0;i<NB;i++) scanf("%d",&b[i]);
	for (int i=0;i<N;i++)
	{
		int ai=a[i%NA],bi=b[i%NB];
		if (F[ai][bi]==0) continue;
		if (F[ai][bi]>0) ansA++;
	 	        	 else ansB++;
	}
	printf("%d %d\n",ansA,ansB);
	return 0;
}
