#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#include<ctime>

int f[1010];
int main()
{
	freopen("link.in", "w", stdout);
	srand((int)time(0));
	int n=rand()%10;
	printf("%d\n", n);
	memset(f, 0, sizeof(f));
	for (int i=1; i<=n; i++)
	{
		while (1)
		{
			int v=rand()%n+1;
			if (f[v]<2 && i!=v) 
			{
				printf("%d %d\n", i, v);
				f[i]++; f[v]++;
				break;
			}
		}
	}
	for (int i=1; i<=n; i++)
		printf("%d\n", rand()%10);
}
