#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#define MAXN 10010
#define MAXM 1010

using namespace std;
struct node
{
	int u, d;
	node(){
		u=d=-1;
	}
}r[MAXN];
bool v[MAXN];
int up[MAXN], down[MAXN];
int f[MAXN][MAXM];


int main()
{
	freopen("bird.in", "r", stdin);
	freopen("bird.out", "w", stdout);
	int n, m, t;
	scanf("%d%d%d", &n, &m, &t);
	for (int i=1; i<=n; i++) scanf("%d%d", &up[i], &down[i]);
	memset(v, 0, sizeof(v));
	for (int i=1; i<=t; i++)
	{
		int p;
		scanf("%d", &p);
		p++;
		scanf("%d%d", &r[p].d, &r[p].u);
		v[p]=1;
	}
	for (int i=1; i<=n+1; i++) 
		if (r[i].d==-1) 
		{
			r[i].d=0;
			r[i].u=MAXN;
		}
	
	for (int i=1; i<=n+1; i++) 
		for (int j=1; j<=m; j++) f[i][j]=-1;
	for (int i=1; i<=m; i++) f[1][i]=0;
	
	int s=0;
	for (int i=1; i<=n; i++)
	{
		bool tg=false;
		for (int j=m; j>=1; j--)
			if (f[i][j]!=-1)
			{	
				int k=1, news=j+up[i];
				if (news>m) news=m;
				while (news<r[i+1].u) 
				{
					if (news>r[i+1].d)
						if (f[i+1][news]=-1 || f[i+1][news]>f[i][j]+k)
						{
							tg=true; 
							f[i+1][news]=f[i][j]+k;
						}
					if (news==m) break;
					k++;
					news+=up[i];
					if (news>m) news=m;
				}
			}
		for (int j=m; j>=1; j--)
			if (f[i][j]!=-1)
			{
				int news=j-down[i];
				if (news<r[i+1].u && news>r[i+1].d)
					if (f[i+1][news]==-1 || f[i+1][news]>f[i][j])
					{
						tg=true;
						f[i+1][news]=f[i][j];
					}
			}
		if (!tg) 
		{
			printf("0\n%d", s); 
	    	return 0;
		} else if (v[i+1]) s++; 
	}
	
	int ans=2100000000;
	for (int i=1; i<=m; i++)
		if (f[n+1][i]!=-1) ans=min(f[n+1][i], ans);
	printf("1\n%d\n", ans);
	for (int i=1; i<=n+1; i++)
	{
		for (int j=0; j<=m; j++) 
			printf("%4d", f[i][j]); 
		printf("\n");
	}
	return 0;
}
