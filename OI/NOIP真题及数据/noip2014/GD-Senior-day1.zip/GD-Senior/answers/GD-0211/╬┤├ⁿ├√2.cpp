#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#include<vector>
#define MAXN 201000
#define MOD 10007

using namespace std;
vector<int> G[MAXN];
int w[MAXN], fa[MAXN];
int fmax, sum;

void build(int u, int dep)
{
	if (dep>=3)
	{
		int p=fa[ fa[u] ];
		sum=(sum+w[p]*w[u])%MOD;
		fmax=max(fmax, w[p]*w[u]);
	}
	int lenn=G[u].size();
	for (int v=0; v<lenn; v++)
		if (G[u][v]!=fa[u]) 
		{
			fa[v]=u;
			build(v, dep+1);
		}
	return;
}

int main()
{
	freopen("link.in", "r", stdin);
	freopen("link.out", "w", stdout);
	int n;
	scanf("%d", &n);
	for (int i=1; i<=n; i++)
	{
		int u, v;
		scanf("%d%d", &u, &v);
		G[u].push_back(v);
		G[v].push_back(u);
	}
	for (int i=1; i<=n; i++) scanf("%d", &w[i]);
	
	sum=0, fmax=2100000000;
	memset(fa, 0, sizeof(fa));
	build(1, 1);
	
	memset(fa, 0, sizeof(fa));
	int v=G[1][0];
	build(v, 1);
	
	printf("%d %d", fmax, sum);
}
