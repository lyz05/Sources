#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cstdlib>

using namespace std;
int v[6][6]=
{{0,  -1, 1, 1, -1},
 {1,  0, -1, 1, -1},
 {-1, 1, 0, -1, 1},
 {-1,-1, 1, 0 , 1},
 {1,  1, -1,-1, 0}
};
int a[1000], b[1000];
int main()
{
	freopen("rps.in", "r", stdin);
	freopen("rps.out", "w", stdout);
	int n, la, lb;
	scanf("%d%d%d", &n, &la, &lb);
	for (int i=1; i<=la; i++) scanf("%d", &a[i]);
	for (int i=1; i<=lb; i++) scanf("%d", &b[i]);
	int l=0, r=0, sa=0, sb=0;
	for (int i=1; i<=n; i++)
	{
		l++; r++;
		if (l>la) l=1; if (r>lb) r=1;
		if (v[ a[l] ][ b[r] ] == 1) sa++;
		if (v[ a[l] ][ b[r] ] == -1) sb++;
	}
	printf("%d %d\n", sa, sb);
	return 0;
}
