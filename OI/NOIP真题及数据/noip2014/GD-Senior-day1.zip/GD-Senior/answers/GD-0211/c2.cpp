#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#define MAXN 1000
#define MOD 10007

using namespace std;
int f[MAXN][MAXN], w[MAXN];

int main()
{
	freopen("link.in", "r", stdin);
	freopen("link.out", "w", stdout);
	int n;
	scanf("%d", &n);
	memset(f, 0, sizeof(f));
	for (int i=1; i<n; i++)
	{
		int u, v;
		scanf("%d%d", &u, &v);
		f[u][v]=f[v][u]=1;
	}
	for (int i=1; i<=n; i++) scanf("%d", &w[i]);
	
	int fmax=0, sum=0;
	for (int i=1; i<=n; i++)
		for (int j=1; j<=n; j++)
			if (i!=j)
				for (int k=1; k<=n; k++)
					if (f[i][k] && f[k][j]) 
					{
						fmax=max(fmax, w[i]*w[j]);
						sum=(sum+w[i]*w[j])%MOD;
					}
	printf("%d %d", fmax, sum);
}
