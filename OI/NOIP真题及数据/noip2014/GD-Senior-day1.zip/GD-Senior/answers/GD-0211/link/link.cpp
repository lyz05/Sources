#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#include<vector>
#define MAXN 1000
#define MOD 10007


using namespace std;
int f[MAXN][MAXN], w[MAXN];
vector<int>G[MAXN];

int main()
{
	freopen("link.in", "r", stdin);
	freopen("link.out", "w", stdout);
	int n;
	scanf("%d", &n);
	memset(f, 0, sizeof(f));
	for (int i=1; i<n; i++)
	{
		int u, v;
		scanf("%d%d", &u, &v);
		G[u].push_back(v);
		G[v].push_back(u);
	}
	for (int i=1; i<=n; i++) scanf("%d", &w[i]);
	
	int fmax=0, sum=0;
	for (int i=1; i<=n; i++)
		for (int j=1; j<=n; j++)
			if (i!=j)
				for (int p=0; p<G[i].size(); p++)
					for (int q=0; q<G[j].size(); q++)
						if (G[i][p]==G[j][q])
						{
							fmax=max(fmax, w[i]*w[j]);
							sum=(sum+w[i]*w[j])%MOD;
						}
	printf("%d %d", fmax, sum);
}
