#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#include<ctime>

using namespace std;
char s[100];
int main()
{
	freopen("result.txt", "r", stdin);
	gets(s);
	gets(s);
	if (s[0]=='*') while (1);
}
