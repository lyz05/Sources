#include<cstdio>
#include<cstring>
using namespace std;

const int N = 205;

#define fo(i , st , en) for (int i = st; i <= en; i++)
#define Me(x , y) memset(x , y , sizeof(x))

int v[5][5] ={
{0 , 0 , 1 , 1 , 0},
{1 , 0 , 0 , 1 , 0},
{0 , 1 , 0 , 0 , 1},
{0 , 0 , 1 , 0 , 1},
{1 , 1 , 0 , 0 , 0},
};

int n , na , nb;
int a[N] , b[N];

int main(){
	freopen("rps.in" , "r" , stdin);
	freopen("rps.out" , "w" , stdout);
	scanf("%d%d%d" , &n , &na , &nb);
	fo (i , 1 , na) scanf("%d" , a + i);
	fo (i , 1 , nb) scanf("%d" , b + i);
	fo (i , na + 1 , n) a[i] = a[i - na];
	fo (i , nb + 1 , n) b[i] = b[i - nb];
	int scoreA = 0 , scoreB = 0;
	fo (i , 1 , n){
		scoreA += v[a[i]][b[i]]; scoreB += v[b[i]][a[i]];
	}
	printf("%d %d\n" , scoreA , scoreB);
	return 0;
}

