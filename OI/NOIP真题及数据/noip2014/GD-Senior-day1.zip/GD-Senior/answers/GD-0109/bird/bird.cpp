#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;

const int N = 10005 , M = 1005 , inf = (int)1e9;

#define fo(i , st , en) for (int i = st; i <= en; i++)
#define Me(x , y) memset(x , y , sizeof(x))

struct _two{
	int a , b;
}a[N] , p[N];

int n , m , k , num;
int f[N][M];

void Init(){
	scanf("%d%d%d" , &n , &m , &k); int x , y , z;
	fo (i , 1 , n) scanf("%d%d" , &a[i].a , &a[i].b);
	fo (i , 1 , k){
		scanf("%d%d%d" , &x , &y , &z); p[x] = (_two){y , z};
	}
}

void Work(){
	Me(f , 127);
	fo (i , 1 , m) f[0][i] = 0;
	fo (i , 1 , n){
		fo (j , a[i].a + 1 , m - 1)
			f[i][j] = min(min(f[i][j - a[i].a] , f[i - 1][j - a[i].a]) + 1 , inf);
		fo (j , max(1 , m - a[i].a) , m)
			f[i][m] = min(f[i][m] , min(f[i][j] , f[i - 1][j]) + 1);
		fo (j , 1 , m - a[i].b) f[i][j] = min(f[i][j] , f[i - 1][j + a[i].b]);
		if (p[i].b){
			fo (j , 1 , p[i].a) f[i][j] = inf;
			fo (j , p[i].b , m) f[i][j] = inf;
			bool flag = 0;
			fo (j , 1 , m)
				if (f[i][j] < inf){
					flag = 1; break;
				}
			if (!flag){
				printf("0\n%d\n" , num); return;
			}
			num++;
		}
	}
	int Min = inf;
	fo (i , 1 , m) Min = min(Min , f[n][i]);
	printf("1\n%d\n" , Min);
}

int main(){
	freopen("bird.in" , "r" , stdin);
	freopen("bird.out" , "w" , stdout);
	Init();
	Work();
	return 0;
}

