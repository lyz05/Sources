#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;

const int N = 200005 , mod = 10007;

#define fo(i , st , en) for (int i = st; i <= en; i++)
#define Me(x , y) memset(x , y , sizeof(x))

struct _two{
	int a , b;
}edge[N + N];

int n , ans1 , ans2;
int st[N] , w[N] , qu[N] , flag[N];

void Init(){
	scanf("%d" , &n); int x , y , tot = 0;
	fo (i , 2 , n){
		scanf("%d%d" , &x , &y);
		edge[++tot] = (_two){y , st[x]}; st[x] = tot;
		edge[++tot] = (_two){x , st[y]}; st[y] = tot;
	}
	fo (i , 1 , n) scanf("%d" , w + i);
}

void Work(){
	int be = 0 , en = 1; qu[1] = 1;
	while (be < en){
		int x = qu[++be] , sum = 0 , Max = 0; flag[x] = 1;
		for (int i = st[x]; i; i = edge[i].b){
			if (!flag[edge[i].a]) qu[++en] = edge[i].a;
			int y = w[edge[i].a];
			ans1 = max(ans1 , Max * y); ans2 = (ans2 + sum * y) % mod;
			Max = max(Max , y); sum = (sum + y) % mod;
		}
	}
	printf("%d %d\n" , ans1 , ans2 * 2 % mod);
}

int main(){
	freopen("link.in" , "r" , stdin);
	freopen("link.out" , "w" , stdout);
	Init();
	Work();
	return 0;
}

