#include <fstream>
#include <iostream>
#include <algorithm>
#include <string.h>
#include <string>
#include <time.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <map>
#include <vector>
using namespace std;

const int maxn = 400 + 2;

const bool win[5][5] = {
	{0, 0, 1, 1, 0}, 
	{1, 0, 0, 1, 0}, 
	{0, 1, 0, 0, 1}, 
	{0, 0, 1, 0, 1}, 
	{1, 1, 0, 0, 0}
};

int n, na, nb;
int a[maxn], b[maxn];

void Init() {
	cin >> n >> na >> nb;
	for (int i = 0; i < na; i++) cin >> a[i];
	for (int i = 0; i < nb; i++) cin >> b[i];		
}

void Solve() {
	int t = 0, g = 0;
	int s1 = 0, s2 = 0;
	for (int i = 0; i < n; i++) {
		if (win[ a[t] ][ b[g] ]) s1++;
		if (win[ b[g] ][ a[t] ]) s2++;
		t = (t + 1) % na;
		g = (g + 1) % nb;
	}
	cout << s1 << ' ' << s2 << endl;
}

int main() {
	freopen("rps.in", "r", stdin);
	freopen("rps.out", "w", stdout);
	
	Init();
	Solve();
	
	return 0;
}


