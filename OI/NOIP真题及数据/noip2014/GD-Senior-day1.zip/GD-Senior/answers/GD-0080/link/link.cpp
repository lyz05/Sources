#include <fstream>
#include <iostream>
#include <algorithm>
#include <string.h>
#include <string>
#include <time.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <map>
#include <vector>
using namespace std;

const int maxn = 200000 + 2;
const int inf = 2000000001;
const int mod = 10007;

struct Tedge {
	int v, next;
} e[maxn * 2];

int N;
int head[maxn];

void insert(int x, int y) {
	e[N].v = y;
	e[N].next = head[x];
	head[x] = N;
	N++;
}

int n;
int w[maxn];

void Init() {
	int x, y;
	scanf("%d", &n);
	N = 0;
	for (int i = 0; i < n; i++) head[i] = -1;
	for (int i = 0; i < n - 1; i++) {
		scanf("%d%d", &x, &y);
		x--;
		y--;
		insert(x, y);
		insert(y, x);
	}
	for (int i = 0; i < n; i++)
		scanf("%d", &w[i]);
}

int o[maxn], anc[maxn];

void Solve() {
	int h = 0, t = 0;
	o[h] = 0;
	anc[0] = -1;
	while (h <= t) {
		int cur = o[h];
		for (int i = head[cur]; i != -1; i = e[i].next) {
			int v = e[i].v;
			if (anc[cur] == v) continue;
			anc[v] = cur;
			t++;
			o[t] = v;
		}
		h++;
	}
	
	int best = 0, sum = 0;
	for (int i = t; i > -1; i--) {
		int cur = o[i], first = -inf, second = -inf, tot = 0;
		for (int j = head[cur]; j != -1; j = e[j].next) {
			int v = e[j].v;
			if (anc[cur] == v) continue;
			tot = (tot + w[v]) % mod;
			if (w[v] > first) {
				second = first;
				first = w[v];
			}
			else if (w[v] > second) {
				second = w[v];
			}
		}
		for (int j = head[cur]; j != -1; j = e[j].next) {
			int v = e[j].v;
			if (anc[cur] == v) continue;
			sum = (sum + (tot - w[v]) * w[v]) % mod;
			if (w[v] == first) {
				if (second != -inf) best = max(best, w[v] * second);
			}
			else best = max(best, w[v] * first);
		}
		if (anc[cur] != -1 && anc[ anc[cur] ] != -1) {
			int t = anc[ anc[cur] ];
			sum = (sum + w[t] * w[cur] * 2) % mod;
			best = max(best, w[t] * w[cur]);
		}
	}
	cout << best << ' ' << (((sum % mod) + mod) % mod) << endl;
	//printf("%d %d\n", best, ((sum % mod) + mod) % mod);
}

int main() {
	freopen("link.in", "r", stdin);
	freopen("link.out", "w", stdout);

	Init();
	Solve();
		
	return 0;
}


