#include <fstream>
#include <iostream>
#include <algorithm>
#include <string.h>
#include <string>
#include <time.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <map>
#include <vector>
using namespace std;

const int maxn = 10000 + 10;
const int maxm = 1000 + 10;
const int inf = 2000000001;

int n, m, k;
int x[maxn], y[maxn], Low[maxn], Top[maxn], block[maxn];
int f[maxn][maxm];

void Init() {
	int p;
	scanf("%d%d%d", &n, &m, &k);
	for (int i = 0; i < n; i++) {
		scanf("%d%d", &x[i], &y[i]);
	}
	for (int i = 0; i <= n; i++) {
		Low[i] = 0;
		Top[i] = m + 1;
	}
	for (int i = 0; i <= n; i++) block[i] = 0;
	for (int i = 0; i < k; i++) {
		scanf("%d", &p);
		scanf("%d%d", &Low[p], &Top[p]);
		block[p]++;
	}
	for (int i = 1; i <= n; i++) block[i] += block[i - 1];
}

void Solve() {
	bool reach = false;
	int best = inf;
	
	for (int i = 1; i <= m; i++) f[0][i] = 0;
	f[0][0] = inf;
	
	for (int i = 1; i <= n; i++) {
		for (int j = 0; j < x[i - 1]; j++) {
			int cur = j + x[i - 1];
			best = inf;
			f[i][j] = inf;
			while (cur <= m) {
				if (best != inf) best += 1;
				best = min(best, f[i - 1][ cur - x[i - 1] ] + 1);
				f[i][cur] = best;
				cur += x[i - 1];
			}
		}
		for (int j = 0; j <= m; j++) f[i][m] = min(f[i][m], f[i - 1][j] + (m - j) / x[i - 1] + 1);
		for (int j = 0; j <= m; j++)
			if (j + y[i - 1] <= m) f[i][j] = min(f[i][j], f[i - 1][j + y[i - 1]]);
			
		for (int j = 0; j <= Low[i]; j++) f[i][j] = inf;
		for (int j = Top[i]; j <= m; j++) f[i][j] = inf;
	}
	
	/*for (int i = 0; i <= n; i++) {
		for (int j = 0; j <= m; j++) cout << f[i][j] << ' ';
		cout << endl;
	}*/
	
	for (int i = 1; i <= m; i++)
		if (f[n][i] < inf) {
			reach = true;
			best = min(best, f[n][i]);
		}
	if (reach) {
		cout << 1 << endl << best << endl;
		//printf("1\n");
		//printf("%d\n", best);
		return ;
	}
	
	cout << 0 << endl;
	//printf("0\n");
	for (int i = n - 1; i > -1; i--) {
		for (int j = 0; j <= m; j++)
			if (f[i][j] < inf) {
				cout << block[i] << endl;
				//printf("%d\n", block[i]);
				return ;
			}		
	}
}

int main() {
	freopen("bird.in", "r", stdin);
	freopen("bird.out", "w", stdout);

	Init();
	Solve();
	return 0;
}


