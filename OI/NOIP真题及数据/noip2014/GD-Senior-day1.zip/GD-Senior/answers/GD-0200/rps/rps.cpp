#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
#define fo(i,a,b) for(int i=a;i<=b;i++)
#define fd(i,a,b) for(int i=a;i>=b;i--)
using namespace std;
typedef long long ll;
int a[400],b[400];
int ans[5][5]={{2,0,1,1,0},
               {1,2,0,1,0},
			   {0,1,2,0,1},
			   {0,0,1,2,1},
			   {1,1,0,0,2}
			   };
int main()
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	int n,na,nb;
	cin>>n>>na>>nb;
	fo(i,1,na) cin>>a[i];
	fo(i,na+1,n) a[i]=a[i-na];
	fo(i,1,nb) cin>>b[i];
	fo(i,nb+1,n) b[i]=b[i-nb];
	int outa=0,outb=0;
	fo(i,1,n) if (ans[a[i]][b[i]]==0) outb++; else
	if (ans[a[i]][b[i]]==1) outa++;
	cout<<outa<<' '<<outb;
	return 0;
}
