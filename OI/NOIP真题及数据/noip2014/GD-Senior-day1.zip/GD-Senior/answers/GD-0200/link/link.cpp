#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
#define fo(i,a,b) for(int i=a;i<=b;i++)
#define fd(i,a,b) for(int i=a;i>=b;i--)
using namespace std;
const int mo=10007;
typedef long long ll;
const int N=210000,M=N*2;
int bf[N],n,a[N],st[N],en[M],next[M],fa[N];
int f[N][2],ans1=0,ans2=0;
void dfs()
{
	int top=0,tail=1;
	bf[1]=1;
	while (top<tail)
	{
		int x=bf[++top];
		for(int i=st[x];i;i=next[i])
		if (fa[x]!=en[i])
		{
			fa[en[i]]=x;
			bf[++tail]=en[i];
		}
	}
	fd(i,n,1)
	{
		int x=bf[i],m1=0,m2=0,sum1=0,sum2=0;
		for(int i=st[x];i;i=next[i])
		if (en[i]!=fa[x])
		{
			f[x][0]=(f[x][0]+a[en[i]])%mo;
			f[x][1]=max(f[x][1],a[en[i]]);
			ans1=(ans1+f[en[i]][0]*a[x]*2)%mo;
			ans2=max(ans2,f[en[i]][1]*a[x]);
			if (a[en[i]]>m1)
			{
				m2=m1;
				m1=a[en[i]];
			} else
			if (a[en[i]]>m2) m2=a[en[i]];
			sum1=(sum1+a[en[i]])%mo;
			sum2=((sum2+a[en[i]]*a[en[i]])%mo+mo)%mo;
		}
		ans2=max(ans2,m1*m2);
		ans1=((ans1+sum1*sum1-sum2)%mo+mo)%mo;
	}
}
int T;
void insert(int x,int y)
{
	next[++T]=st[x];
	st[x]=T;
	en[T]=y;
}
int main()
{
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	cin>>n;
	fo(i,1,n-1)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		insert(x,y);
		insert(y,x);
	}
	fo(i,1,n) scanf("%d",&a[i]);
	dfs();
	cout<<ans2<<' '<<(ans1%mo+mo)%mo;
	return 0;
}
