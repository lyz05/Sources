#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
#define fo(i,a,b) for(int i=a;i<=b;i++)
#define fd(i,a,b) for(int i=a;i>=b;i--)
using namespace std;
const int mo=10007;
typedef long long ll;
const int N=2000;
ll a[N],f[N][N];
int main()
{
	freopen("link.in","r",stdin);
	freopen("linkpio.out","w",stdout);
	ll n;
	cin>>n;
	fo(i,1,n-1)
	{
		int x,y;
		cin>>x>>y;
		f[x][y]=1;
		f[y][x]=1;
	}
	ll ans1=0,ans2=0;
	fo(i,1,n) cin>>a[i];
	fo(i,1,n)
	   fo(j,1,n)
	      fo(k,1,n)
	      if (i!=j && j!=k && i!=k)
	      if (f[i][j] && f[j][k])
	      ans1=(ans1+a[i]*a[k])%mo,
	      ans2=max(ans2,a[i]*a[k]);
	cout<<ans2<<' '<<ans1;
}




