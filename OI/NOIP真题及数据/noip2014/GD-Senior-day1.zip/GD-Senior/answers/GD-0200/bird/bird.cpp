#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
#define fo(i,a,b) for(int i=a;i<=b;i++)
#define fd(i,a,b) for(int i=a;i>=b;i--)
using namespace std;
const int N=11000,M=1100;
typedef long long ll;
int f[2][M],up[N],down[N],xx[N],yy[N];
int here[N];
int main()
{
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	int n,m,p;
	cin>>n>>m>>p;
	fo(i,1,n) scanf("%d%d",&xx[i],&yy[i]);
	n++;
	fo(i,1,n) up[i]=m,down[i]=1;
	fo(i,1,p)
	{
		int a,b,c;
		scanf("%d%d%d",&a,&b,&c);
		a++;
		up[a]=min(up[a],c-1);
		down[a]=max(down[a],b+1);
		here[a]++;
	}
	int now=0,last=1;
	memset(f[0],0,sizeof(f[0]));
	f[0][0]=-1;
	fo(i,2,n)
	{
		here[i]+=here[i-1];
		now^=1;
		last^=1;
		bool ok=0;
		memset(f[now],-1,sizeof(f[now]));
		int x=xx[i-1],y=yy[i-1];
		if (up[i]==m)
		fo(j,down[i-1],up[i-1])
		if (f[last][j]!=-1)
		if (f[now][m]==-1 || f[last][j]+(m==j?1:((m-j-1)/x+1))<f[now][m])
		f[now][m]=f[last][j]+(m==j?1:((m-j-1)/x+1)),ok=1;
		fo(j,max(down[i],x+1),up[i])
		{
		    if (f[last][j-x]!=-1) 
		    if (f[now][j]==-1 || f[last][j-x]+1<f[now][j])
		    f[now][j]=f[last][j-x]+1,ok=1;
		    if (f[now][j-x]!=-1) 
		    if (f[now][j]==-1 || f[now][j-x]+1<f[now][j])
		    f[now][j]=f[now][j-x]+1,ok=1;
		}
		fo(j,down[i],min(up[i],m-y))
		if (f[last][j+y]!=-1)
		if (f[now][j]==-1 || f[last][j+y]<f[now][j])
		f[now][j]=f[last][j+y],ok=1;
		if (ok==0)
		{
			printf("0\n");
			cout<<here[i-1];
			return 0;
		}
	}
	ll outp=1000000000000;
	fo(i,1,m)
	if (f[now][i]!=-1) outp=min(outp,(ll)f[now][i]);
	printf("1\n");
	cout<<outp;
	return 0;
}
