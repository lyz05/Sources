#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
#define fo(i,a,b) for(int i=a;i<=b;i++)
#define fd(i,a,b) for(int i=a;i>=b;i--)
using namespace std;
const int N=11000,M=1100;
typedef long long ll;
int f[N][M],up[N],down[N],xx[N],yy[N];
int here[N];
void check(int &x,int y)
{
	if (x==-1 || x>y) x=y;
}
int main()
{
	freopen("bird.in","r",stdin);
	//freopen("birdpio.out","w",stdout);
	int n,m,p;
	cin>>n>>m>>p;
	fo(i,1,n) scanf("%d%d",&xx[i],&yy[i]);
	n++;
	fo(i,1,n) up[i]=m,down[i]=1;
	fo(i,1,p)
	{
		int a,b,c;
		scanf("%d%d%d",&a,&b,&c);
		a++;
		up[a]=min(up[a],c-1);
		down[a]=max(down[a],b+1);
		here[a]++;
	}
	memset(f,-1,sizeof(f));
	memset(f[1],0,sizeof(f[1]));
	fo(i,1,n-1)
	{
		int x=xx[i],y=yy[i];
		here[i]+=here[i-1];
		bool ok=0;
		fo(j,down[i],up[i])
		if (f[i][j]!=-1)
		{
			ok=1;
			if (j>=y) check(f[i+1][j-y],f[i][j]);
			fo(k,1,(m-j)/x+10)
			check(f[i+1][min(j+x*k,m)],f[i][j]+k);
		}
		if (ok==0)
		{
			cout<<"0\n"<<here[i]-1;
			return 0;
		}
	}
	int ans=-1;
	fo(i,1,m) if (f[n][i]!=-1) check(ans,f[n][i]);
	cout<<"1\n"<<ans;
}



