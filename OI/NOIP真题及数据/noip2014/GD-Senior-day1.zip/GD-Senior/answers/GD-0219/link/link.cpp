#include <fstream>
#include <iostream>
#include <cstring>
#include <vector>

using namespace std;


struct sb
{
	bool a[20001];
	bool operator[](int i)const{return a[i];}
	bool& operator[](int i){return a[i];}
};


const int maxn=200001;//
int main()
{
	int n,i,j,k;
	ifstream fin;
	ofstream fout;
	fin.open("link.in");
	fout.open("link.out");
	fin>>n;
	vector<sb>f(20001);
	for (i=1;i<n;++i)
	{
		long long u,v;
		fin>>u>>v;
		f[u][v]=true;
		f[v][u]=true;
	}
	int w[maxn];
	for (i=1;i<=n;++i)
		fin>>w[i];
	long long ans=0;
	long long max=0;
	for (i=1;i<=n;++i)
		for (j=1;j<=n;++j)
		{
			if (f[i][j])
			{
				for (k=1;k<=n;++k)
					if (f[j][k]&&i!=k)
					{
						int	tmp=w[i]*w[k];
						if (tmp>max) max=tmp;
						ans=(ans+tmp)%10007;
					}
			}
		}
	fout<<max<<" "<< ans<<endl;
	fin.close();
	fout.close();
	return 0;
}
