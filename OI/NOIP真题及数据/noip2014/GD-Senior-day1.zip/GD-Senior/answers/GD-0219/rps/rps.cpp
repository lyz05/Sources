#include <fstream>
#include <cstring>
#define maxn 210
using namespace std;

int f[5][5];
	
int gcd(int x,int y)
{
	return (x%y==0?y:gcd(y,x%y));
}

int main()
{
	int i,j;
	memset(f,0,sizeof(f));
	f[0][2]=f[0][3]=f[1][3]=f[2][4]=f[3][4]=1;
	f[1][0]=f[2][1]=f[3][2]=f[4][0]=f[4][1]=1;

	ifstream fin;	
	ofstream fout;	
	fin.open("rps.in");
	fout.open("rps.out");
	
	int x,y,z;
	fin>>z>>x>>y;
	int m;
	m=x*y/gcd(x,y);
	int a[210],b[210];
	for (int i=0;i<x;++i)
		fin>>a[i];
	for (int i=0;i<y;++i)
		fin>>b[i];
	long long g=0,h=0;
	long long foo,bar;
	for (i=0;i<m;++i)
	{
		foo=i%x;bar=i%y;
		g+=f[a[foo]][b[bar]];
		h+=f[b[bar]][a[foo]];
	}
	g=(z/m)*g;
	h=(z/m)*h;
	for (i=0;i<z%m;++i)
	{
		foo=i%x;bar=i%y;
		g+=f[a[foo]][b[bar]];
		h+=f[b[bar]][a[foo]];
	}

	fout<<g<<" "<<h<<endl;
	fin.close();
	fout.close();
	return 0;
}

