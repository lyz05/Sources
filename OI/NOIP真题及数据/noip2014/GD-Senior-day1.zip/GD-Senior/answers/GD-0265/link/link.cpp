#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cstring>
using namespace std;

int g[1000],l,next[1000];
long n,w[200010],a[200010],b[200010],f1[200010],f2[200010],ma;
long long v[200010],sum;

void add(long t){
	memset(next,0,sizeof(next));
	int j,len=0;
	
	while(t!=0){
		len++;
		next[len]=next[len]+t%10;
		t=t/10;
	}
//	for(j=len;j>=1;j--)
//		cout<<next[j];
//	cout<<endl;
	
	if(len>l)
		l=len;
		
//	for(j=l;j>=1;j--)
//		cout<<g[j]<<" ";
//	cout<<endl;	
		
	for(j=1;j<=l;j++){
		g[j]=g[j]+next[j];
		while(g[j]>9){
			if(j==l)
				l++;
			g[j+1]=g[j]/10+g[j+1];
			g[j]=g[j]%10;
		}
	}

	return;
}

int main(){
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	long i,c;
	
	cin>>n;
	
	for(i=1;i<=n-1;i++){
		cin>>a[i]>>b[i];
	}
	
	for(i=1;i<=n;i++)
		cin>>w[i];
	
	for(i=1;i<=n-1;i++){
		v[b[i]]=v[b[i]]+w[a[i]];
		v[a[i]]=v[a[i]]+w[b[i]];
	}
	
//	for(i=1;i<=n;i++){
//		cout<<v[i]<<" ";
//	}

	for(i=1;i<=n-1;i++){
		if(w[a[i]]>f2[b[i]]){
			if(w[a[i]]>f1[b[i]]){
				c=f1[b[i]];
				f1[b[i]]=w[a[i]];
				f2[b[i]]=c;
			}else{
				f2[b[i]]=w[a[i]];
			}
		}
		
		if(w[b[i]]>f2[a[i]]){
			if(w[b[i]]>f1[a[i]]){
				c=f1[a[i]];
				f1[a[i]]=w[b[i]];
				f2[a[i]]=c;
			}else{
				f2[a[i]]=w[b[i]];
			}
		}
	}	
	
//	for(i=1;i<=n;i++)
//		cout<<f1[i]<<" "<<f2[i]<<endl;
	
	for(i=1;i<=n-1;i++){
		if(f1[a[i]]==w[b[i]]){
			c=f2[a[i]]*w[b[i]];
			if(c>ma)
				ma=c;
		}else{
			c=f1[a[i]]*w[b[i]];
			if(c>ma)
				ma=c;
		}
		if(f1[b[i]]==w[a[i]]){
			c=f2[b[i]]*w[a[i]];
			if(c>ma)
				ma=c;
		}else{
			c=f1[b[i]]*w[a[i]];
			if(c>ma)
				ma=c;
		}
		
		
	}
	
	for(i=1;i<=n-1;i++){
		c=w[a[i]]*(v[b[i]]-w[a[i]]);
	//	cout<<c<<endl;
		sum=sum+c;
		c=w[b[i]]*(v[a[i]]-w[b[i]]);
		sum=sum+c;
		sum=sum%10007;
	//	cout<<c<<endl;
	}

	

	cout<<ma<<" "<<sum;
	
	
	return 0;
}
