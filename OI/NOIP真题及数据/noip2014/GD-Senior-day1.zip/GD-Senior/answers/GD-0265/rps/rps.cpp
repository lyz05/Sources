#include <iostream>
#include <cstdlib>
#include <cstdio>
using namespace std;

int n,na,nb,a[1000],b[1000],ansa,ansb;
int ab[5][5]={0,-1, 1, 1,-1,
			  1, 0,-1, 1,-1,
			 -1, 1, 0,-1, 1,
			 -1,-1, 1, 0, 1,
			  1, 1,-1,-1, 0};

int main(){
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	
	int i;
	
	cin>>n>>na>>nb;
	for(i=1;i<=na;i++)
		cin>>a[i];
	for(i=1;i<=nb;i++)
		cin>>b[i];
	
	for(i=na+1;i<=n;i++){
		a[i]=a[i-na];
	}
	for(i=nb+1;i<=n;i++){
		b[i]=b[i-nb];
	}
	
//	for(i=1;i<=n;i++)
//		cout<<a[i]<<" ";
//	cout<<endl;
//	for(i=1;i<=n;i++)
//		cout<<b[i]<<" ";

	for(i=1;i<=n;i++){
	//	cout<<a[i]<<" "<<b[i]<<endl;
		if(ab[a[i]][b[i]]==1){
			ansa++;
		}
		if(ab[a[i]][b[i]]==-1){
			ansb++;
		}
	}
	cout<<ansa<<" "<<ansb;
}
