#include<fstream>
using namespace std;
int main()
{ifstream fin("bird.in.txt");
ofstream fout("bird.out.txt");
fout<<"0 3";
fin.close();
fout.close();
return 0;}
