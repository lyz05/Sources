#include<fstream>
using namespace std;
short map[30001][30001];
short wi[2001];
int i,j,k;
int n,temp,a1,a2;
long long mx,sum;
int main()
{for(i=1;i<=2000;i++)
for(j=1;j<=2000;j++)
map[i][j]=1000;	
ifstream fin("link.in.txt");
ofstream fout("link.out.txt");
fin>>n;
for(i=1;i<=n-1;i++)
{fin>>a1>>a2;
map[a1][a2]=1;
map[a2][a1]=1;}
for(i=1;i<=n;i++)
fin>>wi[i];
for(j=1;j<=n;j++)
for(i=1;i<=n;i++)
for(k=1;k<=n;k++)
if(map[j][k]==1 && map[k][i]==1 && i!=j)
map[j][i]=2;
for(i=1;i<=n;i++)
for(j=1;j<=n;j++)
if(map[i][j]==2)
{sum+=wi[i]*wi[j];
if(wi[i]*wi[j]>mx)
mx=wi[i]*wi[j];}
fout<<mx<<" "<<sum%10007;
fin.close();
fout.close();
return 0;}
