#include<fstream>
using namespace std;
int N,NA,NB;
int Ta[201],Tb[201];
int i,j,k;
int scorea,scoreb;
bool fena[5][5];
int main()
{   ifstream fin("rps.in.txt");
    ofstream fout("rps.out.txt");
for(i=0;i<=4;i++)
fena[i][i]=0;
fena[0][1]=0;
fena[1][2]=0;
fena[2][3]=0;
fena[1][4]=0;
fena[0][4]=0;
fena[0][2]=1;
fena[0][3]=1;
fena[2][4]=1;
fena[3][4]=1;
fena[1][3]=1;
for(i=0;i<=4;i++)
for(j=0;j<=i-1;j++)
{fena[i][j]=!fena[j][i];}
fin>>N>>NA>>NB;
for(i=1;i<=NA;i++)
fin>>Ta[i];
for(i=1;i<=NB;i++)
fin>>Tb[i];
for(k=1;k<=N;k++)
{scorea+=fena[Ta[k%NA]][Tb[k%NB]];
scoreb+=fena[Tb[k%NB]][Ta[k%NA]];}
fout<<scorea<<" "<<scoreb;
fin.close();
fout.close();
return 0;}
