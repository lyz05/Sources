#include <fstream>
#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <ctime>
#include <cstring>
#include <string>
#include <cmath>
#include <algorithm>
#include <vector>
#include <queue>
#include <stack>
#include <deque>
#include <map>

using namespace std;

typedef long long LL;
typedef double dbl;
typedef pair<int,int> pii;

template<class Tp>
void upMin(const Tp &t,Tp &T) {
	if ( t < T ) T = t;
}

template<class Tp>
void upMax(const Tp &t,Tp &T) {
	if ( t > T ) T = t;
}

template<class Tp>
Tp Abs(const Tp &t) {
	return ( t > 0 ) ? t : -t;
}

void setIO(string St) {
	freopen((St + ".in").c_str(),"r",stdin);
	freopen((St + ".out").c_str(),"w",stdout);
}

const int Winner[5][5] = {{0,2,1,1,2},
						  {1,0,2,1,2},
						  {2,1,0,2,1},
						  {2,2,1,0,1},
						  {1,1,2,2,0}};

int n,na,nb,A[208],B[208];

int main() {
	setIO("rps");
	cin >> n >> na >> nb;
	for (int i = 0; i != na; i++)
		cin >> A[i];
	for (int i = 0; i != nb; i++)
		cin >> B[i];
	int Sa = 0 , Sb = 0 , ka = 0 , kb = 0;
	for (; n; n--) {
		int t = Winner[A[ka]][B[kb]];
		//cout << ka << " " << kb <<endl;
		if ( t == 1 ) Sa++;
		if ( t == 2 ) Sb++;
		ka = (ka + 1) % na;
		kb = (kb + 1) % nb;
	}
	cout << Sa << " " << Sb <<endl; 
	return 0;
}
