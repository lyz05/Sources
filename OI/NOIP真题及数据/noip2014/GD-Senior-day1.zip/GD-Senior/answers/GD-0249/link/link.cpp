#include <fstream>
#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <ctime>
#include <cstring>
#include <string>
#include <cmath>
#include <algorithm>
#include <vector>
#include <queue>
#include <stack>
#include <deque>
#include <map>

using namespace std;

typedef long long LL;
typedef double dbl;

template<class Tp>
void upMin(const Tp &t,Tp &T) {
	if ( t < T ) T = t;
}

template<class Tp>
void upMax(const Tp &t,Tp &T) {
	if ( t > T ) T = t;
}

template<class Tp>
Tp Abs(const Tp &t) {
	return ( t > 0 ) ? t : -t;
}

void setIO(string St) {
	freopen((St + ".in").c_str(),"r",stdin);
	freopen((St + ".out").c_str(),"w",stdout);
}

struct TypeGraph{
	static const int MaxV = 200008 , MaxE = 400008;
	int e,s[MaxE],ne[MaxE],nd[MaxV];
	void Cls() {
		e = 0;
		memset(nd,0,sizeof(nd));
	}
	void Ins(int a,int b) {
		s[++e] = b;
		ne[e] = nd[a];
		nd[a] = e;
	}
} te;

const int MOD = 10007,MaxN = 200008;
int AnsA = 0,AnsB = 0;

queue<int> Q;
int N,Dep[MaxN],Fa[MaxN],Pri[MaxN];

void Dfs() {
	Dep[1] = 1;
	Fa[1] = 0;
	Q.push(1);
	while ( !Q.empty() ) {
		int U = Q.front(); Q.pop();
		int Max = Pri[Fa[U]] , Sum = Pri[Fa[U]];
		for (int i = te.nd[U]; i; i = te.ne[i]) {
			int V = te.s[i];
			if ( V != Fa[U] ) {
				Fa[V] = U;
				Dep[V] = Dep[U] + 1;
				Q.push(V);
				
				upMax(Max * Pri[V],AnsA);
				AnsB = (AnsB + Sum * Pri[V]) % MOD;
				
				upMax(Pri[V],Max);
				Sum = ( Sum + Pri[V] ) % MOD;
			}
		}
	}
}

int main() {
	setIO("link");
	scanf("%d",&N);
	te.Cls();
	for (int i = 1; i != N; i++) {
		int a,b;
		scanf("%d%d",&a,&b);
		te.Ins(a,b);
		te.Ins(b,a);
	}
	for (int i = 1; i <= N; i++)
		scanf("%d",&Pri[i]);
	Dfs();
	cout << AnsA << " " << (AnsB * 2) % MOD <<endl;
	return 0;
}
