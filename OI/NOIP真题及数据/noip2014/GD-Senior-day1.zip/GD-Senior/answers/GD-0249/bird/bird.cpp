#include <fstream>
#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <ctime>
#include <cstring>
#include <string>
#include <cmath>
#include <algorithm>
#include <vector>
#include <queue>
#include <stack>
#include <deque>
#include <map>

using namespace std;

typedef long long LL;
typedef double dbl;

template<class Tp>
inline void upMin(const Tp &t,Tp &T) {
	if ( t < T ) T = t;
}

template<class Tp>
inline void upMax(const Tp &t,Tp &T) {
	if ( t > T ) T = t;
}

template<class Tp>
Tp Abs(const Tp &t) {
	return ( t > 0 ) ? t : -t;
}

void setIO(string St) {
	freopen((St + ".in").c_str(),"r",stdin);
	freopen((St + ".out").c_str(),"w",stdout);
}

const int oo = 1000000000;

const int MaxW = 10005 , MaxH = 1005;
int N,H,K,Fur,NowF;
int uF[MaxW],dF[MaxW],dP[MaxW],uP[MaxW];
int Ans[MaxW][MaxH],G[MaxH];
int Ans1[MaxW][MaxH],nZ;
bool ZZ[MaxW];

inline int GetT(const int &a) {
	int t = 0;
	if ( (H - a) % NowF ) t = 1;
	return (H - a) / NowF + t;
}

int main() {
	setIO("bird");
	
	scanf("%d%d%d",&N,&H,&K);
	for (int i = 1; i <= N; i++) {
		scanf("%d%d",&uF[i],&dF[i]);
		dP[i] = 1 , uP[i] = H;
	}
	dP[0] = 1 , uP[0] = H;
	
	for (int i = 0; i != K; i++) {
		int POS;
		scanf("%d",&POS);
		ZZ[POS] = 1;
		scanf("%d%d",&dP[POS],&uP[POS]);
		dP[POS]++ , uP[POS]--;
	}
	
	for (int i = 0; i <= N; i++)
		for (int j = 0; j <= H; j++)
			Ans[i][j] = oo;
	for (int i = 1; i <= H; i++)
		Ans[0][i] = 0;
	for (int i = 1; i <= N; i++) {
		
		NowF = uF[i];
		for (int j = dP[i]; j <= uP[i]; j++)
			G[j] = oo;
		
		//Down
		
		int MaxH = min(uP[i],uP[i - 1] - dF[i]);
		for (int j = dP[i]; j <= MaxH; j++)
			upMin(Ans[i - 1][j + dF[i]],G[j]);
		
		//Top
		if ( uP[i] == H ) {
			MaxH = min(uP[i - 1],H - 1);
			upMin(Ans[i - 1][H] + 1,G[H]);
			for (int j = dP[i - 1]; j <= MaxH; j++)
				upMin(Ans[i - 1][j] + GetT(j),G[H]);
		}
		
		//Up
		MaxH = H - uF[i];
		for (int j = dP[i - 1]; j <= H; j++)
			upMin(Ans[i - 1][j] + 1,Ans[i - 1][j + uF[i]]);

		for (int j = max(dP[i],1 + uF[i]); j <= uP[i]; j++)
			upMin(Ans[i - 1][j - uF[i]] + 1,Ans[i][j]);
			
		//Get G[]
		for (int j = dP[i]; j <= uP[i]; j++)
			upMin(G[j],Ans[i][j]);
			
		//Further
		for (int j = dP[i]; j <= uP[i]; j++)
			if ( Ans[i][j] != oo ) Fur = i;
		for (int j = 0; j <= H; j++)
			Ans1[i][j] = Ans[i][j];
		
		if ( Fur != i ) break;
		if ( ZZ[i] ) nZ++;
	}
	
	
	////---------------
	
	/*
	for (int i = H; i >= 0; i--) {
		for (int j = 0; j <= N; j++)
			if ( uP[j] >= i && i >= dP[j] ) {
			if ( Ans1[j][i] == oo ) cout << "-  ";
				else {
					cout << Ans1[j][i] << " ";
					if ( Ans1[j][i] < 10 ) cout << " ";
				}
			} else cout << "*  ";
		cout <<endl;
	}
	for (int i = 1; i <= N; i++) {
		cout << uF[i] << " ";
		if ( uF[i] < 10 ) cout << " ";
	}
	cout <<endl;
	for (int i = 1; i <= N; i++) {
		cout << dF[i] << " ";
		if ( dF[i] < 10 ) cout << " ";
	}
	cout <<endl;*/
	
	////-----------------
	
			
	if ( Fur == N ) {
		puts("1");
		int Min = oo;
		for (int j = dP[N]; j <= uP[N]; j++)
			upMin(Ans[N][j],Min);
		cout << Min <<endl;
	} else {
		puts("0");
		cout << nZ <<endl;
	}
	return 0;
}
