#include<cstdio>
#include<cstring>

int main(){
    freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	
	
	int sco[5][5]={{0,0,1,1,0},
	               {1,0,0,1,0},
				   {0,1,0,0,1},
				   {0,0,1,0,1},
                   {1,1,0,0,0}};	
	int i,n,na,nb,a[200],b[200],num[400][2];
	memset(num,0,sizeof(num));
	scanf("%d%d%d",&n,&na,&nb);
	for (i=1; i<=na; i++) 
		scanf("%d",&a[i]);
	a[0]=a[i-1];	
	for (i=1; i<=nb; i++)
		scanf("%d",&b[i]);
	b[0]=b[i-1];	
	for (i=1; i<=n; i++){
		num[i][0]=num[i-1][0]+sco[a[i%na]][b[i%nb]];
		if (a[i%na]!=b[i%nb]) num[i][1]=num[i-1][1]-sco[a[i%na]][b[i%nb]]+1;
		else num[i][1]=num[i-1][1];		
	}
	printf("%d %d",num[n][0],num[n][1]);	
	return 0;
}
