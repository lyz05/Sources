#include<cstdio>
#include<cstring>

int main(){
    freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	
	int i,j,k,n,a,b,num,max,tot;
	int p[720][720],q[2005];
	memset(p,0,sizeof(p));	
	scanf("%d",&n);
	for (i=1; i<n; i++){
		scanf("%d%d",&a,&b);
		p[a][b]=1;
		p[b][a]=1;
	} 
	
	max=0; tot=0;
	for (i=1; i<=n; i++) scanf("%d",&q[i]);
	for (i=1; i<=n; i++)
	    for (j=i+1; j<=n; j++)
	    	if (p[i][j]==1) for (k=j+1; k<=n; k++)
	    		if (p[j][k]==1 && p[i][k]==0){
	    			num=q[i]*q[k];
	    			if (max<num) max=num;
	    			tot=(tot+2*num)%10007;
	    		}
	    	         
	printf("%d %d",max,tot); 	
	return 0;
}
