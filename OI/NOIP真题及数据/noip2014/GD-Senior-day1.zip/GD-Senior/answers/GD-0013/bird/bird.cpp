#include <cstdio>
#include <algorithm>
#include <cstring>

using namespace std ;

const int maxn = 1010 ;
const int maxm = 110 ;

const int inf = 0x7fffffff ;

int dp[ maxn ][ maxn ] , n , m , k , X[ maxn ] , Y[ maxn ] , L[ maxn ] , R[ maxn ] , p[ maxn ] , l[ maxn ] , h[ maxn ] ;

void update( int x , int y , int v ) {
	if ( y >= L[ x ] && y <= R[ x ] ) dp[ x ][ y ] = min( dp[ x ][ y ] , v ) ;
}

int main(  ) {
	freopen( "bird.in" , "r" , stdin ) ; freopen( "bird.out" , "w" , stdout ) ;
	scanf( "%d%d%d" , &n , &m , &k ) ; 
	for ( int i = 0 ; i < n ; ++ i ) scanf( "%d%d" , X + i , Y + i ) ; 
	for ( int i = 0 ; i <= n ; ++ i ) L[ i ] = 1 , R[ i ] = m ; 
	for ( int i = 0 ; i < k ; ++ i ) {
		scanf( "%d%d%d" , p + i , l + i , h + i ) ; L[ p[ i ] ] = l[ i ] + 1 , R[ p[ i ] ] = h[ i ] - 1 ; 
	}
	for ( int i = 0 ; i <= n ; ++ i ) for ( int j = 0 ; j <= m ; ++ j ) dp[ i ][ j ] = inf ; 
	for ( int i = L[ 0 ] ; i <= R[ 0 ] ; ++ i ) dp[ 0 ][ i ] = 0 ;  
	for ( int i = 0 ; i < n ; ++ i ) for ( int j = 1 ; j <= m ; ++ j ) if ( dp[ i ][ j ] < inf ) {
		update(  i + 1 , j - Y[ i ] , dp[ i ][ j ] ) ; 
		for ( int b = 1 ; j + ( b - 1 ) * X[ i ] <= R[ i + 1 ] ; ++ b ) update( i + 1 , min( j + b * X[ i ] , m ) , dp[ i ][ j ] + b ) ;
	}
	int ans = inf ;
	for ( int i = 1 ; i <= m ; ++ i ) ans = min( ans , dp[ n ][ i ] ) ;
	if ( ans < inf ) printf( "1\n%d\n" , ans ) ; else {
		ans = 0 ; 
		for ( int i = 0 ; i < k ; ++ i ) {
			bool flag = false ; 
			for ( int j = L[ p[ i ] ] ; j <= R[ p[ i ] ] ; ++ j ) if ( dp[ p[ i ] ][ j ] < inf ) {
				flag = true ; break ; 
			}
			if ( flag ) ++ ans ; 
		}
		printf( "0\n%d\n" , ans ) ; 
	}
	/*for ( int i = 0 ; i <= n ; ++ i ) {
		for ( int j = 0 ; j <= m ; ++ j ) printf( "%d " , dp[ i ][ j ] ) ; 
		printf( "[%d,%d]\n" , L[ i ] , R[ i ] ) ;
	}*/
	fclose( stdin ) , fclose( stdout ) ; 
	return 0 ; 
}
