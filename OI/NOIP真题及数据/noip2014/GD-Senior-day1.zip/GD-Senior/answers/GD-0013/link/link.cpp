#include <cstdio>
#include <algorithm>
#include <cstring>

using namespace std ;

#define addedge( s , t ) add( s , t ) , add( t , s )

const int maxn = 201000 ;
const int maxm = 401000 ;
const int mod = 10007 ; 

struct edge {
	int t ;
	edge *next ; 
} E[ maxm ] ; 

edge *head[ maxn ] , *pt = E ; 
int w[ maxn ] , n ; 

void add( int s , int t ) {
	pt -> t = t , pt -> next = head[ s ] ; head[ s ] = pt ++ ; 
}

int maxw[ maxn ] , sumw[ maxn ] , mw[ maxn ] , sw[ maxn ] , node[ maxn ] , nv ;

void dfs( int now , int fa ) {
	for ( edge *p = head[ now ] ; p ; p = p -> next ) if ( p -> t != fa ) dfs( p -> t , now ) ;
	nv = 0 ; 
	int x = 0 , y = 0 , v ; 
	for ( edge *p = head[ now ] ; p ; p = p -> next ) if ( p -> t != fa ) {
		node[ ++ nv ] = p -> t ; 
		maxw[ p -> t ] = max( maxw[ p -> t ] , x ) , ( sumw[ p -> t ] += y ) %= mod ; 
		x = max( x , w[ p -> t ] ) , ( y += w[ p -> t ] ) %= mod ; 
	}
	x = 0 , y = 0 ; 
	for ( int i = nv ; i ; -- i ) {
		v = node[ i ] ; 
		maxw[ v ] = max( maxw[ v ] , x ) , ( sumw[ v ] += y ) %= mod ;
		if ( fa ) {
			maxw[ v ] = max( maxw[ v ] , w[ fa ] ) , ( sumw[ v ] += w[ fa ] ) %= mod ; 
		}
		x = max( x , w[ v ] ) , ( y += w[ v ] ) %= mod ; 
	}
	mw[ now ] = x , sw[ now ] = y ;
	for ( int i = 0 ; i ++ < nv ; ) {
		v = node[ i ] ;
		maxw[ now ] = max( maxw[ now ] , mw[ v ] ) , ( sumw[ now ] += sw[ v ] ) %= mod ; 
	}
}

int ans0 = 0 , ans1 = 0 ;  

int main(  ) {
	freopen( "link.in" , "r" , stdin ) ;
	freopen( "link.out" , "w" , stdout ) ;
	scanf( "%d" , &n ) ;
	for ( int i = 0 ; i ++ < n ; ) {
		head[ i ] = NULL ; maxw[ i ] = sumw[ i ] = 0 ; 
	}
	for ( int i = 1 ; i < n ; ++ i ) {
		int s , t ; scanf( "%d%d" , &s , &t ) ; addedge( s , t ) ; 
	}
	for ( int i = 0 ; i ++ < n ; ) scanf( "%d" , w + i ) ; 
	w[ 0 ] = 0 ;
	dfs( 1 , 0 ) ; 
	for ( int i = 1 , j ; i <= n ; ++ i ) {
		ans0 = max( ans0 , w[ i ] * maxw[ i ] ) ; 
		( ans1 += ( ( w[ i ] * sumw[ i ] ) % mod ) ) %= mod ;
	}
	printf( "%d %d\n" , ans0 , ans1 ) ;
//	for ( int i = 0 ; i ++ < n ; ) printf( "%d:(%d) " , i , maxw[ i ] ) ; printf( "\n" ) ;
//	for ( int i = 0 ; i ++ < n ; ) printf( "%d:(%d) " , i , sumw[ i ] ) ; printf( "\n" ) ;
	fclose( stdin ) , fclose( stdout ) ; 
	return 0 ; 
}
