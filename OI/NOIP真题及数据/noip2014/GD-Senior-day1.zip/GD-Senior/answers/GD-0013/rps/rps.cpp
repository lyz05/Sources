#include <cstdio>
#include <algorithm>
#include <cstring>

using namespace std ;

const int maxn = 1010 ;

int a[ maxn ] , b[ maxn ] , na , nb , n , sa = 0 , sb = 0 ; 

int check( int x , int y ) {
	if ( x == y ) return 2 ; 
	if ( x == 0 ) {
		if ( y == 1 || y == 4 ) return 1 ; 
		return 0 ; 
	}
	if ( x == 1 ) {
		if ( y == 2 || y == 4 ) return 1 ; 
		return 0 ; 
	}
	if ( x == 2 ) {
		if ( y == 0 || y == 3 ) return 1 ; 
		return 0 ; 
	}
	if ( x == 3 ) {
		if ( y == 0 || y == 1 ) return 1 ; 
		return 0 ; 
	}
	if ( x == 4 ) {
		if ( y == 2 || y == 3 ) return 1 ;
		return 0 ; 
	}
}

int main(  ) {
	freopen( "rps.in" , "r" , stdin ) ;
	freopen( "rps.out" , "w" , stdout ) ;
	scanf( "%d%d%d" , &n , &na , &nb ) ; 
	for ( int i = 0 ; i < na ; ++ i ) scanf( "%d" , a + i ) ;
	for ( int i = 0 ; i < nb ; ++ i ) scanf( "%d" , b + i ) ;
	for ( int i = 0 , j , x = 0 , y = 0 ; i < n ; ++ i , x = ( x + 1 ) % na , y = ( y + 1 ) % nb ) {
		j = check( a[ x ] , b[ y ] ) ; 
		if ( j == 0 ) sa ++ ; else if ( j == 1 ) sb ++ ; 
	}
	printf( "%d %d\n" , sa , sb ) ;
	fclose( stdin ) , fclose( stdout ) ;
	return 0 ;
}
