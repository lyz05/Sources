#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <map>
#include <queue>
#include <vector>
using namespace std;
#define mod 10007

struct Tedge
{
       int to, next;
}      edge[1000050];

struct Tnode
{
       int current, father, pointer;
}      sk[1000050];

int now, first[200050], weight[200050], f[200050][5], g[200050][5];

void Addedge(int x, int y)
{
     edge[++now].to = y;
     edge[now].next = first[x];
     first[x] = now;
     
     return;
}

void DFS(int root)
{
int  tp, current, father, pointer, next, sum, max1, max2;
     
     sk[tp = 1].current = root;
     sk[1].father = 0;
     sk[1].pointer = first[root];
     while (tp > 0)
     {
           current = sk[tp].current;
           father = sk[tp].father;
           pointer = sk[tp].pointer;
           if  (pointer)
           {
               next = edge[pointer].to;
               sk[tp].pointer = edge[pointer].next;
               if  (next == father)
               {
                   continue;
               }
               sk[++tp].current = next;
               sk[tp].father = current;
               sk[tp].pointer = first[next];
           }   else
           {
               tp--;
               f[current][0] = g[current][0] = weight[current];
               sum = max1 = max2 = 0;
               for (pointer = first[current]; pointer; pointer = edge[pointer].next)
               {
                   next = edge[pointer].to;
                   if  (next == father)
                   {
                       continue;
                   }
                   f[current][1] += f[next][0];
                   f[current][1] %= mod;
                   
                   g[current][1] = max(g[current][1], g[next][0]);
                   
                   f[current][2] += f[next][2];
                   f[current][2] %= mod;
                   f[current][2] += f[next][1] * weight[current];
                   f[current][2] %= mod;
                   f[current][2] += f[next][0] * sum;
                   f[current][2] %= mod;
                   sum += f[next][0];
                   sum %= mod;
                   
                   g[current][2] = max(g[current][2], g[next][2]);
                   g[current][2] = max(g[current][2], g[next][1] * weight[current]);
                   if  (g[next][0] > max1)
                   {
                       max2 = max1;
                       max1 = g[next][0];
                   }   else
                   if  (g[next][0] > max2)
                   {
                       max2 = g[next][0];
                   }
               }
               g[current][2] = max(g[current][2], max1 * max2);
           }
     }
     
     return;
}

int main()
{
int n, i, x, y;
    
    freopen("link.in", "r", stdin);
    freopen("link.out", "w", stdout);
    
    scanf("%d", &n);
    for (i = 1; i < n; i++)
    {
        scanf("%d%d", &x, &y);
        Addedge(x, y);
        Addedge(y, x);
    }
    for (i = 1; i <= n; i++)
    {
        scanf("%d", &weight[i]);
    }
    
    DFS(1);
    
    f[1][2] = (2 * f[1][2]) % mod;
    printf("%d %d\n", g[1][2], f[1][2]);
    
    return 0;
}
