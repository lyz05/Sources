#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <map>
#include <queue>
#include <vector>
using namespace std;

int x[10050], y[10050], from[10050], to[10050], f[10050][1050], g[10050][1050];
bool have[10050];

int main()
{
int n, m, p, i, j, s, a, b, c, temp, best, answer;
bool solved;
    
    freopen("bird.in", "r", stdin);
    freopen("bird.out", "w", stdout);
    
    scanf("%d%d%d", &n, &m, &p);
    for (i = 0; i < n; i++)
    {
        scanf("%d%d", &x[i], &y[i]);
    }
    for (i = 0; i <= n; i++)
    {
        from[i] = 1;
        to[i] = m;
    }
    for (i = 1; i <= p; i++)
    {
        scanf("%d%d%d", &a, &b, &c);
        have[a] = true;
        from[a] = b + 1;
        to[a] = c - 1;
    }
    
    memset(f, 127, sizeof(f));
    memset(g, 127, sizeof(g));
    
    for (i = 1; i <= m; i++)
    {
        f[0][i] = 0;
    }
    
    for (s = 1; s <= x[0]; s++)
    {
        g[0][s] = f[0][s];
        for (i = s; i < m; i += x[0])
        {
            g[0][min(i + x[0], m)] = min(f[0][min(i + x[0], m)], g[0][i] + 1);
        }
    }
    
    for (i = 1; i <= n; i++)
    {
        for (j = from[i]; j <= to[i]; j++)
        {
            temp = j + y[i - 1];
            if  (temp <= m)
            {
                f[i][j] = min(f[i][j], f[i - 1][temp]);
            }
            temp = j - x[i - 1];
            if  (temp > 0)
            {
                f[i][j] = min(f[i][j], g[i - 1][temp] + 1);
            }
        }
        if  (from[i] <= m && m <= to[i])
        {
            for (j = m + 1; j <= 2 * m; j++)
            {
                temp = j - x[i - 1];
                if  (0 < temp && temp <= m)
                {
                    f[i][m] = min(f[i][m], g[i - 1][temp] + 1);
                }
            }
        }
        for (s = 1; s <= x[i]; s++)
        {
            g[i][s] = f[i][s];
            for (j = s; j < m; j += x[i])
            {
                g[i][min(j + x[i], m)] = min(f[i][min(j + x[i], m)], g[i][j] + 1);
            }
        }
    }
    
    solved = false;
    for (i = 1; i <= m; i++)
    if  (f[n][i] < 999999999)
    {
        solved = true;
        break;
    }
    
    if  (solved)
    {
        printf("1\n");
        best = f[n][1];
        for (i = 2; i <= m; i++)
        {
            best = min(best, f[n][i]);
        }
        printf("%d\n", best);
    }   else
    {
        printf("0\n");
        for (i = n; i >= 0; i--)
        {
            solved = false;
            for (j = 1; j <= m; j++)
            if  (f[i][j] < 999999999)
            {
                solved = true;
                break;
            }
            if  (solved)
            {
                break;
            }
        }
        answer = 0;
        for (j = 0; j <= i; j++)
        if  (have[j])
        {
            answer++;
        }
        printf("%d\n", answer);
    }
    
    return 0;
}
