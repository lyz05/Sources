#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <map>
#include <queue>
#include <vector>
using namespace std;

int win[5][5] = {1, 0, 2, 2, 0, 
                 2, 1, 0, 2, 0, 
                 0, 2, 1, 0, 2, 
                 0, 0, 2, 1, 2, 
                 2, 2, 0, 0, 1};

int a[205], b[205];

int main()
{
int n, na, nb, i, ta, tb;
    
    freopen("rps.in", "r", stdin);
    freopen("rps.out", "w", stdout);
    
    scanf("%d%d%d", &n, &na, &nb);
    for (i = 0; i < na; i++)
    {
        scanf("%d", &a[i]);
    }
    for (i = 0; i < nb; i++)
    {
        scanf("%d", &b[i]);
    }
    ta = tb = 0;
    for (i = 0; i < n; i++)
    if  (win[a[i % na]][b[i % nb]] == 0)
    {
        tb++;
    }   else
    if  (win[a[i % na]][b[i % nb]] == 2)
    {
        ta++;
    }
    
    printf("%d %d\n", ta, tb);
    
    return 0;
}
