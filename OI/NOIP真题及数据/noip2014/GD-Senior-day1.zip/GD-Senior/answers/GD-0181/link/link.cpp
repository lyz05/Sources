#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<queue>
#include<string>

using namespace std;

const int mmd=10007;
const int maxn=200000;

int n,wi[maxn+10],sumw,maxw;
int h[maxn+10],e[maxn*2+10],nex[maxn*2+10];
int sta[maxn+10];

void run(int x)
{
	int i=h[x],top=0,now=0,max1=-20000000,max2=-20000000;
	memset(sta,0,sizeof(sta));
	while(i)
	{
		if(max1<wi[e[i]])
		{
			int tm=max1; max1=wi[e[i]];
			if(max2<tm) max2=tm;
		}
		else if(max2<wi[e[i]]) max2=wi[e[i]];
		now+=wi[e[i]];
		++top; sta[top]=wi[e[i]];
		i=nex[i];
	}
	if(top<=1) return;
	maxw=max(maxw,max1*max2);
	for(int k=1;k<=top;++k)
	{
		int bao=((now-sta[k])*sta[k])%mmd;
		sumw=(sumw+bao)%mmd;
	}
	return;
}

void init()
{
	memset(h,0,sizeof(h));
	memset(e,0,sizeof(e));
	memset(nex,0,sizeof(nex));
	cin>>n;
	int top=0,a,b;
	for(int i=1;i<n;++i)
	{
		scanf("%d%d",&a,&b);
		++top; e[top]=b; nex[top]=h[a]; h[a]=top;
		++top; e[top]=a; nex[top]=h[b]; h[b]=top;
	}
	for(int i=1;i<=n;++i) scanf("%d",&wi[i]);
	sumw=0; maxw=0;
	for(int i=1;i<=n;++i) run(i);
	printf("%d %d",maxw,sumw);
	return;
}

int main()
{
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	init();
	return 0;
}
