#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<queue>
#include<string>

using namespace std;

struct node
{
	int head,tail;
	bool flag;
}guan[10010];

bool exi[10010][1010];
int ff[10010][1010];
int n,m;
int xx[10010],yy[10010];

void init()
{
	int kk,a,b,c;
	cin>>n>>m>>kk;
	for(int i=0;i<=n-1;++i)
	{
		scanf("%d%d",&xx[i],&yy[i]);
		guan[i].head=1; guan[i].tail=m; guan[i].flag=false;
	}
	guan[n].head=1; guan[n].tail=m; guan[n].flag=false;
	for(int i=1;i<=kk;++i)
	{
		scanf("%d%d%d",&a,&b,&c);
		guan[a].head=b+1;
		guan[a].tail=c-1;
		guan[a].flag=true;
	}
	return;
}

void cal(int ix,int kx)
{
	if(kx-yy[ix]>=1)
	{
		exi[ix+1][kx-yy[ix]]=true;
		ff[ix+1][kx-yy[ix]]=ff[ix][kx];
	}
	int i=1;
	while(kx+xx[ix]*i<=m)
	{
		int t=kx+xx[ix]*i;
		exi[ix+1][t]=true;
		ff[ix+1][t]=min(ff[ix+1][t],ff[ix][kx]+i);
		++i;
	}
	exi[ix+1][m]=true;
	ff[ix+1][m]=min(ff[ix+1][m],ff[ix][kx]+i);
	return;
}

void run()
{
	int achi=0;
	memset(ff,0x7f,sizeof(ff));
	memset(exi,0,sizeof(exi));
	for(int i=1;i<=m;++i)
	{
		exi[0][i]=true;
		ff[0][i]=0;
	}
	for(int i=0;i<=n-1;++i)
	{
		bool flag=false;
		for(int k=guan[i].head;k<=guan[i].tail;++k)
		{
			if(exi[i][k])
			{
				flag=true;
				cal(i,k);
			}
		}
		if(!flag)
		{
			printf("%d\n%d",0,achi);
			return;
		}
		if(guan[i].flag) ++achi;
	}
	int ans=214748300,tf=0;
	for(int i=1;i<=m;++i)
	{
		if(exi[n][i])
		{
			ans=min(ans,ff[n][i]);
			tf=1;
		}
	}
	if(tf)
		printf("%d\n%d",1,ans);
	else printf("%d\n%d",0,achi);
	return;
}

int main()
{
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	init();
	run();
	return 0;
}
