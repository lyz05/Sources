#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<queue>
#include<string>

using namespace std;

int n,na,nb;
int qa[210],qb[210],f[10][10];

void init()
{
	memset(f,0,sizeof(f));
	f[0][2]=f[0][3]=f[1][0]=f[1][3]=1;
	f[2][1]=f[2][4]=f[3][2]=f[3][4]=1;
	f[4][0]=f[4][1]=1;
	cin>>n>>na>>nb;
	for(int i=0;i<na;++i) scanf("%d",&qa[i]);
	for(int i=0;i<nb;++i) scanf("%d",&qb[i]);
	int ta=0,tb=0;
	int ansa=0,ansb=0;
	for(int i=1;i<=n;++i)
	{
		ansa+=f[qa[ta]][qb[tb]];
		ansb+=f[qb[tb]][qa[ta]];
		ta=(ta+1)%na; tb=(tb+1)%nb;
	}
	printf("%d %d",ansa,ansb);
}

int main()
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	init();
	return 0;
}
