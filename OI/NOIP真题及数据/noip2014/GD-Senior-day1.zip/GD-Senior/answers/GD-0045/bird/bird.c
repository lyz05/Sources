#include <stdio.h>

#define MAXn 10000
#define MAXm 1000

FILE *fin, *fout;

int n, m, k; /* Read */
char map[MAXn + 1][MAXm + 1] = {0}; /* Read */
int X[MAXn], Y[MAXn]; /* Read */
int f[MAXn + 1][MAXm + 1];
int P[MAXn]; /* Read */

void openfile(void);
void readdata(void);
void sortP(void);
void calc(void);
void closefile(void);

int main(void)
{
  openfile();
  
  readdata();
  
  calc();
  
  closefile();
  
  return 0;
}

void openfile(void)
{
  fin = fopen("bird.in", "r");
  fout = fopen("bird.out", "w");
}

void readdata(void)
{
  int L, H;
  int i, j;
  
  fscanf(fin, "%d%d%d", &n, &m, &k);
  for (i = 0; i < n; i++)
    fscanf(fin, "%d%d", &X[i], &Y[i]);
  for (i = 1; i <= k; i++) {
    fscanf(fin, "%d%d%d", &P[i], &L, &H);
    for (j = 0; j <= L; j++)
      map[P[i]][j] = 1;
    for (j = H; j <= m; j++)
      map[P[i]][j] = 1;
  }
  sortP();
  P[0] = -1;
}

void sortP()
{
  int A[MAXn + 1], C[MAXn + 1];
  int i, j;
  
  for (i = 0; i <= n; i++)
    C[i] = 0;
  for (i = 1; i <= k; i++)
    C[P[i]]++;
  for (i = 1; i <= n; i++)
    C[i] += C[i - 1];
  for (i = k; i >= 1; i--) {
    A[C[P[i]]] = P[i];
    C[P[i]]--;
  }
  for (i = 1; i <= k; i++)
    P[i] = A[i];
}

void calc(void)
{
  int i, j, q, r, min;
  int isfail, passcnt;
  
  for (j = 0; j <= m; j++)
    f[0][j] = 0;
  f[0][0] = -1;
  for (i = 1; i <= n; i++) {
    isfail = 1;
    for (j = 0; j <= m; j++) {
      /* Ground or unreachable case */
      if (j == 0 || map[i][j] == 1) {
        f[i][j] = -1;
        continue;
      }
      /* Top case */
      min = -1;
      if (j == m) {
        r = 1;
        for (q = m; q >= m - X[i - 1]; q--) {
          if (f[i - 1][q] == -1)
            continue;
          if (min == -1 || f[i - 1][q] + r < min) 
            min = f[i - 1][q] + r;
        }
        for (q = m - X[i - 1] * 2, r = 2; q >= 0; q -= X[i - 1], r++) {
          if (f[i - 1][q] == -1)
            continue;
          if (min == -1 || f[i - 1][q] + r < min)
            min = f[i - 1][q] + r;
        }
        f[i][j] = min;
        if (f[i][j] != -1)
          isfail = 0;
        continue;
      }
      /* Rest cases */
      min = -1;
      r = 0;
      q = j + Y[i - 1];
      if (q <= m && f[i - 1][q] != -1 && f[i - 1][q] + r > min)
        min = f[i - 1][q] + r;
      for (q = j - X[i - 1] * 1, r = 1; q >= 0; q -= X[i - 1], r++) {
        if (f[i - 1][q] == -1)
          continue;
        if (min == -1 || f[i - 1][q] + r < min)
          min = f[i - 1][q] + r;
      }
      f[i][j] = min;
      if (f[i][j] != -1)
        isfail = 0;
    }
    if (isfail == 1) 
      break;
  }
  
  if (i <= n) {
    for (passcnt = 0; P[passcnt] <= i - 1; passcnt++)
      ;
    passcnt--;
    fprintf(fout, "0\n%d\n", passcnt);
  }
  else {
    min = -1;
    for (j = 0; j <= m; j++) {
      if (f[n][j] == -1)
        continue;
      if (min == -1 || f[n][j] < min)
        min = f[n][j];
    }
    fprintf(fout, "1\n%d\n", min);
  }
}
  

void closefile(void)
{
  fclose(fin);
  fclose(fout);
}

