#include <stdio.h>

FILE *fin, *fout;
int rule[5][5] = {{ 0, -1,  1,  1, -1},
                  { 1,  0, -1,  1, -1},
                  {-1,  1,  0, -1,  1},
                  {-1, -1,  1,  0,  1},
                  { 1,  1, -1, -1,  0}};

void openfile(void);
void closefile(void);

int main(void)
{
  int N, NA, NB, pA, pB;
  int Ascore, Bscore;
  int A[220], B[220];
  int i, j;
  
  openfile();
  
  fscanf(fin, "%d%d%d", &N, &NA, &NB);
  for (i = 0; i < NA; i++)
    fscanf(fin, "%d", &A[i]);
  for (i = 0; i < NB; i++)
    fscanf(fin, "%d", &B[i]);
  
  Ascore = Bscore = 0;
  pA = pB = 0;
  for (i = 1; i <= N; i++) {
    if (rule[A[pA]][B[pB]] == -1)
      Bscore++;
    else if (rule[A[pA]][B[pB]] == 1)
      Ascore++;
    pA = (pA + 1) % NA;
    pB = (pB + 1) % NB;
  }
  
  fprintf(fout, "%d %d\n", Ascore, Bscore);
  
  closefile();
  
  return 0;
}

void openfile(void)
{
  fin = fopen("rps.in", "r");
  fout = fopen("rps.out", "w");
}

void closefile(void)
{
  fclose(fin);
  fclose(fout);
}

