#include <stdio.h>
#include <stdlib.h>

#define MOD 10007

struct Node {
  int vertex;
  int W;
  struct Node *next;
};
typedef struct {
  int va, vb;
} Edge;

FILE *fin, *fout;
struct Node *adjlist[200500];
Edge edge[200500]; /* Read */
int W[200500]; /* Read */
int n;

void openfile(void);
void readdata(void);
void calc(void);
void closefile(void);

int main(void)
{
  openfile();
  
  readdata();
  
  calc();
  
  closefile();
  
  return 0;
}

void openfile(void)
{
  fin = fopen("link.in", "r");
  fout = fopen("link.out", "w");
}

void readdata(void)
{
  struct Node *newp;
  int i;
  
  /* Read */
  fscanf(fin, "%d", &n);
  for (i = 1; i <= n - 1; i++)
    fscanf(fin, "%d%d", &edge[i].va, &edge[i].vb);
  for (i = 1; i <= n; i++) 
    fscanf(fin, "%d", &W[i]);
    
  /* Process */
  for (i = 1; i <= n; i++)
    adjlist[i] = NULL;
  for (i = 1; i <= n - 1; i++) {
    /* vb add to va */
    newp = (struct Node *) malloc(sizeof (struct Node));
    newp -> vertex = edge[i].vb;
    newp -> W = W[edge[i].vb];
    newp -> next = adjlist[edge[i].va];
    adjlist[edge[i].va] = newp;
    /* va add to vb */
    newp = (struct Node *) malloc(sizeof (struct Node));
    newp -> vertex = edge[i].va;
    newp -> W = W[edge[i].va];
    newp -> next = adjlist[edge[i].vb];
    adjlist[edge[i].vb] = newp;    
  }
}

void calc(void)
{
  int max1, max2, maxtime;
  int sum, sumeach, subeach;
  struct Node *p;
  int i, j;
  
  maxtime = 0;
  sum = 0;
  for (i = 1; i <= n; i++) { /* Find through each head */
    /* Find max time */
    max1 = max2 = 0;
    for (p = adjlist[i]; p != NULL; p = p -> next) {
      if (p -> W > max1) {
        max2 = max1;
        max1 = p -> W;
      }
      else if (p -> W > max2)
        max2 = p -> W;
    }
    if (max1 * max2 > maxtime)
      maxtime = max1 * max2;
    
    /* Find sum */
    sumeach = subeach = 0;
    for (p = adjlist[i]; p != NULL; p = p -> next) {
      sumeach += p -> W;
      sumeach %= MOD;
      subeach += p -> W * p -> W;
      subeach %= MOD;
    }
    sum += (sumeach * sumeach + MOD - subeach) % MOD;
  }
  
  fprintf(fout, "%d %d\n", maxtime, sum);
}

void closefile(void)
{
  fclose(fin);
  fclose(fout);
}

