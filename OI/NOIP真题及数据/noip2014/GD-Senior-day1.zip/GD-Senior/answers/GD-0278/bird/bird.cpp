#include<iostream>
#include<fstream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<string>
#include<ctime>
#include<map>
#include<queue>
#include<set>
#include<vector>
#include<algorithm>
using namespace std;
#define st first
#define nd second
#define For(i,a,b)  for(int i=a,_b=b;i<=_b;i++)
#define Forr(i,a,b) for(int i=a,_b=b;i>=_b;i--)
#define lson l,mid,rt<<1
#define rson mid+1,r,rt<<1|1
typedef long long LL;
typedef unsigned long long USLL;
//#define fin cin
//#define fout cout
const int maxn=10002;
const int maxm=1002;
int n,m,k1;
int p[maxn],l[maxn],h[maxn];
int x[maxn],y[maxn];
int f[maxn][maxm];
	ifstream fin("bird.in");
	ofstream fout("bird.out");
int judge(int x,int y)
{
	if (y==-1) return x;
	return min(x,y);
}
void dp()
{
	For(i,1,m) f[0][i]=0;
	int z;
	For(i,0,n-1)
	  {
	  	int r;
	    if (p[i+1]==1) r=0;
	  	if (p[i+1]==0) r=1;
	  	For(j,1,m)
	  	{
	  		if (f[i][j]==-1) {continue;}
	  		if (p[i+1]==0)
	  		  {
	  		  	
	 	 		  if (j-y[i]>0)
	   			   f[i+1][j-y[i]]=judge(f[i][j],f[i+1][j-y[i]]);
	   	           For(k,1,m)
	   	           {
	   	             	 if (j+x[i]*k<=m)
	   			  	 	f[i+1][j+k*x[i]]=judge(f[i][j]+k,f[i+1][j+k*x[i]]);
	   			  		 if (j+x[i]*k>m) {f[i+1][m]=judge(f[i][j]+k,f[i+1][m]);break;}
							  }
      	}
       		 if (p[i+1]==1)
       	 	{
       	 		//fout<<j<<"******\n";
       	 		
       	 		if (j-y[i]>l[i+1]&&j-y[i]<h[i+1])
	   	 	  	{f[i+1][j-y[i]]=judge(f[i][j],f[i+1][j-y[i]]); r=1;}
	   	 	  	z=l[i+1]-j;if (z<=x[i]) z=1;else z=z/x[i];
	   	        For(k,z,m)
	   	        {
	   	        	   	   			if(j+k*x[i]>l[i+1]) if (j+k*x[i]<h[i+1]) 
	   		  		 {f[i+1][j+k*x[i]]=judge(f[i][j]+1,f[i+1][j+k*x[i]]); r=1;} else break;
	      		}
        	
        	
        	}
        	
        
        	
         }
	  if (r==0) {
        		fout<<"0\n";
        	//	fout<<i<<"\n";
        		int ans=0;
        		For(k,1,i) if (p[k]==1) ans++;
        		fout<<ans<<"\n";
        		return;
	  }
	  	
	  
     }
int min1=1000000;
fout<<"1\n";
For(i,1,m) min1=judge(min1,f[n][i]);
fout<<min1<<"\n";
}

int main()
{

	
	memset(f,-1,sizeof(f));
	
	memset(p,0,sizeof(p));
	fin>>n>>m>>k1;
	For(i,0,n-1)
	{
		fin>>x[i]>>y[i];
		//x[i]++;y[i]--;
	}
	For(i,1,k1)
	{int q;
	fin>>q;
	p[q]=1;
	fin>>l[q];fin>>h[q];
    }
    dp();
   /* For(i,0,n)
    {
    	For(j,1,m)
    	fout<<f[i][j]<<" ";
    	fout<<'\n';
    }*/
    
	return 0;
}
