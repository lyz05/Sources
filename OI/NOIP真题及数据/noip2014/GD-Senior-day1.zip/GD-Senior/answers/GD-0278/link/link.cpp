#include<iostream>
#include<fstream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<string>
#include<ctime>
#include<map>
#include<queue>
#include<set>
#include<vector>
#include<algorithm>
using namespace std;
#define st first
#define nd second
#define For(i,a,b)  for(int i=a,_b=b;i<=_b;i++)
#define Forr(i,a,b) for(int i=a,_b=b;i>=_b;i--)
//#define lson l,mid,rt<<1
//#define rson mid+1,r,rt<<1|1
typedef long long LL;
typedef unsigned long long USLL;
	ifstream fin("link.in");
	ofstream fout("link.out");
const int maxn=200002;
vector<int> a[maxn]; 
int t[maxn];
int n,x,y;
//#define fin cin
int v[maxn];
int max1=0,sum=0;
void search(int w)
{
	//fout<<w;
	For(i,0,t[w]-1) 
	  For(j,0,i-1)
	  {
	  	//fout<<"i="<<i<<"j="<<j<<'\n';
	  	int ans=v[a[w][i]]*v[a[w][j]];
        if (ans>max1) max1=ans;
        sum=(sum+ans)%10007;
}
    
}

int main()
{

	memset(t,0,sizeof(t));
    fin>>n;
    For(i,1,n-1)
	{
		fin>>x>>y;
		a[x].push_back(y);
	    a[y].push_back(x);
	    t[x]++;t[y]++;
		
	}
	
	//For(i,1,n) fout<<t[i]<<"###\n";
	
	For(i,1,n) fin>>v[i];
	 
	For(i,1,n)
	search(i);
	
	
	fout<<max1<<" "<<(sum*2)%10007;
	
	//fout<<(double)clock()/CLOCKS_PER_SEC;
	return 0;
}
