#include<iostream>
#include<fstream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<string>
#include<ctime>
#include<map>
#include<queue>
#include<set>
#include<vector>
#include<algorithm>
using namespace std;
#define st first
#define nd second
#define For(i,a,b)  for(int i=a,_b=b;i<=_b;i++)
#define Forr(i,a,b) for(int i=a,_b=b;i>=_b;i--)
#define lson l,mid,rt<<1
#define rson mid+1,r,rt<<1|1
typedef long long LL;
typedef unsigned long long USLL;
int n,na,nb;
int a[201],b[201];
int pa=0,pb=0;

int judge(int x,int y)
{
	if (x==y) return 0;
	if (x==0&&y==2)return 1;
	if (x==0&&y==3)return 1;
	if (x==1&&y==0)return 1;
	if (x==1&&y==3)return 1;
	if (x==2&&y==1)return 1;
	if (x==2&&y==4)return 1;
	if (x==3&&y==2)return 1;
	if (x==3&&y==4)return 1;
	if (x==4&&y==0)return 1;
	if (x==4&&y==1)return 1;
	return -1;
}

int main()
{
	ifstream fin("rps.in");
	ofstream fout("rps.out");
	
	memset(a,0,sizeof(a));
	memset(b,0,sizeof(b));
	fin>>n>>na>>nb;
	For(i,0,na-1)
	fin>>a[i];
	For(i,0,nb-1)
	fin>>b[i];
	For(i,0,n-1)
	{
		if (judge(a[i%na],b[i%nb])==1) pa++;
		if (judge(a[i%na],b[i%nb])==-1) pb++;
	
	}
	
	
	fout<<pa<<" "<<pb;
	return 0;
}
