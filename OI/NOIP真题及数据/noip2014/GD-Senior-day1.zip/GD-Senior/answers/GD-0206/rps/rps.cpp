#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>
#define rep(i,j,k) for (i=j;i<=k;i++)
#define reps(i,j,k) for (i=j;i>=k;i--)
#define maxn 210
#define mem(a,b) memset(a,b,sizeof(a))
using namespace std;
int n,na,nb,ansa,ansb;
int a[maxn],b[maxn];
int map[5][5];
int main()
{
	freopen("rps.in","r",stdin);freopen("rps.out","w",stdout);
	int i,j,k;
	ansa=0;ansb=0;
	mem(map,0);
	map[0][2]=1;map[0][3]=1;
	map[1][3]=1;map[2][4]=1;map[3][4]=1;
	rep(i,0,4)
		rep(j,0,i-1)map[i][j]=1-map[j][i];
	scanf("%d%d%d",&n,&na,&nb);
	rep(i,1,na)scanf("%d",&a[i]);
	rep(i,1,nb)scanf("%d",&b[i]);
	rep(i,1,n)
	{
		int nowa=i%na,nowb=i%nb;
		if (nowa==0)nowa=na;
		if (nowb==0)nowb=nb;
		if (a[nowa]==b[nowb])continue;
		else if (map[a[nowa]][b[nowb]])ansa++;
		else ansb++;
	}
	printf("%d %d\n",ansa,ansb);
	return 0;
}

