#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<vector>
#define rep(i,j,k) for (i=j;i<=k;i++)
#define reps(i,j,k) for (i=j;i>=k;i--)
#define mem(a,b) memset(a,b,sizeof(a))
#define mod 10007
#define maxn 11000
#define inf 0x3fffffff
using namespace std;
int X[maxn],Y[maxn],L[maxn],R[maxn],n,m,p,gg[maxn],num[maxn];
int ok,ans0,ans1;
void dfs(int x,int y,int dep)
{
	if (y<L[x]||y>R[x])
	{
		if (!ok)ans0=max(ans0,num[x]);
		return;
	}
	if (x==n)
	{
		if (!ok) ok=1;
		ans1=min(ans1,dep);
		return;
	}
	if (y-Y[x]>0)dfs(x+1,y-Y[x],dep);
	int k=1;
	while(y+k*X[x]<=m)
	{
		dfs(x+1,y+k*X[x],dep+k);
		k++;
	}
	if (y+k*X[x]>m)dfs(x+1,m,dep+k);
}
int main()
{
	freopen("bird.in","r",stdin);freopen("bird.ans","w",stdout);
	int i,j,k;
	scanf("%d%d%d",&n,&m,&p);
	rep(i,0,n-1)scanf("%d%d",&X[i],&Y[i]);
	rep(i,0,n)
	{
		L[i]=1;R[i]=m;
	}
	rep(i,1,p)
	{
		int x,l,r;
		scanf("%d%d%d",&x,&l,&r);
		L[x]=l+1;R[x]=r-1;
		gg[i]=x;
	}
	sort(gg+1,gg+p+1);
	rep(i,1,p)num[gg[i]+1]=i;
	num[0]=0;
	rep(i,1,n)if (num[i]==0)num[i]=num[i-1];
	ok=0;ans0=0;ans1=inf;
	rep(i,1,m)dfs(0,i,0);
	if (ok==0)
	printf("%d\n%d\n",ok,ans0);
	else printf("%d\n%d\n",ok,ans1);
	return 0;
}

