#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<vector>
#define rep(i,j,k) for (i=j;i<=k;i++)
#define reps(i,j,k) for (i=j;i>=k;i--)
#define mem(a,b) memset(a,b,sizeof(a))
#define mod 10007
#define maxn 11000
using namespace std;
typedef long long LL;
int X[maxn],Y[maxn],L[maxn],R[maxn],n,m,p,gg[maxn],num[maxn];
int dp[2][1100],minnum[1100];
void update(int &x,int y){if (x==-1||x>y)x=y;}
void solve()
{
	int now=0,i,j,k;
	rep(i,1,m)dp[0][i]=0;
	rep(i,1,m)minnum[i]=0;
	int ans=0;
	bool ok=true;
	rep(i,1,n)
	{
		now^=1;mem(dp[now],-1);
		rep(j,L[i],R[i])
		{
			if (j+Y[i-1]<=m&&dp[now^1][j+Y[i-1]]!=-1)update(dp[now][j],dp[now^1][j+Y[i-1]]);
			if (j-X[i-1]>0&&minnum[j-X[i-1]]!=-1)update(dp[now][j],minnum[j-X[i-1]]+1);
			if (j==m)
			{
				rep(k,1,m)if (dp[now^1][k]!=-1)
				{
					int p=(m-k)/X[i-1];
					if ((m-k)%X[i-1]!=0||m==k)p++;
					update(dp[now][j],dp[now^1][k]+p);
				}
			}
		}
		mem(minnum,-1);
		rep(j,1,m)
		{
			if (dp[now][j]==-1)
			{
				if (j-X[i]<=0||minnum[j-X[i]]==-1)minnum[j]=-1;
				else minnum[j]=minnum[j-X[i]]+1;
			}
			else
			{
				if (j-X[i]<=0||minnum[j-X[i]]==-1)minnum[j]=dp[now][j];
				else minnum[j]=min(dp[now][j],minnum[j-X[i]]+1);
			}
		}
		bool zero=true;
		rep(j,L[i],R[i])if (dp[now][j]!=-1)zero=false;
		if (zero){ok=false;ans=num[i];break;}
	}
	if (!ok)
	{
		printf("0\n%d\n",ans);
	}
	else
	{
		printf("1\n");
		ans=-1;
		rep(i,L[n],R[n])if (dp[now][i]!=-1)update(ans,dp[now][i]);
		printf("%d\n",ans);
	}
}
int main()
{
	freopen("bird.in","r",stdin);freopen("bird.out","w",stdout);
	int i,j,k;
	scanf("%d%d%d",&n,&m,&p);
	rep(i,0,n-1)scanf("%d%d",&X[i],&Y[i]);
	rep(i,0,n)
	{
		L[i]=1;R[i]=m;
	}
	rep(i,1,p)
	{
		int x,l,r;
		scanf("%d%d%d",&x,&l,&r);
		L[x]=l+1;R[x]=r-1;
		gg[i]=x;
	}
	sort(gg+1,gg+p+1);
	rep(i,1,p)num[gg[i]+1]=i;
	num[0]=0;
	rep(i,1,n)if (num[i]==0)num[i]=num[i-1];
	solve();
	return 0;
}

