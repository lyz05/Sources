#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<ctime>
#include<vector>
#define rep(i,j,k) for (i=j;i<=k;i++)
#define reps(i,j,k) for (i=j;i>=k;i--)
#define mem(a,b) memset(a,b,sizeof(a))
#define mod 10007
#define maxn 11000
#define inf 0x3fffffff
using namespace std;
int a[maxn];
int main()
{
	srand(time(0));
	freopen("bird.in","w",stdout);
	int n=rand()%20+2,m=rand()%50+5;
	int i,j,k,p;
	p=rand()%(n-1)+1;
	printf("%d %d %d\n",n,m,p);
	rep(i,1,n)
	{
		int x,y;
		x=rand()%(m-1)+1;y=rand()%(m-1)+1;
		printf("%d %d\n",x,y);
	}
	rep(i,1,n-1)a[i]=i;
	rep(i,1,10000)
	{
		int x=rand()%(n-1)+1;int y=rand()%(n-1)+1;
		swap(a[x],a[y]);
	}
	rep(i,1,p)
	{
		int l,r;
		l=rand()%(m-1)+1,r=rand()%(m-1)+1;
		if (l>r)swap(l,r);
		printf("%d %d %d\n",a[i],l-1,r+1);
	}
	return 0;
}
