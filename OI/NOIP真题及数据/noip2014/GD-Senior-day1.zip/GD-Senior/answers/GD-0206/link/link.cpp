#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<vector>
#define rep(i,j,k) for (i=j;i<=k;i++)
#define reps(i,j,k) for (i=j;i>=k;i--)
#define mem(a,b) memset(a,b,sizeof(a))
#define mod 10007
#define maxn 210000
using namespace std;
struct node
{
	int y,next;
}edge[maxn*2];
int n,w[maxn],first[maxn],len,sta[maxn],head,tail,maxnum,ans,fa[maxn];
void ins(int x,int y)
{
	edge[++len].y=y;edge[len].next=first[x];first[x]=len;
}
void solve()
{
	int i,j,k;
	vector<int> a;
	sta[head=tail=1]=1;
	mem(fa,0);
	while(head<=tail)
	{
		int x=sta[head];
		if (fa[fa[x]]!=0)
		{
			maxnum=max(maxnum,w[x]*w[fa[fa[x]]]);
			ans+=(w[x]*w[fa[fa[x]]]*2)%mod;
			ans%=mod;
		}
		a.clear();
		for (k=first[x];k!=-1;k=edge[k].next)
		{
			int y=edge[k].y;
			if (y!=fa[x])
			{
				a.push_back(y);
				sta[++tail]=y;
				fa[y]=x;
			}
		}
		int sum=0,maxx=0;
		for (i=0;i<a.size();i++)
		{
			maxnum=max(maxnum,maxx*w[a[i]]);
			maxx=max(maxx,w[a[i]]);
			ans=(ans+(sum*w[a[i]]*2)%mod)%mod;
			sum=(sum+w[a[i]])%mod;
		}
		head++;
	}
	printf("%d %d\n",maxnum,ans);
}
int main()
{
	freopen("link.in","r",stdin);freopen("link.out","w",stdout);
	int i,j,k;
	scanf("%d",&n);
	maxnum=ans=0;
	len=0;mem(first,-1);
	rep(i,1,n-1)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		ins(x,y);ins(y,x);
	}
	rep(i,1,n)scanf("%d",&w[i]);
	solve();
	return 0;
}

