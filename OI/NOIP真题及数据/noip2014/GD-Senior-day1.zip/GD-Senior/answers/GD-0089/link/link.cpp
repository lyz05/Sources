#include <cstdio>
#include <algorithm>
#include <cstdlib>
#include <cstring>
using namespace std;

#define maxN 200005
#define Mod 10007

int N, H[maxN], now;
struct Tedge
{
	int id, nxt;
} edge[maxN * 2];

int w[maxN];

void addedge(int u, int v)
{
	++now;
	edge[now].id = v;
	edge[now].nxt = H[u];
	H[u] = now;
}

int main()
{
	freopen("link.in", "r", stdin);
	freopen("link.out", "w", stdout);

	scanf("%d", &N);
	
	now = 0;
	for (int i=1; i<=N; ++i) H[i] = 0;
	
	for (int i=1; i<N; ++i)
	{
		int u, v;
		scanf("%d%d", &u, &v);
		addedge(u, v);
		addedge(v, u);
	}
	
	for (int i=1; i<=N; ++i) scanf("%d", w+i);
	
	int Ans_s = 0;
	int Ans_max = 0;
	for (int i=1; i <= N; ++i)
	{
		int ws = 0, ws2 = 0;
		int m1 = 0, m2 = 0;
		for (int tmp = H[i]; tmp; tmp = edge[tmp].nxt)
		{
			int id = edge[tmp].id;
			ws = (ws + w[id]) % Mod;
			ws2 = (ws2 + w[id] * w[id] % Mod) % Mod;
			if (w[id] >= m1)
			{
				m2 = m1;
				m1 = w[id];
			}
			else if (w[id] > m2) m2 = w[id];
		}
		Ans_s = (Ans_s + ws * ws % Mod - ws2) % Mod;
		if (m1 * m2 > Ans_max) Ans_max = m1 * m2;
	}
	
	printf("%d %d\n", Ans_max, (Ans_s + Mod) % Mod);

	return 0;
}
