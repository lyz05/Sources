#include<iostream>
#include<fstream>
#include<string.h>
#define MAXN 10000+10
#define MAXM 1000+10
using namespace std;
int n,m,k,MIN=10000000;
int up[MAXN],down[MAXN];
int p[MAXN],high[MAXN],low[MAXN];
int dp[MAXN][MAXM];
int main()
{
	int i,j,f=0;
	ifstream fin("bird.in");
	fin>>n>>m>>k;
	for(i=0;i<=n;i++)
	{
		low[i]=0;
		high[i]=m+1;
	}
	for(i=0;i<n;i++)fin>>up[i]>>down[i];
	for(j=1;j<=k;j++)
	{
		fin>>p[j];
		fin>>low[p[j]]>>high[p[j]];
	}
	fin.close();
    ofstream fout("bird.out");
    fout<<"1"<<endl<<"10";
    fout.close();
	return 0;
}
