#include<iostream>
#include<fstream>
#include<string.h>
#define MAXN 2000+10
using namespace std;
int ans=0,MAX=0,W;
int d[MAXN][MAXN];
int v[MAXN][MAXN];
int n,w[MAXN];
void find(int x)
{
	int i,j;
	for(i=1;i<=n;i++)
	{
		if(d[x][i]==1)
		{
			for(j=1;j<=n;j++)
			{
				if(j!=x&&d[i][j]==1&&v[x][j]==0)
				{
					W=w[x]*w[j];
					if(W>MAX)MAX=W;
					ans+=W;
					v[x][j]=1;
				}
			}
		}
	}
}
int main()
{
	memset(v,0,sizeof(v));
	int i,x,y,j,k=1;
	ifstream fin("link.in");
	fin>>n;
	for(i=1;i<n;i++)
	{
		fin>>x>>y;
		d[x][y]=1;
		d[y][x]=1;
	}
	for(i=1;i<=n;i++)fin>>w[i];
	fin.close();
	for(i=1;i<=n;i++)find(i);
	ofstream fout("link.out");
	fout<<MAX<<" "<<ans;
	fout.close();
	return 0; 
}
