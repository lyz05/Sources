#include<iostream>
#include<fstream>
using namespace std;
int rps[5][5];
void rps_in()
{
	rps[0][0]=0;rps[0][1]=2;rps[0][2]=1;rps[0][3]=1;rps[0][4]=2;
	rps[1][0]=1;rps[1][1]=0;rps[1][2]=2;rps[1][3]=1;rps[1][4]=2;
	rps[2][0]=2;rps[2][1]=1;rps[2][2]=0;rps[2][3]=2;rps[2][4]=1;
	rps[3][0]=2;rps[3][1]=2;rps[3][2]=1;rps[3][3]=0;rps[3][4]=1;
	rps[4][0]=1;rps[4][1]=1;rps[4][2]=2;rps[4][3]=2;rps[4][4]=0;
	return;
}
int main()
{
	ifstream fin("rps.in");
	int a[210],b[210],na,nb,n;
	fin>>n>>na>>nb;
	int i,j,ka=0,kb=0;
	for(i=1;i<=na;i++)fin>>a[i];
	for(j=1;j<=nb;j++)fin>>b[j];
	fin.close();
	for(i=na+1;i<=n;i++)a[i]=a[(i-1)%na+1];
	for(j=nb+1;j<=n;j++)b[j]=b[(j-1)%nb+1];
	rps_in();
	for(i=1;i<=n;i++)
	{
		if(rps[a[i]][b[i]]==0)continue;
		else if(rps[a[i]][b[i]]==1)ka++;
		else kb++;
	}
	ofstream fout("rps.out");
	fout<<ka<<" "<<kb;
	fout.close();
	return 0;
}
