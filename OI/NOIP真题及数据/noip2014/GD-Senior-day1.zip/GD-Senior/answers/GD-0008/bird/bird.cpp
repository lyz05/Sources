#include <cstdio>
#include <algorithm>
#include <cstring>
#define repu(i,x,y) for (int i=x; i<=y; ++i)
#define repd(i,x,y) for (int i=x; i>=y; --i)
using namespace std;

int n,m,k,x[10100],y[10100],l[10100],r[10100],t,sum[10100],f[2][1100],cnt,ans;
struct data
{
    int p,l,h;
    bool operator<(const data &t) const
    {
        return p<t.p;
    }
} a[10100];
bool flag;

void dp()
{
    t=0;
    f[0][0]=1<<30;
    repu(i,1,n)
    {
        t^=1;
        memset(f[t],127,sizeof(f[t]));
        bool flag=true;
        repu(j,1,r[i])
            if (j-x[i]>0)
                f[t][j]=min(f[t][j],min(f[t^1][j-x[i]],f[t][j-x[i]])+1);
        repu(j,1,l[i]-1)
            f[t][j]=1<<30;
        repu(j,l[i],r[i])
        {
            if (j+y[i]<=m)
                f[t][j]=min(f[t^1][j+y[i]],f[t][j]);
            if (f[t][j]<1<<30)
                flag=false;
        }
        cnt=1;
        if (r[i]==m)
            repd(j,m,l[i-1])
            {
                if (cnt*x[i]+j<m)
                    ++cnt;
                f[t][m]=min(f[t][m],f[t^1][j]+cnt);
            }
        if (flag && f[t][m]>=1<<30)
        {
            printf("0\n");
            printf("%d\n",sum[i-1]);
            return;
        }
    }
    printf("1\n");
    ans=1<<30;
    repu(i,l[n],r[n])
        ans=min(ans,f[t][i]);
    printf("%d\n",ans);
}

int main()
{
    freopen("bird.in","r",stdin);
    freopen("bird.out","w",stdout);
    scanf("%d%d%d",&n,&m,&k);
    repu(i,1,n)
        scanf("%d%d",&x[i],&y[i]);
    repu(i,1,k)
        scanf("%d%d%d",&a[i].p,&a[i].l,&a[i].h);
    sort(a+1,a+1+k);
    t=1;
    repu(i,0,n)
    {
        sum[i]=sum[i-1];
        if (t<=k && a[t].p==i)
            l[i]=a[t].l+1,r[i]=a[t].h-1,++sum[i],++t;
        else
            l[i]=1,r[i]=m;
    }
    dp();
    return 0;
}
