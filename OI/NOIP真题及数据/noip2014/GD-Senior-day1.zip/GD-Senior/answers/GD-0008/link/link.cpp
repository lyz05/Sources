#include <cstdio>
#include <algorithm>
#define repu(i,x,y) for (int i=x; i<=y; ++i)
#define repe(x) for (edge *i=first[x]; i; i=i->next)
using namespace std;

const int mod=10007;
int n,w[200100],u,v,fa[200100],ans1,ans2;
struct edge
{
    int v;
    edge *next;
} pool[400100],*tp=pool,*first[200100];

void dfs(int x)
{
    if (fa[fa[x]])
    {
        ans1=max(ans1,w[x]*w[fa[fa[x]]]);
        ans2=(ans2+(w[x]*w[fa[fa[x]]]%mod<<1))%mod;
    }
    int sum=0,fst=0,snd=0;
    repe(x)
        if (i->v!=fa[x])
        {
            fa[i->v]=x,dfs(i->v);
            sum=(sum+w[i->v])%mod;
            if (w[i->v]>fst)
                snd=fst,fst=w[i->v];
            else
                if (w[i->v]>snd)
                    snd=w[i->v];
        }
    ans1=max(ans1,fst*snd);
    repe(x)
        if (i->v!=fa[x])
            ans2=(ans2+(sum-w[i->v]+mod)*w[i->v])%mod;
}

int main()
{
    freopen("link.in","r",stdin);
    freopen("link.out","w",stdout);
    scanf("%d",&n);
    repu(i,2,n)
    {
        scanf("%d%d",&u,&v);
        tp->v=v,tp->next=first[u],first[u]=tp++;
        tp->v=u,tp->next=first[v],first[v]=tp++;
    }
    repu(i,1,n)
        scanf("%d",&w[i]);
    dfs(1);
    printf("%d %d\n",ans1,ans2);
    return 0;
}
