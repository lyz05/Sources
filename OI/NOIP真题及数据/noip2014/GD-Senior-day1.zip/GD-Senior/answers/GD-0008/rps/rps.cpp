#include <cstdio>
#define repu(i,x,y) for (int i=x; i<=y; ++i)
using namespace std;

const int res[5][5]={{1,0,2,2,0},{2,1,0,2,0},
{0,2,1,0,2},{0,0,2,1,2},{2,2,0,0,1}};
int n,na,nb,a[1000],b[1000],i,j,ansa,ansb;

int main()
{
    freopen("rps.in","r",stdin);
    freopen("rps.out","w",stdout);
    scanf("%d%d%d",&n,&na,&nb);
    repu(i,1,na)
        scanf("%d",&a[i]);
    repu(i,1,nb)
        scanf("%d",&b[i]);
    i=j=1;
    while (n--)
    {
        if (!res[a[i]][b[j]])
            ++ansb;
        if (res[a[i]][b[j]]==2)
            ++ansa;
        if ((++i)>na)
            i=1;
        if ((++j)>nb)
            j=1;
    }
    printf("%d %d\n",ansa,ansb);
    return 0;
}
