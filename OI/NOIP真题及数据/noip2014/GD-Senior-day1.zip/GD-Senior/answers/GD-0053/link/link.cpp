#include <cstdio>
#include <cstdlib>
#include <cstring>
using namespace std;
typedef long long LL;
const long maxn=200000;

long n,an=0,ah[maxn+5];
long Q[maxn+5],fa[maxn+5];
LL x[maxn+5],ansmx=0,anss=0;
struct pat{long lh,to;} a[2*maxn+5];
bool f[maxn+5];

void add(long x,long y){
	an++; a[an].to=y; a[an].lh=ah[x]; ah[x]=an;
	an++; a[an].to=x; a[an].lh=ah[y]; ah[y]=an;
}
void init(){
	long i,j,k;
	scanf("%ld",&n);
	memset(ah,0,sizeof(ah));
	for (i=1;i<n;i++){
		scanf("%ld%ld",&j,&k);
		add(j,k);
	}
	for (i=1;i<=n;i++){
		scanf("%ld",&j);
		x[i]=j;
	}
	memset(f,0,sizeof(f));
}
void tr(){
	long P,p=0,q=1,i,t;
	LL s,tx,m1,m2;
	Q[0]=1; fa[1]=0;
	while (p<q){
		P=Q[p];
		s=x[fa[P]];
		for (i=ah[P];i>0;i=a[i].lh){
			t=a[i].to;
			if (t!=fa[P]){
				fa[t]=P;
				Q[q]=t;
				q++;
				s+=x[t];
			}
		}
		//ans=(ans+x[fa[P]]*(s-x[fa[P]]))%10007;
		m1=m2=0;
		for (i=ah[P];i>0;i=a[i].lh){
			t=a[i].to;
			if (x[t]>m1){m2=m1;m1=x[t];}
				else if (x[t]>m2) m2=x[t];
			anss=(anss+x[t]*(s-x[t])%10007)%10007;
		}
		if (m2>0) tx=m1*m2;
		if (tx>ansmx) ansmx=tx;
		p++;
	}
	i=ansmx; t=anss;
	printf("%ld %ld",i,t);
}
int main(){
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	init();
	tr();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
