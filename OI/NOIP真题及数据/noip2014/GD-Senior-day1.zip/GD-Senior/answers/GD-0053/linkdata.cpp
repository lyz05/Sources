#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
using namespace std;
bool f[1005];
long h[1005];
int main(){
	freopen("link.in","w",stdout);
	srand(time(0));
	long n=1000,i,j,k;
	printf("%ld\n",n);
	memset(f,0,sizeof(f));
	for (i=1;i<=n;i++){
		do{
			h[i]=rand()%n;
		}while (f[h[i]]);
		f[h[i]]=1;
	}
	for (i=1;i<=n;i++)
	if (h[i]>0){
		j=i;
		do {k=rand()%n+1;} while (h[k]>=h[j]);
		printf("%ld %ld\n",j,k);
	}
	for (i=0;i<n;i++)
		printf("%ld ",rand()*rand()%10000+1);
		
	fclose(stdout);
	return 0;
}
