#include <cstdio>
#include <cstdlib>
#include <cstring>
using namespace std;
const long c[5][5]={
	{0,0,1,1,0},
	{1,0,0,1,0},
	{0,1,0,0,1},
	{0,0,1,0,1},
	{1,1,0,0,0}};
long n,na,nb,a[205],b[205];
void init(){
	long i;
	scanf("%ld%ld%ld",&n,&na,&nb);
	for (i=0;i<na;i++)
		scanf("%ld",&a[i]);
	for (i=0;i<nb;i++)
		scanf("%ld",&b[i]);
}
void tr(){
	long i,j=0,k=0,sa=0,sb=0;
	for (i=0;i<n;i++){
		sa+=c[a[j]][b[k]];
		sb+=c[b[k]][a[j]];
		j=(j+1)%na;
		k=(k+1)%nb;
	}
	printf("%ld %ld",sa,sb);
}
int main(){
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	init();
	tr();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
