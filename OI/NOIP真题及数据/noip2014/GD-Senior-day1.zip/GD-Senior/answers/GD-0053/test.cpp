#include <cstdio>
#include <cstdlib>
#include <cstring>
using namespace std;
int main(){
	freopen("test.in","r",stdin);
	freopen("test.out","w",stdout);
	long a[100],n,i,j,t;
	scanf("%ld",&n);
	for (i=0;i<n;i++)
		scanf("%ld",&a[i]);
	for (i=0;i<n;i++)
		for (j=i+1;j<n;j++)
			if (a[i]>a[j]){
				t=a[i]; a[i]=a[j]; a[j]=t;
			}
	for (i=0;i<n;i++)
		printf("%ld ",a[i]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
