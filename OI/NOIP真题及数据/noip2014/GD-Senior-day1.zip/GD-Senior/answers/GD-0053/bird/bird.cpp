#include <cstdio>
#include <cstdlib>
#include <cstring>
using namespace std;
long n,m,qn,vu[10005],vd[10005],U[10005],D[10005],a[2][2005];
bool f[10005];
void init(){
	long i,j,k,l;
	scanf("%ld%ld%ld",&n,&m,&qn);
	for (i=0;i<n;i++)
		scanf("%ld%ld",&vu[i],&vd[i]);
	for (i=0;i<=n;i++){
		U[i]=m;
		D[i]=1;
	}
	memset(f,0,sizeof(f));
	for (i=0;i<qn;i++){
		scanf("%ld%ld%ld",&l,&j,&k);
		U[l]=k-1; D[l]=j+1;
		f[l]=1;
	}
}
void tr(){
	long i,j,k,mi,t,tt,p=0,q=1,s=0;
	bool die;
	for (i=1;i<=m;i++) a[0][i]=0;
	for (i=1;i<=n;i++){
		for (j=0;j<=m;j++) a[q][j]=-1;
		die=1;
		for (j=0;j<vu[i-1];j++){
			mi=n*m+1;
			for (k=D[i]+j;k<=U[i];k+=vu[i-1]){
				tt=k-vu[i-1];
				if (D[i-1]<=tt&&tt<=U[i-1]){
					t=a[p][tt];
					if (t>=0){
						t-=(k-D[i])/vu[i-1];
						if (t<mi) mi=t;
					}
				}
				if (mi<=n*m)
					a[q][k]=mi+(k-D[i])/vu[i-1]+1;
				else a[q][k]=-1;
			}
		}
		for (j=D[i];j<=U[i];j++){
			k=j+vd[i-1];
			if (D[i-1]<=k&&k<=U[i-1]){
				t=a[p][k];
				if (t>=0)
					if (t<a[q][j]||a[q][j]<0) a[q][j]=t;
			}
			if (a[q][j]>=0) die=0;
		}
		if (U[i]==m){
			mi=a[q][m];
			for (j=m+1;j<=m+vu[i-1];j++){
				k=j-vu[i-1];
				if (D[i-1]<=k&&k<=U[i-1]){
					t=a[p][k];
				if (t>=0)
					if (t+1<mi||mi<0) mi=t+1;
				}
			}
			a[q][m]=mi;
			if (mi>=0) die=0;
		}
		if (die){
			printf("0\n%ld",s);
			return;
		}
		/*for (j=1;j<=m;j++)
			printf("%ld ",a[q][j]);
		printf("\n");*/
		if (f[i]) s++;
		p^=1; q^=1;
	}
	mi=-1;
	for (i=1;i<=m;i++)
		if (a[p][i]>=0)
			if (a[p][i]<mi||mi<0)
				mi=a[p][i];
	printf("1\n%ld",mi);
}
int main(){
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	init();
	tr();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
