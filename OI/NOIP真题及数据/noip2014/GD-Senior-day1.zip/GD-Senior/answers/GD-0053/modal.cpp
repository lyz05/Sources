#include <cstdio>
#include <cstdlib>
#include <cstring>
using namespace std;
int main(){
	freopen(".in","r",stdin);
	freopen(".out","w",stdout);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
