#include <cstdio>
#include <cstdlib>
#include <cstring>
using namespace std;
long n,a[1005][1005];
long long ansmx=0,anss=0,x[1005];
void init(){
	long i,j,k;
	scanf("%ld",&n);
	memset(a,0,sizeof(a));
	for (i=1;i<n;i++){
		scanf("%ld%ld",&j,&k);
		a[j][k]=a[k][j]=1;
	}
	for (i=1;i<=n;i++){
		scanf("%ld",&j);
		x[i]=j;
	}
}
void tr(){
	long i,j,k;
	long long t;
	for (k=1;k<=n;k++)
		for (i=1;i<=n;i++)
			if (a[i][k]>0)
				for (j=1;j<=n;j++)
					if (i!=j&&a[k][j]>0)
						if (a[i][j]==0||a[i][k]+a[k][j]<a[i][j])
							a[i][j]=a[i][k]+a[k][j];
	for (i=1;i<=n;i++)
		for (j=1;j<=n;j++)
			if (a[i][j]==2){
				t=x[i]*x[j];
				if (t>ansmx) ansmx=t;
				anss=(anss+t%10007)%10007;
			}
	i=ansmx; j=anss;
	printf("%ld %ld",i,j);
}
int main(){
	freopen("link.in","r",stdin);
	freopen("linktest.out","w",stdout);
	init();
	tr();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
