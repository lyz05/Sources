#include<iostream>
#include<cstdio>
#include<string.h>
using namespace std;
const int maxx=200001;
struct data{
	int x;int y;
};
struct data2{
	int a;
	int one;int f1;
	int two; int f2;
};
int n,i,j,k,lj=0,ljmax=0,w[maxx]={0},xx,yy;data b[maxx];data2 f[maxx];
void intt()
{
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	cin>>n;
	for (i=1;i<=n-1;i++)
	{
		cin>>xx>>yy;
		b[i].x=xx;b[i].y=yy;
	}
	for (i=1;i<=n;i++)
	cin>>w[i];
	
	for (i=1;i<=n;i++)
	f[i].a=f[i].one=f[i].two=f[i].f1=f[i].f2=0;
}
void bg(int m,int bb)
{
    if (w[bb]>f[m].one) 
    	{
    		f[m].two=f[m].one;f[m].f2=f[m].f1;
    		f[m].one=w[bb];f[m].f1=bb;
    		
    	}	
    	else
    	if (w[bb]>f[m].two)
    	{
    			f[m].two=w[bb];f[m].f2=bb;
    	}
	
}
int main()
{

    intt();
    for (i=1;i<=n-1;i++)
    {
    	xx=b[i].x;yy=b[i].y;
    	f[xx].a+=w[yy];
    	bg(yy,xx);
    	f[yy].a+=w[xx];
    	bg(xx,yy);
    	
    }
    for (i=1;i<=n-1;i++)
    {
    	xx=b[i].x;yy=b[i].y;
    	k=(((f[xx].a-w[yy])*w[yy])+((f[yy].a-w[xx])*w[xx]))%10007;
    	lj=(lj+k)%10007;
    	if (f[xx].f1!=yy) ljmax=max(ljmax,f[xx].one*w[yy]);
    	else 
    	if (f[xx].f2!=0) ljmax=max(ljmax,f[xx].two*w[yy]);
    	
    		if (f[yy].f1!=xx) ljmax=max(ljmax,f[yy].one*w[xx]);
    	else 
    	if (f[yy].f2!=0) ljmax=max(ljmax,f[yy].two*w[xx]);
    	
    }
    cout<<ljmax<<" "<<lj;
	fclose(stdin);fclose(stdout);
	return 0;
}
