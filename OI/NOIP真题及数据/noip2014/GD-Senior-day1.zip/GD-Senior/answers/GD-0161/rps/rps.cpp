#include<iostream>
#include<cstdio>
#include<string.h>
using namespace std;
const int gx[5][5]={{2,0,1,1,0},{1,2,0,1,0},{0,1,2,0,1},{0,0,1,2,1},{1,1,0,0,2}};
int n,na,nb,i,j,nna,nnb,a[201],b[201],aa,bb,la=0,lb=0;
void intt()
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	cin>>n>>na>>nb;
	for (i=1;i<=na;i++)
	cin>>a[i];
	for (i=1;i<=nb;i++)
	cin>>b[i];
}
int main()
{
	intt();
	
	for (i=1;i<=n;i++)
	{
		nna++;nnb++;
		if (nna>na) nna=1;if (nnb>nb) nnb=1;
		aa=a[nna];bb=b[nnb];
		if (gx[aa][bb]==0) lb++;
		if (gx[aa][bb]==1) la++;
		
		
	}
	cout<<la<<" "<<lb;

	fclose(stdin);fclose(stdout);
	return 0;
}
