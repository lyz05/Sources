#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <string>

using namespace std;

const int maxdot=200005;
const int maxedge=200005*2;
const int oo=10007;

int tree,v[maxedge],next[maxedge],node[maxedge];
int n,w[maxedge];
int ans1,ans2;

void insert(int x,int y)
{
	tree++;
	v[tree]=y;
	next[tree]=node[x];
	node[x]=tree;
	return ;
}
int main()
{
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	cin >> n;
	for (int i=1;i<=n-1;i++)
	{
		int x,y;
		scanf("%d %d",&x,&y);
		insert(x,y);
		insert(y,x);
	}
	for (int i=1;i<=n;i++)
	 scanf("%d",&w[i]);
	 
	for (int i=1;i<=n;i++)
	{
		int sum1=0;
		int sum2=0;
		int max1=0;
		int max2=0;
		for (int z=node[i];z!=0;z=next[z])
		{
			sum1=(sum1+w[v[z]]) %oo;
			sum2=(sum2+ (w[v[z]]*w[v[z]]) %oo ) %oo;
			if (w[v[z]]>max2)
			{
				if (w[v[z]]>max1) { max2=max1;max1=w[v[z]];}
				else {max2=w[v[z]];}
			}
		}
		ans1=max(ans1,max1*max2);
		ans2=ans2+(sum1*sum1) %oo -sum2;
		for (;ans2<0;) ans2+=oo;
		ans2=ans2 %oo;
	}
	cout << ans1 << " " <<ans2 << endl;
	return 0;
}

