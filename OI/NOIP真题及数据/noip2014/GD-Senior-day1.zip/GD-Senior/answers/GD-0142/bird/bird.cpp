#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <string>

using namespace std;

const int oo=2147483647;

const int maxdot=10505;

int n,m,kk,u[maxdot],d[maxdot];
int f[2][maxdot],l[maxdot],h[maxdot];
int From,Go;
int ans1,ans2;

void init()
{
	for (int i=1;i<=m;i++)
	f[0][i]=0;
	f[0][0]=oo;
	return ;
}

int main()
{
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	cin>> n >> m >> kk;
	
	for (int i=1;i<=n+1;i++) h[i]=m+1;
	
	for (int i=1;i<=n;i++)
	 scanf("%d %d",&u[i],&d[i]);
	for (int i=1;i<=kk;i++)
	{
		int P,L,H;
		scanf("%d %d %d",&P,&L,&H);
		l[P+1]=L;h[P+1]=H;
	}
	
	init();
	From=1;
	Go=0;
	ans1=0;
	for (int i=1;i<=n;i++)
	{
		From=1-From;
		Go=1-Go;
		for (int j=0;j<=m;j++) f[Go][j]=oo;
		for (int j=u[i]+1;j<=m;j++)
		{
			if (f[From][j-u[i]]!=oo)
			f[Go][j]=min(f[Go][j],f[From][j-u[i]]+1);
		}
		for (int j=u[i]+1;j<=m;j++)
		{
			if (f[Go][j-u[i]]!=oo)
			f[Go][j]=min(f[Go][j],f[Go][j-u[i]]+1);
		}
		
		for (int j=m-u[i];j<=m;j++)
		{
			if (f[From][j]!=oo)
			f[Go][m]=min(f[Go][m],f[From][j]+1);
		}
		
		for (int j=1;j<=m-d[i];j++)
		{
			f[Go][j]=min(f[Go][j],f[From][j+d[i]]);
		}
		for (int j=0;j<=l[i+1];j++) f[Go][j]=oo;
		for (int j=h[i+1];j<=m;j++) f[Go][j]=oo;
		
		bool ansboo=false;
		for (int j=0;j<=m;j++)
		{
			if (f[Go][j]!=oo) {ansboo=true;break;}
		}
		if (ansboo==false) 
		{
		cout <<0 << endl;
		cout << ans1 << endl;
		return 0;
		}
		if (h[i+1]!=m+1) { ans1++;}
	}
	cout << 1 << endl;
	ans2=oo;
	for (int i=1;i<=m;i++)
	 ans2=min(ans2,f[Go][i]);
	cout << ans2 << endl;
	return 0;
}

