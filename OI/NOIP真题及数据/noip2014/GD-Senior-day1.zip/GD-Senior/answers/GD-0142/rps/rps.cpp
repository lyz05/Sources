#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <string>

using namespace std;

const int sc[5][5]
          ={{0,0,1,1,0},
            {1,0,0,1,0},
            {0,1,0,0,1},
            {0,0,1,0,1},
            {1,1,0,0,0}};
const int maxdot=505;


int ans1,ans2,n,na,nb;
int a[maxdot],b[maxdot];

int main()
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	cin >> n >> na >> nb;
	for (int i=1;i<= na;i++)
	 cin >> a[i];
	for (int i=1;i<= nb;i++)
	 cin >> b[i];
	int a1=0;
	int b1=0;
	ans1=0;ans2=0;
	for (int i=1;i<=n;i++)
	{
		a1++;b1++;
		if (a1>na) a1=1;
		if (b1>nb) b1=1;
		ans1+=sc[a[a1]][b[b1]];
		ans2+=sc[b[b1]][a[a1]];
    }
    cout << ans1 << " " << ans2 << endl;
	return 0;
}

