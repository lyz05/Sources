#include<cstdio>
#include<cstdlib>
#define MAXN 10001
#define MAXM 1001
#define INTMAX 1000001
#define MAX(a,b) ((a)>(b)?(a):(b))
#define MIN(a,b) ((a)<(b)?(a):(b))
using namespace std;

int n,m,k,x[MAXN],y[MAXN],down[MAXN],up[MAXN],f[2][MAXM],ans;
bool find=1;
void init()
{
    scanf("%d%d%d",&n,&m,&k);
    for (int i=0;i<n;i++)
      scanf("%d%d",&x[i],&y[i]);
    for (int i=1;i<=n;i++)  {
	  x[i]=0;  y[i]=m;
	}
    int a;
	for (int i=1;i<=k;i++)  {
	  scanf("%d",&a);
	  scanf("%d%d",&down[a],&up[a]);
	}  
	return;
}
void perform()
{
    for (int i=0;i<=m;i++)
      f[0][i]=1;
    int a,b,c,d,jmax,jmin;
    a=0; b=m;  
    for (int i=1;i<=n;i++)  {
      bool sign=0;
     /* jmin=MAX(down[i]+1,0);  
	  jmin=MAX(a-y[i-1],jmin);
	  jmax=MIN(up[i]-1,m);
	  jmax=MIN(b+x[i-1],jmax);
	  printf("%d %d% d%\n",i,jmin,jmax);  */ 
	  for (int j=1;j<=m;j++)  {
	    sign=1;
	    if (j-x[i-1]>0 && f[(i-1)%2][j-x[i-1]]>0) c=f[(i-1)%2][j-x[i-1]]+1;  
		  else c=INTMAX;
		if (f[(i-1)%2][MIN(m,j+y[i-1])]>0)  d=f[(i-1)%2][MIN(m,j+y[i-1])];
	    f[i%2][j]=MIN(c,d);
	  }
	  if (!sign)  { find=0;ans=i-1;break;}
	//  a=jmin;
	//  b=jmax;
	}
	if (find)  {
	   ans=INTMAX;
	   for (int i=1;i<=m;i++)
	     if (f[n%2][i]<ans && f[n%2][i]!=0)  ans=f[n%2][i];  
	   printf("1\n%d",ans);
	} 
	else  printf("0\n%d",ans);
	return;
}
int main()
{
    freopen("bird.in","r",stdin);
    freopen("bird.out","w",stdout);
	init();
	perform();
	return 0;
}
