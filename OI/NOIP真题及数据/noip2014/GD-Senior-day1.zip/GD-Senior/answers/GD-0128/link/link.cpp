#include<cstdio>
#include<cstdlib>
#define MAXX 200001
#define MO 10007
using namespace std;


struct {
   int max,cmax,min,cmin;
   int sum;
}  g[MAXX];
int n,v[MAXX],x[MAXX],y[MAXX],maxans;
long long ans;

void init()
{
    scanf("%d",&n);
    for (int i=1;i<=n-1;i++)  
	  scanf("%d%d",&x[i],&y[i]);
	for (int i=1;i<=n;i++)
	  scanf("%d",&v[i]);
	for (int i=1;i<=n;i++)  {
	  g[i].max=0;  g[i].cmax=0;
	  g[i].min=0;  g[i].cmin=0;
	  g[i].sum=0;
	}
	int a,b;
	for (int i=1;i<n;i++)  {
	  a=x[i];  
	  b=y[i];
	  if (v[b]>g[a].max)  {g[a].max=v[b];g[a].cmax++;}
	  else if (v[b]>g[a].min)  {g[a].min=v[b];g[a].cmin++;}
	  g[a].sum +=v[b];
	  
	  if (v[a]>g[b].max)  {g[b].max=v[a];g[b].cmax++;}
	  else if (v[a]>g[b].min)  {g[b].min=v[a];g[b].cmin++;}
	  g[b].sum +=v[a];
	} 
	
	ans=0;
	maxans=0;
	for (int i=1;i<n;i++)  {
	  a=x[i];
	  b=y[i];
	  
	  ans=(ans+(g[b].sum-v[a])*v[a]%MO)%MO;
	  if (v[a]==g[b].max && g[b].cmax==1)  {
	     if (v[a]*g[b].min>maxans && g[b].cmin>0)  maxans=v[a]*g[b].min;  
	  } 
	  else if (v[a]!=g[b].max && g[b].cmax>0 && v[a]*g[b].max>maxans)  maxans=v[a]*g[b].max;
	  
	  ans=(ans+(g[a].sum-v[b])*v[b]%MO)%MO;
	  if (v[b]==g[a].max && g[a].cmax==1)  {
	     if (v[b]*g[a].min>maxans && g[a].cmin>0)  maxans=v[b]*g[a].min;  
	  } 
	  else if (v[b]!=g[a].max && g[a].cmax>0 && v[b]*g[a].max>maxans)  maxans=v[b]*g[a].max;
	} 
	
	printf("%d %d",maxans,ans);
	return;
}
int main()
{
    freopen("link.in","r",stdin);
    freopen("link.out","w",stdout);
    init();
    return 0;
}
