#include<cstdio>
#include<cstdlib>
using namespace std;

int n,a[201],b[201],x,y,sa=0,sb=0;
int g[5][5]={{0,0,1,1,0},{1,0,0,1,0},{0,1,0,0,1},{0,0,1,0,1},{1,1,0,0,0}};
void init()
{
    scanf("%d%d%d",&n,&x,&y);
    for (int i=1;i<=x;i++)
      scanf("%d",&a[i]);
    for (int i=1;i<=y;i++)
      scanf("%d",&b[i]);
    a[0]=a[x];
    b[0]=b[y];
    for (int i=x+1;i<=n;i++) 
      a[i]=a[i%x];
    for (int i=y+1;i<=n;i++)
      b[i]=b[i%y];
    for (int i=1;i<=n;i++)  {
      //printf("%d%d%d%d\n",a[i],b[i],g[a[i]][b[i]],g[b[i]][a[i]]);
      sa +=g[a[i]][b[i]];
	  sb +=g[b[i]][a[i]];	
	}
	printf("%d %d",sa,sb);
	return;
}
int main()
{
    freopen("rps.in","r",stdin);
    freopen("rps.out","w",stdout);
	init();
    return 0;
}
