# include<stdio.h>
# include<string.h>
# include<algorithm>
using namespace std;
const int maxn=210;
int n,m1,m2;
int ans1=0,ans2=0;
int a[6][6];
int C[maxn],D[maxn];
int t1,t2;
int main(){
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	a[5][5]=a[1][1]=a[2][2]=a[3][3]=a[4][4]=0;
	a[1][3]=a[1][4]=a[2][1]=a[2][4]=a[3][2]=a[3][5]=a[4][3]=a[4][5]=a[5][1]=a[5][2]=1;
	a[1][2]=a[1][5]=a[2][3]=a[2][5]=a[3][1]=a[3][4]=a[4][1]=a[4][2]=a[5][3]=a[5][4]=0;
	scanf("%d%d%d",&n,&m1,&m2);
	for(int i=1;i<=m1;i++)
		scanf("%d",&C[i]),C[i]++;
	for(int i=1;i<=m2;i++)
		scanf("%d",&D[i]),D[i]++;
	for(int i=1;i<=n;i++){
		t1=(i%m1);if(i%m1==0) t1=m1;
		t2=(i%m2);if(i%m2==0) t2=m2;
		ans1+=a[C[t1]][D[t2]];
		ans2+=a[D[t2]][C[t1]];
		//printf("ans1:%d ans2:%d\n",ans1,ans2);
	}
	printf("%d\n%d\n",ans1,ans2);
	//system("pause");
	return 0;
}
 