# include<stdio.h>
# include<string.h>
# include<vector>
# include<algorithm>
using namespace std;
typedef long long LL;
const int maxn=200010;
const int mod=10007;
vector<int> C[maxn];
int n;
int a[maxn],b[maxn],w[maxn];
LL ans1=0,ans2=0;
int main(){
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<n;i++){
		scanf("%d%d",&a[i],&b[i]);
	}
	for(int i=1;i<=n;i++)
		scanf("%d",&w[i]);
	for(int i=1;i<n;i++){
		C[a[i]].push_back(w[b[i]]);
		C[b[i]].push_back(w[a[i]]);
	}
	LL tot,num,max1,max2;
	for(int i=1;i<=n;i++){
		tot=0,num=0,max1=0,max2=0;
		for(int j=0;j<C[i].size();j++){
			num+=(LL)C[i][j]*C[i][j],tot+=C[i][j];
			//printf("C[%d][%d]:%d num:%lld\n",i,j,C[i][j],num);
			if(C[i][j]>=max1) max2=max1,max1=C[i][j];
			else if(C[i][j]>max2) max2=C[i][j];
		}
		ans1=max(ans1,max1*max2);
		//printf("tot:%lld\n",tot);
		//printf("num:%lld\n",num);
		//printf("tot*tot:%lld\n",tot*tot);
		ans2=ans2+(tot*tot-num);
		if(ans2>=mod) ans2%=mod;
	}
	printf("%lld",ans1);printf(" %lld\n",ans2);
	//system("pause");
	return 0;
}
 