# include<stdio.h>
# include<string.h>
# include<algorithm>
using namespace std;
const int maxn=10010;
const int maxm=1010;
const int INF=1000000;
int n,m,k;
int x[maxn],y[maxn];
int dp[2][maxm],q[maxm];

struct Tube{
	int X,h1,h2;
}tube[maxn];

bool cmp(Tube A,Tube B){
	return A.X<B.X;
}

int update(int x,int y){
	if(x==-1||y<x) return y;
	return x;
}

int main(){
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=0;i<n;i++){
		scanf("%d%d",&x[i],&y[i]);
	}
	for(int i=1;i<=k;i++)
		scanf("%d%d%d",&tube[i].X,&tube[i].h1,&tube[i].h2);
	if(k>0) sort(tube+1,tube+k+1,cmp);
	int t_pos=1;if(k==0) tube[1].X=-100;
	dp[0][0]=-1;for(int i=1;i<=m;i++) dp[0][i]=0;
	bool fly=true,ok;
	int ans;
	int last,now,t;
	for(int i=1;i<=n;i++){
		now=i%2;last=now^1;ok=false;
		memset(dp[now],-1,sizeof(dp[now]));for(int j=0;j<=m;j++) q[j]=-INF;
		for(int j=1;j<m;j++){
			t=j%x[i-1];
			if(tube[t_pos].X!=i||(j<tube[t_pos].h2&&j>tube[t_pos].h1)){
				if(q[t]!=-INF) dp[now][j]=q[t]+j/x[i-1];
				if(j+y[i-1]<=m){
					if(dp[last][j+y[i-1]]!=-1)
						dp[now][j]=update(dp[now][j],dp[last][j+y[i-1]]);
				}
			}
			if(dp[last][j]==-1) continue;
			if(q[t]==-INF) q[t]=dp[last][j]-j/x[i-1];
			else if(dp[last][j]-j/x[i-1]<q[t]) q[t]=dp[last][j]-j/x[i-1];
		}
		
		if(tube[t_pos].X!=i||(m<tube[t_pos].h2&&m>tube[t_pos].h1)){
			for(int j=1;j<m;j++){
				if(dp[last][j]!=-1) dp[now][m]=update(dp[now][m],dp[last][j]+(m-j+x[i-1]-1)/x[i-1]);
			}
			if(dp[last][m]!=-1) dp[now][m]=update(dp[now][m],dp[last][m]+1);
		}
		
		for(int j=1;j<=m;j++){
			//printf("dp[%d][%d]:%d\n",i,j,dp[now][j]);
			if(dp[now][j]!=-1) {ok=true;break;
				}
		}
		//if(i>=9999)
		//for(int j=1;j<=m;j++) printf("dp[%d][%d]:%d\n",i,j,dp[now][j]);
		if(!ok) {fly=false,ans=t_pos-1;break;}
		if(i==tube[t_pos].X&&t_pos<k) t_pos++;
	}
	if(!fly){
		printf("0\n%d\n",ans);return 0;
	}
	ans=-1;
	for(int j=1;j<=m;j++)
		if(dp[n%2][j]!=-1) ans=update(ans,dp[n%2][j]);
	printf("1\n%d\n",ans);
	//printf("k:%d\n",k);
	//system("pause");
	return 0;
}
 