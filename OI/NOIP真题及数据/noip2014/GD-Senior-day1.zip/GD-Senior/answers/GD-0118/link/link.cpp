// NOIP 2014 D1P2 Linked Weight
// @pwecar
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <algorithm>
#include <iostream>
#include <functional>
#include <utility>
#include <numeric>
#include <vector>
#include <set>
#include <map>

#define fo(i,a,b) for (int i = a; i <= b; i ++)
#define fd(i,a,b) for (int i = a; i >= b; i --)
#define fe(i,x,y) for (int i = x, y = lnk[i]; i; i = nxt[i], y = lnk[i])
#define fi first
#define se second
#define mkp make_pair
#define Fill(x,y) memset(x,y,sizeof(x))

using namespace std;

int Read()
{
	char c; while (c = getchar(), (c != '-') && (c < '0' || c > '9'));
	bool neg = (c == '-'); int ret = neg ? 0 : c - 48;
	while (c = getchar(), c >= '0' && c <= '9') ret = ret * 10 + c - 48;
	return neg ? -ret : ret;
}

const int MAXN = 200005, MOD = 10007;

int N, cnt, ans1, ans2, w[MAXN], fa[MAXN], q[MAXN], st[MAXN], nxt[MAXN << 1], lnk[MAXN << 1];

void init()
{
	scanf("%d", &N);
	fo (i, 2, N)
	{
		int u = Read(), v = Read();
		lnk[++ cnt] = v, nxt[cnt] = st[u], st[u] = cnt;
		lnk[++ cnt] = u, nxt[cnt] = st[v], st[v] = cnt;
	}
	fo (i, 1, N) w[i] = Read();
}

void work()
{
	int tail = 1; q[1] = 1;
	fo (head, 1, tail)
	{
		int x = q[head];
		fe (i, st[x], y) if (y != fa[x])
			fa[y] = x, q[++ tail] = y;
	}
	fd (head, tail, 1)
	{
		int x = q[head], tmp = 0, opt1 = 0, opt2 = 0;
		if (fa[fa[x]])
			ans1 = max(ans1, w[x] * w[fa[fa[x]]]), (ans2 += w[x] * w[fa[fa[x]]] % MOD) %= MOD;
		fe (i, st[x], y) if (y != fa[x])
		{
			if (w[y] > opt1) opt2 = opt1, opt1 = w[y];
				else if (w[y] > opt2) opt2 = w[y];
			(ans2 += tmp * w[y] % MOD) %= MOD, (tmp += w[y]) %= MOD;
		}
		ans1 = max(ans1, opt1 * opt2);
	}
	printf("%d %d\n", ans1, 2 * ans2 % MOD);
}

int main()
{
	freopen("link.in", "r", stdin), freopen("link.out", "w", stdout);
	init();
	work();
	return 0;
}

