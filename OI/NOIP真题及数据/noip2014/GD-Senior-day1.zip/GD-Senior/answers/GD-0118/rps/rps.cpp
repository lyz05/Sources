// NOIP 2014 D1P1 Rock Paper Scissor feat.TBBT
// @pwecar
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <algorithm>
#include <iostream>
#include <functional>
#include <utility>
#include <numeric>
#include <vector>
#include <set>
#include <map>

#define fo(i,a,b) for (int i = a; i <= b; i ++)
#define fd(i,a,b) for (int i = a; i >= b; i --)
#define fi first
#define se second
#define mkp make_pair
#define Fill(x,y) memset(x,y,sizeof(x))

using namespace std;

int Read()
{
	char c; while (c = getchar(), (c != '-') && (c < '0' || c > '9'));
	bool neg = (c == '-'); int ret = neg ? 0 : c - 48;
	while (c = getchar(), c >= '0' && c <= '9') ret = ret * 10 + c - 48;
	return neg ? -ret : ret;
}

const int MAXN = 205;

int N, A, B, ans1, ans2, a[MAXN], b[MAXN];//, c[MAXN*MAXN], d[MAXN*MAXN];
int p[5][5];

void init()
{
	scanf("%d%d%d", &N, &A, &B);
	p[0][2] = p[0][3] = 1;
	p[1][0] = p[1][3] = 1;
	p[2][1] = p[2][4] = 1;
	p[3][2] = p[3][4] = 1;
	p[4][0] = p[4][1] = 1;
	fo (i, 0, A - 1) scanf("%d", a + i);
	fo (i, 0, B - 1) scanf("%d", b + i);
}

void work()
{
	//fo (i, 0, A * B - 1)
		//c[i + 1] = c[i] + p[a[i % A]][b[i % B]], d[i + 1] = d[i] = p[b[i % B]][a[i % A]];
	fo (i, 0, N - 1)
		ans1 += p[a[i % A]][b[i % B]], ans2 += p[b[i % B]][a[i % A]];

	printf("%d %d\n", ans1, ans2);
}

int main()
{
	freopen("rps.in", "r", stdin), freopen("rps.out", "w", stdout);
	init();
	work();
	return 0;
}

