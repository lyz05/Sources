#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <algorithm>
#include <iostream>
#include <functional>
#include <utility>
#include <numeric>
#include <vector>
#include <set>
#include <map>

#define fo(i,a,b) for (int i = a; i <= b; i ++)
#define fd(i,a,b) for (int i = a; i >= b; i --)
#define fi first
#define se second
#define mkp make_pair
#define Fill(x,y) memset(x,y,sizeof(x))

using namespace std;

int Read()
{
	char c; while (c = getchar(), (c != '-') && (c < '0' || c > '9'));
	bool neg = (c == '-'); int ret = neg ? 0 : c - 48;
	while (c = getchar(), c >= '0' && c <= '9') ret = ret * 10 + c - 48;
	return neg ? -ret : ret;
}

const int MAXN = 10005, MAXM = 1005;
int N, M, K, x[MAXN], y[MAXN], l[MAXN], r[MAXN], f[MAXN][MAXM], mark[MAXN];

void init()
{
	scanf("%d%d%d", &N, &M, &K);
	fo (i, 1, N) x[i] = Read(), y[i] = Read(), l[i] = 1, r[i] = M;
	fo (i, 1, K)
	{
		int P = Read(); mark[P] = 1;
		l[P] = Read() + 1, r[P] = Read() - 1;
	}
}

void work()
{
	Fill(f, 60); fo (i, 1, M) f[0][i] = 0;
	int cnt = 0, opt;
	fo (i, 1, N)
	{
		fo (j, l[i], r[i])
		{
			if (j + y[i] <= M) f[i][j] = min(f[i][j], f[i - 1][j + y[i]]);
			fo (k, 1, j)
				if (j > k * x[i]) f[i][j] = min(f[i][j], f[i - 1][j - k * x[i]] + k);
					else break;
		}
		if (r[i] == M)
			fo (j, 1, M)
				f[i][M] = min(f[i][M], f[i - 1][j] + 1 + (M - j) / x[i]);
		opt = 1e9;
		fo (j, l[i], r[i])
			opt = min(opt, f[i][j]);
		if (opt >= 1e9)
		{
			printf("0\n%d\n", cnt);
			return;
		}
		cnt += mark[i];
	}
	printf("1\n%d\n", opt);
}

int main()
{
	freopen("bird.in", "r", stdin), freopen("bird_bf.out", "w", stdout);
	init();
	work();
	return 0;
}

