#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <iostream>
#include <fstream>
#include <algorithm>

using namespace std;

const int MAXN=10010,MAXM=1010,INF=(1<<30)-1;

int F[MAXN][MAXM];
int N,M,K;
int Up_L[MAXN],Down_L[MAXN];
int UpPos_L[MAXN],DownPos_L[MAXN];

int PipeNum_L[MAXN];


int main()
{
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	
	scanf("%d%d%d",&N,&M,&K);
	for (int i=0;i!=N;++i)
		scanf("%d%d",&Up_L[i],&Down_L[i]);
	
	for (int i=1;i<=N;++i)
	{
		UpPos_L[i]=M;
		DownPos_L[i]=1;
	}
	for (int i=1;i<=K;++i)
	{
		int P,L,H;
		scanf("%d%d%d",&P,&L,&H);
		UpPos_L[P]=H-1;
		DownPos_L[P]=L+1;
		PipeNum_L[P]++;
	}
	for (int i=0;i<=N;++i)
		for (int j=0;j<=M;++j) F[i][j]=INF;

	for (int i=1;i<=M;++i) F[0][i]=0;
	
	int PassPipe=0;
	
	for (int i=1;i<=N;++i)
	{
		bool canGo=0;
		for (int j=DownPos_L[i];j<=UpPos_L[i];++j)
		{
			if (j!=M)
			{
				if (j>Up_L[i-1])
					F[i][j]=min(F[i-1][j-Up_L[i-1]]+1,F[i][j-Up_L[i-1]]+1);
			}
			else
			{
				for (int k=0;k<=min(Up_L[i-1],j);++k)
					F[i][j]=min(F[i][j], min(F[i-1][j-k]+1,F[i][j-k]+1) );
			}
		}
		for (int j=DownPos_L[i];j<=UpPos_L[i];++j)
			if (j+Down_L[i-1]<=M)
				F[i][j]=min(F[i][j],F[i-1][j+Down_L[i-1]]);
		for (int j=DownPos_L[i];j<=UpPos_L[i];++j)
		{
			if (F[i][j]<INF) canGo=1;
		}
		if (!canGo)
		{
			printf("0\n");
			printf("%d\n",PassPipe);
			return 0;
		}
		PassPipe+=PipeNum_L[i];
	}
	int ans=INF;
	for (int i=1;i<=M;++i) ans=min(ans,F[N][i]);
	printf("1\n");
	printf("%d\n",ans);
	
	return 0;
}

