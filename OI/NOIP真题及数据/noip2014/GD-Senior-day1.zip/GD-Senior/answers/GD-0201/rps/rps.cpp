#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <iostream>
#include <fstream>
#include <algorithm>

using namespace std;

int points_L[6][6];

int n_L,na_L,nb_L;
int A_L[210];
int B_L[210];

int ansA,ansB;

void Init_L();

int main()
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);

	scanf("%d%d%d",&n_L,&na_L,&nb_L);
	for (int i=0;i!=na_L;++i)
		scanf("%d",&A_L[i]);
	for (int i=0;i!=nb_L;++i)
		scanf("%d",&B_L[i]);
	
	ansA=ansB=0;
	
	Init_L();
	int pA=0,pB=0;
	for (int i=0;i!=n_L;++i)
	{
		int a=A_L[pA],b=B_L[pB];
		if (points_L[a][b]==1)
			ansA++;
		else
		if (points_L[a][b]==-1)
			ansB++;
		pA=(pA+1)%na_L;
		pB=(pB+1)%nb_L;
	}
	printf("%d %d\n",ansA,ansB);
	
	return 0;
}
void Init_L()
{
	points_L[0][0]=0;
	points_L[0][1]=-1;
	points_L[0][2]=1;
	points_L[0][3]=1;
	points_L[0][4]=-1;
	points_L[1][1]=0;
	points_L[1][2]=-1;
	points_L[1][3]=1;
	points_L[1][4]=-1;
	points_L[2][2]=0;
	points_L[2][3]=-1;
	points_L[2][4]=1;
	points_L[3][3]=0;
	points_L[3][4]=1;
	points_L[4][4]=0;
	for (int i=0;i!=4;++i)
		for (int j=i+1;j!=5;++j)
			points_L[j][i]=-points_L[i][j];
}

