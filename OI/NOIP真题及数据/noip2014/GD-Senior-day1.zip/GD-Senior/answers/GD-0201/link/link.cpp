#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>

using namespace std;

const int MAXN=200010,MOD=10007;

int n_L;
int W_L[MAXN];
vector<int> E_L[MAXN];

int maxson[MAXN];
int maxid[MAXN];
int secson[MAXN];
int secid[MAXN];
int sumson[MAXN];


int ansmax,anssum;


int main()
{
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	
	scanf("%d",&n_L);
	for (int i=1;i!=n_L;++i)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		E_L[x].push_back(y);
		E_L[y].push_back(x);
	}
	for (int i=1;i<=n_L;++i) scanf("%d",&W_L[i]);
	
	for (int i=1;i<=n_L;++i)
	{
		int x=i;
		int Max=0,Sum=0,Maxid=0,Sec=0,Secid=0;
		for (int j=0;j!=E_L[x].size();++j)
		{
			int y=E_L[x][j];
			
			if (W_L[y]>Max)
			{
				Sec=Max;
				Secid=Maxid;
				Max=W_L[y];
				Maxid=y;
			} else
			if (W_L[y]>Sec)
			{
				Sec=W_L[y];
				Secid=y;
			}
			
			Sum=(Sum+W_L[y]);
		}
		maxson[x]=Max;
		maxid[x]=Maxid;
		secson[x]=Sec;
		secid[x]=Secid;
		sumson[x]=Sum;

	}
	ansmax=0;
	anssum=0;
	for (int i=1;i<=n_L;++i)
	{
		int x=i;
		for (int j=0;j!=E_L[x].size();++j)
		{
			int y=E_L[x][j];
			if (maxid[y]!=x)
				ansmax=max(ansmax,W_L[x]*maxson[y]);
			else
				ansmax=max(ansmax,W_L[x]*secson[y]);
			anssum=(anssum+W_L[x]*((sumson[y]-W_L[x])%MOD) )%MOD;

		}
	}
	printf("%d %d\n",ansmax,anssum%MOD);
	
	return 0;	
}


