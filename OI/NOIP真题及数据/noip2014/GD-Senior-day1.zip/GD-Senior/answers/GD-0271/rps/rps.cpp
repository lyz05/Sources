#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
const int d[5][5]={{0,-1,1,1,-1},{1,0,-1,1,-1},{-1,1,0,-1,1},{-1,-1,1,0,1},{1,1,-1,-1,0}};
int ia,ib,ka,kb,n,na,nb,a[234],b[234];
void init(){
scanf("%d%d%d",&n,&na,&nb);
for(int i=0;i<na;++i)scanf("%d",&a[i]);
for(int i=0;i<nb;++i)scanf("%d",&b[i]);

}
void ppp(){
	ia=0;ib=0;ka=0;kb=0;
	for(int i=0;i<n;++i){
		if(d[a[ia]][b[ib]]==1)++ka;
		else if(d[a[ia]][b[ib]]==-1)++kb;
		ia=(ia+1)%na;
		ib=(ib+1)%nb;
	}
}
void qqq(){
	printf("%d %d\n",ka,kb);
}
int main(){
freopen("rps.in","r",stdin);
freopen("rps.out","w",stdout);	
	init();
	ppp();
	qqq();
fclose(stdin);
fclose(stdout);
return 0;
}
	
