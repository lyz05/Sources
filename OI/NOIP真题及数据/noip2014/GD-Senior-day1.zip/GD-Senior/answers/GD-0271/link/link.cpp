#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
int n,ans,maxx,a[200010][2],b[200010],first[200010],second[200010],f[200010];
bool bi[200010];
void init(){
	memset(first,0,sizeof(first));
	memset(second,0,sizeof(second));
	scanf("%d",&n);
	for(int i=1;i<=n-1;++i)scanf("%d%d",&a[i][0],&a[i][1]);
	for(int i=1;i<=n;++i)scanf("%d",&b[i]);	
}
void ppp(){
	for(int i=1;i<=n-1;++i){
		int x=a[i][0],y=a[i][1];
		f[x]=(f[x]+b[y])%10007;
		f[y]=(f[y]+b[x])%10007;
		if(b[y]>first[x]){second[x]=first[x];first[x]=b[y];}
		else if(b[y]>second[x]){second[x]=b[y];}
		if(b[x]>first[y]){second[y]=first[y];first[y]=b[x];}
		else if(b[x]>second[y]){second[y]=b[x];}
	}
	memset(bi,0,sizeof(bi));
	for(int i=1;i<=n-1;++i){if(second[a[i][0]])bi[a[i][1]]=true;if(second[a[i][1]])bi[a[i][0]]=true;}
}
void qqq(){
	maxx=0;ans=0;
	for(int i=1;i<=n;++i)
	if(second[i]){
	   maxx=max(maxx,first[i]*second[i]);
	   ans=(f[i]*f[i]+ans)%10007;
}
for(int i=1;i<=n;++i)if(bi[i])ans=(ans+100070000-b[i]*b[i])%10007;
printf("%d %d\n",maxx,ans);
}
    

int main(){
freopen("link.in","r",stdin);
freopen("link.out","w",stdout);	
	init();
	ppp();
	qqq();
fclose(stdin);
fclose(stdout);
return 0;
}
