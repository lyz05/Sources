#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
const int INF=1<<30;
int m,n,k,l,up[10010],down[10010],p[10010][2],x,f[10010][1001],no,ans;
bool ok,b[10010];
void init(){
	scanf("%d%d%d",&n,&m,&k);memset(b,0,sizeof(b));
	for(int i=0;i<n;++i)scanf("%d%d",&up[i],&down[i]);
	for(int i=0;i<=n;++i){p[i][0]=0;p[i][1]=m+1;}
	for(int i=1;i<=k;++i){
		int x,y,z;
		scanf("%d%d%d",&x,&y,&z);
		p[x][0]=y;p[x][1]=z;
		b[x]=true;
	}
}
void ppp(){
	no=-1;
	memset(f,0x7f,sizeof(f));
	for(int i=1;i<=m;++i)f[0][i]=0;
	for(int i=0;i<=n-1;++i){
		ok=false;
		for(int j=p[i][0]+1;j<p[i][1];++j)if(f[i][j]<INF){
		k=0;l=j;while(min(l+up[i],m)<p[i+1][1])
		{++k;l+=up[i];if(l>m)l=m;
		if(l>p[i+1][0])f[i+1][l]=(min(f[i+1][l],f[i][j]+k)),ok=true;
		if(l==m)break;
		}
		if(j-down[i]>p[i+1][0]&&j-down[i]<p[i+1][1])f[i+1][j-down[i]]=min(f[i+1][j-down[i]],f[i][j]),(ok=true);
	}
	if(!ok){no=i;break;}
}
}
void qqq(){
	if(no>=0){
	int noo=0;for(int i=no;i>0;--i)if(b[i])++noo;
	printf("0\n%d\n",noo);
}
	else {ans=INF-3;
	for(int i=1;i<=m;++i)ans=min(ans,f[n][i]);
	printf("1\n%d\n",ans);
}
//for(int i=m;i>=1;--i){
//for(int j=1;j<=n;++j)if(f[j][i]<1000);else printf("%d %d\n",j,i);}
}
int main(){
freopen("bird.in","r",stdin);
freopen("bird.out","w",stdout);	
	init();
	ppp();
	qqq();
fclose(stdin);
fclose(stdout);
return 0;
}
	
