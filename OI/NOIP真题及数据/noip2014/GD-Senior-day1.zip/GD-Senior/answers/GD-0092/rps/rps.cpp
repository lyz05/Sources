#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <iostream>
#include <algorithm>
#include <map>
using namespace std;

const int table[5][5] = 
{
	{ 0,-1, 1, 1,-1},
	{ 1, 0,-1, 1,-1},
	{-1, 1, 0,-1, 1},
	{-1,-1, 1, 0, 1},
	{ 1, 1,-1,-1, 0}
};

const int MAXN = 200 + 5;
int n, na, nb;
int A[MAXN], B[MAXN];
int cura, curb;
int wina, winb;

int getA()
{
	int ret = A[cura++];
	if (cura == na)
	{
		cura = 0;
	}
	return ret;
}

int getB()
{
	int ret = B[curb++];
	if (curb == nb)
	{
		curb = 0;
	}
	return ret;
}

int main()
{
	freopen("rps.in", "r", stdin);
	freopen("rps.out", "w", stdout);

	cin >> n >> na >> nb;
	for (int i=0; i<na; i++) cin >> A[i];
	for (int i=0; i<nb; i++) cin >> B[i];

	for (int i=0; i<n; i++)
	{
		int a = getA();
		int b = getB();
		int result = table[a][b];
		if (result == 1)
		{
			wina ++;
		}
		else if (result == -1)
		{
			winb ++;
		}
	}
	cout << wina << ' ' << winb << endl;

	return 0;
}

