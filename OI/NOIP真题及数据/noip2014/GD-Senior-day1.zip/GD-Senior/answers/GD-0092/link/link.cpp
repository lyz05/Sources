#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <iostream>
#include <algorithm>
#include <map>
using namespace std;

const int MAXN = 200000 + 5;
const int MOD = 10007;

template <class T>
void Add(T &a, const T &b)
{
	a += b;
	if (a >= MOD) a -= MOD;
}

template <class T>
void Qmax(T &a, const T &b)
{
	if (b > a) a = b;
}

int n;
int w[MAXN];

struct Edge
{
	int to;
	Edge *next;
}pool[MAXN*2], *pool_cur=pool, *info[MAXN];

void Insert(int u, int v)
{
	pool_cur->to = v;
	pool_cur->next = info[u];
	info[u] = pool_cur ++;
}

int fa[MAXN];
int Que[MAXN];

void bfs()
{
	int low = 0, high = 0;
	Que[high ++] = 1;
	fa[1] = -1;
	while (low < high)
	{
		int u = Que[low ++];
		for (Edge *p=info[u]; p; p=p->next)
		{
			int v = p->to;
			if (v == fa[u]) continue;
			fa[v] = u;
			Que[high++] = v;
		}
	}
}

pair<int, int> f[MAXN], ff[MAXN];

void dp_down(int u)
{
	for (Edge *p=info[u]; p; p=p->next)
	{
		int v = p->to;
		if (v==fa[u]) continue;
		Qmax(f[u].first, w[v]);
		Add(f[u].second, w[v]);
		Qmax(ff[u].first, f[v].first);
		Add(ff[u].second, f[v].second);
	}
}

int ans1[MAXN], ans2[MAXN];

void dp_up(int u)
{
	int max1=-1, max2=-1, idx1=-1, sum = 0;
	for (Edge *p=info[u]; p; p=p->next)
	{
		int v = p->to;
		if (v==fa[u]) continue;
		int val = w[v];
		Add(sum, val);
		if (val > max1)
		{
			max2 = max1;
			max1 = val;
			idx1 = v;
		}
		else if (val > max2)
		{
			max2 = val;
		}
	}

	for (Edge *p=info[u]; p; p=p->next)
	{
		int v = p->to;
		if (v == fa[u]) continue;
		int &maxv = ans1[v];
		int &ssum = ans2[v];
		maxv = ff[v].first;
		if (u != 1) 
		{
			Qmax(maxv, w[fa[u]]);
		}

		if (v != idx1) 
		{
			Qmax(maxv, max1);
		}
		else 
		{
			Qmax(maxv, max2);
		}
		maxv = maxv * w[v];

		ssum = ff[v].second * w[v] % MOD;
		if (u != 1)
		{
			Add(ssum, w[fa[u]] * w[v] % MOD);
		}
		int tmp = sum-w[v];
		Add(ssum, (tmp<0 ? tmp+MOD : tmp) * w[v] % MOD);
	}
}

int main()
{
	freopen("link.in", "r", stdin);
	freopen("link.out", "w", stdout);

	scanf("%d", &n);
	for (int i=1; i<n; i++)
	{
		int u, v;
		scanf("%d%d", &u, &v);
		Insert(u, v);
		Insert(v, u);
	}
	for (int i=1; i<=n; i++)
	{
		scanf("%d", w+i);
	}

	bfs();
	for (int i=n-1; i>=0; i--)
	{
		dp_down(Que[i]);
	}
	ans1[1] = ff[1].first;
	ans2[1] = ff[1].second * w[1] % MOD;
	for (int i=0; i<n; i++)
	{
		dp_up(Que[i]);
	}

	int answer1 = 0, answer2 = 0;
	for (int i=1; i<=n; i++)
	{
		Qmax(answer1, ans1[i]);
		Add(answer2, ans2[i]);
	}

	cout << answer1 << ' ' << answer2 << endl;

	return 0;
}

