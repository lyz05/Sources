#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <iostream>
#include <algorithm>
#include <map>
using namespace std;

const int MAXN = 10000 + 5;
const int INF = 0x3f3f3f3f;

template <class T>
void Qmin(T &a, const T &b)
{
	if (b < a) a = b;
}

int n, m;
int X[MAXN], Y[MAXN];
int L[MAXN], H[MAXN];

int dp[2][MAXN];
bool block[MAXN];

int main()
{
	freopen("bird.in", "r", stdin);
	freopen("bird.out", "w", stdout);

	int K;
	scanf("%d%d%d", &n, &m, &K);
	for (int i=1; i<=n; i++)
	{
		scanf("%d%d", X+i, Y+i);
		L[i] = 1; 
		H[i] = m;
	}
	while (K--)
	{
		int a, b, c;
		scanf("%d%d%d", &a, &b, &c);
		block[a] = true;
		L[a] = b+1;
		H[a] = c-1;
	}

	int *f = dp[0], *g = dp[1];
	g[0] = INF;
	int cnt = 0;
	for (int i=1; i<=n; i++)
	{
		bool existsolution = false;
		for (int r=0; r<X[i]; r++)
		{
			int C = m, val = INF;
			for (int j=r; j<=m; j+=X[i])
			{
				f[j] = INF;
				if (j >= L[i] && j <= H[i])
				{
					if (j+Y[i] <= m)
					{
						Qmin(f[j], g[j+Y[i]]);
					}
					if (j == m)
					{
						for (int h=max(1, j-X[i]+1); h<=m; h++)
						{
							Qmin(f[j], g[h]+1);
						}
					}
					if (val != INF)
					{
						Qmin(f[j], val-C);
					}
				}
				Qmin(val, g[j]+C);
				if (f[j] != INF) existsolution = true;
				C --;
			}
		}
		/*
		for (int j=0; j<=m; j++)
		{
			cerr << f[j] << ' ';
		}
		cerr << endl;
		*/
		if (! existsolution)
		{
			cout << 0 << endl << cnt << endl;
			return 0;
		}
		cnt += block[i];
		swap(f, g);
	}
	int ans = INF;
	for (int i=1; i<=m; i++)
		Qmin(ans, g[i]);
	cout << 1 << endl << ans << endl;

	return 0;
}

