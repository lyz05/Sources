#include <cstdio>
#include <iostream>
#include <cstring>
#include <algorithm>
#include <cmath>

using namespace std;

const int maxn=200000+5;

int now,n,p,q;
int h[maxn+5],fa[maxn+5],e[maxn+5][3],open[maxn+5],f[maxn+5],g[maxn+5],w[maxn+5];
bool boo[maxn+5];
long long ans1,ans2,p1,p2;

void init()
{
	now=0;
	ans1=0; ans2=0;
	for (int i=1; i<=maxn; i++) h[i]=-1;
	for (int i=1; i<=maxn; i++) boo[i]=1;
	for (int i=1; i<=maxn; i++) fa[i]=0;
}
void isert(int p,int q)
{
	now++;
	e[now][0]=q;
	e[now][1]=h[p];
	h[p]=now;
}
void bfs()
{
	open[1]=1; boo[1]=0;
	int head=1,tail=1;
	for (; head<=tail; head++)
	{
		int tmp=h[open[head]];
		for (; tmp!=-1; tmp=e[tmp][1])
		{
			if (boo[e[tmp][0]])
			{
				fa[e[tmp][0]]=open[head];
				boo[e[tmp][0]]=0;
				tail++;
				open[tail]=e[tmp][0];
			}
		}
	}
}

void work()
{
	for (int i=n; i>0; i--)
	{
		int tmp=h[open[i]];
		int maxx=0,sum=0; 
		int max1=0,max2=0;
		p1=0; p2=0;
		for (; tmp!=-1; tmp=e[tmp][1])
		{
			if (e[tmp][0]!=fa[open[i]])
			{
				if (g[e[tmp][0]]>maxx)
				{
					maxx=g[e[tmp][0]];
				}
				sum=sum+f[e[tmp][0]];
				
				if (w[e[tmp][0]]>g[open[i]]) g[open[i]]=w[e[tmp][0]];
				f[open[i]]=f[open[i]]+w[e[tmp][0]];
				
				if (w[e[tmp][0]]>max1)
				{
					max2=max1; max1=w[e[tmp][0]];
				} else
				if (w[e[tmp][0]]>max2) max2=w[e[tmp][0]];
				
				p1=p1+w[e[tmp][0]]*w[e[tmp][0]];
				p2=p2+w[e[tmp][0]];
			}
		}
		if (w[open[i]]*maxx>ans1) ans1=w[open[i]]*maxx;
		if (max1*max2>ans1) ans1=max1*max2;
		
		ans2=(ans2+((sum%10007)*(w[open[i]]%10007)%10007))%10007;
		p2=((p2*p2-p1)/2)%10007;
		ans2=(ans2+p2)%10007;
	}
}
int main()
{
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	init();
	scanf("%d",&n);
	for (int i=1; i<=n-1; i++)
	{
		scanf("%d%d",&p,&q);
		isert(p,q);
		isert(q,p);
	}
	bfs();

	for (int i=1; i<=n; i++) scanf("%d",&w[i]);
	work();

	cout << ans1<< ' ' << (ans2*2)%10007 << endl;
	return 0;
}
