#include <cstdio>
#include <cmath>
#include <iostream>
#include <cstring>
#include <algorithm>

using namespace std;
int ans1,ans2,k,n,m;
int c[20][20],a[300],b[300];
int init()
{
	c[0][0]=0; c[0][1]=0; c[0][2]=1; c[0][3]=1; c[0][4]=0;
	c[1][0]=1; c[1][1]=0; c[1][2]=0; c[1][3]=1; c[1][4]=0;
	c[2][0]=0; c[2][1]=1; c[2][2]=0; c[2][3]=0; c[2][4]=1;
	c[3][0]=0; c[3][1]=0; c[3][2]=1; c[3][3]=0; c[3][4]=1;
	c[4][0]=1; c[4][1]=1; c[4][2]=0; c[4][3]=0; c[4][4]=0;
}
int main()
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	init();
	scanf("%d%d%d",&k,&n,&m);
	for (int i=1; i<=n; i++) scanf("%d",&a[i]);
	for (int i=1; i<=m; i++) scanf("%d",&b[i]);
	for (int i=n+1; i<=k; i++) a[i]=a[i-n];
	for (int i=m+1; i<=k; i++) b[i]=b[i-m];
	for (int i=1; i<=k; i++)
	{
		ans1=ans1+c[a[i]][b[i]];
		ans2=ans2+c[b[i]][a[i]];
	}
	printf("%d %d\n",ans1,ans2);
	return 0;
}
