#include <cstdio>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <iostream>

using namespace std;

const int oo=100000000;
const int maxm=1000+10;
const int maxn=10000+10;
int n,m,tt,last,x,l,r,p,q;
int f[2][maxm+5],lo[maxn+5],he[maxn+5],a[maxn+5],b[maxn+5];
bool exis[maxn+5],okk;

void init()
{
	for (int i=0; i<=n; i++)
	{
		lo[i]=0;
		he[i]=m+1;
		exis[i]=0;
	}	
}
void wrii()
{
	for (int i=0; i<=m; i++) printf("%d ",f[p][i]);
	printf("\n");
}
int main()
{
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	scanf("%d%d%d",&n,&m,&tt);
	for (int i=0; i<=n-1; i++) scanf("%d%d",&a[i],&b[i]);
	init();
	for (int i=1; i<=tt; i++) 
	{
	  scanf("%d%d%d",&x,&l,&r);
	  lo[x]=l;
	  he[x]=r;
	  exis[x]=1;
    }
    p=0; q=1; okk=1;
    for (int i=0; i<=m+1; i++) f[p][i]=oo;
    for (int i=lo[0]+1; i<he[0]; i++) f[p][i]=0;
    //wrii();
    for (int i=0; i<n; i++)
    {
    	bool boo=0;
    	for (int j=0; j<=m+1; j++) f[q][j]=oo;
    	
    	for (int j=lo[i]+1; j<=he[i]-1; j++)
    	  if (f[p][j]!=oo)
    	  {
    	  	 if ((lo[i+1]<(j-b[i])) && ((j-b[i])<he[i+1]))
    	  	 {
    	  	 	boo=1;
    	  	 	if (f[q][j-b[i]]>f[p][j]) f[q][j-b[i]]=f[p][j];
			 }
			 for (int k=1; k<=m; k++)
			 {
			 	if ( (lo[i+1]<(j+k*a[i])) && ((j+k*a[i])<he[i+1]) )
			 	{
			 		boo=1;
			 		if (f[q][j+k*a[i]]>(f[p][j]+k))
			 		   f[q][j+k*a[i]]=f[p][j]+k;
				}
				if ( ((j+k*a[i])>m) && (he[i+1]==(m+1)) )
				{
					boo=1;
					if (f[q][m]>(f[p][j]+k)) f[q][m]=f[p][j]+k;
				}
				if ( (j+k*a[i]) >=he[i+1]) break;
			 }
		  }
		if (boo) last=last+exis[i];
		if (!boo) okk=0;
		int tmp=p; p=q; q=tmp;
		//wrii();
	}
	if (!okk) 
	{
		printf("%d\n",0);
		printf("%d\n",last);
	} else
	{
		int ans=oo;
		for (int i=lo[n]+1; i<he[n]; i++)
		  if (ans>f[p][i]) ans=f[p][i];
		printf("%d\n",1);
		printf("%d\n",ans);
	}
	return 0;
}
