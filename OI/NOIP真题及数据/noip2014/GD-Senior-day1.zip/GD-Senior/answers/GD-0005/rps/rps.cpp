#include <cstdio>

const int MAXN = 210;
int a[MAXN], b[MAXN];

const int judge[5][5] = {
	{ 0, -1, 1, 1, -1 },
	{ 1, 0, -1, 1, -1 },
	{ -1, 1, 0, -1, 1 },
	{ -1, -1, 1, 0, 1 },
	{ 1, 1, -1, -1, 0 }
};

int main()
{
	freopen("rps.in", "r", stdin);
	freopen("rps.out", "w", stdout);

	int n, na, nb;
	scanf("%d%d%d", &n, &na, &nb);

	for (int i = 0; i < na; ++i)
		scanf("%d", &a[i]);
	for (int i = 0; i < nb; ++i)
		scanf("%d", &b[i]);

	int cnta = 0, cntb = 0;
	for (int i = 0; i < n; ++i) {
		switch (judge[a[i % na]][b[i % nb]]) {
			case 0: break;
			case 1: ++cnta; break;
			case -1: ++cntb; break;
		}
	}
	printf("%d %d\n", cnta, cntb);
	return 0;
}
