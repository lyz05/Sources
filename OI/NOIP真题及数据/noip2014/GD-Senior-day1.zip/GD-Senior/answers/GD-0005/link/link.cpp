#include <cstdio>
#include <vector>
using namespace std;

const int MOD = 10007;
const int MAXN = 200010;
int w[MAXN];

struct node {
	int w;
	vector<int> e;
} c[MAXN];

int main()
{
	freopen("link.in", "r", stdin);
	freopen("link.out", "w", stdout);

	int n;
	scanf("%d", &n);
	int u, v;
	for (int i = 1; i < n; ++i) {
		scanf("%d%d", &u, &v);
		c[u].e.push_back(v);
		c[v].e.push_back(u);
	}
	for (int i = 1; i <= n; ++i)
		scanf("%d", &c[i].w);

	int maxprd = 0, prd, sum = 0;
	for (int i = 1; i <= n; ++i) {
		for (int j = 0, sizej = int(c[i].e.size()); j < sizej; ++j) {
			node &now = c[c[i].e[j]];
			for (int k = 0, sizek = int(now.e.size()); k < sizek; ++k) {
				if (now.e[k] == i) continue;
				prd = c[i].w * c[now.e[k]].w;
				sum = (sum + prd) % MOD;
				if (prd > maxprd)
					maxprd = prd;
			}
		}
	}

	printf("%d %d\n", maxprd, sum);

	return 0;
}

