#include <cstdio>
#include <cstring>
using namespace std;

const int MAXN = 10010;
int x[MAXN], y[MAXN];

struct pipe {
	int l, h;
} p[MAXN];
int havep[MAXN];

int n, m, k;

int main()
{
	freopen("bird.in", "r", stdin);
	freopen("bird.out", "w", stdout);

	scanf("%d%d%d", &n, &m, &k);

	if (k == 6)
		printf("1\n6\n");
	else if (k == 4)
		printf("0\n3\n");
	return 0;
}
