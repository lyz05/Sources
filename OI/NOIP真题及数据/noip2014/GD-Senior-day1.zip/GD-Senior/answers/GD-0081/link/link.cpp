#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <map>
using namespace std;

const int maxN = 200005;
struct Tedge{
	int v, next;
}edge[2*maxN];
int dad[maxN], edges;
int n;
int s[maxN], open[maxN];
int lev[maxN], fa[maxN];
long long ans, maxV;

void insertedge(int u, int v){
	edges++;
	edge[edges].v=v;
	edge[edges].next = dad[u];
	dad[u] = edges;
}

void Readln(){
	scanf( "%d", &n );
	for (int i=1; i<n; i++){
		int u, v;
		scanf( "%d%d", &u, &v );
		insertedge(u, v);
		insertedge(v, u);
	}
	for (int i=1; i<=n; i++) scanf( "%d", &s[i] );
}

void bfs(){
	int head = 1, tail = 1;
	open[1] = 1;
	for (int i=1; i<=n; i++) lev[i] = 0;
	lev[1] = 1; fa[1] = 0;
	while (head <= tail){
		int now = open[head];
		head++;
		for (int i=dad[now]; i!=0; i=edge[i].next)
		if (lev[edge[i].v] == 0){
			fa[edge[i].v] = now;
			lev[edge[i].v] = lev[now]+1;
			tail++;
			open[tail] = edge[i].v;
		}
	}
}

void Solve(){
	bfs();
	ans = 0; maxV = 0;
	for (int i=2; i<=n; i++)
	if (fa[fa[i]] != 0){
		long long tmp = s[i]*s[fa[fa[i]]];
		ans += 2*tmp;
		maxV = max(tmp, maxV);
	}
	for (int i=1; i<=n; i++){
		long long sum = 0;
		long long tmpA = 0;
		int Fmax = 0;
		int Smax = 0;
		for (int j=dad[i]; j!=0; j=edge[j].next)
		if (lev[i]+1 == lev[edge[j].v]){
			int val = s[edge[j].v];
			long long tmp = val*val;
			tmpA -= tmp;
			sum += val;
			if (Fmax < val){
				Smax = Fmax;
				Fmax = val;
			}else{
				if (Smax < val) Smax = val;
			}
		}
		tmpA += sum*sum;
		ans += tmpA;
		long long tt = Fmax*Smax;
		maxV = max(tt, maxV);
	}
	cout<<maxV;
	cout<<' ';
	cout<<ans%10007LL;
	cout<<endl;
}

int main(){
	freopen( "link.in", "r", stdin );
	freopen( "link.out", "w", stdout );
	Readln();
	Solve();
	return 0;
}
