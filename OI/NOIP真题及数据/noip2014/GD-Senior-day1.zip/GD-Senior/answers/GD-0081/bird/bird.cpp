#include <iostream>
#include <fstream>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <map>
using namespace std;

const int maxN = 10005, maxM = 1005;
const int oo = 100000000;
int n, m, c, dx[maxN], dy[maxN];
struct Tdata{int L, H;}s[maxN];
int f[2][maxM];
int minV[maxM];

void Readln(){
	scanf( "%d%d%d", &n, &m, &c );
	for (int i=1; i<=n; i++) scanf( "%d%d", &dx[i], &dy[i] );
	for (int i=1; i<=n; i++) s[i].L = s[i].H = -1;
	for (int i=1; i<=c; i++) {
		int p;
		scanf( "%d", &p );
		scanf( "%d%d", &s[p].L, &s[p].H );
	}
}

void Solve(){
	int cal = 0;
	for (int i=1; i<=m; i++) f[0][i] = 0;
	f[0][0] = oo;
	for (int i=1; i<=n; i++){
		int t = i%2;
		for (int j=0; j<=m; j++) f[t][j] = oo;
		for (int j=0; j<dx[i]; j++) minV[j] = oo;
		for (int j=0; j<=m; j++){
			if (j < m) f[t][j] = min(f[t][j], minV[j%dx[i]]+1);
			else{
				for (int k=0; k<dx[i]; k++) f[t][j] = min(f[t][j], minV[k]+1);
				f[t][j] = min(f[t][j], f[1-t][j]+1);
			}
			minV[j%dx[i]] = min(minV[j%dx[i]]+1, f[1-t][j]);
		}
		for (int j=m-dy[i]; j>=0; j--)
			f[t][j] = min(f[t][j], f[1-t][j+dy[i]]);
		f[t][0] = oo;
		
		if (s[i].L != -1 && s[i].H != -1){
			for (int j=0; j<=s[i].L; j++) f[t][j] = oo;
			for (int j=s[i].H; j<=m; j++) f[t][j] = oo;
			bool ok = false;
			for (int j=0; j<=m; j++){
				if (f[t][j] < oo){
					ok = true;
					break;
				}
			}
			if (!ok) {
				printf( "0\n%d\n", cal );
				return;
			}
			cal++;
		}
	}
	int ans = oo;
	for (int i=1; i<=m; i++) ans = min(ans, f[n%2][i]);
	printf( "1\n%d\n", ans );
}

int main(){
	freopen( "bird.in", "r", stdin );
	freopen( "bird.out", "w", stdout );
	Readln();
	Solve();
	return 0;
}
