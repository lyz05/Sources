#include<iostream>
#include<stdio.h>
using namespace std;
int nex[200003];
int las[200003];
int w[200003];
int main()
{
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	int n;
	cin>>n;
	for(int i=0;i<=n+1;i++) {
		nex[i]=-1;
		las[i]=-1;
	}
	int x;
	for(int i=1;i<n;i++)
	{
		cin>>x;
		cin>>nex[x];
		las[nex[x]]=x;
	}
	int front;
	for(front=1;front<=n;front++)
	{
		if(las[front]==-1) break;
	}
	for(int i=1;i<=n;i++)
	{
		cin>>w[i];
	}
	int max=0,all=0;
	int y=0;
	for(int i=1;i<n-1;i++)
	{
	    y=w[front]*w[nex[nex[front]]];
		if(max<y) max=y;
		all+=y;
		all=all%10007;
		front=nex[front];
	}
	all=all*2;
	all=all%10007;
	cout<<max<<' '<<all;
	return 0;
}
