#include<iostream>
#include<stdio.h>
using namespace std;
int nulz=0;
int x[10001];
int y[10001];
int m,n,k;
int p;
int l[10001];
int h[10001];
int num=0;
int solve(int a,int b);
int main()
{
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=0;i<n;i++) {
		cin>>x[i];
		cin>>y[i];
	}
	for(int i=0;i<10001;i++) {
		l[i]=0;
		h[i]=m;
	}
	for(int i=0;i<k;i++) {
		cin>>p;
		cin>>l[p];
		cin>>h[p];
	}
	h[n]=m;
	l[n]=0;
	int mid;
	for(int i=m;i>0;i--)
	{
		if(solve(0,i)==0) {
			cout<<1<<' '<<num;
			return 0;
		}
	}
	cout<<0<<' '<<nulz;
	return 0;
}
int solve(int a,int b)
{
	if(a>=n) return 0;
	if(b-y[a]>l[a+1]+1) if(solve(a+1,b-y[a])==0) return 0;else return 1;
	else {
		if(b+x[a]>l[a+1]+1&&b+x[a]<h[a+1]-1) {num++;if(solve(a+1,b+x[a])==0) return 0;else return 1;}
		if(b+2*x[a]>l[a+1]+1&&b+x[a]<h[a+1]-1) {num++;if(solve(a+1,2*b+x[a])==0) return 0;else return 1;}
		if(b+3*x[a]>l[a+1]+1&&b+x[a]<h[a+1]-1) {num++;if(solve(a+1,3*b+x[a])==0) return 0;else return 1;}
    } 
}
