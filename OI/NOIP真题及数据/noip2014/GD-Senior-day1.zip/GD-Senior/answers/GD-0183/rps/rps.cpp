#include<iostream>
#include<stdio.h>
using namespace std;
int rule[5][5];
int inrule[25]={0,0,1,1,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,1,1,1,0,0,0};
int main()
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	int n,na,nb;
	cin>>n>>na>>nb;
	int a[210];
	int b[210];
	int d=0;
	for(int i=0;i<5;i++)
	{
		for(int j=0;j<5;j++)
		{rule[i][j]=inrule[d];
		 d++;}
	}
	for(int i=0;i<na;i++)
	{
		cin>>a[i];
	}
	for(int i=0;i<nb;i++)
	{
		cin>>b[i];
	}
	int ka=0;
	int kb=0;
	int sa=0,sb=0;
	while(n--)
	{
		sa+=rule[a[ka]][b[kb]];
		sb+=rule[b[kb]][a[ka]];
		ka++; ka=ka%na;
		kb++; kb=kb%nb;
	}
	cout<<sa<<' '<<sb;
	return 0;
}
