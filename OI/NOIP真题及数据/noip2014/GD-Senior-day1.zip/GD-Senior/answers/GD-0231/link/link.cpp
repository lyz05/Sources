#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<queue>
using namespace std;
struct node
{
	int x,y,next;
}a[400010];
int first[200010],len=0;
int p[200010],s[200010],w[200010],fa[200010],Max=0,Sum=0;
queue<int> z;
void ins(int x,int y)
{
	a[++len].x=x;a[len].y=y;
	a[len].next=first[x];first[x]=len;
}
void BFS()
{
	while(!z.empty())z.pop();
	int x,y,k;
	z.push(1);
	while(!z.empty())
	{
	  x=z.front();
	  for(k=first[x];k;k=a[k].next)
	  {
	  	y=a[k].y;
	  	if(y==fa[x])continue;
	  	fa[y]=x;
	  	Sum=(Sum+2*p[x]*w[y])%10007;
	  	if(w[y]*s[x]>Max)Max=w[y]*s[x];
	  	if(w[y]>s[x])s[x]=w[y];
	  	p[x]+=w[y];
	  	if(p[x]>=10007)p[x]-=10007;
	  	p[y]=s[y]=w[x];
	  	z.push(y);
	  }
	  z.pop();
	}
}
int main()
{
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	int n,i,x,y;
	memset(p,0,sizeof(p));
	memset(s,0,sizeof(s));
	scanf("%d",&n);
	for(i=1;i<n;i++)
	{
	  scanf("%d%d",&x,&y);
	  ins(x,y);ins(y,x);
    }
	for(i=1;i<=n;i++)
	  scanf("%d",&w[i]);
	BFS();
	printf("%d %d\n",Max,Sum);
	return 0;
}
