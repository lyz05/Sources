#include<cstdio>
#include<cstdlib>
using namespace std;
int p[10][10]={
{0,0,1,1,0},
{1,0,0,1,0},
{0,1,0,0,1},
{0,0,1,0,1},
{1,1,0,0,0}
};
int a[210],b[210];
int main()
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	int n,l1,l2,x=0,y=0,s1=0,s2=0,i;
	scanf("%d%d%d",&n,&l1,&l2);
	for(i=1;i<=l1;i++)scanf("%d",&a[i]);
	for(i=1;i<=l2;i++)scanf("%d",&b[i]);
	for(i=1;i<=n;i++)
	{
	  x++;y++;
	  if(x==l1+1)x=1;
	  if(y==l2+1)y=1;
	  if(a[x]==b[y])continue;
	  if(p[a[x]][b[y]])s1++;
	  else s2++;
	}
	printf("%d %d\n",s1,s2);
	return 0;
}
