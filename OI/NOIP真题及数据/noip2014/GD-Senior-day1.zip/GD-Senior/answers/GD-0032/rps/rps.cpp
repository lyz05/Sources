#include <iostream>
#include <fstream>
#include <algorithm>
using namespace std;
int score[][5] = {{0, 0, 1, 1, 0},
						{1, 0, 0, 1, 0},
						{0, 1, 0, 0, 1},
						{0, 0, 1, 0, 1},
						{1, 1, 0, 0, 0}};
						
int gcd(int a, int b) {
	if (a < b) swap(a, b);
    if (a % b == 0) return b;
	return gcd(b, a % b);
}

int main() {
	ios::sync_with_stdio(false);
	ifstream in("rps.in");
	ofstream out("rps.out");
	int n, na, nb;
	int scorea = 0, scoreb = 0;
	int a[250],b[250];
	in >> n >> na >> nb;
	for (int i = 0;i < na;i++) in >> a[i];
	for (int i = 0;i < nb;i++) in >> b[i];
	int lcm = na * nb / gcd(na,nb);
	
	if (n > lcm) {
		for (int i = 0;i < lcm;i++) {
			scorea += score[a[i % na]][b[i % nb]];
			scoreb += score[b[i % nb]][a[i % na]];
		}
		scorea *= n / lcm;
		scoreb *= n / lcm;
		for (int i = 0;i < n % lcm;i++) {
			scorea += score[a[i % na]][b[i % nb]];
			scoreb += score[b[i % nb]][a[i % na]];
		}
	} else {
		for (int i = 0;i < n;i++) {
			scorea += score[a[i % na]][b[i % nb]];
			scoreb += score[b[i % nb]][a[i % na]];
		}
	}
	out << scorea << " " << scoreb << endl;
}
