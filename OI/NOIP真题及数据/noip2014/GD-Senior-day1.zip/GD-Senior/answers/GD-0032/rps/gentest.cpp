#include <iostream>
#include <fstream>
#include <time.h>
#include <stdlib.h>
using namespace std;
int score[][5] = {{0, 0, 1, 1, 0},
						{1, 0, 0, 1, 0},
						{0, 1, 0, 0, 1},
						{0, 0, 1, 0, 1},
						{1, 1, 0, 0, 0}};

int main() {
	srand(time(NULL));
	ofstream in("rps.in");
	ofstream ans("rps.ans");
	int n = rand() % 200 + 1;
	int na = rand() % 200 + 1;
	int nb = rand() % 200 + 1;
	int a[250],b[250];
	for (int i = 0; i < na;i++) a[i] = rand() % 5;
	for (int i = 0; i < nb;i++) b[i] = rand() % 5;
	in << n << " " << na << " " << nb << endl;
	for (int i = 0; i < na;i++) in << a[i] << " ";
	for (int i = 0; i < nb;i++) in << b[i] << " ";
	int scorea = 0, scoreb = 0;
	for (int i = 0;i < n;i++) {
		scorea += score[a[i % na]][b[i % nb]];
		scoreb += score[b[i % nb]][a[i % na]];
	}
	ans << scorea << " " << scoreb << endl;
}
