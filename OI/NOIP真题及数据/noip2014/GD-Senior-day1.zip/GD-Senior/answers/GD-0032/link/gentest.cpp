#include <fstream>
#include <stdlib.h>
#include <string.h>
#include <algorithm>
#include <vector>
#include <set>
#include <time.h>
using namespace std;
vector<int> G[200050];
int w[200050];
int dist[2001][2001];

int main() {
	srand(time(NULL));
	int n = rand() % 50 + 1;
	set< pair<int, int> > pairs;
	ofstream in("link.in");
	ofstream oans("link.ans");
	in << n << endl;
	int ans = 0, sum = 0;
	for (int i = 1;i <= n;i++) for (int j = 1;j <= n;j++) dist[i][j] = i == j ? 0 : 1000000;
	for (int i = 1;i <= n-1;i++) {
		int from, to;
		do {
			from = rand() % n + 1, to = rand() % n + 1;
		}while (from == to);

		dist[from][to] = 1;
		dist[to][from] = 1;
		in << from << " " << to << endl;
	}
	
	for (int i = 1;i <= n;i++) {
		w[i] = rand() % 10;
		in << w[i] << " ";
	}
	
	for (int a = 1;a <= n;a++) for (int b = 1;b <= n;b++) for (int c = 1;c <= n;c++) {
		dist[a][c] = min(dist[a][c], dist[a][b] + dist[b][c]);
	}
	
	for (int i = 1;i <= n;i++) for (int j = 1;j <= n;j++) {
		if (i == j) continue;
		if (dist[i][j] == 2) {
			pairs.insert(make_pair(i, j));
		}
	}
	
	for (set< pair<int, int> >::iterator i = pairs.begin();i != pairs.end();i++) {
		int temp = w[i->first] * w[i->second];
		ans = max(ans, temp);
		sum += temp;
		sum %= 10007;
	}
	oans << ans << " " << sum << endl;
}
