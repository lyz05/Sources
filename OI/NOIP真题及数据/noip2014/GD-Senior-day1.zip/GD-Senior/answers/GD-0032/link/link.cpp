#include <stdio.h>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
using namespace std;
vector<int> G[200050];
int w[200050];

int main() {
	int n;
	set< pair<int, int> > pairs;
	freopen("link.in", "r", stdin);
	freopen("link.out", "w", stdout);
	
	scanf("%d",&n);
	int from, to, ans = 0, sum = 0, temp;
	for (int i = 0;i < n-1;i++) {
		scanf("%d%d",&from, &to);
		G[from].push_back(to);
		G[to].push_back(from);
	}
	for (int i = 1;i <= n;i++) {
		scanf("%d",&w[i]);
	}
	for (int i = 1;i <= n;i++) {
		int size = G[i].size();
		for (int a = 0;a < size;a++) for (int b = 0;b < size;b++) {
			if (G[i][a] >= G[i][b]) continue;
			pairs.insert(make_pair(G[i][a], G[i][b]));
		}
	}
	
	for (set< pair<int, int> >::iterator i = pairs.begin();i != pairs.end();i++) {
		temp = w[i->first] * w[i->second];
		ans = max(ans, temp);
		sum += temp;
		sum %= 10007;
	}
	sum *= 2;
	sum %= 10007;
	printf("%d %d\n", ans, sum);
}
