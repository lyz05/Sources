#include <stdio.h>
#include <vector>
#include <algorithm>
#include <string.h>
using namespace std;

typedef struct Pipe {
	int p, l, h;
}Pipe;

bool operator <(const Pipe first, const Pipe second) {
	return first.p < second.p;
}
const int INF = 100000000;
int dp[10010][1010];
int main() {
	int n, m, k;
	int x[10010], y[10010];
	vector<Pipe> pipes;
	freopen("bird.in", "r", stdin);
	freopen("bird.out", "w", stdout);
	scanf("%d%d%d",&n,&m,&k);
	for (int i = 0;i < n;i++) {
		scanf("%d%d",&x[i],&y[i]);
	}
	for (int i = 0;i < k;i++) {
		Pipe pipe;
		scanf("%d%d%d", &pipe.p, &pipe.l,&pipe.h);
		pipes.push_back(pipe);
	}
	sort(pipes.begin(), pipes.end());
	for (int i = 1;i <= m;i++) dp[0][i] = 0;
	
	int index = 0;
	
	for (int i = 0;i < n;i++) {
		for (int j = 1;j <= m;j++) dp[i+1][j] = INF;
		if (index < pipes.size() && pipes[index].p == i) {
			bool flag = false;
			for (int j = pipes[index].l+1;j < pipes[index].h;j++) {
				flag |= dp[i][j] != INF;
				for (int jump = 1;;jump++) {
					if (j + jump*x[i] <= m) {
						dp[i+1][j + jump*x[i]] = min(dp[i][j] + jump, dp[i+1][j + jump*x[i]]);
					} else {
						dp[i+1][m] = min(dp[i][j] + jump, dp[i+1][m]);
						break;
					}
				}
				
				if (j - y[i] >= 1) {
					dp[i+1][j - y[i]] = min(dp[i][j], dp[i+1][j - y[i]]);
				}
			}
			if (!flag) break;
			index++;
		} else {
			for (int j = 1;j <= m;j++) {
				for (int jump = 1;;jump++) {
					if (j + jump*x[i] <= m) {
						dp[i+1][j + jump*x[i]] = min(dp[i][j] + jump, dp[i+1][j + jump*x[i]]);
					} else {
						dp[i+1][m] = min(dp[i][j] + jump, dp[i+1][m]);
						break;
					}
				}
				
				if (j - y[i] >= 1) {
					dp[i+1][j - y[i]] = min(dp[i][j], dp[i+1][j - y[i]]);
				}
			}
		}
	}
	int ans = INF;
	if (index == pipes.size()) {
		for (int i = 1;i <= m;i++) {
			ans = min(ans, dp[n][i]);
		}
		printf("1\n%d\n", ans);
	} else {
		printf("0\n%d\n",index);
	}
}
