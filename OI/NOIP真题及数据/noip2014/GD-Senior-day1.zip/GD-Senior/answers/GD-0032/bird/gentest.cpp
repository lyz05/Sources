#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <time.h>
#include <algorithm>
#include <fstream>
using namespace std;
int n, m, k;
int x[10010], y[10010];
int maxpipe = 0;
typedef struct Pipe {
	int p, l, h;
}Pipe;
bool operator <(const Pipe first, const Pipe second) {
	return first.p < second.p;
}
vector<Pipe> pipes;
const int INF = 100000000;

int dfs(int xx, int yy,int clicks,int index) {
	maxpipe = max(maxpipe, index);
	int ans = INF;
	if (yy == n) return clicks;
	if (xx == pipes[index].p && (yy <= pipes[index].l || yy >= pipes[index].h)) return INF;
	if (yy < 1 || yy > m) return INF;
	if (xx == pipes[index].p) {
		ans = min(ans, dfs(xx+1, yy-y[xx], clicks, index+1));
	} else {
		ans = min(ans, dfs(xx+1, yy-y[xx], clicks, index));
	}
	for(int jump = 1;;jump++) {
		if (yy + jump * x[xx] <= m) {
			if (xx == pipes[index].p) {
				ans = min(ans, dfs(xx+1, yy+x[xx]*jump, clicks+jump, index+1));
			} else {
				ans = min(ans, dfs(xx+1, yy+x[xx]*jump, clicks+jump, index));
			}
		} else {
			break;
		}
	}
	return ans;
}

int main() {
	ofstream in("bird.in");
	ofstream ans("bird.ans");
	srand(time(NULL));
	n = rand() % 10 + 1;
	m = rand() % 10 + 1;
	k = rand() % 10 + 1;
	bool haspipe[10010] = {0};
	
	sort(pipes.begin(), pipes.end());
	
	in << n << " " << m >> " " << << k;
	for (int i = 0;i < n;i++) {
		x[i] = rand() % m;
		y[i] = rand() % m;
		in << x[i] << " " << y[i];
	}
	
	for (int i = 0;i < k;i++) {
		Pipe pipe;
		do {
			pipe.p = rand() % n + 1;
		} while (haspipe[pipe.p]);
		do {
			pipe.l = rand() % m + 1;
			pipe.h = rand() % m + 1;
		} while (pipe.l + 1 < pipe.h);
		in << pipe.p << " " << pipe.l << " " << pipe.h;
		pipes.push_back(pipe);
	}
	int ans = INF;
	for (int i = 0;i <= m;i++) {
		
	}
}
