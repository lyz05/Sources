#include<cstdio>
#include<cstring>
#include<vector>
#include<queue>
#include<algorithm>

using namespace std;

const int maxn=200010;

struct Edge
{
	int from,to;
};
typedef pair<int,int> pii;
int n;
bool vis[maxn];
vector<int> G[maxn];
vector<Edge> edges;
int w[maxn];

int main(void)
{
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	int x,y;
	int m;
	scanf("%d",&n);
	for(int i=1;i<n;i++)
	{
		scanf("%d%d",&x,&y);
		m=edges.size();
		G[x].push_back(m);
		edges.push_back((Edge){x,y});
		m=edges.size();
		G[y].push_back(m);
		edges.push_back((Edge){y,x});
	}
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&w[i]);
	}
	
	queue<pii> q;//����BFS���򣬵�һΪ��ţ��ڶ�����BFS��� 
	queue<pii> point;//���泤��Ϊ2�������� 
	int sum=0,maxnum=0;
	
	for(int i=1;i<=n;i++)//using bfs to count point
	{
		q.push(make_pair(i,0));
		memset(vis,false,sizeof(vis));//using array vis must be careful
		vis[i]=true;
		
		while(!q.empty())
		{
			pii a;
			a=q.front(); q.pop();
			for(int j=0;j<G[a.first].size();j++)
			{
				Edge e=edges[G[a.first][j]];
				if(vis[e.to]==false)
				{
					int dep=a.second+1;
					if(dep==2)//the sitation which should pop
					{
						point.push(make_pair(i,e.to));
					}
					else
					{
						q.push(make_pair(e.to,dep));
					}
				}
			}
		}
	}
	
	while(!point.empty())
	{
		pii a=point.front(); point.pop();
		int from=a.first,to=a.second;
		int result=w[from]*w[to];
		maxnum=max(maxnum,result);
		sum+=result;
		sum%=10007;
	}
	printf("%d %d\n",maxnum,sum);
	
	return 0;	
}
