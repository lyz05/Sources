#include<cstdio>
#include<cstring>
using namespace std;

const int maxn=210;

int a[maxn],b[maxn];
int ra,rb;
int rank[5][5]={
{0,-1,1,1,-1},
{1,0,-1,1,-1},
{-1,1,0,-1,1},
{-1,-1,1,0,1},
{1,1,-1,-1,0},
};

int main(void)
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	
	int n,na,nb;
	scanf("%d%d%d",&n,&na,&nb);
	ra=0,rb=0;
	for(int i=1;i<=na;i++)
		scanf("%d",&a[i]);
	a[0]=a[na];
	for(int i=1;i<=nb;i++)
		scanf("%d",&b[i]);
	b[0]=b[nb];
	
	int s1,s2;
	for(int i=1;i<=n;i++)
	{
		s1=a[i%na],s2=b[i%nb];
		int r=rank[s1][s2];
		if(r>0)
			ra++;
		else if(r<0)
			rb++;
	}
	printf("%d %d\n",ra,rb);
	
	return 0;	
}
