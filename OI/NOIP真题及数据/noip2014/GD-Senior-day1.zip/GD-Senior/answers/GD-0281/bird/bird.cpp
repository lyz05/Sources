#include<cstdio>
#include<cstring>
#include<algorithm>
#define INF 1000000000
//��������50�� 
using namespace std;

const int maxn=10010;
const int maxm=1010;
const int maxk=10010;
struct point
{
	int x,y;
};

struct pipe
{
	int u,l,x;
};

bool haspipe[maxn];
int s[maxn][maxm];
int sit[maxn];
point p[maxn];
pipe r[maxk];
int n,m,k;
int ok=0,nmin=INF,nmax=0;

void dfs(int x,int h,int result)
{
	if(x==n)
	{
		ok=1;
		nmin=min(nmin,result);
		return;
	}
	if(result>nmin&&ok==1)
		return;
	else if(s[x][h]>result||s[x][h]==-1)
		s[x][h]=result;
	else if(s[x][h]<result&&s[x][h]!=-1)
		return;
	int up=m,low=0;
	int zb=sit[x+1];
	if(haspipe[x+1]==true)
	{
		up=r[zb].u,low=r[zb].l;
		if(h-p[x].y>low&&h-p[x].y<up)
		{
			if(ok==0)
				nmax=max(nmax,zb);
			dfs(x+1,h-p[x].y,result);
		}
		for(int i=1;h+p[x].x*i<up;i++)
		{
			if(h+p[x].x*i>=up)
				break;
			else if(h+p[x].x*i<=low)
				continue;
			dfs(x+1,h+p[x].x*i,result+i);
			if(ok==0)
				nmax=max(nmax,zb);
		}
	}
	else
	{
		up=m,low=0;
		if(h-p[x].y>low)
		{
			dfs(x+1,h-p[x].y,result);
		}
		int height;
		int i=1;
		do
		{
			height=h+p[x].x*i;
			if(height>m)
				height=m;
			dfs(x+1,height,result+i);
			i++;
		}while(h+p[x].x*i<=m);
	}
	
}

bool cmp(const pipe &a,const pipe &b)
{
	return a.x<b.x;
}

int main(void)
{
	freopen("bird.in","r",stdin);	
	freopen("bird.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=0;i<n;i++)
	{
		scanf("%d%d",&p[i].x,&p[i].y);
	}
	for(int i=1;i<=k;i++)
	{
		scanf("%d%d%d",&r[i].x,&r[i].l,&r[i].u);
	}
	sort(r+1,r+k+1,cmp);

	memset(s,-1,sizeof(s));
	memset(sit,-1,sizeof(sit));
	memset(haspipe,false,sizeof(haspipe));
	for(int i=1;i<=k;i++)
	{
		sit[r[i].x]=i;
		haspipe[r[i].x]=true;
//		printf("%d %d\n",r[i].x,sit[r[i].x]);		
	}
	int up=m,low=0;
	if(haspipe[1]==true)
		up=r[1].u,low=r[1].l;
	for(int i=0;i<=m;i++)
	{
		if(i+p[0].x<=low)
			continue;
		else if(i-p[0].y>=up)
			break;
		dfs(0,i,0);	
	}
		
	if(ok==0)
		printf("%d\n%d\n",ok,nmax);
	else if(ok==1)
		printf("%d\n%d\n",ok,nmin);
		
	return 0;
}
