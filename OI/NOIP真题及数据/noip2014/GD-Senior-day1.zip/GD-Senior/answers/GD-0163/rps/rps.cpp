#include<cstdio>
int A[210],B[210],N,NA,NB,a=1,b=1,sa=0,sb=0;
int per[5][5]={{0,-1,1,1,-1},{1,0,-1,1,0},{-1,1,0,-1,1},{-1,-1,1,0,1},{1,1,-1,-1,0}};
void in(){
	scanf("%d%d%d",&N,&NA,&NB);
	for(int i=1;i<=NA;++i)
		scanf("%d",&A[i]);
	for(int i=1;i<=NA;++i)
		scanf("%d",&B[i]);
}
void adda(){++a;if(a>NA)a=1;}
void addb(){++b;if(b>NB)b=1;}
void work(int i,int j){
	if(per[i][j]==1)sa++;
	if(per[i][j]==-1)sb++;
}
int main(){
	freopen ("rps.in","r",stdin);
freopen ("rps.out","w",stdout);
	in();
	for(int i=1;i<=N;++i){
		work(A[a],B[b]);
		adda();addb();
	}
	printf("%d %d",sa,sb);
	return 0;
}
