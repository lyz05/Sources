#include<cstdio>
int n,m,k;//weight height and number of pipes
int X[10010],Y[10010];//up and down
int P[10010],L[10010],H[10010];//the d... of pipes
int isp[10010]={};//is there pipe?0 or the num
int mini[1010]={},minj[1010]={};//now the dp
int cnt=0;//num of through the pipe
void in(){
	scanf("%d%d%d",&n,&m,&k);
	for(int i=0;i<n;++i)
		scanf("%d%d",&X[i],&Y[i]);
	for(int i=1;i<=k;++i){
		scanf("%d%d%d",&P[i],&L[i],&H[i]);
		isp[P[i]]=i;
	}
}
void ret(){
	for(int i=0;i<=m;++i){
		mini[i]=minj[i];
		minj[i]=-1;
	}
}
bool iszero(){
	for(int i=1;i<=m;++i)
		if(mini[i]!=-1)return false;
	return true;
}
void test(){
	for(int i=0;i<=m;++i)
		printf("%d ",mini[i]);
		printf("\n");
}
int find(){
	int min=1000000;
	for(int i=1;i<=m;++i)if(mini[i]<min&&mini[i]!=-1)min=mini[i];
		return min;
}
bool work(int i){
	int lb=1,ub=m,um=X[i],lm=Y[i];
	if(isp[i]){lb=L[isp[i]]+1;ub=H[isp[i]]-1;cnt++;}
	for(int j=lb;j<=ub;++j){
		if(mini[j]!=-1||i==0){
			if(lm<=j&&(minj[j-lm]==-1||minj[j-lm]>mini[j]))
				minj[j-lm]=mini[j];
			for(int k=j+um;k<=m;k+=um)
				if(minj[k]==-1||minj[k]>mini[j]+(k-j)/um)
					minj[k]=mini[j]+(k-j)/um;
			if(minj[m]==-1||minj[m]>mini[j]+(m-j-um)/um+1)
				minj[m]=mini[j]+(m-j-um)/um+1;
		}
	}
	ret();
	if(iszero())return false;
	if(i<n-1)
	work(i+1);
	return true;
}
int main(){
	freopen ("bird.in","r",stdin);
	freopen ("bird.out","w",stdout);
	in();
	for(int i=0;i<=m;++i){mini[i]=0;minj[i]=-1;}
	if(work(0)&&!iszero())printf("1\n%d",find());
		else printf("0\n%d",cnt);
	return 0;
}