#include<cstdio>
int A[200010]={},B[200010]={},W[200010],T[200010],v[200010]={},n,f,s=0,max=0;
void in(){
	scanf("%d",&n);
	for(int i=1;i<n;++i){
		int u,v;
		scanf("%d%d",&u,&v);
		if(A[u])B[u]=v;
			else A[u]=v;
		if(A[v])B[v]=u;
			else A[v]=u;
	}
	for(int i=1;i<=n;++i){
		scanf("%d",&W[i]);
	}
}
void find(){
	for(int i=1;i<=n;++i)
		if(!B[i])f=i;
}
void ret(){
	int i=0;
	T[++i]=f;
	v[f]=1;
	f=A[f];
	while(B[f]){
		T[++i]=f;
		v[f]=1;
		if(v[A[f]])f=B[f];
			else f=A[f];
	}
	T[++i]=f;
}
void add(){
	for(int i=3;i<=n;++i){
		int p=W[T[i]]*W[T[i-2]];
		max=max<p?p:max;
		s+=p;
		s%=10007;
	}
}
void test(){
	for(int i=1;i<=n;++i)printf("%d ",A[i]);
	printf("\n");
	for(int i=1;i<=n;++i)printf("%d ",B[i]);
	printf("\n");
	for(int i=1;i<=n;++i)
		printf("%d ",T[i]); 
}
int main(){
	freopen ("link.in","r",stdin);
	freopen ("link.out","w",stdout);
	in();
	find();
	ret();
	if(n>=3)add();
	printf("%d %d",max,s*2%10007);
	return 0;
}
	