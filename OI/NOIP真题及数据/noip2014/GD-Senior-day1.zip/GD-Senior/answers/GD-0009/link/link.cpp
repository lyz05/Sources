#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
using namespace std;
const int N=200005;
const int M=10007;
struct edge {int x,next;} b[N*2]; bool v[N];
int n,ansx,ansy,w[N],a[N],tot,q[N],head,tail;
int sum[N],firson[N][2],secson[N][2],father[N];
int getint()
{
	char c=getchar(); int x=0; bool flag=false;
	while ((c!='-')&&((c<'0')||(c>'9'))) c=getchar();
	if (c=='-') flag=true,c=getchar();
	while ((c>='0')&&(c<='9')) x=x*10+c-'0',c=getchar();
	if (flag) return -x; else return x;
}
void addedge(int x,int y)
{
	tot++; b[tot].x=y; b[tot].next=a[x]; a[x]=tot;
	tot++; b[tot].x=x; b[tot].next=a[y]; a[y]=tot;
}
void init()
{
	n=getint(); tot=0; memset(a,0,sizeof(a));
	for (int i=1; i<n; i++) {int x=getint(),y=getint(); addedge(x,y);}
	for (int i=1; i<=n; i++) w[i]=getint();
}
void bfs()
{
	head=0,tail=1; q[1]=1; father[1]=0;
	memset(v,true,sizeof(v)); v[1]=false;
	while (head<tail)
	{
		int k=q[++head]; 
		for (int p=a[k];p;p=b[p].next)
		{
			int pp=b[p].x; if (v[pp]==false) continue;
			tail++; q[tail]=pp; v[pp]=false;
			sum[k]=(sum[k]+w[pp])%M; father[pp]=k;
			if (w[pp]>firson[k][0]) secson[k][0]=firson[k][0],secson[k][1]=firson[k][1],firson[k][0]=w[pp],firson[k][1]=pp;
			else if (w[pp]>secson[k][0]) secson[k][0]=w[pp],secson[k][1]=pp;
		}
	}
}
void solve()
{
	for (int i=1; i<=n; i++)
	{
		for (int p=a[i];p;p=b[p].next)
		{
			int pp=b[p].x; if (pp==father[i]) continue;
			ansx=max(ansx,w[i]*firson[pp][0]);
			ansy=(ansy+w[i]*sum[pp]*2)%M;
		}
		if (father[i]==0) continue;
		if (i!=firson[father[i]][1]) ansx=max(ansx,w[i]*firson[father[i]][0]);
		else ansx=max(ansx,w[i]*secson[father[i]][0]);
		int othersum=((sum[father[i]]-w[i])%M+M)%M;
		ansy=(ansy+w[i]*othersum)%M;
	}
	printf("%d %d\n",ansx,ansy);
}
int main()
{
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	init();
	bfs();
	solve();
	return 0;
}
