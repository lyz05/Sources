#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
using namespace std;
const int N=505;
int a[N],b[N],n,na,nb,ansx,ansy;
int score[10][10];
int getint()
{
	char c=getchar(); int x=0; bool flag=false;
	while ((c!='-')&&((c<'0')||(c>'9'))) c=getchar();
	if (c=='-') flag=true,c=getchar();
	while ((c>='0')&&(c<='9')) x=x*10+c-'0',c=getchar();
	if (flag) return -x; else return x;
}
void init()
{
	n=getint(); na=getint(); nb=getint();
	for (int i=1; i<=na; i++) a[i]=getint();
	for (int i=1; i<=nb; i++) b[i]=getint();
	for (int i=na+1; i<=n; i++) if (i%na==0) a[i]=a[na]; else a[i]=a[i%na];
	for (int i=nb+1; i<=n; i++) if (i%nb==0) b[i]=b[nb]; else b[i]=b[i%nb];
}
void solve()
{
	memset(score,0,sizeof(score));
	score[0][2]=score[0][3]=1;
	score[1][0]=score[1][3]=1;
	score[2][1]=score[2][4]=1;
	score[3][2]=score[3][4]=1;
	score[4][0]=score[4][1]=1;
	ansx=0; ansy=0;
	for (int i=1; i<=n; i++) 
	ansx+=score[a[i]][b[i]],ansy+=score[b[i]][a[i]];
	printf("%d %d\n",ansx,ansy);
}
int main()
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	init();
	solve();
	return 0;
}
