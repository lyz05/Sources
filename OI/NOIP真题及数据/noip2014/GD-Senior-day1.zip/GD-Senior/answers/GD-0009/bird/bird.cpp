#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
using namespace std;
const int N=10005;
const int M=1005;
int n,m,K,INF,f[N][M],g[N][M],minF[N];
int X[N],Y[N],L[N],H[N],ans,a[N],ans1;
int getint()
{
	char c=getchar(); int x=0; bool flag=false;
	while ((c!='-')&&((c<'0')||(c>'9'))) c=getchar();
	if (c=='-') flag=true,c=getchar();
	while ((c>='0')&&(c<='9')) x=x*10+c-'0',c=getchar();
	if (flag) return -x; else return x;
}
void init()
{
	n=getint(); m=getint(); K=getint();
	for (int i=0; i<=n-1; i++) X[i]=getint(),Y[i]=getint();
	for (int i=1; i<=n; i++) L[i]=0,H[i]=m+1;
	for (int i=1; i<=K; i++) {int p=getint(); a[i]=p; L[p]=getint(); H[p]=getint();}
}
void solve()
{
	memset(minF,127,sizeof(minF));
	memset(f,127,sizeof(f)); INF=f[0][0];
	for (int i=1; i<=m; i++) f[0][i]=0;
	for (int i=1; i<=m; i++)
	{
		int now=(m-i)/X[0]+f[0][i];
		if (i-X[0]<1) g[0][i]=i;
		else
		{
			int last=g[0][i-X[0]];
			if ((m-last)/X[0]+f[0][last]>now) g[0][i]=i; else g[0][i]=last;
		}
		if ((m-i)%X[0]==0) now=(m-i)/X[0]; else now=(m-i)/X[0]+1;
		if (i==m) now++; minF[0]=min(minF[0],now);
	}
	for (int i=1; i<=n; i++)
	{
		for (int j=1; j<=m; j++)
		{
			if ((j>=H[i])||(j<=L[i])) continue;
			if (j==m) {f[i][j]=minF[i-1]; continue;}
			if (j+Y[i-1]<=m) f[i][j]=f[i-1][j+Y[i-1]];
			if (j-X[i-1]<1) continue; int last=g[i-1][j-X[i-1]];
			f[i][j]=min(f[i][j],(j-last)/X[i-1]+f[i-1][last]);
		}
		if (i==n) break;
		for (int j=1; j<=m; j++)
		{
			int now=(m-j)/X[i]+f[i][j];
			if (j-X[i]<1) g[i][j]=j;
			else
			{
				int last=g[i][j-X[i]];
			    if ((m-last)/X[i]+f[i][last]>now) g[i][j]=j; else g[i][j]=last;
			}
			if ((m-j)%X[i]==0) now=(m-j)/X[i]; else now=(m-j)/X[i]+1;
			if (m==j) now++; minF[i]=min(minF[i],now+f[i][j]);
		}
	}
	for (int i=1; i<=n; i++)
	{
		for (int j=1; j<=m; j++) if (f[i][j]<INF) ans=i;
	}
	if (ans==n) 
	{
	    printf("1\n"); ans1=INF;
	    for (int j=1; j<=m; j++) ans1=min(ans1,f[n][j]);
	    printf("%d\n",ans1);
		return;
	} 
	ans1=0;
	for (int i=1; i<=K; i++) if (a[i]<=ans) ans1++;
	printf("0\n"); printf("%d\n",ans1);
}
int main()
{
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	init();
	solve();
	return 0;
}
