#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <cstring>
#include <vector>
//#define che 1
using namespace std;
const int maxn= 200000+10,modd= 10007;
typedef long long LL;
vector <int> G[maxn];
int w[maxn], n,maxw=0, sum=0;

bool cmp(int a, int b)
{
	return w[a] > w[b];
}

void init();
void count(int u);

int main()
{
	freopen("link.in","rt",stdin);
	freopen("link.out","wt",stdout);
	init();
	for (int i=1; i<=n; i++)
		count(i);
	sum %= modd;
	maxw %= modd;
	printf("%d %d\n",maxw, sum);
	return 0;
}
void init()
{
	scanf("%d",&n);
	for (int i=1; i<n; i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		G[u].push_back( v);
		G[v].push_back(u);
	}
	for (int i=1; i<=n; i++)
		scanf("%d",&w[i]);
	for (int i=1; i<=n; i++)
		sort( G[i].begin(), G[i].end(), cmp);
	
}

void count(int u)
{
	LL Tsum=0;
	if ( G[u].size() <=1 ) return ;
	int v1= G[u][0], v2=G[u][1];
	maxw = max( maxw , w[v1] * w[v2]);
	#ifdef che 
	printf("----------doint node %d\n------------",u);
	printf("Now v1=%d, v2=%d, w[%d]=%d  w[%d]=%d  maxw=%d\n",v1,v2,v1,w[v1],v2,w[v2],maxw);
	#endif

	for (int i=0; i<G[u].size(); i++)
	{
		int v= G[u][i];
		Tsum += w[v];
	}
	
	Tsum = Tsum*Tsum;
	
	for (int i=0; i<G[u].size(); i++)
	{
		int v= G[u][i];
		Tsum -= w[v]*w[v];
	}
	
	Tsum %=modd;
	sum = (sum + Tsum)%modd;
}
