#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cstring>
//#define che 1
using namespace std;
const int maxn= 200+10 , maxche = 5;
const int wins[maxche][maxche]={ {0,0,1,1,0},
								 {1,0,0,1,0},
								 {0,1,0,0,1},
								 {0,0,1,0,1},
								 {1,1,0,0,0}};
int A[maxn], B[maxn], NA, NB, N;

void init();

int main()
{
	freopen("rps.in","rt",stdin);
	freopen("rps.out","wt",stdout);
	init();
	int ansA=0,ansB=0;
	for (int i=0; i<N; i++)
	{
		
		int chsA=A[i%NA], chsB= B[i%NB];
		#ifdef che
		printf("wins[%d][%d]= %d\n",chsA, chsB, wins[chsA][chsB]);
		#endif
		ansA += wins[ chsA][chsB];
		ansB += wins[ chsB][chsA];
	}
	printf("%d %d\n",ansA,ansB);
	return 0;
}
void init()
{
	scanf("%d%d%d",&N,&NA, &NB);
	for (int i=0; i< NA; i++)	
		scanf("%d",&A[i]);
	for (int i=0; i< NB ; i++)
		scanf("%d",&B[i]);
	
	#ifdef che 
	printf("NA:%d , NB:%d,N:%d\n",NA , NB, N);
	for (int i=0; i<5; i++)
		for (int j=0; j<5; j++)
			if ( wins[i][j] + wins[j][i] !=1 && i!=j)
				printf("i=%d,j=%d Arr is error!\n",i,j);
	#endif
	
}
