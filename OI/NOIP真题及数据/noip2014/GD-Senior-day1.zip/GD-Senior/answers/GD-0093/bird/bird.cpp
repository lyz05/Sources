#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
//#define che 1
using namespace std;
const int maxn= 10000+10, maxm= 1000+10, oo= 1<<29;
struct Stk
{
	int x, y1,y2;
}p[maxn];

bool cmp(Stk a, Stk b)
{
	return a.x < b.x;
}
int n ,m ,k;
int f[2][maxm], usd[2][maxm];
int x[maxn], y[maxn];

void init();

int main()
{
	freopen("bird.in","rt",stdin);
	freopen("bird.out","wt",stdout);
	init();
	for (int i=1; i <=m; i++)	f[0][i]= 0;
	usd[0][0]=m;
	for (int i=1; i<=m; i++)	usd[0][i]=i;
	int ans=oo;
	for (int i=0,pp=0; i<n; i++ )
	{
		int d2= (i+1)%2, d1= i%2;
		#ifdef che
		printf("turn %d\n",i);
		#endif
		for (int j=0; j<=m; j++)	f[d2][j]= oo;
		usd[d2][0]=0;
		for (int j=1; j<=usd[d1][0]; j++)
		{
			int rch = usd[d1][j];
			if ( p[pp].x==i+1)
			{
				if ( rch-y[i] >0 && rch-y[i] <p[pp].y2 && rch-y[i] > p[pp].y1)
				{
					if ( f[d2][ rch- y[i]] == oo)
					{
						usd[d2][0]++;
						usd[d2][ usd[d2][0] ] = rch-y[i];
					}
					f[d2][rch-y[i]] = min( f[d2][ rch-y[i]] , f[d1][rch]);
				}
				
				int rch1=rch,stp=0;
				while ( rch1 < m)
				{
					rch1= min(rch1+x[i] , m);
					stp++;
					if ( rch1 >= p[pp].y2 || rch1 <= p[pp].y1) continue;
					if ( f[d2][ rch1]==oo)
					{
						usd[d2][0]++;
						usd[d2][ usd[d2][0]]= rch1;
					}
					f[d2][ rch1]= min( f[d2][rch1] , f[d1][rch]+ stp);
				}
			}else
			{
				if ( rch-y[i] >0)
				{
					if ( f[d2][ rch-y[i]] ==oo)
					{
						usd[d2][0]++;
						usd[ d2][ usd[d2][0]]= rch- y[i];
					}
					f[d2][ rch-y[i]] = min( f[d2][ rch- y[i]] , f[d1][rch] );
				}
				
				int rch1 = rch , stp=0;
				while ( rch1 <m )
				{
					rch1= min( rch1+x[i], m);
					stp++;
					if ( f[d2][ rch1]==oo)
					{
						usd[ d2][0]++;
						usd[ d2][ usd[d2][0]]= rch1;
					}
					f[d2][ rch1]= min( f[d2][rch1], f[d1][rch]+stp); 
				}
			}
		}
		#ifdef che 
		printf("%d turn , change %d box:",i,usd[d2][0]);
		for (int j=1; j<= usd[d2][0]; j++)	
			printf("%d ",usd[d2][j]);
		printf("\nThis f is:\n");
		for (int j=1; j<=usd[d2][0]; j++)
		{
			int rch= usd[d2][j];
			printf("\tf[%d(%d)][%d]=%d\n",d2,i+1,j, f[d2][j]);
		}
		#endif
		if ( usd[d2][0] ==0 )
		{
			ans=pp;
			break;
		}
		
		if (p[pp].x==i+1) pp++;
	}
	
	if ( ans!=oo)
	{
		printf("0\n%d\n",ans);
	}	else
	{
		for (int i=1; i<=m; i++)
			ans = min( ans, f[n%2][i]);
		printf("1\n%d\n",ans);
	}
	return 0;
}
void init()
{
	scanf("%d%d%d",&n,&m, &k);
	
	for (int i=0; i<n; i++)
		scanf("%d%d",&x[i], &y[i]);
		
	for (int i=0; i<k; i++)
		scanf("%d%d%d",&p[i].x, &p[i].y1, &p[i].y2);
	
	sort( p,  p+k , cmp);
	
	#ifdef che 
	for (int i=0; i<n; i++)
		printf("x[%d]= %d  y[%d]=%d\n",i,x[i],i,y[i]);
	for (int i=0; i<k; i++)
		printf("p[%d].x=%d  p[%d].y1=%d, p[%d].y2=%d\n",i,p[i].x,i,p[i].y1, i, p[i].y2);
	#endif
}
