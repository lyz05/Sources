#include<fstream>
#include<algorithm>
using namespace std;

ifstream fin("link.in");
ofstream fout("link.out");

int visit[20000][20000];

long n;
int val[100000];
long maxx=-1, ans=0;

void debug()
{
	for (long i=1; i<=n; i++){
	
	    for (long j=1; j<=visit[i][0]; j++)
           fout<<visit[i][j]<<" ";
        fout<<visit[i][0];
		fout<<endl;      
	}
}
void init()
{
	fin>>n;
	for (long i=1; i<=n; i++) visit[i][0]=0;
	long x, y;
	for (long i=1; i<n; i++) {
		fin>>x>>y;
		visit[x][0]++;
		visit[x][visit[x][0]]=y;
	
		visit[y][0]++;
		visit[y][visit[y][0]]=x;
	
	}
	//debug();
	for (long i=1; i<=n; i++) fin>>val[i];
	
	long all;
	for (long i=1; i<=n; i++)
	    for (long j=1; j<visit[i][0]; j++)
	       for (long k=j+1; k<=visit[i][0]; k++)
	       {
	       	   all=val[visit[i][j]]*val[visit[i][k]];
	       	   if (all>maxx) maxx=all;
	       	   ans=(ans+all*2)%10007;
	       }
	fout<<maxx<<" "<<ans<<endl;
}


int main(){
	
	init();

	fin.close();
	fout.close();
	return 0;
}
