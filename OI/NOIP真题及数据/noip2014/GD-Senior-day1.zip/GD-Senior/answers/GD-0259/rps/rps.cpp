#include<fstream>
using namespace std;

ifstream fin("rps.in");
ofstream fout("rps.out");

long n, na, nb, ansa=0, ansb=0;
long a[201], b[201];

void init(){
	fin>>n>>na>>nb;
	for (long i=0; i<na; i++) fin>>a[i];
	for (long i=0; i<nb; i++) fin>>b[i];
	for (long i=0; i<n; i++)
	{
		long x=a[i%na];
		long y=b[i%nb];
		if (x!=y){
			if (x==0)
			{
				if (y==2||y==3) ansa++;
				else ansb++;
			} 
			if (x==1)
			{
				if (y==0||y==3) ansa++;
				else ansb++;
			}
			if (x==2)
			{
				if (y==1||y==4) ansa++;
				else ansb++;
			}
			if (x==3){
				if (y==2||y==4) ansa++;
				else ansb++;
			}
			if (x==4)
			{
				if (y==0||y==1) ansa++;
				else ansb++;
			}
		}
	}
	fout<<ansa<<" "<<ansb<<endl;
}

int main()
{
	init();
	fin.close();
	fout.close();
	return 0;
}
