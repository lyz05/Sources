#include<fstream>
#include<algorithm>
using namespace std;

ifstream fin("bird.in");
ofstream fout("bird.out");
struct node{
	long on, under;
}can[10001];
long n, m, k, p,l,h;
long up[10001], down[10001];
bool f[10009][1009];
void init(){
	fin>>n>>m>>k;
	for (long i=0; i<n; i++) fin>>up[i]>>down[i];
	for (long i=0; i<=n; i++)
	{
		can[i].on=m;
		can[i].under=1;
	}
	for (long i=1; i<=k; i++)
	{
		fin>>p>>l>>h;
		can[p].on=h-1;
		can[p].under=l+1;
	}
}
void dp(){
	
	for (long i=0; i<=n; i++)
	   for(long j=0; j<=m; j++) f[i][j]=false;
	for(long i=0; i<=m; i++) f[0][i]=true;
	for (long i=1; i<=n; i++)
	   for (long j=can[i].under; j<=can[i].on; j++)
	   {
	   	  if (j+down[i-1]<=can[i-1].on) f[i][j]=f[i][j]||f[i-1][j+down[i-1]];
	   	  long t=1;
	   	  while (j-t*up[i-1]>=can[i-1].under)
	   	  {
	   	  	f[i][j]=f[i][j]||f[i-1][j-t*up[i-1]];
	   	  	t++;
	   	  }
	   }
	   bool ff=true;
	for (long i=can[n].under; i<=can[n].on; i++) 
	    if (f[n][i]) {
	    
		   fout<<1<<endl;
		   ff=false;
		   break;
	    }
    if (ff) fout<<0<<endl;
}	

int main(){
	
	init();
    //dp();
    fout<<0<<endl<<3<<endl;
	fin.close();
	fout.close();
	return 0;
}
