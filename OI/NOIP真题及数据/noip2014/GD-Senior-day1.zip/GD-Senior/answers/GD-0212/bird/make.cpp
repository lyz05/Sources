#include<cstdio>
#include<ctime>
#include<cstdlib>
#include<iostream>
#include<cstring>
#define SIZE 1100
using namespace std;

int T[ SIZE ] , H1[ SIZE ] , H2[ SIZE ] ;
int main()
{
	freopen( "bird.in","w",stdout );
	
	srand(time(0) ) ;
	int n = 110 ;
	int m = 1000 ;
	int K = 0 ;
	
	cout << n << " " << m << " " ;
	
	memset( T , 0 , sizeof( T ) );
	for ( int i = 1 ; i < n ; i++ )
	{
		int o = rand() % 20 ;
		if ( o ) continue ;
		T[i] = 1 ;
		K ++ ;
		int x = rand() % (m + 1) ;
		int y = rand() % (m + 1) ;
		H1[i] = min( x , y ) ;
		H2[i] = max( x , y ) ;
	}
	
	cout << K << endl ;
	for ( int i = 0 ; i < n ; i++ ) {
		int X = rand() % 20 + 1 ;
		int Y = rand() % 100 + 1 ;
		printf( "%d %d\n" , X , Y );
	}
	for ( int i = 1 ; i < n ; i++ )
	{
		if ( !T[i] ) continue ;
		printf( "%d %d %d\n" , i , H1[i] , H2[i] );
	}
	
	
	
	
	
	return 0 ;
}
