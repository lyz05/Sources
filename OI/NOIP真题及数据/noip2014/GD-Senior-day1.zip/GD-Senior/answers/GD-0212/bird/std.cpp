#include<cstdio>
#include<ctime>
#include<cstdlib>
#include<iostream>
#include<cstring>
#include<algorithm>

#define inf 1000000000
#define SIZE 1100
#define SIZEM 1100
using namespace std;

int n , m , K , X[ SIZE ] , Y[ SIZE ] , f[ SIZE ][ SIZEM ] ;
struct Tube{
	int u , h1 , h2 ;
}T[ SIZE ] ;

bool cmp( Tube t1 , Tube t2 ) 
{
	return t1.u < t2.u ;
}
int main()
{
	freopen( "bird.in","r",stdin );
	freopen( "std.out","w",stdout );
	
	scanf( "%d%d%d" , &n , &m , &K );
	for ( int i = 0 ; i < n ; i++ ) scanf( "%d%d" , &X[i] , &Y[i] );
	for ( int i = 1 ; i <= K ; i++ )
		scanf( "%d%d%d" , &T[i].u , &T[i].h1 , &T[i].h2 );
	sort( T+1 , T+K+1 , cmp ) ;
	
	for ( int i = 1 ; i <= n ; i++ ) 
		for ( int j = 0 ; j <= m+1 ; j++ ) f[i][j] = inf ;
	for ( int j = 1 ; j <= m ; j++ ) f[0][j] = 0 ;
	f[0][0] = inf ;
	int t = 1 ;
	for ( int i = 0 ; i < n ; i++ ) 
	{
		while ( T[t].u < i && t <= K ) t ++ ;
		
		int tmp = inf ;
		for ( int j = 1 ; j <= m ; j++ ) {
			if ( t <= K && T[t].u == i && ( j <= T[t].h1 || j >= T[t].h2 ) ) continue ;
			if ( j - Y[i] > 0 ) f[i+1][ j - Y[i] ] = min( f[i+1][ j-Y[i] ] , f[i][j] ) ;
			int c = 1 ;
			for ( int k = j + X[i] ; k <= m ; k+=X[i] , c++ )
				f[i+1][ k ] = min( f[i+1][ k ] , f[i][j] + c ) ;
			f[i+1][m] = min( f[i+1][m] , f[i][j] + c ) ;
		
			tmp = min( tmp , f[i][j] ) ;
		}
		if ( tmp == inf ) {
			printf( "0\n" );
			printf( "%d\n" , t-1 );
			return 0 ;
		}
		
	}
	
	int tmp = inf ;
	for ( int j = 1 ; j <= m ; j++ ) tmp = min( tmp , f[n][j] ) ;
	printf( "1\n" ) ;
	printf( "%d\n" , tmp );
	return 0;	
}
