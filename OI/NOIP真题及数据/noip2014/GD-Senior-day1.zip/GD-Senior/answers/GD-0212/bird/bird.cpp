#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>

#define SIZE 11000
#define SIZEM 1100
#define inf 1000000000
using namespace std;

int n , m , K , X[ SIZE ] , Y[ SIZE ] , H1[ SIZE ] , H2[ SIZE ] , f[ 2 ][ SIZEM ] , Tube[ SIZE ] ;

int main()
{
	freopen( "bird.in","r",stdin );
	freopen( "bird.out","w",stdout );
	
	scanf( "%d%d%d" , &n , &m , &K );
	for ( int i = 0 ; i < n ; i++ ) scanf( "%d%d" , &X[i] , &Y[i] );
	for ( int i = 0 ; i <= n ; i++ ) H1[i] = 0 , H2[i] = m + 1 ;
	
	memset( Tube , 0 , sizeof( Tube ) );
	for ( int i = 1 ; i <= K ; i++ ) 
	{
		int u , h1 , h2 ;
		scanf( "%d%d%d"  ,&u , &h1 , &h2 );
		H1[u] = h1 ;
		H2[u] = h2 ;
		
		Tube[ u ] ++ ;
	}
	for ( int i = 1 ; i <= n ; i++ ) Tube[i] += Tube[i-1] ;
	
	for ( int i = 1 ; i <= m ; i++ ) f[0][i] = 0 ;
	f[0][0] = inf ;
	
	int t = 1 , OK , tmp ;
	for ( int i = 1 ; i <= n ; i++ )
	{
		for ( int j = 0 ; j <= m ; j++ ) {
			f[t][j] = inf ;
			
			if ( j - X[i-1] >= 1 ) f[t][j] = min( f[t^1][ j-X[i-1] ] + 1 , f[t][j] ) ;
			if ( j - X[i-1] >= 1 ) f[t][j] = min( f[t][ j-X[i-1] ] + 1 , f[t][j] ) ;
			
			if ( j == m ) 
				for ( int k = max( j - X[i-1] , 1 ) ; k <= m ; k++ ) {
					f[t][j] = min( f[t][j] , f[t^1][k] + 1 ) ;
					f[t][j] = min( f[t][j] , f[t][k] + 1 ) ;
				}
		}
		for ( int j = 1 ; j <= m ; j++ ) {
			if ( j + Y[ i-1 ] <= m ) f[t][j] = min( f[t^1][ j+Y[i-1] ] , f[t][j] ) ;
		}
		for ( int j = 0 ; j <= H1[i] ; j++ ) f[t][j] = inf ;
		for ( int j = H2[i] ; j <= m ; j++ ) f[t][j] = inf ;
		
		tmp = inf ;
		for ( int j = 1 ; j <= m ; j++ ) tmp = min( tmp , f[t][j] ) ;
		
		if ( tmp == inf ) {
			printf( "0\n" );
			printf( "%d\n" , Tube[i-1] );
			return 0;
		}
		
		t = t ^ 1 ;
	}
	
	printf( "1\n" ) ;
	printf( "%d\n" , tmp ) ;
	
	return 0;
}
