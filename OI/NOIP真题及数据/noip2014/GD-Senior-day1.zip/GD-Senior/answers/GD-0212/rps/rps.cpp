#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>

#define SIZE 210
using namespace std;

const int r[5][5] = {
	-1 , 0  , 1  , 1  , 0 ,
	1  , -1 , 0  , 1  , 0 ,
	0  , 1  , -1 , 0  , 1 ,
	0  , 0  , 1  , -1 , 1 , 
	1  , 1  , 0  , 0  , -1 
};

int N , Na , Nb , a[ SIZE ] , b[ SIZE ];
int main()
{
	freopen( "rps.in","r",stdin );
	freopen( "rps.out","w",stdout );
	
	scanf( "%d%d%d" , &N , &Na , &Nb );
	for ( int i = 0 ; i < Na ; i++ ) scanf( "%d" , &a[i] );
	for ( int i = 0 ; i < Nb ; i++ ) scanf( "%d" , &b[i] );
	
	int A = 0 , B = 0 ;
	for ( int i = 0 ; i < N ; i++ )
	{
			int ta = a[ i % Na ] ;
			int tb = b[ i % Nb ] ;
			if ( r[ta][tb] == 1 ) A ++ ;
			if ( r[tb][ta] == 1 ) B ++ ;
	}
	printf( "%d %d\n" , A , B );
	
	return 0;
}
