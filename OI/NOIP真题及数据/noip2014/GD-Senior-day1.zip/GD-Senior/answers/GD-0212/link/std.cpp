#include<cstdio>
#include<cstdlib>
#include<iostream>
#include<cstring>

#define MOD 10007
#define SIZE 1100
using namespace std;

int n , v[ SIZE ][ SIZE ] , w[ SIZE ] , Sum , Max ;
int main()
{
	freopen( "link.in","r",stdin );
	freopen( "std.out","w",stdout );
	
	scanf( "%d" , &n );
	memset( v , 63 , sizeof( v ) );
	
	for ( int i = 1 ; i < n ; i++ ) {
		int x , y ;
		scanf( "%d%d"  ,&x , &y );
		v[x][y] = 1 ;
		v[y][x] = 1 ;
	}
	for ( int i = 1 ; i <= n ; i++ ) v[i][i] = 0 ;
	for ( int i = 1 ; i <= n ; i++ ) scanf( "%d" , &w[i] );
	
	for ( int k = 1 ; k <= n ; k++ )
		for ( int i = 1 ; i <= n ; i++ )
			for ( int j = 1 ; j <= n ; j++ ) 
				v[i][j] = min( v[i][j] , v[i][k] + v[k][j] ) ;
	
	Sum = Max = 0 ;
	for ( int i = 1 ; i <= n ; i++ )
		for ( int j = 1 ; j <= n ; j++ ) if ( v[i][j] == 2 ) {
			Sum = ( Sum + w[i] * w[j] ) % MOD ;
			Max = max( Max , w[i] * w[j] ) ;
		}
	
	printf( "%d %d\n" , Max , Sum ) ;
	return 0;
}

