#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<vector>

#define pb push_back
#define MOD 10007
#define SIZE 210000
#define Add( A,B ) A = ( A + (B) ) % MOD
using namespace std;

int n , h[ SIZE ] , Max , Sum , fa[ SIZE ] , w[ SIZE ];
vector<int> e[ SIZE ] , q ;

void bfs( int root )
{
	q.clear();
	
	memset( h , 0 , sizeof( h ) );
	h[root] = 1 ;
	fa[ root ] = 0 ;
	q.pb( root ) ;
	
	for ( int i = 0 ; i < q.size() ; i++ )
	{
		int u = q[i] ;
		for ( int k = 0 ; k < e[u].size() ; k++ ) {
			int v = e[u][k] ;
			if ( h[v] ) continue ;
			
			h[v] = h[u] + 1 ;
			fa[ v ] = u ;
			q.pb( v ) ;
		}
	}
	for ( int i = 1 ; i <= n ; i++ )
	{
		int u = i , tmp = 0 ;
		for ( int k = 0 ; k < e[u].size() ; k++ )
		{
			int v = e[u][k] ;
			if ( fa[v] != u ) continue ; 
			
			Add( Sum , w[v] * tmp % MOD ) ;
			Add( tmp , w[v] ) ;
		}
		if ( h[u] >= 3 ) Add( Sum , w[u] * w[ fa[fa[u]] ] % MOD ) ;
	}
	
	for ( int i = 1 ; i <= n ; i++ )
	{
		int u = i , M1 = 0 , M2 = 0 ;
		for ( int k = 0 ; k < e[u].size() ; k++ )
		{
			int v = e[u][k] ;
			if ( fa[v] != u ) continue ;
			
			if ( w[v] >= M1 ) {
				M2 = M1 ;
				M1 = w[v] ;
			}	else 
			if ( w[v] > M2 ) M2 = w[v] ;
		}
		Max = max( Max , M1 * M2 ) ;
		if ( h[u] >= 3 ) Max = max( Max , w[u] * w[ fa[fa[u]] ] ) ;
	}
	
	Sum = Sum * 2 % MOD ;
}
int main()
{
	freopen( "link.in","r",stdin );
	freopen( "link.out","w",stdout );
	
	scanf( "%d" , &n );
	
	for ( int i = 1 ; i <= n ; i++ ) e[i].clear();
	for ( int i = 1 ; i < n ; i++ )
	{
		int u , v ; 
		scanf( "%d%d" , &u , &v );
		e[u].pb( v ) ;
		e[v].pb( u ) ;
	}
	for ( int i = 1 ; i <= n ; i++ ) scanf( "%d" , &w[i] );
	
	Max = 0 ;
	Sum = 0 ;
	bfs( 1 ) ;
	
	printf( "%d %d\n" , Max , Sum );
	return 0;
}

