#include<cstdio>
#include<ctime>
#include<cstdlib>
#include<iostream>

#define SIZE 2100
using namespace std;

int n , fa[ SIZE ]; 

int Get( int u )
{
	if ( fa[u] == u ) return u ;
		else return ( fa[u] = Get( fa[u] ) ) ;
}
int main()
{
	freopen( "link.in","w",stdout );
	
	srand( time(0) ) ;
	int n = 4 ;
	printf( "%d\n" , n );
	
	for ( int i = 1 ; i <= n ; i++ ) fa[i] = i ;
	for ( int i = 1 ; i < n ; i++ )
	{
		int u = rand() % n + 1 ;
		int v = rand() % n + 1 ;
		int fau = Get( u ) ;
		int fav = Get( v ) ;
		while ( fau ==fav )
		{
			u = rand()%n+1;
			v = rand()%n+1;
			fau = Get(u) ;
			fav = Get(v) ;
		}
		cout<<u<<" "<<v<<endl;
		fa[fau] = fav ;
	}
	
	for ( int i = 1 ; i <= n ; i++ ) 
		printf( "%d " , rand() % 10 + 1 );
	return 0;
}
