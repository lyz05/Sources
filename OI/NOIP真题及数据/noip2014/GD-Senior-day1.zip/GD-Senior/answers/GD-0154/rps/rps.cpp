#include<cstdio>
#include<cstring>
#define fr(i,m,n) for(int i=m; i<=n; i++)
#define dfr(i,m,n) for(int i=m; i>=n; i--)
#define inx(x) scanf("%d",&x)

const int N=205;
const int rps[5][5]={{0,-1,1,1,-1},{1,0,-1,1,-1},{-1,1,0,-1,1},{-1,-1,1,0,1},{1,1,-1,-1,0}};
int n,na,nb;
int ta[N],tb[N];


int main() {
    freopen("rps.in","r",stdin);
    freopen("rps.out","w",stdout);
    scanf("%d%d%d",&n,&na,&nb);
    fr(i,0,na-1) inx(ta[i]);
    fr(i,0,nb-1) inx(tb[i]);
    int i=0,j=0;
    
    int ans[4];
    memset(ans,0,sizeof(ans));
    
    fr(k,1,n) {
        int t1=ta[i], t2=tb[j];
        int tmp=rps[t2][t1];
        if (tmp>0) ans[1]++;
        if (tmp<0) ans[2]++;
        i=(i+1)%na;
        j=(j+1)%nb;
    }
    printf("%d %d",ans[2],ans[1]);
    return 0;
    
}
