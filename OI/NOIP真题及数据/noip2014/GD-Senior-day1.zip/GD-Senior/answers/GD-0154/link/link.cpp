#include<cstdio>
#include<cstring>
#define fr(i,m,n) for(int i=m; i<=n; i++)
#define dfr(i,m,n) for(int i=m; i>=n; i--)
#define inx(x) scanf("%d",&x)
#include<vector>
#include<algorithm>

using namespace std;

typedef long long ll;
const int N=200010;

vector<int> G[N];

int n;
int w[N];
ll sum=0LL;
int ans=0;

void dfs(int u, int fa) {
    ll tmp=0, Sum=0; // tmpΪ�ӽڵ��໥��֮�� 
    int maxw=0, maxw2=0;
    if (u!=1 && G[u].size()==1) return;
    
    fr(i,0,(int)G[u].size()-1) {
        int v=G[u][i];
        if (v==fa) continue;
        Sum+=w[v];
        tmp-=w[v]*w[v];
        if (w[v]>maxw) maxw2=maxw, maxw=w[v];
        else if (w[v]>maxw2) maxw2=w[v];
        dfs(v,u);
    }
    ans=max(ans,max(maxw2*maxw,maxw*w[fa]));
    tmp+=Sum*Sum+w[fa]*Sum*2LL;
    sum+=tmp;
}

int main() {
    freopen("link.in","r",stdin);
    freopen("link.out","w",stdout);
    inx(n);
    fr(i,1,n) G[i].clear();
    
    fr(i,1,n-1) {
        int u,v; inx(u),inx(v);
        G[u].push_back(v);
        G[v].push_back(u);
    }
    w[0]=0;
    fr(i,1,n) inx(w[i]);
    
    dfs(1,0);
    
    printf("%d %d",ans,(int)(sum%10007));
    return 0;
    
}
