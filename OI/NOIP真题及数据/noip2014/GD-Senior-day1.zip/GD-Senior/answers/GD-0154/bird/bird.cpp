#include<cstdio>
#include<cstring>
#define fr(i,m,n) for(int i=m; i<=n; i++)
#define dfr(i,m,n) for(int i=m; i>=n; i--)
#define inx(x) scanf("%d",&x)
#include<vector>
#include<algorithm>
#define local
#define pos(i) v[i].pos
#define st(i) v[i].st
#define ed(i) v[i].ed
using namespace std;

typedef long long ll;

const int N=10010;
const int M=1005;
const int INF=0x6f6f6f6f;
//int pos[N],st[N],ed[N];

int d[M],t[M];

int x[N],y[N];
int n,m,k;

struct pipe{
    int pos,st,ed;
    bool operator < (const pipe& rhs) const {
        return pos<rhs.pos;
    }
}v[N];


int main() {
    freopen("bird.in","r",stdin);
    freopen("bird.out","w",stdout);
    
    scanf("%d%d%d",&n,&m,&k);
    fr(i,1,n) inx(x[i]),inx(y[i]);
    fr(i,1,k) {
        int u,vv,w;
        scanf("%d%d%d",&u,&vv,&w);
        v[i]=(pipe){u,vv,w};
    }
    sort(v+1,v+1+k);
    
    memset(d,0,sizeof(d));
    int cnt=1, ans=0;
    bool flag=1;
    int mind,lo,hi;
    
    fr(i,1,n) {
        memcpy(t,d,sizeof(d));
        memset(d,0x7f,sizeof(d));
        mind=0x7f7f7f7f, lo=1, hi=m;
        
        if (cnt<=k && pos(cnt)==i) {lo=st(cnt)+1, hi=ed(cnt)-1; cnt++;}
        fr(h,lo,hi) {
            int tmp=1;
            if (h+y[i]<=m) d[h]=min(d[h],t[h+y[i]]);
            if (h==m) {
                d[h]=min(d[h],t[h]+1);
                dfr(j,m-1,1) d[h]=min(d[h],t[j]+(h-j-1)/x[i]+1);
            }
            else {while (h-x[i]*tmp>0) d[h]=min(d[h],t[h-x[i]*tmp]+tmp), tmp++;}
            mind=min(mind,d[h]);
        }
        if (mind>INF) {
            flag=false;
            if (i==pos(cnt-1)) ans=cnt-2; else ans=cnt-1;
            break;
        }
    }
    if (flag) printf("1\n%d", mind);
    else printf("0\n%d",ans);
    return 0;
}




