#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cmath>
#include<cstring>

using namespace std;
typedef long long ll;

int que[200011][2];
int w[200011],pre[200011],suf[200011],id[200011],cq[200011];
int g[200011],next[400011],y[400011],ws[200011],mx[200011];
int fax[200011],fa[200011];
int mo=10007;
int n,x,z,i,tt,xzq,ple;

void star(int i,int j)
{
	tt++;
	next[tt]=g[i];
	g[i]=tt;
	y[tt]=j;
}


void Bfs()
{
	int l,r,x,i,j,k;
	l=r=1;
	que[l][0]=1;
	que[l][1]=0;
	while(l<=r){
		x=que[l][0];
		j=g[x];
		while(j!=0){
			k=y[j];
			if(k!=que[l][1]){
				r++;
				que[r][0]=k;
				que[r][1]=x;
			}
			j=next[j];
		}
		l++;
	}
	for(i=r;i>=2;i--){
		ws[que[i][1]]+=w[que[i][0]];
		if(w[que[i][0]]>mx[que[i][1]])mx[que[i][1]]=w[que[i][0]];
	}
}

void Dp()
{
	int l,r,x,j,k,i,fag,num,mxp,sum;
	l=r=1;
	que[l][0]=1;
	que[l][1]=0;
	while(l<=r){
		x=que[l][0];
		j=g[x];
		sum=0;
		fag=0;
		num=0;
		mxp=0;
		while(j!=0){
			k=y[j];
			num++;
			if(k!=que[l][1]){
				sum+=ws[k];
				if(mx[k]>mxp)mxp=mx[k];
				fag+=w[k];
				id[num]=k;
				cq[num]=w[k];
			}
			else{
				sum+=fa[x];
				fag+=w[k];
				if(fax[x]>mxp)mxp=fax[x];
				id[num]=k;
				cq[num]=w[k];
			}
			j=next[j];
		}
		pre[0]=0;
		suf[num+1]=0;
		for(i=1;i<=num;i++){
			if(cq[i]>pre[i-1])pre[i]=cq[i];
			else pre[i]=pre[i-1];
		}
		for(i=num;i>=1;i--){
			if(cq[i]>suf[i+1])suf[i]=cq[i];
			else suf[i]=suf[i+1];
		}
		xzq=max(xzq,mxp*w[x]);
		ple=((ll)ple+(ll)w[x]*sum)%mo;
		for(i=1;i<=num;i++)if(id[i]!=que[l][1]){
			r++;
			que[r][0]=id[i];
			que[r][1]=x;
			fa[id[i]]=fag-w[id[i]];
			fax[id[i]]=max(pre[i-1],suf[i+1]);
		}
		l++;
	}
}

int main()
{
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	scanf("%d",&n);
	for(i=1;i<n;i++){
		scanf("%d%d",&x,&z);
		star(x,z);
		star(z,x);
	}
	for(i=1;i<=n;i++)scanf("%d",&w[i]);
	Bfs();
	Dp();
	printf("%d %d\n",xzq,ple);
}
