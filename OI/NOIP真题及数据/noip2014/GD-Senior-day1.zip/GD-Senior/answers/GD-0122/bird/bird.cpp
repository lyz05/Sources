#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cmath>
#include<cstring>

using namespace std;

struct data{
	int x,lm,rm;
}ty[10011];

bool cmp(data a,data b)
{
	return a.x<b.x;
}

bool pp;
int f[10011][1011];
int rs[10011],st[10011],up[10011],dn[10011];
int xzq,i,n,m,j,k,nk,t,x,lm,rm;

int main()
{
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	scanf("%d%d%d",&n,&m,&t);
	for(i=0;i<n;i++)scanf("%d%d",&rs[i],&st[i]);
	for(i=1;i<=n;i++){
		up[i]=m+1;
		dn[i]=0;
	}
	for(i=1;i<=t;i++){
		scanf("%d%d%d",&x,&lm,&rm);
		dn[x]=lm;
		up[x]=rm;
		ty[i].x=x;
		ty[i].lm=lm;
		ty[i].rm=rm;
	}
	sort(ty+1,ty+1+t,cmp);
	memset(f,255,sizeof(f));
	for(i=1;i<=m;i++)f[0][i]=0;
	for(i=0;i<n;i++){
		for(j=m;j>=1;j--)if(f[i][j]!=-1){
			for(k=0;k<=2147483647;k++){
				if(k==0)nk=j-st[i];
				else nk=j+rs[i]*k;
				if(nk>m)nk=m;
				if(nk>dn[i+1]&&nk<up[i+1]){
					if(f[i+1][nk]==-1||f[i][j]+k<f[i+1][nk])f[i+1][nk]=f[i][j]+k;
				}
				if(j+rs[i]*k>m)break;
				if(k!=0&&j+rs[i]*k>=up[i+1])break;
				if(k!=0&&f[i+1][nk]!=-1&&f[i+1][nk]<f[i][j]+k)break;
			}
		}
	}
	xzq=2147483647;
	for(i=1;i<=m;i++)if(f[n][i]<xzq&&f[n][i]!=-1)xzq=f[n][i];
	if(xzq!=2147483647){
		printf("1\n");
		printf("%d\n",xzq);
	}
	else{
		printf("0\n");
		xzq=0;
		pp=false;
		for(i=t;i>=1;i--){
			for(j=ty[i].lm+1;j<ty[i].rm;j++)if(f[ty[i].x][j]!=-1){
				pp=true;
				xzq=i;
				break;
			}
			if(pp)break;
		}
		printf("%d\n",xzq);
	}
}
