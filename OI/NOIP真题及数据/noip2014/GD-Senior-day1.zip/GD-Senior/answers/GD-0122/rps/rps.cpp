#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cmath>
#include<cstring>

using namespace std;

int n,i,sa,sb,za,zb,zq,ap,ple;
int a[211],b[211];
int g[11][11];

int gcd(int a,int b){
	if(a%b==0)return b;
	else return gcd(b,a%b);
}

int main()
{
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	scanf("%d%d%d",&n,&sa,&sb);
	for(i=1;i<=sa;i++)scanf("%d",&a[i%sa]);
	for(i=1;i<=sb;i++)scanf("%d",&b[i%sb]);
	g[0][0]=0; g[0][1]=0; g[0][2]=1; g[0][3]=1; g[0][4]=0;
	g[1][0]=1; g[1][1]=0; g[1][2]=0; g[1][3]=1; g[1][4]=0;
	g[2][0]=0; g[2][1]=1; g[2][2]=0; g[2][3]=0; g[2][4]=1;
	g[3][0]=0; g[3][1]=0; g[3][2]=1; g[3][3]=0; g[3][4]=1;
	g[4][0]=1; g[4][1]=1; g[4][2]=0; g[4][3]=0; g[4][4]=0;
	zq=sa*sb/gcd(sa,sb);
	for(i=1;i<=zq;i++){
		za+=g[a[i%sa]][b[i%sb]];
		zb+=g[b[i%sb]][a[i%sa]];
	}
	ap=n/zq*za;
	ple=n/zq*zb;
	for(i=1;i<=n%zq;i++){
		ap+=g[a[i%sa]][b[i%sb]];
		ple+=g[b[i%sb]][a[i%sa]];
	}
	printf("%d %d\n",ap,ple);
}
