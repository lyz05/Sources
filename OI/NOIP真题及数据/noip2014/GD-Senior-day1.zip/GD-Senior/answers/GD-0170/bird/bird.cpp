#include<cstdio>
#include<cstring>
#define MAXN 10005
#define MAXM 1005

int n,m,k,p,flag,pos,ans=100000;

int now[MAXM],past[MAXM],fup[MAXM],f[MAXN],b[MAXN],up[MAXN],down[MAXN],c[MAXN];

int main() {
	freopen("bird.in","r",stdin);
	freopen("bird.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	memset(f,0,sizeof(f));
	for (int i=0;i<=n;i++) b[i]=m+1;
	for (int i=0;i<n;i++) scanf("%d%d",&up[i],&down[i]);
	for (int i=0;i<k;i++) {
		scanf("%d",&p);
		scanf("%d%d",&f[p],&b[p]);
		c[p]=1;
	}
	memset(past,0,sizeof(past));
	for (int i=1;i<=n;i++) {
		flag=0;
		memset(fup,0,sizeof(fup));
		memset(now,0x7f,sizeof(now));
		for (int h=1;h<=m;h++) {
			if (h+down[i-1]<=m && now[h]>past[h+down[i-1]] && h+down[i-1]<b[i-1] && h+down[i-1]>f[i-1]) {
				now[h]=past[h+down[i-1]];
				if (h<b[i] && h>f[i]) flag=1;
			}
			if (h-up[i-1]>0 && now[h]>past[h-up[i-1]]+1 && h-up[i-1]<b[i-1] && h-up[i-1]>f[i-1]) {
				now[h]=past[h-up[i-1]]+1;
				fup[h]=1;
				if (h<b[i] && h>f[i]) flag=1;
			}
			if (h-up[i-1]>0 && fup[h-up[i-1]] && now[h]>now[h-up[i-1]]+1) {
				now[h]=now[h-up[i-1]]+1;
				fup[h]=1;
				if (h<b[i] && h>f[i]) flag=1;
			}
			if (h==m) {
				for (int j=0;j<=up[i-1];j++) 
					if (now[h]>past[h-j]+1 && h-j<b[i-1] && h-j>f[i-1]) {
						now[h]=past[h-j]+1;
						if (h<b[i] && h>f[i]) flag=1;
					}
				for (int j=0;j<=up[i-1];j++) 
					if (fup[h-j] && now[h]>now[h-j]+1){
						now[h]=now[h-j]+1;
						fup[h]=1;
						if (h<b[i] && h>f[i]) flag=1;
					}
			}
		}
		if (!flag) {
			ans=pos;
			break;
		}
		pos+=c[i];
		for (int j=1;j<=m;j++) {
			past[j]=now[j];
		}
	}
	if (flag) for (int i=1;i<=m;i++) if (ans>past[i]) ans=past[i];
	printf("%d\n%d\n",flag,ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
