#include<cstdio>

int f[5][5]={{0,0,1,1,0},{1,0,0,1,0},{0,1,0,0,1},{0,0,1,0,1},{1,1,0,0,0}};

int n,na,nb,p,q,suma,sumb,a[205],b[205];

int main() {
	freopen("rps.in","r",stdin);
	freopen("rps.out","w",stdout);
	scanf("%d%d%d",&n,&na,&nb);
	for (int i=0;i<na;i++) {
		scanf("%d",&a[i]);
	}
	for (int i=0;i<nb;i++) {
		scanf("%d",&b[i]);
	}
	p=q=0;
	for (int i=0;i<n;i++) {
		suma+=f[a[p]][b[q]];
		sumb+=f[b[q]][a[p]];
		p=(p+1)%na;
		q=(q+1)%nb;
	}
	printf("%d %d\n",suma,sumb);
	fclose(stdin);fclose(stdout);
	return 0;
}
