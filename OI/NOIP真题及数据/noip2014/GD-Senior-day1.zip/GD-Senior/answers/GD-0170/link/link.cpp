#include<cstdio>
#include<vector>
#define MOD 10007
#define MAXN 200005
using namespace std;

vector<int> edges[MAXN];

int n,sum,u,v,p,r,h,now,ans;

int q[MAXN],w[MAXN],fa[MAXN],k[MAXN],f[MAXN],MAX[MAXN];

int main() {
	freopen("link.in","r",stdin);
	freopen("link.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<n;i++) {
		scanf("%d%d",&u,&v);
		edges[u].push_back(v);
		edges[v].push_back(u);
	}
	for (int i=1;i<=n;i++) {
		scanf("%d",&w[i]);
	}
	r=h=0;
	q[0]=1;
	f[1]=1;
	for (int total=0;total<n;total++) {
		p=q[r++];
		sum+=(w[p]*k[fa[p]]) % MOD;
		if (ans<w[p]*MAX[fa[p]]) ans=w[p]*MAX[fa[p]];
		k[fa[p]]=(k[fa[p]]+w[p]) % MOD;
		if (MAX[fa[p]]<w[p]) MAX[fa[p]]=w[p];
		for (int i=0;i<edges[p].size();i++) {
			now=edges[p][i];
			if (!f[now]) {
				f[now]=1;
				q[++h]=now;
				fa[now]=p;
				k[now]=w[p];
				MAX[now]=w[p];
			}
		}
	}
	sum=(sum*2) % MOD;
	printf("%d %d\n",ans,sum);
	fclose(stdin);fclose(stdout);
	return 0;
}
