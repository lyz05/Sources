#include<bits/stdc++.h>

using namespace std;

typedef pair<int, int> pII;
const int N = 1000000 + 10;

pII p[N];
priority_queue<int, vector<int>, greater<int> > que;

int main(){ 
	freopen("1.in", "r", stdin);
	freopen("1.out", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(0);
    int n;
    while(cin >> n){
        while(que.size()) que.pop();
        for(int i=1; i<=n; i++) cin >> p[i].second >> p[i].first;
        sort(p+1, p+1+n);
        for(int i=1; i<=n; i++){
            que.push(p[i].second);
            if(p[i].first<que.size()) que.pop();
        }
        long long res = 0;
        while(que.size()){
            res += que.top();
            que.pop();
        }
        cout << res << endl;
    }
    return 0;
}
