#include <iostream>

using namespace std;

int main()
{
	//freopen("in.txt", "r", stdin);
	//freopen("out.txt", "w", stdout);
    long long t, n;
    long long ans;
    while (cin >> n)
    {
        ans = 0;
       
        while (n)
        {
            n = n >> 1;
            ans += n;
        }
        cout << ans << endl;
    }
    return 0;
}