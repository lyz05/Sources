#include<bits/stdc++.h>

using namespace std;

const int N = 100020, INF = 0x3f3f3f3f;

int a[N], n;

bool check(int m){
    for(int i=1; i<=n; i++){
        m = m*2-a[i];
        if(m>INF) return true;
        if(m<0) return false;
    }
    return true;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    freopen("1.in", "r", stdin);
	freopen("1.out", "w", stdout);
	while(cin >> n){
		for(int i=1; i<=n; i++) cin >> a[i];
	    int l = 0, r = N;
	    while(l<r){
	        int mid = l+r>>1;
	        if(check(mid)) r = mid;
	        else l = mid+1;
	    }
	    cout << l << endl;
	}
    return 0;
}
