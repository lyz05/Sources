#include<bits/stdc++.h>

using namespace std;

const int N = 100000 +10;
const int INF = 0x3f3f3f3f; 

int a[N], l[N], r[N], q[N];

int main(){
	//freopen("1.in", "r", stdin);
	//freopen("1.out", "w", stdout);
	ios::sync_with_stdio(false);
	int n;
	while(cin >> n){
		for(int i=1; i<=n; i++) cin >> a[i];
		a[0] = a[n+1] = -INF;
		int tt = 0;
		q[0] = 0;
		for(int i=1; i<=n; i++){
			while(tt && a[i]<=a[q[tt]]) tt--;
			l[i] = q[tt];
			q[++tt] = i;
		}
		q[0] = n+1;
		tt=0;
		for(int i=n; i>0; i--){
			while(tt && a[i]<=a[q[tt]]) tt--;
			r[i] = q[tt];
			q[++tt] = i;
		}
		int res = 0;
		for(int i=1; i<=n; i++) res = max(res, a[i]*(r[i]-l[i]-1));
		cout << res << endl;
	}
	return 0;
}
