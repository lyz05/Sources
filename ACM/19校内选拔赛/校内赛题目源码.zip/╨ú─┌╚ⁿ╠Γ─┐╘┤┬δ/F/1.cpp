#include<bits/stdc++.h>

using namespace std;

typedef long long LL;

priority_queue<LL, vector<LL>, greater<LL> > que;

int main(){
	freopen("1.in", "r", stdin);
	freopen("1.out", "w", stdout);
	ios::sync_with_stdio(false);
	int n;
	while(cin >> n){
		while(que.size()) que.pop();
		long long a, b;
		for(int i=0; i<n; i++) {
			cin >> a;
			que.push(a);
		}
		LL ans = 0;
		while(que.size()>1){
			a = que.top(); que.pop();
			b = que.top(); que.pop();
			ans += a+b;
			que.push(a+b);
		}
		cout << ans << endl;
	}
	return 0;
}

