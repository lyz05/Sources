#include<bits/stdc++.h>

using namespace std;

const int N = 1000010, M = 2010;

int a[N], s[N];

int main(){
	ios::sync_with_stdio(false);
    cin.tie(0);
    freopen("1.in", "r", stdin);
	freopen("1.out", "w", stdout);
    int n, m;
    while(cin >> n >> m){
    	bool f = true;
	    int res = INT_MAX, cnt=0;
	    for(int i=0; i<n; i++) cin >> a[i];
	    int j=0;
	    memset(s, 0, sizeof(s));
	    while(!a[j]) j++;
	    for(int i=0; i<n; i++){
	        if(!a[i]) continue;
	        if(!s[a[i]]) cnt++;
	        s[a[i]]++;
	        if(cnt==m){
	            f = false;
	            while(!a[j] ||  s[a[j]]-1>0) {
	                s[a[j]]--;
	                j++;
	            }
	            res = min(res, i-j+1);
	            s[a[j]]--;
	            j++;
	            cnt--;
	        }
	    }
	    if(f) cout << "-1" << endl;
	    else cout << res << endl;
    }
    return 0;
}

