#include<bits/stdc++.h>

using namespace std;

const int N = 100010;

int a[N], sum[N];

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    freopen("1.in", "r", stdin);
	freopen("1.out", "w", stdout);
    int n, p;
    while(cin >> n){
        cin >> p;
        for(int i=1; i<=n; i++) cin >> a[i];
        sort(a+1, a+1+n);
        for(int i=1; i<=n; i++) sum[i] = sum[i-1] + a[i];
        int res = INT_MAX;
        for(int i=p; i<=n; i++){
            res = min(res, p*a[i]-sum[i]+sum[i-p]);
        }
        cout << res << endl;
    }
    return 0;
}
