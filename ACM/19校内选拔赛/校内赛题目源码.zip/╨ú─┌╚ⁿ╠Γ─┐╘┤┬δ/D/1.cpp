#include<bits/stdc++.h>

using namespace std;

const int N = 100000 + 10;

int a[N], ans, help[N];

void merge(int l, int mid, int r){
	for(int k=l, i=l, j=mid+1; k<=r; k++){
		if(j>r || (i<=mid && a[i]<=a[j])) help[k] = a[i++];
		else help[k]=a[j++], ans += mid-i+1;
	}
	for(int i=l; i<=r; i++) a[i] = help[i];
}

void gb(int l, int r){
	if(l<r){
		int mid = l+r>>1;
		gb(l, mid);
		gb(mid+1, r);
		merge(l, mid, r);
	}
}

int main(){
	freopen("1.in", "r", stdin);
	freopen("1.out", "w", stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	int n;
	while(cin >> n){
		for(int i=0; i<n; i++) cin >> a[i];
		ans = 0;
		gb(0, n-1);
		cout << ans << endl;
	}
	return 0;
}
